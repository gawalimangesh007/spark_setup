package com.sterling.bookingapi.dto.request;


/**
 * The Class RoomsDetails.
 */
/**
 * @author tcs
 *
 */
public class HsdResortRoomDTO {

	/** The room type. */
	private String roomType;
	
	/** The occupancy detail. */
	private String occupancyDetail;
	

	/**
	 * Gets the room type.
	 *
	 * @return the roomType
	 */
	public String getRoomType() {
		return roomType;
	}

	/**
	 * Sets the room type.
	 *
	 * @param roomType the roomType to set
	 */
	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}

	/**
	 * Gets the occupancy detail.
	 *
	 * @return the occupancyDetail
	 */
	public String getOccupancyDetail() {
		return occupancyDetail;
	}

	/**
	 * Sets the occupancy detail.
	 *
	 * @param occupancyDetail the occupancyDetail to set
	 */
	public void setOccupancyDetail(String occupancyDetail) {
		this.occupancyDetail = occupancyDetail;
	}
		
}
