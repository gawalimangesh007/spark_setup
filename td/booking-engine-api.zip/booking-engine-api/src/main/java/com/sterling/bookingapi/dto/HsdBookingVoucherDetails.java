package com.sterling.bookingapi.dto;

import java.util.List;


/**
 * The Class HsdBookingVoucherDetails.
 */
/**
 * @author tcs
 *
 */
public class HsdBookingVoucherDetails {
	
	/** The booking id. */
	private String bookingId;
	
	/** The booking date. */
	private String bookingDate;
	
	/** The resort name. */
	private String resortName;
	
	/** The resort logo. */
	private String resortLogo;
	
	/** The user id. */
	private String userId;
	
	/** The user type. */
	private String userType;
	
	/** The booking for. */
	private String bookingFor;
	
	/** The check in. */
	private String checkIn;
	
	/** The check out. */
	private String checkOut;
	
	/** The check in. */
	private String checkinTime;
	
	private String checkoutTime;
	
	/** The adult count. */
	private int adultCount;
	
	/** The child count. */
	private int childCount;
	
	/** The room count. */
	private int roomCount;
	
	/** The booking owner name. */
	private String bookingOwnerName;
	
	/** The booking owner email. */
	private String bookingOwnerEmail;
	
	/** The booking owner mobile. */
	private String bookingOwnerMobile;
	
	/** The sub total. */
	private double subTotal;
	
	/** The discount amount. */
	private double discountAmt;
	
	/** The Actual amount. */
	private double netSubTotal;
	
	/** The approx tax. */
	private double approxTax;
	
	/** The total. */
	private double total;
	
	private String packageName;
	
	/** The hsd bookin voucher room details. */
	private List<HsdBookinVoucherRoomDetails>  hsdBookinVoucherRoomDetails;

	/**
	 * Gets the booking id.
	 *
	 * @return the booking id
	 */
	public String getBookingId() {
		return bookingId;
	}

	/**
	 * Sets the booking id.
	 *
	 * @param bookingId the new booking id
	 */
	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}

	/**
	 * Gets the booking date.
	 *
	 * @return the booking date
	 */
	public String getBookingDate() {
		return bookingDate;
	}

	/**
	 * Sets the booking date.
	 *
	 * @param bookingDate the new booking date
	 */
	public void setBookingDate(String bookingDate) {
		this.bookingDate = bookingDate;
	}

	/**
	 * Gets the resort name.
	 *
	 * @return the resort name
	 */
	public String getResortName() {
		return resortName;
	}

	/**
	 * Sets the resort name.
	 *
	 * @param resortName the new resort name
	 */
	public void setResortName(String resortName) {
		this.resortName = resortName;
	}

	/**
	 * Gets the user id.
	 *
	 * @return the user id
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * Sets the user id.
	 *
	 * @param userId the new user id
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * Gets the user type.
	 *
	 * @return the user type
	 */
	public String getUserType() {
		return userType;
	}

	/**
	 * Sets the user type.
	 *
	 * @param userType the new user type
	 */
	public void setUserType(String userType) {
		this.userType = userType;
	}

	/**
	 * Gets the booking for.
	 *
	 * @return the booking for
	 */
	public String getBookingFor() {
		return bookingFor;
	}

	/**
	 * Sets the booking for.
	 *
	 * @param bookingFor the new booking for
	 */
	public void setBookingFor(String bookingFor) {
		this.bookingFor = bookingFor;
	}

	/**
	 * Gets the check in.
	 *
	 * @return the check in
	 */
	public String getCheckIn() {
		return checkIn;
	}

	/**
	 * Sets the check in.
	 *
	 * @param checkIn the new check in
	 */
	public void setCheckIn(String checkIn) {
		this.checkIn = checkIn;
	}

	/**
	 * Gets the check out.
	 *
	 * @return the check out
	 */
	public String getCheckOut() {
		return checkOut;
	}

	/**
	 * Sets the check out.
	 *
	 * @param checkOut the new check out
	 */
	public void setCheckOut(String checkOut) {
		this.checkOut = checkOut;
	}

	/**
	 * Gets the adult count.
	 *
	 * @return the adult count
	 */
	public int getAdultCount() {
		return adultCount;
	}

	/**
	 * Sets the adult count.
	 *
	 * @param adultCount the new adult count
	 */
	public void setAdultCount(int adultCount) {
		this.adultCount = adultCount;
	}

	/**
	 * Gets the child count.
	 *
	 * @return the child count
	 */
	public int getChildCount() {
		return childCount;
	}

	/**
	 * Sets the child count.
	 *
	 * @param childCount the new child count
	 */
	public void setChildCount(int childCount) {
		this.childCount = childCount;
	}

	/**
	 * Gets the room count.
	 *
	 * @return the room count
	 */
	public int getRoomCount() {
		return roomCount;
	}

	/**
	 * Sets the room count.
	 *
	 * @param roomCount the new room count
	 */
	public void setRoomCount(int roomCount) {
		this.roomCount = roomCount;
	}

	/**
	 * Gets the booking owner name.
	 *
	 * @return the booking owner name
	 */
	public String getBookingOwnerName() {
		return bookingOwnerName;
	}

	/**
	 * Sets the booking owner name.
	 *
	 * @param bookingOwnerName the new booking owner name
	 */
	public void setBookingOwnerName(String bookingOwnerName) {
		this.bookingOwnerName = bookingOwnerName;
	}

	/**
	 * Gets the booking owner email.
	 *
	 * @return the booking owner email
	 */
	public String getBookingOwnerEmail() {
		return bookingOwnerEmail;
	}

	/**
	 * Sets the booking owner email.
	 *
	 * @param bookingOwnerEmail the new booking owner email
	 */
	public void setBookingOwnerEmail(String bookingOwnerEmail) {
		this.bookingOwnerEmail = bookingOwnerEmail;
	}

	/**
	 * Gets the booking owner mobile.
	 *
	 * @return the booking owner mobile
	 */
	public String getBookingOwnerMobile() {
		return bookingOwnerMobile;
	}

	/**
	 * Sets the booking owner mobile.
	 *
	 * @param bookingOwnerMobile the new booking owner mobile
	 */
	public void setBookingOwnerMobile(String bookingOwnerMobile) {
		this.bookingOwnerMobile = bookingOwnerMobile;
	}

	/**
	 * Gets the sub total.
	 *
	 * @return the sub total
	 */
	public double getSubTotal() {
		return subTotal;
	}

	/**
	 * Sets the sub total.
	 *
	 * @param subTotal the new sub total
	 */
	public void setSubTotal(double subTotal) {
		this.subTotal = subTotal;
	}

	/**
	 * Gets the approx tax.
	 *
	 * @return the approx tax
	 */
	public double getApproxTax() {
		return approxTax;
	}

	/**
	 * Sets the approx tax.
	 *
	 * @param approxTax the new approx tax
	 */
	public void setApproxTax(double approxTax) {
		this.approxTax = approxTax;
	}

	/**
	 * Gets the total.
	 *
	 * @return the total
	 */
	public double getTotal() {
		return total;
	}

	/**
	 * Sets the total.
	 *
	 * @param total the new total
	 */
	public void setTotal(double total) {
		this.total = total;
	}

	/**
	 * Gets the hsd bookin voucher room details.
	 *
	 * @return the hsd bookin voucher room details
	 */
	public List<HsdBookinVoucherRoomDetails> getHsdBookinVoucherRoomDetails() {
		return hsdBookinVoucherRoomDetails;
	}

	/**
	 * Sets the hsd bookin voucher room details.
	 *
	 * @param hsdBookinVoucherRoomDetails the new hsd bookin voucher room details
	 */
	public void setHsdBookinVoucherRoomDetails(List<HsdBookinVoucherRoomDetails> hsdBookinVoucherRoomDetails) {
		this.hsdBookinVoucherRoomDetails = hsdBookinVoucherRoomDetails;
	}

	/**
	 * Gets the resort logo.
	 *
	 * @return the resort logo
	 */
	public String getResortLogo() {
		return resortLogo;
	}

	/**
	 * Sets the resort logo.
	 *
	 * @param resortLogo the new resort logo
	 */
	public void setResortLogo(String resortLogo) {
		this.resortLogo = resortLogo;
	}

	public String getCheckinTime() {
		return checkinTime;
	}

	public void setCheckinTime(String checkinTime) {
		this.checkinTime = checkinTime;
	}

	public String getCheckoutTime() {
		return checkoutTime;
	}

	public void setCheckoutTime(String checkoutTime) {
		this.checkoutTime = checkoutTime;
	}

	public String getPackageName() {
		return packageName;
	}

	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}

	public double getDiscountAmt() {
		return discountAmt;
	}

	public void setDiscountAmt(double discountAmt) {
		this.discountAmt = discountAmt;
	}

	public double getNetSubTotal() {
		return netSubTotal;
	}

	public void setNetSubTotal(double netSubTotal) {
		this.netSubTotal = netSubTotal;
	}
	
}
