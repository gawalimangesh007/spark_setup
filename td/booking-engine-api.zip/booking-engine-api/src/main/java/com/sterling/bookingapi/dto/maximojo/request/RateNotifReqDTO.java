package com.sterling.bookingapi.dto.maximojo.request;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class RateNotifReqDTO.
 */
/**
 * @author tcs
 *
 */
public class RateNotifReqDTO {

	/** The max guest applicable. */
	@JacksonXmlProperty(localName = "MaxGuestApplicable", isAttribute = true)
	private String maxGuestApplicable;

	/** The min LOS. */
	@JacksonXmlProperty(localName = "MinLOS", isAttribute = true)
    private String minLOS;

	/** The min guest applicable. */
	@JacksonXmlProperty(localName = "MinGuestApplicable", isAttribute = true)
    private String minGuestApplicable;

	/** The inv type code. */
	@JacksonXmlProperty(localName = "InvTypeCode", isAttribute = true)
    private String invTypeCode;

	/** The inv type. */
	@JacksonXmlProperty(localName = "InvType", isAttribute = true)
    private String invType;

	/** The max LOS. */
	@JacksonXmlProperty(localName = "MaxLOS", isAttribute = true)
    private String maxLOS;

	/**
	 * Gets the max guest applicable.
	 *
	 * @return the maxGuestApplicable
	 */
	public String getMaxGuestApplicable() {
		return maxGuestApplicable;
	}

	/**
	 * Sets the max guest applicable.
	 *
	 * @param maxGuestApplicable the maxGuestApplicable to set
	 */
	public void setMaxGuestApplicable(String maxGuestApplicable) {
		this.maxGuestApplicable = maxGuestApplicable;
	}

	/**
	 * Gets the min LOS.
	 *
	 * @return the minLOS
	 */
	public String getMinLOS() {
		return minLOS;
	}

	/**
	 * Sets the min LOS.
	 *
	 * @param minLOS the minLOS to set
	 */
	public void setMinLOS(String minLOS) {
		this.minLOS = minLOS;
	}

	/**
	 * Gets the min guest applicable.
	 *
	 * @return the minGuestApplicable
	 */
	public String getMinGuestApplicable() {
		return minGuestApplicable;
	}

	/**
	 * Sets the min guest applicable.
	 *
	 * @param minGuestApplicable the minGuestApplicable to set
	 */
	public void setMinGuestApplicable(String minGuestApplicable) {
		this.minGuestApplicable = minGuestApplicable;
	}

	/**
	 * Gets the inv type code.
	 *
	 * @return the invTypeCode
	 */
	public String getInvTypeCode() {
		return invTypeCode;
	}

	/**
	 * Sets the inv type code.
	 *
	 * @param invTypeCode the invTypeCode to set
	 */
	public void setInvTypeCode(String invTypeCode) {
		this.invTypeCode = invTypeCode;
	}

	/**
	 * Gets the inv type.
	 *
	 * @return the invType
	 */
	public String getInvType() {
		return invType;
	}

	/**
	 * Sets the inv type.
	 *
	 * @param invType the invType to set
	 */
	public void setInvType(String invType) {
		this.invType = invType;
	}

	/**
	 * Gets the max LOS.
	 *
	 * @return the maxLOS
	 */
	public String getMaxLOS() {
		return maxLOS;
	}

	/**
	 * Sets the max LOS.
	 *
	 * @param maxLOS the maxLOS to set
	 */
	public void setMaxLOS(String maxLOS) {
		this.maxLOS = maxLOS;
	}

	
}
