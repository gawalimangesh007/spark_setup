package com.sterling.bookingapi.dto.request;

import java.util.Date;


/**
 * The Class UserDetailsUpdateRequestDTO.
 */
/**
 * @author tcs
 *
 */
public class UserDetailsUpdateRequestDTO {

	/** The user id. */
	private String userId;
	
	/** The first name. */
	private String firstName;
	
	/** The last name. */
	private String lastName;
	
	/** The email. */
	private String email;
	
	/** The password. */
	private String password;
	
	/** The phone number. */
	private String phoneNumber;
	
	/** The salesforce ref id. */
	private String salesforceRefId;

	/** The birth date. */
	private Date birthDate;
	
	/** The anniv date. */
	private Date annivDate;
	
	/** The recovery email. */
	private String recoveryEmail;
	
	/** The security quest one. */
	private String securityQuestOne;
	
	/** The security quest two. */
	private String securityQuestTwo;
	
	/** The security ans one. */
	private String securityAnsOne;
	
	/** The security ans two. */
	private String securityAnsTwo;
	
	/** The landline. */
	private String landline;
	
	/** The address. */
	private String address;

	/**
	 * Gets the user id.
	 *
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * Sets the user id.
	 *
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * Gets the first name.
	 *
	 * @return the first name
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * Sets the first name.
	 *
	 * @param firstName the new first name
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * Gets the last name.
	 *
	 * @return the last name
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * Sets the last name.
	 *
	 * @param lastName the new last name
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * Gets the email.
	 *
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * Sets the email.
	 *
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * Gets the password.
	 *
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * Sets the password.
	 *
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * Gets the phone number.
	 *
	 * @return the phoneNumber
	 */
	public String getPhoneNumber() {
		return phoneNumber;
	}

	/**
	 * Sets the phone number.
	 *
	 * @param phoneNumber the phoneNumber to set
	 */
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	/**
	 * Gets the salesforce ref id.
	 *
	 * @return the salesforceRefId
	 */
	public String getSalesforceRefId() {
		return salesforceRefId;
	}

	/**
	 * Sets the salesforce ref id.
	 *
	 * @param salesforceRefId the salesforceRefId to set
	 */
	public void setSalesforceRefId(String salesforceRefId) {
		this.salesforceRefId = salesforceRefId;
	}

	/**
	 * Gets the birth date.
	 *
	 * @return the birthDate
	 */
	public Date getBirthDate() {
		return birthDate;
	}

	/**
	 * Sets the birth date.
	 *
	 * @param birthDate the birthDate to set
	 */
	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}

	/**
	 * Gets the anniv date.
	 *
	 * @return the annivDate
	 */
	public Date getAnnivDate() {
		return annivDate;
	}

	/**
	 * Sets the anniv date.
	 *
	 * @param annivDate the annivDate to set
	 */
	public void setAnnivDate(Date annivDate) {
		this.annivDate = annivDate;
	}

	/**
	 * Gets the recovery email.
	 *
	 * @return the recoveryEmail
	 */
	public String getRecoveryEmail() {
		return recoveryEmail;
	}

	/**
	 * Sets the recovery email.
	 *
	 * @param recoveryEmail the recoveryEmail to set
	 */
	public void setRecoveryEmail(String recoveryEmail) {
		this.recoveryEmail = recoveryEmail;
	}

	/**
	 * Gets the security quest one.
	 *
	 * @return the securityQuestOne
	 */
	public String getSecurityQuestOne() {
		return securityQuestOne;
	}

	/**
	 * Sets the security quest one.
	 *
	 * @param securityQuestOne the securityQuestOne to set
	 */
	public void setSecurityQuestOne(String securityQuestOne) {
		this.securityQuestOne = securityQuestOne;
	}

	/**
	 * Gets the security quest two.
	 *
	 * @return the securityQuestTwo
	 */
	public String getSecurityQuestTwo() {
		return securityQuestTwo;
	}

	/**
	 * Sets the security quest two.
	 *
	 * @param securityQuestTwo the securityQuestTwo to set
	 */
	public void setSecurityQuestTwo(String securityQuestTwo) {
		this.securityQuestTwo = securityQuestTwo;
	}

	/**
	 * Gets the security ans one.
	 *
	 * @return the securityAnsOne
	 */
	public String getSecurityAnsOne() {
		return securityAnsOne;
	}

	/**
	 * Sets the security ans one.
	 *
	 * @param securityAnsOne the securityAnsOne to set
	 */
	public void setSecurityAnsOne(String securityAnsOne) {
		this.securityAnsOne = securityAnsOne;
	}

	/**
	 * Gets the security ans two.
	 *
	 * @return the securityAnsTwo
	 */
	public String getSecurityAnsTwo() {
		return securityAnsTwo;
	}

	/**
	 * Sets the security ans two.
	 *
	 * @param securityAnsTwo the securityAnsTwo to set
	 */
	public void setSecurityAnsTwo(String securityAnsTwo) {
		this.securityAnsTwo = securityAnsTwo;
	}

	/**
	 * Gets the landline.
	 *
	 * @return the landline
	 */
	public String getLandline() {
		return landline;
	}

	/**
	 * Sets the landline.
	 *
	 * @param landline the landline to set
	 */
	public void setLandline(String landline) {
		this.landline = landline;
	}

	/**
	 * Gets the address.
	 *
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * Sets the address.
	 *
	 * @param address the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}
	
	
}
