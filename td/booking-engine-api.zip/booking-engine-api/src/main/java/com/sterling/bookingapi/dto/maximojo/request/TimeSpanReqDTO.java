package com.sterling.bookingapi.dto.maximojo.request;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class TimeSpanReqDTO.
 */
/**
 * @author tcs
 *
 */
public class TimeSpanReqDTO {

	/** The end. */
	@JacksonXmlProperty(localName = "End", isAttribute = true)
	 private String end;

	/** The start. */
	@JacksonXmlProperty(localName = "Start", isAttribute = true)
	 private String start;
	 
	/** The duration. */
	@JacksonXmlProperty(localName = "Duration", isAttribute = true)
	 private String duration;

	/**
	 * Gets the end.
	 *
	 * @return the end
	 */
	public String getEnd() {
		return end;
	}

	/**
	 * Sets the end.
	 *
	 * @param end the new end
	 */
	public void setEnd(String end) {
		this.end = end;
	}

	/**
	 * Gets the start.
	 *
	 * @return the start
	 */
	public String getStart() {
		return start;
	}

	/**
	 * Sets the start.
	 *
	 * @param start the new start
	 */
	public void setStart(String start) {
		this.start = start;
	}

	/**
	 * Gets the duration.
	 *
	 * @return the duration
	 */
	public String getDuration() {
		return duration;
	}

	/**
	 * Sets the duration.
	 *
	 * @param duration the new duration
	 */
	public void setDuration(String duration) {
		this.duration = duration;
	}

	
}
