package com.sterling.bookingapi.dto.maximojo.response;

import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class RatePlansResDTO.
 * @author tcs
 * @version 1.0
 */
public class RatePlansResDTO {

	/** The rate plan. */
	@JacksonXmlElementWrapper(useWrapping=false, localName = "RatePlans")
	@JacksonXmlProperty(localName = "RatePlan")
    private List<RatePlanResDTO> ratePlan;

	/** The hotel code. */
	@JacksonXmlProperty(localName = "HotelCode", isAttribute = true)
    private String hotelCode;
 
	/**
	 * Gets the rate plan.
	 *
	 * @return the rate plan
	 */
	public List<RatePlanResDTO> getRatePlan() {
		return ratePlan;
	}

	/**
	 * Sets the rate plan.
	 *
	 * @param ratePlan the new rate plan
	 */
	public void setRatePlan(List<RatePlanResDTO> ratePlan) {
		this.ratePlan = ratePlan;
	}

	/**
	 * Gets the hotel code.
	 *
	 * @return the hotel code
	 */
	public String getHotelCode() {
		return hotelCode;
	}

	/**
	 * Sets the hotel code.
	 *
	 * @param hotelCode the new hotel code
	 */
	public void setHotelCode(String hotelCode) {
		this.hotelCode = hotelCode;
	}
	
}
