package com.sterling.bookingapi.dto.response;

import java.io.Serializable;

/**
 * @author tcs
 * @version 1.0
 *
 */
public class VOOfferResponseDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String contractId;
	private String offerId;
	private String offerMasterId;
	private String category;
	private String startDate;
	private String endDate;
	private String status;
	private String offerValue;
	private String noOfNights;
	private String nightsRemaining;
	
	private String podNumber;
	private String courierName;
	private String courierCompany;
	private String offerType;
	
	private String offerName;
	private String unitsOfMessurement;
	private Boolean availedOnline;

	public String getCourierCompany() {
		return courierCompany;
	}
	public void setCourierCompany(String courierCompany) {
		this.courierCompany = courierCompany;
	}
	public String getOfferType() {
		return offerType;
	}
	public void setOfferType(String offerType) {
		this.offerType = offerType;
	}
	public Boolean getAvailedOnline() {
		return availedOnline;
	}
	public void setAvailedOnline(Boolean availedOnline) {
		this.availedOnline = availedOnline;
	}
	public String getPodNumber() {
		return podNumber;
	}
	public void setPodNumber(String podNumber) {
		this.podNumber = podNumber;
	}
	public String getCourierName() {
		return courierName;
	}
	public void setCourierName(String courierName) {
		this.courierName = courierName;
	}
	public String getOfferName() {
		return offerName;
	}
	public void setOfferName(String offerName) {
		this.offerName = offerName;
	}
	public String getUnitsOfMessurement() {
		return unitsOfMessurement;
	}
	public void setUnitsOfMessurement(String unitsOfMessurement) {
		this.unitsOfMessurement = unitsOfMessurement;
	}
	public String getOfferMasterId() {
		return offerMasterId;
	}
	public void setOfferMasterId(String offerMasterId) {
		this.offerMasterId = offerMasterId;
	}
	public String getContractId() {
		return contractId;
	}
	public void setContractId(String contractId) {
		this.contractId = contractId;
	}
	public String getOfferId() {
		return offerId;
	}
	public void setOfferId(String offerId) {
		this.offerId = offerId;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getOfferValue() {
		return offerValue;
	}
	public void setOfferValue(String offerValue) {
		this.offerValue = offerValue;
	}
	public String getNoOfNights() {
		return noOfNights;
	}
	public void setNoOfNights(String noOfNights) {
		this.noOfNights = noOfNights;
	}
	public String getNightsRemaining() {
		return nightsRemaining;
	}
	public void setNightsRemaining(String nightsRemaining) {
		this.nightsRemaining = nightsRemaining;
	}
	
}
