package com.sterling.bookingapi.dto.maximojo.request;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlText;


/**
 * The Class EmailReqDTO.
 */
/**
 * @author tcs
 *
 */
public class EmailReqDTO {
	
	/** The default ind. */
	@JacksonXmlProperty(localName = "DefaultInd", isAttribute = true)
    private boolean defaultInd;
	
	/** The email type. */
	@JacksonXmlProperty(localName = "EmailType", isAttribute = true)
    private int emailType;

	/** The content. */
	@JacksonXmlText
	private String content;

	/**
	 * Gets the content.
	 *
	 * @return the content
	 */
	public String getContent() {
		return content;
	}

	/**
	 * Sets the content.
	 *
	 * @param content the content to set
	 */
	public void setContent(String content) {
		this.content = content;
	}

	/**
	 * Gets the email type.
	 *
	 * @return the emailType
	 */
	public int getEmailType() {
		return emailType;
	}

	/**
	 * Sets the email type.
	 *
	 * @param emailType the emailType to set
	 */
	public void setEmailType(int emailType) {
		this.emailType = emailType;
	}

	/**
	 * Checks if is default ind.
	 *
	 * @return the defaultInd
	 */
	public boolean isDefaultInd() {
		return defaultInd;
	}

	/**
	 * Sets the default ind.
	 *
	 * @param defaultInd the defaultInd to set
	 */
	public void setDefaultInd(boolean defaultInd) {
		this.defaultInd = defaultInd;
	}

	
}
