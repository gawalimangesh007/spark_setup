package com.sterling.bookingapi.dto.request;


/**
 * The Class HsdBookingEnhancementDetailsDTO.
 */
/**
 * @author tcs
 *
 */
public class HsdBookingEnhancementDetailsDTO {
	
	/** The meals. */
	private boolean meals;
	
	/** The spa. */
	private boolean spa;
	
	/**
	 * Checks if is meals.
	 *
	 * @return true, if is meals
	 */
	public boolean isMeals() {
		return meals;
	}
	
	/**
	 * Sets the meals.
	 *
	 * @param meals the new meals
	 */
	public void setMeals(boolean meals) {
		this.meals = meals;
	}
	
	/**
	 * Checks if is spa.
	 *
	 * @return true, if is spa
	 */
	public boolean isSpa() {
		return spa;
	}
	
	/**
	 * Sets the spa.
	 *
	 * @param spa the new spa
	 */
	public void setSpa(boolean spa) {
		this.spa = spa;
	}
	
}