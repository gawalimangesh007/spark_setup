package com.sterling.bookingapi.dto.response;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author tcs
 * @version 1.0
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class ApartmentDetails implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@JsonProperty("_1BR")
	private int noOf1BR;
	@JsonProperty("_2BR")
	private int noOf2BR;
	@JsonProperty("_ST")
	private int noOfStudioBR;
	@JsonProperty("_GR")
	private int noOfGuestBR;
	
	/**
	 * @return noOf1BR
	 */
	public int getNoOf1BR() {
		return noOf1BR;
	}
	/**
	 * @param noOf1BR
	 * set the noOf1BR
	 */
	public void setNoOf1BR(int noOf1BR) {
		this.noOf1BR = noOf1BR;
	}
	/**
	 * @return noOf2BR
	 */
	public int getNoOf2BR() {
		return noOf2BR;
	}
	/**
	 * @param noOf2BR
	 * set the noOf2BR
	 */
	public void setNoOf2BR(int noOf2BR) {
		this.noOf2BR = noOf2BR;
	}
	/**
	 * @return noOfStudioBR
	 */
	public int getNoOfStudioBR() {
		return noOfStudioBR;
	}
	/**
	 * @param noOfStudioBR
	 * set the noOfStudioBR
	 */
	public void setNoOfStudioBR(int noOfStudioBR) {
		this.noOfStudioBR = noOfStudioBR;
	}
	public int getNoOfGuestBR() {
		return noOfGuestBR;
	}
	public void setNoOfGuestBR(int noOfGuestBR) {
		this.noOfGuestBR = noOfGuestBR;
	}	
}
