package com.sterling.bookingapi.dto.response;

import java.util.List;

public class HSDResortMappingResDTO {
	
	/** The resort id. */
	private String resortId;
	
	/** The resort name. */
	private String resortName;
		
	private List<HSDResortRoomMappingResDTO> roomsMapped;

	public String getResortId() {
		return resortId;
	}

	public void setResortId(String resortId) {
		this.resortId = resortId;
	}

	public String getResortName() {
		return resortName;
	}

	public void setResortName(String resortName) {
		this.resortName = resortName;
	}

	public List<HSDResortRoomMappingResDTO> getRoomsMapped() {
		return roomsMapped;
	}

	public void setRoomsMapped(List<HSDResortRoomMappingResDTO> roomsMapped) {
		this.roomsMapped = roomsMapped;
	}
}
