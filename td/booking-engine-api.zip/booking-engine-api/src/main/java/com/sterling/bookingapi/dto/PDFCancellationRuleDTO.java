package com.sterling.bookingapi.dto;

import java.io.Serializable;

public class PDFCancellationRuleDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String cancellationTime;
	private String pointsDebit;
	
	public PDFCancellationRuleDTO() {
		super();
	}

	public PDFCancellationRuleDTO(String cancellationTime, String pointsDebit) {
		super();
		this.cancellationTime = cancellationTime;
		this.pointsDebit = pointsDebit;
	}

	public String getCancellationTime() {
		return cancellationTime;
	}

	public void setCancellationTime(String cancellationTime) {
		this.cancellationTime = cancellationTime;
	}

	public String getPointsDebit() {
		return pointsDebit;
	}

	public void setPointsDebit(String pointsDebit) {
		this.pointsDebit = pointsDebit;
	}
	
	
}
