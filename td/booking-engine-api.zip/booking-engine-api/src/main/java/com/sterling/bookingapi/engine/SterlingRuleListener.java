package com.sterling.bookingapi.engine;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jeasy.rules.api.Facts;
import org.jeasy.rules.api.Rule;
import org.jeasy.rules.api.RuleListener;

public class SterlingRuleListener implements RuleListener {

	private static final Logger logger = LogManager.getLogger(SterlingRuleListener.class);
	
	private Rule failureRule;
	private Exception error;
	
	private boolean status;
	
	public Rule getFailureRule() {
		return failureRule;
	}

	public void setFailureRule(Rule failureRule) {
		this.failureRule = failureRule;
	}

	public Exception getError() {
		return error;
	}

	public void setError(Exception error) {
		this.error = error;
	}

	public boolean getStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	@Override
	public void afterEvaluate(Rule rule, Facts arg1, boolean arg2) {
		
	}

	@Override
	public boolean beforeEvaluate(Rule rule, Facts arg1) {
		logger.info("*********** on before eveluate " + rule.getName());
		return true;
	}

	@Override
	public void beforeExecute(Rule rule, Facts arg1) {
		logger.info("*********** on before execute " + rule.getName());
		
	}

	@Override
	public void onFailure(Rule rule, Facts arg1, Exception e) {
		logger.info("*********** on failure " + rule.getName());
		failureRule = rule;
		error = e;
		status = false;
		
	}

	@Override
	public void onSuccess(Rule rule, Facts arg1) {
		logger.info("*********** on success " + rule.getName());
		status = true;
		
	}
	
}
