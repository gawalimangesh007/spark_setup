package com.sterling.bookingapi.engine.rules;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.BooleanUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;

import com.sterling.bookingapi.dto.request.VOConfirmBookingRequest;
import com.sterling.bookingapi.dto.response.VODashboardResponse;
import com.sterling.bookingapi.engine.rules.models.BookingRule;
import com.sterling.bookingapi.engine.rules.models.Season;
import com.sterling.bookingapi.engine.rules.models.VOBookingRuleDTO;
import com.sterling.bookingapi.utils.BookingEngineUtils;


@Rule(name="RedTravelRule", description="RED_TRAVEL_RULE")
public class RedTravelRule {

	private static final Logger logger = LogManager.getLogger(RedTravelRule.class);
	
	@Condition
	public boolean when(@Fact("bookingRequest") VOConfirmBookingRequest req, 
			@Fact("productRules") Map<String, List<VOBookingRuleDTO>> rulesMap,
			@Fact("memberDetail") VODashboardResponse memberDetail,
			@Fact("bookingSeasons") Set<String> bookingSeason,
			@Fact("brdFlag") boolean brdFlag) {
		//my rule conditions
		logger.info("=========== RED_TRAVEL_RULE executing");
		
		if(!brdFlag) {
			//Season bookingSeason = null;//Season.getByName(req.getSeasonCode());
			Season memberSeason = Season.getByName(memberDetail.getMembershipDetails().getMemberSeason());
			List<VOBookingRuleDTO> ruleList = rulesMap.get(BookingRule.RED_TRAVEL_RULE.getRuleName());
			if(memberSeason != null && memberSeason == Season.RED) {
				for (VOBookingRuleDTO voBookingRuleDTO : ruleList) {
					if (BooleanUtils.isTrue(voBookingRuleDTO.getActive())) {
						List<String> availableSeason = BookingEngineUtils
								.getAvailableSeason(voBookingRuleDTO
										.getApplicableSeasons());
						if (!availableSeason.containsAll(bookingSeason)) {
							logger.info("=========== RED_TRAVEL_RULE :: allowed seasons are only :{}",availableSeason );
							return false;
						}
					}
				}
			}
		}
		return true;
	}

	@Action(order = 1)
	public void then() throws Exception {
		//my actions
		logger.info("################# excecuting action");
	}
}
