package com.sterling.bookingapi.auth.bean;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * @author tcs
 *
 */
public class User implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String userId;
	
	@JsonIgnore
	private String password;
	
	private String email;
	private String firstName;
	private String lastName;
	private String age;
	private String gender;
	private String contact;
	private String title;
	private String dob;
	
	private AuthType authType;
	private Object userObject;
	

	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	/**
	 * @return userId
	 */
	public String getUserId() {
		return userId;
	}
	/**
	 * @param userId
	 * set the userId
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	/**
	 * @return userObject
	 */
	public Object getUserObject() {
		return userObject;
	}
	/**
	 * @param userObject
	 * set the userObject
	 */
	public void setUserObject(Object userObject) {
		this.userObject = userObject;
	}
	/**
	 * @return password
	 */
	public String getPassword() {
		return password;
	}
	/**
	 * @param password
	 * set the password
	 */
	public void setPassword(String password) {
		this.password = password;
	}
	/**
	 * @return authType
	 */
	public AuthType getAuthType() {
		return authType;
	}
	/**
	 * @param authType
	 * set the authType
	 */
	public void setAuthType(AuthType authType) {
		this.authType = authType;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}

}
