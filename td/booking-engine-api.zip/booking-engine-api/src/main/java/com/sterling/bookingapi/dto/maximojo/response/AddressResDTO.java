package com.sterling.bookingapi.dto.maximojo.response;

import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class AddressResDTO.
 * @author tcs
 * @version 1.0
 */
public class AddressResDTO {

	/** The country name. */
	@JacksonXmlProperty(localName = "CountryName")
	private String countryName;

	/** The postal code. */
	@JacksonXmlProperty(localName = "PostalCode")
    private String postalCode;

	/** The state prov. */
	@JacksonXmlProperty(localName = "StateProv")
    private String stateProv;
	
	/** The city name. */
	@JacksonXmlProperty(localName = "CityName")
    private String cityName;

	/** The address line. */
	@JacksonXmlElementWrapper(useWrapping=false)
	@JacksonXmlProperty(localName = "AddressLine")
    private List<String> addressLine;

	/**
	 * Gets the country name.
	 *
	 * @return the countryName
	 */
	public String getCountryName() {
		return countryName;
	}

	/**
	 * Sets the country name.
	 *
	 * @param countryName the countryName to set
	 */
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	/**
	 * Gets the postal code.
	 *
	 * @return the postalCode
	 */
	public String getPostalCode() {
		return postalCode;
	}

	/**
	 * Sets the postal code.
	 *
	 * @param postalCode the postalCode to set
	 */
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	/**
	 * Gets the state prov.
	 *
	 * @return the stateProv
	 */
	public String getStateProv() {
		return stateProv;
	}

	/**
	 * Sets the state prov.
	 *
	 * @param stateProv the stateProv to set
	 */
	public void setStateProv(String stateProv) {
		this.stateProv = stateProv;
	}

	/**
	 * Gets the city name.
	 *
	 * @return the cityName
	 */
	public String getCityName() {
		return cityName;
	}

	/**
	 * Sets the city name.
	 *
	 * @param cityName the cityName to set
	 */
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	/**
	 * Gets the address line.
	 *
	 * @return the addressLine
	 */
	public List<String> getAddressLine() {
		return addressLine;
	}

	/**
	 * Sets the address line.
	 *
	 * @param addressLine the addressLine to set
	 */
	public void setAddressLine(List<String> addressLine) {
		this.addressLine = addressLine;
	}

	
}
