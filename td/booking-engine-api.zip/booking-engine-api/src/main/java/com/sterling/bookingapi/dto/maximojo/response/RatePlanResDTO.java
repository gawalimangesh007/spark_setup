package com.sterling.bookingapi.dto.maximojo.response;

import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class RatePlanResDTO.
 * @author tcs
 * @version 1.0
 */
public class RatePlanResDTO {
	
	/** The rate. */
	@JacksonXmlElementWrapper(useWrapping=true, localName = "Rates")
	@JacksonXmlProperty(localName = "Rate")
    private List<RateResDTO> rate;

	/** The currency code. */
	@JacksonXmlProperty(localName = "CurrencyCode", isAttribute = true)
    private String currencyCode;
	
	/** The rate plan code. */
	@JacksonXmlProperty(localName = "RatePlanCode", isAttribute = true)
    private String ratePlanCode;

	/** The rate plan status type. */
	@JacksonXmlProperty(localName = "RatePlanStatusType", isAttribute = true)
    private String ratePlanStatusType;
	
	/** The description. */
	@JacksonXmlProperty(localName = "Description")
	private DescriptionResDTO description;

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public DescriptionResDTO getDescription() {
		return description;
	}

	/**
	 * Sets the description.
	 *
	 * @param description the new description
	 */
	public void setDescription(DescriptionResDTO description) {
		this.description = description;
	}

	/**
	 * Gets the rate.
	 *
	 * @return the rate
	 */
	public List<RateResDTO> getRate() {
		return rate;
	}

	/**
	 * Sets the rate.
	 *
	 * @param rate the new rate
	 */
	public void setRate(List<RateResDTO> rate) {
		this.rate = rate;
	}

	/**
	 * Gets the rate plan code.
	 *
	 * @return the rate plan code
	 */
	public String getRatePlanCode() {
		return ratePlanCode;
	}

	/**
	 * Sets the rate plan code.
	 *
	 * @param ratePlanCode the new rate plan code
	 */
	public void setRatePlanCode(String ratePlanCode) {
		this.ratePlanCode = ratePlanCode;
	}

	/**
	 * Gets the currency code.
	 *
	 * @return the currency code
	 */
	public String getCurrencyCode() {
		return currencyCode;
	}

	/**
	 * Sets the currency code.
	 *
	 * @param currencyCode the new currency code
	 */
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	/**
	 * Gets the rate plan status type.
	 *
	 * @return the rate plan status type
	 */
	public String getRatePlanStatusType() {
		return ratePlanStatusType;
	}

	/**
	 * Sets the rate plan status type.
	 *
	 * @param ratePlanStatusType the new rate plan status type
	 */
	public void setRatePlanStatusType(String ratePlanStatusType) {
		this.ratePlanStatusType = ratePlanStatusType;
	}
    
	
	
}
