package com.sterling.bookingapi.dto.maximojo.response;

import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class RatePlansForSummaryFalseResDTO.
 * @author tcs
 * @version 1.0
 */
public class RatePlansForSummaryFalseResDTO {
	
	/** The hotel code. */
	@JacksonXmlProperty(localName = "HotelCode", isAttribute = true)
	private String hotelCode;

	/** The rate plan. */
	@JacksonXmlElementWrapper(useWrapping=false, localName = "RatePlan")
	@JacksonXmlProperty(localName = "RatePlan")
    private List<RatePlanForSummaryFalse> ratePlan;

	/**
	 * Gets the hotel code.
	 *
	 * @return the hotel code
	 */
	public String getHotelCode() {
		return hotelCode;
	}

	/**
	 * Sets the hotel code.
	 *
	 * @param hotelCode the new hotel code
	 */
	public void setHotelCode(String hotelCode) {
		this.hotelCode = hotelCode;
	}

	/**
	 * Gets the rate plan.
	 *
	 * @return the ratePlan
	 */
	public List<RatePlanForSummaryFalse> getRatePlan() {
		return ratePlan;
	}

	/**
	 * Sets the rate plan.
	 *
	 * @param ratePlan the ratePlan to set
	 */
	public void setRatePlan(List<RatePlanForSummaryFalse> ratePlan) {
		this.ratePlan = ratePlan;
	}


}
