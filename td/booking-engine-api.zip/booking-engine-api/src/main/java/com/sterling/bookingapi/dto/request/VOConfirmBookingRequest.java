package com.sterling.bookingapi.dto.request;

import java.io.Serializable;
import java.util.List;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.sterling.bookingapi.dto.PaymentRequestDTO;

/**
 * @author tcs
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class VOConfirmBookingRequest implements Serializable {

	private static final long serialVersionUID = 1L;

	private String bookingDate;
	
	@NotEmpty(message="Contract id should not be empty")
	private String contractId;
	
	@NotEmpty(message="checkInDate should not be empty")
	private String checkInDate;
	
	@NotEmpty(message="checkOutDate should not be empty")
	private String checkOutDate;
	
	private String checkInTime;
	private String checkOutTime;
	
	private String bookingStatus;
	
	@NotEmpty(message="noOfAdults should not be empty")
	@Pattern(regexp="^[0-9]*$", message="noOfChildren should be a number")
	private String noOfAdults;
	
	@NotEmpty(message="noOfChildren should not be empty")
	@Pattern(regexp="^[0-9]*$", message="noOfChildren should be a number")
	private String noOfChildren;
	
	@NotNull(message="productId should not be empty")
	private String productId;
	
	@NotNull(message="productCode should not be empty")
	private String productCode;
	
	@NotNull(message="Resort id should not be empty")
	private String resortMasterId;

	@NotNull(message="Resort id should not be empty")
	private String resortSerielNo;
	
	@JsonProperty("_1BR")
	private String noOf1BR;
	@JsonProperty("_2BR")
	private String noOf2BR;
	@JsonProperty("_ST")
	private String noOfStudio;
	@JsonProperty("_GR")
	private String noOfGuest;
	
	@NotEmpty(message="utilityChargesMasterId should not be empty")
	private String utilityChargesMasterId;
	
	@NotEmpty(message="bookingPoints shouldnot be empty")
	private String bookingPoints;
	
	private String cvNumber;
	
	private boolean advPointsNext1;
	private boolean advPointsNext2;
	
	private Double addBedAdult;
	private Double addBedChild;
	
	private String pointsReducedFromCurrent;
	private String bookingType;

	//@NotEmpty(message="travelingType shouldnot be empty")
	private String travelingType;

	//@NotEmpty
	//@NotNull
	private List<VOBookingRoomDetailReq> roomDetails;
	
	private List<VOBookingEnhancementDetailReq> enhancementList;
	
	private Boolean isOfferBooking = false;
	private String offerType;
	private String offerCheckinDate;
	private String offerCheckoutDate;
	private String offeredUnits;
	private String offerId;
	
	private Boolean isHolidayFallen;
	private Boolean isNationalHolidayFallen;
	
	private VOPayCustomerDetailsDTO customerDetails;
	private Double totalExtraCost;
	
	private VOExtarPersonDetailDTO guestFeeDetail;
	private VOGuestDetailDTO guestDetail;
	
	//@NotNull
	//@NotEmpty
	private List<SeasonDetail> seasonDetail;
	
	@JsonProperty("BRWBookingFlag")
	private Boolean brdBookingFlag;

	//sf Airpay dto, hide from Frontend 
	@JsonIgnore
	private PaymentRequestDTO paymentRequestDTO;
	
	@JsonIgnore
	private String bookingId;
	
	private VOPayEMIRequestDTO emiRequest;
	private VOPayASFRequestDTO asfRequest;
	private Boolean hasEMI;
	private Boolean hasASF;
	private Double totalAmount;
	
	private Double payatResortGuestFee;
	private Double payatResortUtilityCharge;
	
	private Boolean payatResortGuestFlag;
	private Boolean payatResortUtilityFlag;
	
	private String aliasName;

	private Double utilityCharges;
	
	@JsonIgnore
	private String bookingUserType;

	
	private PDFContentRequestDTO cvPDFContent;
	
	private String insuranceFlag;
	
	public String getInsuranceFlag() {
		return insuranceFlag;
	}
	public void setInsuranceFlag(String insuranceFlag) {
		this.insuranceFlag = insuranceFlag;
	}
	
	public Double getUtilityCharges() {
		return utilityCharges;
	}
	public void setUtilityCharges(Double utilityCharges) {
		this.utilityCharges = utilityCharges;
	}
	public PDFContentRequestDTO getCvPDFContent() {
		return cvPDFContent;
	}
	public void setCvPDFContent(PDFContentRequestDTO cvPDFContent) {
		this.cvPDFContent = cvPDFContent;
	}
	public String getAliasName() {
		return aliasName;
	}
	public void setAliasName(String aliasName) {
		this.aliasName = aliasName;
	}
	public String getCheckInTime() {
		return checkInTime;
	}
	public void setCheckInTime(String checkInTime) {
		this.checkInTime = checkInTime;
	}
	public String getCheckOutTime() {
		return checkOutTime;
	}
	public void setCheckOutTime(String checkOutTime) {
		this.checkOutTime = checkOutTime;
	}
	public Double getPayatResortGuestFee() {
		return payatResortGuestFee;
	}
	public void setPayatResortGuestFee(Double payatResortGuestFee) {
		this.payatResortGuestFee = payatResortGuestFee;
	}
	public Double getPayatResortUtilityCharge() {
		return payatResortUtilityCharge;
	}
	public void setPayatResortUtilityCharge(Double payatResortUtilityCharge) {
		this.payatResortUtilityCharge = payatResortUtilityCharge;
	}
	
	public Boolean getPayatResortGuestFlag() {
		return payatResortGuestFlag;
	}
	public void setPayatResortGuestFlag(Boolean payatResortGuestFlag) {
		this.payatResortGuestFlag = payatResortGuestFlag;
	}
	public Boolean getPayatResortUtilityFlag() {
		return payatResortUtilityFlag;
	}
	public void setPayatResortUtilityFlag(Boolean payatResortUtilityFlag) {
		this.payatResortUtilityFlag = payatResortUtilityFlag;
	}
	public String getTravelingType() {
		return travelingType;
	}
	public void setTravelingType(String travelingType) {
		this.travelingType = travelingType;
	}
	public Boolean getHasEMI() {
		return hasEMI;
	}
	public void setHasEMI(Boolean hasEMI) {
		this.hasEMI = hasEMI;
	}
	public Boolean getHasASF() {
		return hasASF;
	}
	public void setHasASF(Boolean hasASF) {
		this.hasASF = hasASF;
	}
	public Double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}
	public Boolean getBrdBookingFlag() {
		return brdBookingFlag;
	}
	public void setBrdBookingFlag(Boolean brdBookingFlag) {
		this.brdBookingFlag = brdBookingFlag;
	}
	public String getBookingId() {
		return bookingId;
	}
	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}
	public String getCvNumber() {
		return cvNumber;
	}
	public void setCvNumber(String cvNumber) {
		this.cvNumber = cvNumber;
	}
	public Boolean getIsNationalHolidayFallen() {
		return isNationalHolidayFallen;
	}
	public void setIsNationalHolidayFallen(Boolean isNationalHolidayFallen) {
		this.isNationalHolidayFallen = isNationalHolidayFallen;
	}
	public String getResortSerielNo() {
		return resortSerielNo;
	}
	public void setResortSerielNo(String resortSerielNo) {
		this.resortSerielNo = resortSerielNo;
	}
	public List<SeasonDetail> getSeasonDetail() {
		return seasonDetail;
	}
	public void setSeasonDetail(List<SeasonDetail> seasonDetail) {
		this.seasonDetail = seasonDetail;
	}
	public VOGuestDetailDTO getGuestDetail() {
		return guestDetail;
	}
	public void setGuestDetail(VOGuestDetailDTO guestDetail) {
		this.guestDetail = guestDetail;
	}
	
	public String getBookingType() {
		return bookingType;
	}
	public void setBookingType(String bookingType) {
		this.bookingType = bookingType;
	}
	
	/**
	 * @return  bookingDate
	 */
	public String getBookingDate() {
		return bookingDate;
	}
	/**
	 * @param bookingDate
	 * set the bookingDate
	 */
	public void setBookingDate(String bookingDate) {
		this.bookingDate = bookingDate;
	}
	/**
	 * @return contractId
	 */
	public String getContractId() {
		return contractId;
	}
	/**
	 * @param contractId
	 * set the contractId
	 */
	public void setContractId(String contractId) {
		this.contractId = contractId;
	}
	/**
	 * @return checkInDate
	 */
	public String getCheckInDate() {
		return checkInDate;
	}
	/**
	 * @param checkInDate
	 * set the checkInDate
	 */
	public void setCheckInDate(String checkInDate) {
		this.checkInDate = checkInDate;
	}
	/**
	 * @return checkOutDate
	 */
	public String getCheckOutDate() {
		return checkOutDate;
	}
	/**
	 * @param checkOutDate
	 * set the checkOutDate
	 */
	public void setCheckOutDate(String checkOutDate) {
		this.checkOutDate = checkOutDate;
	}
	/**
	 * @return bookingStatus
	 */
	public String getBookingStatus() {
		return bookingStatus;
	}
	/**
	 * @param bookingStatus
	 * set the bookingStatus
	 */
	public void setBookingStatus(String bookingStatus) {
		this.bookingStatus = bookingStatus;
	}
	/**
	 * @return noOfAdults
	 */
	public String getNoOfAdults() {
		return noOfAdults;
	}
	/**
	 * @param noOfAdults
	 * set the noOfAdults
	 */
	public void setNoOfAdults(String noOfAdults) {
		this.noOfAdults = noOfAdults;
	}
	/**
	 * @return noOfChildren
	 */
	public String getNoOfChildren() {
		return noOfChildren;
	}
	/**
	 * @param noOfChildren
	 * set the noOfChildren
	 */
	public void setNoOfChildren(String noOfChildren) {
		this.noOfChildren = noOfChildren;
	}
	/**
	 * @return product id
	 */
	public String getProductId() {
		return productId;
	}
	/**
	 * @param productId
	 * set the product id
	 */
	public void setProductId(String productId) {
		this.productId = productId;
	}
	/**
	 * @return resortMasterId
	 */
	public String getResortMasterId() {
		return resortMasterId;
	}
	/**
	 * @param resortMasterId
	 * set the resortMasterId
	 */
	public void setResortMasterId(String resortMasterId) {
		this.resortMasterId = resortMasterId;
	}
	/**
	 * @return noOf1BR
	 */
	public String getNoOf1BR() {
		return noOf1BR;
	}
	/**
	 * @param noOf1BR
	 * set the noOf1BR
	 */
	public void setNoOf1BR(String noOf1BR) {
		this.noOf1BR = noOf1BR;
	}
	/**
	 * @return noOf2BR
	 */
	public String getNoOf2BR() {
		return noOf2BR;
	}
	/**
	 * @param noOf2BR
	 * set the noOf2BR
	 */
	public void setNoOf2BR(String noOf2BR) {
		this.noOf2BR = noOf2BR;
	}
	/**
	 * @return utilityChargesMasterId
	 */
	public String getUtilityChargesMasterId() {
		return utilityChargesMasterId;
	}
	/**
	 * @param utilityChargesMasterId
	 * set the utilityChargesMasterId
	 */
	public void setUtilityChargesMasterId(String utilityChargesMasterId) {
		this.utilityChargesMasterId = utilityChargesMasterId;
	}
	/**
	 * @return bookingPoints
	 */
	public String getBookingPoints() {
		return bookingPoints;
	}
	/**
	 * @param bookingPoints
	 * set the bookingPoints
	 */
	public void setBookingPoints(String bookingPoints) {
		this.bookingPoints = bookingPoints;
	}

	/**
	 * @return advPointsNext1
	 */
	public boolean isAdvPointsNext1() {
		return advPointsNext1;
	}
	/**
	 * @param advPointsNext1
	 * set the advPointsNext1
	 */
	public void setAdvPointsNext1(boolean advPointsNext1) {
		this.advPointsNext1 = advPointsNext1;
	}
	/**
	 * @return advPointsNext2
	 */
	public boolean isAdvPointsNext2() {
		return advPointsNext2;
	}
	/**
	 * @param advPointsNext2
	 * set the advPointsNext2
	 */
	public void setAdvPointsNext2(boolean advPointsNext2) {
		this.advPointsNext2 = advPointsNext2;
	}
	/**
	 * @return pointsReducedFromCurrent
	 */
	public String getPointsReducedFromCurrent() {
		return pointsReducedFromCurrent;
	}
	/**
	 * @param pointsReducedFromCurrent
	 * set the pointsReducedFromCurrent
	 */
	public void setPointsReducedFromCurrent(String pointsReducedFromCurrent) {
		this.pointsReducedFromCurrent = pointsReducedFromCurrent;
	}
	/**
	 * @return roomDetails
	 */
	public List<VOBookingRoomDetailReq> getRoomDetails() {
		return roomDetails;
	}
	/**
	 * @param roomDetails
	 * set the roomDetails
	 */
	public void setRoomDetails(List<VOBookingRoomDetailReq> roomDetails) {
		this.roomDetails = roomDetails;
	}
	/**
	 * @return noOfStudio
	 */
	public String getNoOfStudio() {
		return noOfStudio;
	}
	/**
	 * @param noOfStudio
	 * set the noOfStudio
	 */
	public void setNoOfStudio(String noOfStudio) {
		this.noOfStudio = noOfStudio;
	}
	/**
	 * @return noOfGuest
	 */
	public String getNoOfGuest() {
		return noOfGuest;
	}
	/**
	 * @param noOfGuest
	 * set the noOfGuest
	 */
	public void setNoOfGuest(String noOfGuest) {
		this.noOfGuest = noOfGuest;
	}
	/**
	 * @return enhancementList
	 */
	public List<VOBookingEnhancementDetailReq> getEnhancementList() {
		return enhancementList;
	}
	/**
	 * @param enhancementDetails
	 * set the enhancementList
	 */
	public void setEnhancementList(
			List<VOBookingEnhancementDetailReq> enhancementDetails) {
		this.enhancementList = enhancementDetails;
	}
	public Boolean getIsOfferBooking() {
		return isOfferBooking;
	}
	public void setIsOfferBooking(Boolean isOfferBooking) {
		this.isOfferBooking = isOfferBooking;
	}
	public Double getAddBedAdult() {
		return addBedAdult;
	}
	public void setAddBedAdult(Double addBedAdult) {
		this.addBedAdult = addBedAdult;
	}
	public Double getAddBedChild() {
		return addBedChild;
	}
	public void setAddBedChild(Double addBedChild) {
		this.addBedChild = addBedChild;
	}
	public String getOfferType() {
		return offerType;
	}
	public void setOfferType(String offerType) {
		this.offerType = offerType;
	}
	public String getOfferCheckinDate() {
		return offerCheckinDate;
	}
	public void setOfferCheckinDate(String offerCheckinDate) {
		this.offerCheckinDate = offerCheckinDate;
	}
	public String getOfferCheckoutDate() {
		return offerCheckoutDate;
	}
	public void setOfferCheckoutDate(String offerCheckoutDate) {
		this.offerCheckoutDate = offerCheckoutDate;
	}
	public String getOfferedUnits() {
		return offeredUnits;
	}
	public void setOfferedUnits(String offeredUnits) {
		this.offeredUnits = offeredUnits;
	}
	public String getOfferId() {
		return offerId;
	}
	public void setOfferId(String offerId) {
		this.offerId = offerId;
	}
	public Boolean getIsHolidayFallen() {
		return isHolidayFallen;
	}
	public void setIsHolidayFallen(Boolean isHolidayFallen) {
		this.isHolidayFallen = isHolidayFallen;
	}
	public VOPayCustomerDetailsDTO getCustomerDetails() {
		return customerDetails;
	}
	public void setCustomerDetails(VOPayCustomerDetailsDTO customerDetails) {
		this.customerDetails = customerDetails;
	}
	public Double getTotalExtraCost() {
		return totalExtraCost;
	}
	public void setTotalExtraCost(Double totalExtraCost) {
		this.totalExtraCost = totalExtraCost;
	}
	public PaymentRequestDTO getPaymentRequestDTO() {
		return paymentRequestDTO;
	}
	public void setPaymentRequestDTO(PaymentRequestDTO paymentRequestDTO) {
		this.paymentRequestDTO = paymentRequestDTO;
	}
	public VOExtarPersonDetailDTO getGuestFeeDetail() {
		return guestFeeDetail;
	}
	public void setGuestFeeDetail(VOExtarPersonDetailDTO guestFeeDetail) {
		this.guestFeeDetail = guestFeeDetail;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public VOPayEMIRequestDTO getEmiRequest() {
		return emiRequest;
	}
	public void setEmiRequest(VOPayEMIRequestDTO emiRequest) {
		this.emiRequest = emiRequest;
	}
	public VOPayASFRequestDTO getAsfRequest() {
		return asfRequest;
	}
	public void setAsfRequest(VOPayASFRequestDTO asfRequest) {
		this.asfRequest = asfRequest;
	}
	public String getBookingUserType() {
		return bookingUserType;
	}
	public void setBookingUserType(String bookingUserType) {
		this.bookingUserType = bookingUserType;
	}
}
