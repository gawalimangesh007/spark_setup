package com.sterling.bookingapi.dto.response;

import java.io.Serializable;

/**
 * @author tcs
 * @version 1.0
 */
public class HsdMemberResponseDTO extends BaseRecord implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String id;
	private String title;
	private String firstName;
	private String lastName;
	private String gender;
	private String mobileNo;
	private String alternateMobileNo;
	private String email;
	private String dob;
	private Boolean isvalidUser;
	
	/**
	 * @return id
	 */
	public String getId() {
		return id;
	}
	/**
	 * @param id
	 * set the id
	 */
	public void setId(String id) {
		this.id = id;
	}
	/**
	 * @return title
	 */
	public String getTitle() {
		return title;
	}
	/**
	 * @param title
	 * set the title
	 */
	public void setTitle(String title) {
		this.title = title;
	}
	/**
	 * @return firstName
	 */
	public String getFirstName() {
		return firstName;
	}
	/**
	 * @param firstName
	 * set the firstName
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	/**
	 * @return lastName
	 */
	public String getLastName() {
		return lastName;
	}
	/**
	 * @param lastName
	 * set the lastName
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	/**
	 * @return gender
	 */
	public String getGender() {
		return gender;
	}
	/**
	 * @param gender
	 * set the gender
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}
	/**
	 * @return email
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * @param email
	 * set the email
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	/**
	 * @return dob
	 */
	public String getDob() {
		return dob;
	}
	/**
	 * @param dob
	 * set the dob
	 */
	public void setDob(String dob) {
		this.dob = dob;
	}
	/**
	 * @return isvalidUser
	 */
	public Boolean getIsvalidUser() {
		return isvalidUser;
	}
	/**
	 * @param isvalidUser
	 * set the isvalidUser
	 */
	public void setIsvalidUser(Boolean isvalidUser) {
		this.isvalidUser = isvalidUser;
	}
	/**
	 * @return mobileNo
	 */
	public String getMobileNo() {
		return mobileNo;
	}
	/**
	 * @param mobileNo
	 * set the mobileNo
	 */
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	/**
	 * @return alternateMobileNo
	 */
	public String getAlternateMobileNo() {
		return alternateMobileNo;
	}
	/**
	 * @param alternateMobileNo
	 * set the alternateMobileNo
	 */
	public void setAlternateMobileNo(String alternateMobileNo) {
		this.alternateMobileNo = alternateMobileNo;
	}
	
}
