package com.sterling.bookingapi.dto.maximojo.response;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class GuestCountResDTO.
 * @author tcs
 * @version 1.0
 */
public class GuestCountResDTO {

	/** The count. */
	@JacksonXmlProperty(localName = "Count", isAttribute = true)
	  private String count;

	  /** The age qualifying code. */
  	@JacksonXmlProperty(localName = "AgeQualifyingCode", isAttribute = true)
	  private String ageQualifyingCode;

	/**
	 * Gets the count.
	 *
	 * @return the count
	 */
	public String getCount() {
		return count;
	}

	/**
	 * Sets the count.
	 *
	 * @param count the count to set
	 */
	public void setCount(String count) {
		this.count = count;
	}

	/**
	 * Gets the age qualifying code.
	 *
	 * @return the ageQualifyingCode
	 */
	public String getAgeQualifyingCode() {
		return ageQualifyingCode;
	}

	/**
	 * Sets the age qualifying code.
	 *
	 * @param ageQualifyingCode the ageQualifyingCode to set
	 */
	public void setAgeQualifyingCode(String ageQualifyingCode) {
		this.ageQualifyingCode = ageQualifyingCode;
	}
	  
	  
}
