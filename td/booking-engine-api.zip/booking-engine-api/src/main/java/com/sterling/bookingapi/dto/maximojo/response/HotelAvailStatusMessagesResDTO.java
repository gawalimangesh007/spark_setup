package com.sterling.bookingapi.dto.maximojo.response;

import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class HotelAvailStatusMessagesResDTO.
 * @author tcs
 * @version 1.0
 */
public class HotelAvailStatusMessagesResDTO {

	/** The avail status message. */
	@JacksonXmlElementWrapper(useWrapping = false, localName = "AvailStatusMessages")
	@JacksonXmlProperty(localName = "AvailStatusMessage")
	private List<HotelAvailStatusMessageResDTO> availStatusMessage;

	/** The hotel code. */
	@JacksonXmlProperty(localName = "HotelCode", isAttribute = true)
    private String hotelCode;

	/**
	 * Gets the avail status message.
	 *
	 * @return the availStatusMessage
	 */
	public List<HotelAvailStatusMessageResDTO> getAvailStatusMessage() {
		return availStatusMessage;
	}

	/**
	 * Sets the avail status message.
	 *
	 * @param availStatusMessage the availStatusMessage to set
	 */
	public void setAvailStatusMessage(List<HotelAvailStatusMessageResDTO> availStatusMessage) {
		this.availStatusMessage = availStatusMessage;
	}

	/**
	 * Gets the hotel code.
	 *
	 * @return the hotelCode
	 */
	public String getHotelCode() {
		return hotelCode;
	}

	/**
	 * Sets the hotel code.
	 *
	 * @param hotelCode the hotelCode to set
	 */
	public void setHotelCode(String hotelCode) {
		this.hotelCode = hotelCode;
	}
    
    
}
