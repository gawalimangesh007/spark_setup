package com.sterling.bookingapi.dto.response;

import java.util.Date;

import javax.persistence.Column;

import org.hibernate.validator.constraints.Email;

/**
 * @author tcs
 * @version 1.0
 */
public class UserDetailsResponseDTO {

	/** The user id. */
	private String userId;
	
	/** The first name. */
	private String firstName;
	
	/** The last name. */
	private String lastName;
	
	/** The email. */
	private String email;
	
	/** The phone number. */
	private String phoneNumber;
	
	/** The active. */
	private boolean active = true;

	/** The birth date. */
	private Date birthDate;
	
	/** The anniv date. */
	private Date annivDate;
	
	/** The recovery email. */
	private String recoveryEmail;
	
	/** The security quest one. */
	private String securityQuestOne;
	
	/** The security quest two. */
	private String securityQuestTwo;
	
	/** The security ans one. */
	private String securityAnsOne;
	
	/** The security ans two. */
	private String securityAnsTwo;
	
	/** The landline. */
	private String landline;
	
	/** The address. */
	private String address;
	
	/**
	 * Instantiates a new user details response DTO.
	 */
	public UserDetailsResponseDTO() {
		super();
	}
	
	
	/**
	 * Gets the email.
	 *
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}


	/**
	 * Sets the email.
	 *
	 * @param email the new email
	 */
	public void setEmail(String email) {
		this.email = email;
	}


	/**
	 * Gets the phone number.
	 *
	 * @return the phone number
	 */
	public String getPhoneNumber() {
		return phoneNumber;
	}


	/**
	 * Sets the phone number.
	 *
	 * @param phoneNumber the new phone number
	 */
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}


	/**
	 * Checks if is active.
	 *
	 * @return true, if is active
	 */
	public boolean isActive() {
		return active;
	}


	/**
	 * Sets the active.
	 *
	 * @param active the new active
	 */
	public void setActive(boolean active) {
		this.active = active;
	}


	/**
	 * Gets the birth date.
	 *
	 * @return the birth date
	 */
	public Date getBirthDate() {
		return birthDate;
	}


	/**
	 * Sets the birth date.
	 *
	 * @param birthDate the new birth date
	 */
	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}


	/**
	 * Gets the anniv date.
	 *
	 * @return the anniv date
	 */
	public Date getAnnivDate() {
		return annivDate;
	}


	/**
	 * Sets the anniv date.
	 *
	 * @param annivDate the new anniv date
	 */
	public void setAnnivDate(Date annivDate) {
		this.annivDate = annivDate;
	}


	/**
	 * Gets the recovery email.
	 *
	 * @return the recovery email
	 */
	public String getRecoveryEmail() {
		return recoveryEmail;
	}


	/**
	 * Sets the recovery email.
	 *
	 * @param recoveryEmail the new recovery email
	 */
	public void setRecoveryEmail(String recoveryEmail) {
		this.recoveryEmail = recoveryEmail;
	}


	/**
	 * Gets the security quest one.
	 *
	 * @return the security quest one
	 */
	public String getSecurityQuestOne() {
		return securityQuestOne;
	}


	/**
	 * Sets the security quest one.
	 *
	 * @param securityQuestOne the new security quest one
	 */
	public void setSecurityQuestOne(String securityQuestOne) {
		this.securityQuestOne = securityQuestOne;
	}


	/**
	 * Gets the security quest two.
	 *
	 * @return the security quest two
	 */
	public String getSecurityQuestTwo() {
		return securityQuestTwo;
	}


	/**
	 * Sets the security quest two.
	 *
	 * @param securityQuestTwo the new security quest two
	 */
	public void setSecurityQuestTwo(String securityQuestTwo) {
		this.securityQuestTwo = securityQuestTwo;
	}


	/**
	 * Gets the security ans one.
	 *
	 * @return the security ans one
	 */
	public String getSecurityAnsOne() {
		return securityAnsOne;
	}


	/**
	 * Sets the security ans one.
	 *
	 * @param securityAnsOne the new security ans one
	 */
	public void setSecurityAnsOne(String securityAnsOne) {
		this.securityAnsOne = securityAnsOne;
	}


	/**
	 * Gets the security ans two.
	 *
	 * @return the security ans two
	 */
	public String getSecurityAnsTwo() {
		return securityAnsTwo;
	}


	/**
	 * Sets the security ans two.
	 *
	 * @param securityAnsTwo the new security ans two
	 */
	public void setSecurityAnsTwo(String securityAnsTwo) {
		this.securityAnsTwo = securityAnsTwo;
	}


	/**
	 * Gets the landline.
	 *
	 * @return the landline
	 */
	public String getLandline() {
		return landline;
	}


	/**
	 * Sets the landline.
	 *
	 * @param landline the new landline
	 */
	public void setLandline(String landline) {
		this.landline = landline;
	}


	/**
	 * Gets the address.
	 *
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}


	/**
	 * Sets the address.
	 *
	 * @param address the new address
	 */
	public void setAddress(String address) {
		this.address = address;
	}


	/**
	 * Instantiates a new user details response DTO.
	 *
	 * @param userId the user id
	 * @param firstName the first name
	 * @param lastName the last name
	 * @param email the email
	 * @param phoneNumber the phone number
	 */
	public UserDetailsResponseDTO(String userId, String firstName, String lastName, String email, String phoneNumber) {
		this.userId = userId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.phoneNumber = phoneNumber;
	}
	
	
	/**
	 * Gets the user id.
	 *
	 * @return the user id
	 */
	public String getUserId() {
		return userId;
	}
	
	/**
	 * Sets the user id.
	 *
	 * @param userId the new user id
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}


	/**
	 * Gets the first name.
	 *
	 * @return the first name
	 */
	public String getFirstName() {
		return firstName;
	}


	/**
	 * Sets the first name.
	 *
	 * @param firstName the new first name
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	/**
	 * Gets the last name.
	 *
	 * @return the last name
	 */
	public String getLastName() {
		return lastName;
	}


	/**
	 * Sets the last name.
	 *
	 * @param lastName the new last name
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}	
}
