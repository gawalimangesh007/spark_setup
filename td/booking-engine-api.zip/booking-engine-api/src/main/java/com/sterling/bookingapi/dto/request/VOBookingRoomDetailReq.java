package com.sterling.bookingapi.dto.request;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author tcs
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class VOBookingRoomDetailReq implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String roomType;
	@JsonIgnore
	private String roomName;
	private Double roomPoints;
	private Double extraPersonCost;
	private Double extraChildCost;
	
	private Double adultCount;
	private Double childCount;
	private Double extraAdultCount;
	private Double extraChildCount;
	private Integer sequenceNo;
	private String roomCount;
	
	
	private VOExtarPersonDetailDTO extraCostDetail;
	private List<VOBookingPersonDetailReq> personDetails;
	
	
	public String getRoomCount() {
		return roomCount;
	}
	public void setRoomCount(String roomCount) {
		this.roomCount = roomCount;
	}
	/**
	 * @return room type
	 */
	public String getRoomType() {
		return roomType;
	}
	/**
	 * @param roomType
	 * set the room type
	 */
	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}
	/**
	 * @return room points
	 */
	public Double getRoomPoints() {
		return roomPoints;
	}
	/**
	 * @param roomPoints
	 * set the room points
	 */
	public void setRoomPoints(Double roomPoints) {
		this.roomPoints = roomPoints;
	}
	/**
	 * @return extra person cost
	 */
	public Double getExtraPersonCost() {
		return extraPersonCost;
	}
	/**
	 * @param extraPersonCost
	 * set extra person cost
	 */
	public void setExtraPersonCost(Double extraPersonCost) {
		this.extraPersonCost = extraPersonCost;
	}
	/**
	 * @return adult count
	 */
	public Double getAdultCount() {
		return adultCount;
	}
	/**
	 * @param adultCount
	 * set the adult count
	 */
	public void setAdultCount(Double adultCount) {
		this.adultCount = adultCount;
	}
	/**
	 * @return child count
	 */
	public Double getChildCount() {
		return childCount;
	}
	/**
	 * @param childCount
	 * set the child count
	 */
	public void setChildCount(Double childCount) {
		this.childCount = childCount;
	}
	/**
	 * @return extra adult count
	 */
	public Double getExtraAdultCount() {
		return extraAdultCount;
	}
	/**
	 * @param extraAdultCount
	 * set the extra adult count
	 */
	public void setExtraAdultCount(Double extraAdultCount) {
		this.extraAdultCount = extraAdultCount;
	}
	/**
	 * @return extra child count
	 */
	public Double getExtraChildCount() {
		return extraChildCount;
	}
	/**
	 * @param extraChildCount
	 * set the extra child count
	 */
	public void setExtraChildCount(Double extraChildCount) {
		this.extraChildCount = extraChildCount;
	}
	/**
	 * @return person details
	 */
	public List<VOBookingPersonDetailReq> getPersonDetails() {
		return personDetails;
	}
	/**
	 * @param personDetails
	 * set the person details
	 */
	public void setPersonDetails(List<VOBookingPersonDetailReq> personDetails) {
		this.personDetails = personDetails;
	}
	public Double getExtraChildCost() {
		return extraChildCost;
	}
	public void setExtraChildCost(Double extraChildCost) {
		this.extraChildCost = extraChildCost;
	}
	public Integer getSequenceNo() {
		return sequenceNo;
	}
	public void setSequenceNo(Integer sequenceNo) {
		this.sequenceNo = sequenceNo;
	}
	public VOExtarPersonDetailDTO getExtraCostDetail() {
		return extraCostDetail;
	}
	public void setExtraCostDetail(VOExtarPersonDetailDTO extraCostDetail) {
		this.extraCostDetail = extraCostDetail;
	}
	public String getRoomName() {
		return roomName;
	}
	public void setRoomName(String roomName) {
		this.roomName = roomName;
	}	
}
