package com.sterling.bookingapi.dto.response;

import java.io.Serializable;
import java.util.List;
/**
 * @author tcs
 * @version 1.0
 */
public class VODashboardResponse extends BaseRecord implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private List<HolidayDetails> holidayDetails;
	private List<BRWDto> brwDetails;
	private MemberDetails membershipDetails;
	private PointsDetails pointDetails;
	private PaymentDetails paymentDetails;
	private List<VOUsagePointsResponseDTO> usagePointsDetails;
	private List<VOOfferResponseDTO> welcomeOfferDetails;
	
	/**
	 * @return the holidayDetails
	 */
	public List<HolidayDetails> getHolidayDetails() {
		return holidayDetails;
	}
	/**
	 * @param holidayDetails the holidayDetails to set
	 */
	public void setHolidayDetails(List<HolidayDetails> holidayDetails) {
		this.holidayDetails = holidayDetails;
	}
	
	public List<BRWDto> getBrwDetails() {
		return brwDetails;
	}
	public void setBrwDetails(List<BRWDto> brwDetails) {
		this.brwDetails = brwDetails;
	}
	/**
	 * @return membershipDetails
	 */
	public MemberDetails getMembershipDetails() {
		return membershipDetails;
	}
	/**
	 * @param membershipDetails
	 * set the membershipDetails
	 */
	public void setMembershipDetails(MemberDetails membershipDetails) {
		this.membershipDetails = membershipDetails;
	}
	/**
	 * @return pointDetails
	 */
	public PointsDetails getPointDetails() {
		return pointDetails;
	}
	/**
	 * @param pointDetails
	 * set the pointDetails
	 */
	public void setPointDetails(PointsDetails pointDetails) {
		this.pointDetails = pointDetails;
	}
	/**
	 * @return paymentDetails
	 */
	public PaymentDetails getPaymentDetails() {
		return paymentDetails;
	}
	/**
	 * @param paymentDetails
	 * set the paymentDetails
	 */
	public void setPaymentDetails(PaymentDetails paymentDetails) {
		this.paymentDetails = paymentDetails;
	}
	/**
	 * @return usagePointsDetails
	 */
	public List<VOUsagePointsResponseDTO> getUsagePointsDetails() {
		return usagePointsDetails;
	}
	/**
	 * @param usagePointsDetails
	 * set the usagePointsDetails
	 */
	public void setUsagePointsDetails(
			List<VOUsagePointsResponseDTO> usagePointsDetails) {
		this.usagePointsDetails = usagePointsDetails;
	}
	public List<VOOfferResponseDTO> getWelcomeOfferDetails() {
		return welcomeOfferDetails;
	}
	public void setWelcomeOfferDetails(
			List<VOOfferResponseDTO> welcomeOfferDetails) {
		this.welcomeOfferDetails = welcomeOfferDetails;
	}
}
