package com.sterling.bookingapi.dto.request;

import java.io.Serializable;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.sterling.bookingapi.utils.AppConstants.ContactType;
import com.sterling.bookingapi.utils.AppConstants.RegisterUserType;

/**
 * @author tcs
 *
 */

public class VOForgotPassReq implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@NotEmpty(message = "Email/Mobile number is mandatory")
	private String value;
	
	@NotNull
	private ContactType type;
	
	private RegisterUserType userType;
	
	/**
	 * @return value
	 */
	public String getValue() {
		return value;
	}
	/**
	 * @param value
	 * set the value
	 */
	public void setValue(String value) {
		this.value = value;
	}
	/**
	 * @return type
	 */
	public ContactType getType() {
		return type;
	}
	/**
	 * @param type
	 * set the type
	 */
	public void setType(ContactType type) {
		this.type = type;
	}
	public RegisterUserType getUserType() {
		return userType;
	}
	public void setUserType(RegisterUserType userType) {
		this.userType = userType;
	}
	
}
