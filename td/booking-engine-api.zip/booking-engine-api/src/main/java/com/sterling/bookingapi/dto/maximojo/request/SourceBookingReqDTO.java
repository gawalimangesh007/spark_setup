package com.sterling.bookingapi.dto.maximojo.request;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class SourceBookingReqDTO.
 */
/**
 * @author tcs
 *
 */
public class SourceBookingReqDTO {
	
	/** The requestor ID. */
	@JacksonXmlProperty(localName = "RequestorID")
	private RequestorIDBookingReqDTO requestorID;

	/** The booking channel. */
	@JacksonXmlProperty(localName = "BookingChannel")
    private BookingChannelBookingReqDTO bookingChannel;

	/**
	 * Gets the requestor ID.
	 *
	 * @return the requestorID
	 */
	public RequestorIDBookingReqDTO getRequestorID() {
		return requestorID;
	}

	/**
	 * Sets the requestor ID.
	 *
	 * @param requestorID the requestorID to set
	 */
	public void setRequestorID(RequestorIDBookingReqDTO requestorID) {
		this.requestorID = requestorID;
	}

	/**
	 * Gets the booking channel.
	 *
	 * @return the bookingChannel
	 */
	public BookingChannelBookingReqDTO getBookingChannel() {
		return bookingChannel;
	}

	/**
	 * Sets the booking channel.
	 *
	 * @param bookingChannel the bookingChannel to set
	 */
	public void setBookingChannel(BookingChannelBookingReqDTO bookingChannel) {
		this.bookingChannel = bookingChannel;
	}
	
	

}
