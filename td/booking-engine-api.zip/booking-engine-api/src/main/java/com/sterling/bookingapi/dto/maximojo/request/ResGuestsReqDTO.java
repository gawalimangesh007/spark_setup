package com.sterling.bookingapi.dto.maximojo.request;

import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class ResGuestsReqDTO.
 */
/**
 * @author tcs
 *
 */
public class ResGuestsReqDTO {
	
	/** The primary indicator. */
	@JacksonXmlProperty(localName = "PrimaryIndicator", isAttribute = true)
    private boolean primaryIndicator;
	
	/** The res guest RPH. */
	@JacksonXmlProperty(localName = "ResGuestRPH", isAttribute = true)
	    private int resGuestRPH;

	/** The profile info. */
	@JacksonXmlElementWrapper(useWrapping=true,localName = "Profiles")
	@JacksonXmlProperty(localName = "ProfileInfo")
	    private List<ProfileInfoReqDTO> profileInfo;


	/**
	 * Gets the res guest RPH.
	 *
	 * @return the resGuestRPH
	 */
	public int getResGuestRPH() {
		return resGuestRPH;
	}

	/**
	 * Sets the res guest RPH.
	 *
	 * @param resGuestRPH the resGuestRPH to set
	 */
	public void setResGuestRPH(int resGuestRPH) {
		this.resGuestRPH = resGuestRPH;
	}

	/**
	 * Gets the profile info.
	 *
	 * @return the profileInfo
	 */
	public List<ProfileInfoReqDTO> getProfileInfo() {
		return profileInfo;
	}

	/**
	 * Sets the profile info.
	 *
	 * @param profileInfo the profileInfo to set
	 */
	public void setProfileInfo(List<ProfileInfoReqDTO> profileInfo) {
		this.profileInfo = profileInfo;
	}

	/**
	 * Gets the primary indicator.
	 *
	 * @return the primaryIndicator
	 */
	public boolean getPrimaryIndicator() {
		return primaryIndicator;
	}

	/**
	 * Sets the primary indicator.
	 *
	 * @param primaryIndicator the primaryIndicator to set
	 */
	public void setPrimaryIndicator(boolean primaryIndicator) {
		this.primaryIndicator = primaryIndicator;
	}
	
	
}
