package com.sterling.bookingapi.dto;



/**
 * The Class ResortRoomMappingDTO.
 */
/**
 * @author tcs
 *
 */
public class ResortRoomMappingDTO {

	/** The room type id. */
	private String roomTypeId;
	
	/** The resort id. */
	private String resortId;
	
	/**
	 * Gets the room type id.
	 *
	 * @return the roomTypeId
	 */
	public String getRoomTypeId() {
		return roomTypeId;
	}
	
	/**
	 * Sets the room type id.
	 *
	 * @param roomTypeId the roomTypeId to set
	 */
	public void setRoomTypeId(String roomTypeId) {
		this.roomTypeId = roomTypeId;
	}
	
	/**
	 * Gets the resort id.
	 *
	 * @return the resortId
	 */
	public String getResortId() {
		return resortId;
	}
	
	/**
	 * Sets the resort id.
	 *
	 * @param resortId the resortId to set
	 */
	public void setResortId(String resortId) {
		this.resortId = resortId;
	}

	
}
