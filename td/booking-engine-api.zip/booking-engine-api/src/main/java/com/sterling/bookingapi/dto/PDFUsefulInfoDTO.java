package com.sterling.bookingapi.dto;

import java.io.Serializable;

public class PDFUsefulInfoDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String usefulInfoItem;
	
	public PDFUsefulInfoDTO() {
		super();
	}

	
	public PDFUsefulInfoDTO(String usefulInfoItem) {
		super();
		this.usefulInfoItem = usefulInfoItem;
	}


	public String getUsefulInfoItem() {
		return usefulInfoItem;
	}

	public void setUsefulInfoItem(String usefulInfoItem) {
		this.usefulInfoItem = usefulInfoItem;
	}

}
