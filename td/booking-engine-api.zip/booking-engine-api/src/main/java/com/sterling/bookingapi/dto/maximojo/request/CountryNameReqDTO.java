package com.sterling.bookingapi.dto.maximojo.request;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class CountryNameReqDTO.
 */
/**
 * @author tcs
 *
 */
public class CountryNameReqDTO {

	/** The Code. */
	@JacksonXmlProperty(localName = "Code", isAttribute = true)
	 private String Code;

	/**
	 * Gets the code.
	 *
	 * @return the code
	 */
	public String getCode() {
		return Code;
	}

	/**
	 * Sets the code.
	 *
	 * @param code the code to set
	 */
	public void setCode(String code) {
		Code = code;
	}
	
	
}
