package com.sterling.bookingapi.dto.response;

import java.io.Serializable;
import java.util.List;

import javax.validation.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sterling.bookingapi.utils.AppConstants.RegisterUserType;

/**
 * @author tcs
 * @version 1.0
 */
public class VOCustomerPersonalDetails extends BaseRecord implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@NotEmpty(message = "Contract id should not be empty")
	private String contractId;
	
	@NotEmpty(message = "Sterling contract id should not be empty")
	private String sterlingContractId;
	private String memberId;
	
	private String profileImage;
	private String title;
	private String firstName;
	private String lastName;
	private String gender;
	private String maritalStatus;
	private String dob;
	private String weddingDay;
	
//	@Size(min = 10,max = 10)
	private String mobileNumber;
	
	private String alternateMobileNumber;
	
	private String contactEmail;
	
	private String alternateEmail;
	
	private String fixedLineNumber;
	private String alternateFixedLine;
	private String customerState;
	private boolean marketEmailOption; 
	private boolean marketPhoneOption; 

	private AddressDTO permanentAddress;
	private AddressDTO correspondenceAddress;
	private List<PersonDetailsDTO> dependentsDetails;
	private CoApplicantDetailsDTO coApplicantDetails;
	
	private String interestDetails;
	private String travellerInfo;
	
	private Preferences preferences;
	private VOCustomer customer;
	private String lastLogin;
	
	private String otp;
	
	@JsonIgnore
	private String oldPasswordOne;
	@JsonIgnore
	private String oldPasswordTwo;
	@JsonIgnore
	private String password;
	
	private String webStatus;
	private String country;

	private boolean mailFlag;
	
	@JsonIgnore
	RegisterUserType userType;

	@JsonIgnore
	private String memberStatus;
	
	
	public String getMemberId() {
		return memberId;
	}
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}
	public String getMemberStatus() {
		return memberStatus;
	}
	public void setMemberStatus(String memberStatus) {
		this.memberStatus = memberStatus;
	}
	public boolean getMailFlag() {
		return mailFlag;
	}
	public void setMailFlag(boolean mailFlag) {
		this.mailFlag = mailFlag;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public RegisterUserType getUserType() {
		return userType;
	}
	public void setUserType(RegisterUserType userType) {
		this.userType = userType;
	}
	public String getLastLogin() {
		return lastLogin;
	}
	public void setLastLogin(String lastLogin) {
		this.lastLogin = lastLogin;
	}
	/**
	 * @return sterlingContractId
	 */
	public String getSterlingContractId() {
		return sterlingContractId;
	}
	/**
	 * @param sterlingContractId
	 * set the sterlingContractId
	 */
	public void setSterlingContractId(String sterlingContractId) {
		this.sterlingContractId = sterlingContractId;
	}
	/**
	 * @return contractId
	 */
	public String getContractId() {
		return contractId;
	}
	/**
	 * @param contractId
	 * set the contractId
	 */
	public void setContractId(String contractId) {
		this.contractId = contractId;
	}
	/**
	 * @return title
	 */
	public String getTitle() {
		return title;
	}
	/**
	 * @param title
	 * set the title
	 */
	public void setTitle(String title) {
		this.title = title;
	}
	/**
	 * @return firstName
	 */
	public String getFirstName() {
		return firstName;
	}
	/**
	 * @param firstName
	 * set the firstName
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	/**
	 * @return lastName
	 */
	public String getLastName() {
		return lastName;
	}
	/**
	 * @param lastName
	 * set the lastName
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	/**
	 * @return gender
	 */
	public String getGender() {
		return gender;
	}
	/**
	 * @param gender
	 * set the gender
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}
	/**
	 * @return maritalStatus
	 */
	public String getMaritalStatus() {
		return maritalStatus;
	}
	/**
	 * @param maritalStatus
	 * set the maritalStatus
	 */
	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}
	/**
	 * @return dob
	 */
	public String getDob() {
		return dob;
	}
	/**
	 * @param dob
	 * set the dob
	 */
	public void setDob(String dob) {
		this.dob = dob;
	}
	/** 
	 * @return weddingDay
	 */
	public String getWeddingDay() {
		return weddingDay;
	}
	/**
	 * @param weddingDay
	 * set the weddingDay
	 */
	public void setWeddingDay(String weddingDay) {
		this.weddingDay = weddingDay;
	}
	/**
	 * @return mobileNumber
	 */
	public String getMobileNumber() {
		return mobileNumber;
	}
	/**
	 * @param mobileNumber
	 * set the mobileNumber
	 */
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	/**
	 * @return alternateMobileNumber
	 */
	public String getAlternateMobileNumber() {
		return alternateMobileNumber;
	}
	/**
	 * @param alternateMobileNumber
	 * set the alternateMobileNumber
	 */
	public void setAlternateMobileNumber(String alternateMobileNumber) {
		this.alternateMobileNumber = alternateMobileNumber;
	}
	/**
	 * @return contactEmail
	 */
	public String getContactEmail() {
		return contactEmail;
	}
	/**
	 * @param contactEmail
	 * set the contactEmail
	 */
	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}
	/**
	 * @return alternateEmail
	 */
	public String getAlternateEmail() {
		return alternateEmail;
	}
	/**
	 * @param alternateEmail
	 * set the alternateEmail
	 */
	public void setAlternateEmail(String alternateEmail) {
		this.alternateEmail = alternateEmail;
	}
	/**
	 * @return fixedLineNumber
	 */
	public String getFixedLineNumber() {
		return fixedLineNumber;
	}
	/**
	 * @param fixedLineNumber
	 * set the fixedLineNumber
	 */
	public void setFixedLineNumber(String fixedLineNumber) {
		this.fixedLineNumber = fixedLineNumber;
	}
	/**
	 * @return alternateFixedLine
	 */
	public String getAlternateFixedLine() {
		return alternateFixedLine;
	}
	/**
	 * @param alternateFixedLine
	 * set the alternateFixedLine
	 */
	public void setAlternateFixedLine(String alternateFixedLine) {
		this.alternateFixedLine = alternateFixedLine;
	}
	/**
	 * @return permanentAddress
	 */
	public AddressDTO getPermanentAddress() {
		return permanentAddress;
	}
	/**
	 * @param permanentAddress
	 * set the permanentAddress
	 */
	public void setPermanentAddress(AddressDTO permanentAddress) {
		this.permanentAddress = permanentAddress;
	}
	/**
	 * @return correspondenceAddress
	 */
	public AddressDTO getCorrespondenceAddress() {
		return correspondenceAddress;
	}
	/**
	 * @param correspondenceAddress
	 * set the correspondenceAddress
	 */
	public void setCorrespondenceAddress(AddressDTO correspondenceAddress) {
		this.correspondenceAddress = correspondenceAddress;
	}
	/**
	 * @return dependentsDetails
	 */
	public List<PersonDetailsDTO> getDependentsDetails() {
		return dependentsDetails;
	}
	/**
	 * @param dependentsDetails
	 * set the dependentsDetails
	 */
	public void setDependentsDetails(List<PersonDetailsDTO> dependentsDetails) {
		this.dependentsDetails = dependentsDetails;
	}
	/**
	 * @return coApplicantDetails
	 */
	public CoApplicantDetailsDTO getCoApplicantDetails() {
		return coApplicantDetails;
	}
	public void setCoApplicantDetails(CoApplicantDetailsDTO coApplicantDetails) {
		this.coApplicantDetails = coApplicantDetails;
	}
	/**
	 * @return preferences
	 */
	public Preferences getPreferences() {
		return preferences;
	}
	/**
	 * @param preferences
	 * set the preferences
	 */
	public void setPreferences(Preferences preferences) {
		this.preferences = preferences;
	}
	/**
	 * @return profileImage
	 */
	public String getProfileImage() {
		return profileImage;
	}
	/**
	 * @param profileImage
	 * set the profileImage
	 */
	public void setProfileImage(String profileImage) {
		this.profileImage = profileImage;
	}
	
	/**
	 * @return customer
	 */
	public VOCustomer getCustomer() {
		return customer;
	}
	/**
	 * @param customer
	 * set the customer
	 */
	public void setCustomer(VOCustomer customer) {
		this.customer = customer;
	}
	public String getCustomerState() {
		return customerState;
	}
	public void setCustomerState(String customerState) {
		this.customerState = customerState;
	}
	public boolean isMarketEmailOption() {
		return marketEmailOption;
	}
	public void setMarketEmailOption(boolean marketEmailOption) {
		this.marketEmailOption = marketEmailOption;
	}
	public boolean isMarketPhoneOption() {
		return marketPhoneOption;
	}
	public void setMarketPhoneOption(boolean marketPhoneOption) {
		this.marketPhoneOption = marketPhoneOption;
	}
	public String getOtp() {
		return otp;
	}
	public void setOtp(String otp) {
		this.otp = otp;
	}
	public String getOldPasswordOne() {
		return oldPasswordOne;
	}
	public void setOldPasswordOne(String oldPasswordOne) {
		this.oldPasswordOne = oldPasswordOne;
	}
	public String getOldPasswordTwo() {
		return oldPasswordTwo;
	}
	public void setOldPasswordTwo(String oldPasswordTwo) {
		this.oldPasswordTwo = oldPasswordTwo;
	}
	public String getWebStatus() {
		return webStatus;
	}
	public void setWebStatus(String webStatus) {
		this.webStatus = webStatus;
	}
	public String getInterestDetails() {
		return interestDetails;
	}
	public void setInterestDetails(String interestDetails) {
		this.interestDetails = interestDetails;
	}
	public String getTravellerInfo() {
		return travellerInfo;
	}
	public void setTravellerInfo(String travellerInfo) {
		this.travellerInfo = travellerInfo;
	}
}
