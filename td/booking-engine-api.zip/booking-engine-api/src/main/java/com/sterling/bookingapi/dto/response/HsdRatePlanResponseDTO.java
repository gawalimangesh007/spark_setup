package com.sterling.bookingapi.dto.response;


/**
 * @author tcs
 * @version 1.0
 */
public class HsdRatePlanResponseDTO {
	
	/** The rate plan id. */
	private int ratePlanId;
	
	/** The rate plan. */
	private String ratePlan;
	
	/** The rate plan detail. */
	private String ratePlanDetail;
	
	/**
	 * Instantiates a new hsd rate plan response DTO.
	 *
	 * @param ratePlanId the rate plan id
	 * @param ratePlan the rate plan
	 * @param ratePlanDetail the rate plan detail
	 */
	public HsdRatePlanResponseDTO(int ratePlanId,String ratePlan,String ratePlanDetail){
		this.ratePlanId = ratePlanId;
		this.ratePlan = ratePlan;
		this.ratePlanDetail = ratePlanDetail;
	}
	
	/**
	 * Gets the rate plan id.
	 *
	 * @return the rate plan id
	 */
	public int getRatePlanId() {
		return ratePlanId;
	}
	
	/**
	 * Sets the rate plan id.
	 *
	 * @param ratePlanId the new rate plan id
	 */
	public void setRatePlanId(int ratePlanId) {
		this.ratePlanId = ratePlanId;
	}
	
	/**
	 * Gets the rate plan.
	 *
	 * @return the rate plan
	 */
	public String getRatePlan() {
		return ratePlan;
	}
	
	/**
	 * Sets the rate plan.
	 *
	 * @param ratePlan the new rate plan
	 */
	public void setRatePlan(String ratePlan) {
		this.ratePlan = ratePlan;
	}
	
	/**
	 * Gets the rate plan detail.
	 *
	 * @return the rate plan detail
	 */
	public String getRatePlanDetail() {
		return ratePlanDetail;
	}
	
	/**
	 * Sets the rate plan detail.
	 *
	 * @param ratePlanDetail the new rate plan detail
	 */
	public void setRatePlanDetail(String ratePlanDetail) {
		this.ratePlanDetail = ratePlanDetail;
	}
}