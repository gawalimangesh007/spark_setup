package com.sterling.bookingapi.dto.request;

import java.util.Date;
import java.util.List;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.sterling.bookingapi.utils.CustomJsonDateDeserializer;
import com.sterling.bookingapi.utils.CustomJsonTimeDeserializer;


/**
 * The Class HsdBookingRequestDTO.
 */
/**
 * @author tcs
 *
 */
public class HsdBookingRequestDTO {
	
	
	/** The user id. */
	private String userId;
	
	/** The booking for. */
	@NotNull(message="bookingFor should not be empty")
	private String bookingFor;
	
	/** The arrival date. */
	@NotNull(message="arrivalDate should not be empty")
	@JsonDeserialize(using = CustomJsonDateDeserializer.class)
	private Date arrivalDate;
	
	/** The departure date. */
	@NotNull(message="departureDate should not be empty")
	@JsonDeserialize(using = CustomJsonDateDeserializer.class)
	private Date departureDate;
	
	@JsonDeserialize(using = CustomJsonTimeDeserializer.class)
	private Date checkinTime;
	
	@JsonDeserialize(using = CustomJsonTimeDeserializer.class)
	private Date checkoutTime;
	
	/** The total nights. */
	@NotNull(message="totalNights should not be empty")
	private int totalNights;
	
	/** The enhancement detail. */
	private Object enhancementDetail;
	
	/** The enhancement detail. */
	private Object roomUpgradeDetail;
	
	/** The package details. */
	private Object packageDetails;
	
	/** The offer details. */
	private Object offerDetails;
	
	/** The booked date. */
	private Date bookedDate;
	
	/** The resort id. */
	@NotNull(message="resortId should not be empty")
	private String resortId;
	
	/** The hsd booking customers details. */
	private HsdBookingCustomerRequestDTO hsdBookingCustomersDetails;
	
	/** The hsd booking calc details. */
	private HsdBookingCalcDetailsRequestDTO hsdBookingCalcDetails;
	
	/** The hsd booking rooms details. */
	private List<HsdBookingRoomsRequestDTO> hsdBookingRoomsDetails;
	
	/**
	 * Gets the user id.
	 *
	 * @return the user id
	 */
	public String getUserId() {
		return userId;
	}
	
	/**
	 * Sets the user id.
	 *
	 * @param userId the new user id
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	/**
	 * Gets the booking for.
	 *
	 * @return the booking for
	 */
	public String getBookingFor() {
		return bookingFor;
	}
	
	/**
	 * Sets the booking for.
	 *
	 * @param bookingFor the new booking for
	 */
	public void setBookingFor(String bookingFor) {
		this.bookingFor = bookingFor;
	}
	
	/**
	 * Gets the arrival date.
	 *
	 * @return the arrival date
	 */
	public Date getArrivalDate() {
		return arrivalDate;
	}
	
	/**
	 * Sets the arrival date.
	 *
	 * @param arrivalDate the new arrival date
	 */
	public void setArrivalDate(Date arrivalDate) {
		this.arrivalDate = arrivalDate;
	}
	
	/**
	 * Gets the departure date.
	 *
	 * @return the departure date
	 */
	public Date getDepartureDate() {
		return departureDate;
	}
	
	/**
	 * Sets the departure date.
	 *
	 * @param departureDate the new departure date
	 */
	public void setDepartureDate(Date departureDate) {
		this.departureDate = departureDate;
	}
	
	/**
	 * Gets the total nights.
	 *
	 * @return the total nights
	 */
	public int getTotalNights() {
		return totalNights;
	}
	
	/**
	 * Sets the total nights.
	 *
	 * @param totalNights the new total nights
	 */
	public void setTotalNights(int totalNights) {
		this.totalNights = totalNights;
	}
	
	/**
	 * Gets the enhancement detail.
	 *
	 * @return the enhancement detail
	 */
	public Object getEnhancementDetail() {
		return enhancementDetail;
	}
	
	/**
	 * Sets the enhancement detail.
	 *
	 * @param enhancementDetail the new enhancement detail
	 */
	public void setEnhancementDetail(
Object enhancementDetail) {
		this.enhancementDetail = enhancementDetail;
	}
	
	/**
	 * Gets the package details.
	 *
	 * @return the package details
	 */
	public Object getPackageDetails() {
		return packageDetails;
	}
	
	/**
	 * Sets the package details.
	 *
	 * @param packageDetails the new package details
	 */
	public void setPackageDetails(Object packageDetails) {
		this.packageDetails = packageDetails;
	}
	
	/**
	 * Gets the offer details.
	 *
	 * @return the offer details
	 */
	public Object getOfferDetails() {
		return offerDetails;
	}
	
	/**
	 * Sets the offer details.
	 *
	 * @param offerDetails the new offer details
	 */
	public void setOfferDetails(Object offerDetails) {
		this.offerDetails = offerDetails;
	}
	
	/**
	 * Gets the booked date.
	 *
	 * @return the booked date
	 */
	public Date getBookedDate() {
		return bookedDate;
	}
	
	/**
	 * Sets the booked date.
	 *
	 * @param bookedDate the new booked date
	 */
	public void setBookedDate(Date bookedDate) {
		this.bookedDate = bookedDate;
	}
	
	/**
	 * Gets the hsd booking customers details.
	 *
	 * @return the hsd booking customers details
	 */
	public HsdBookingCustomerRequestDTO getHsdBookingCustomersDetails() {
		return hsdBookingCustomersDetails;
	}
	
	/**
	 * Sets the hsd booking customers details.
	 *
	 * @param hsdBookingCustomersDetails the new hsd booking customers details
	 */
	public void setHsdBookingCustomersDetails(
			HsdBookingCustomerRequestDTO hsdBookingCustomersDetails) {
		this.hsdBookingCustomersDetails = hsdBookingCustomersDetails;
	}
	
	/**
	 * Gets the hsd booking calc details.
	 *
	 * @return the hsd booking calc details
	 */
	public HsdBookingCalcDetailsRequestDTO getHsdBookingCalcDetails() {
		return hsdBookingCalcDetails;
	}
	
	/**
	 * Sets the hsd booking calc details.
	 *
	 * @param hsdBookingCalcDetails the new hsd booking calc details
	 */
	public void setHsdBookingCalcDetails(
			HsdBookingCalcDetailsRequestDTO hsdBookingCalcDetails) {
		this.hsdBookingCalcDetails = hsdBookingCalcDetails;
	}
	
	/**
	 * Gets the hsd booking rooms details.
	 *
	 * @return the hsd booking rooms details
	 */
	public List<HsdBookingRoomsRequestDTO> getHsdBookingRoomsDetails() {
		return hsdBookingRoomsDetails;
	}
	
	/**
	 * Sets the hsd booking rooms details.
	 *
	 * @param hsdBookingRoomsDetails the new hsd booking rooms details
	 */
	public void setHsdBookingRoomsDetails(
			List<HsdBookingRoomsRequestDTO> hsdBookingRoomsDetails) {
		this.hsdBookingRoomsDetails = hsdBookingRoomsDetails;
	}
	
	/**
	 * Gets the resort id.
	 *
	 * @return the resort id
	 */
	public String getResortId() {
		return resortId;
	}
	
	/**
	 * Sets the resort id.
	 *
	 * @param resortId the new resort id
	 */
	public void setResortId(String resortId) {
		this.resortId = resortId;
	}

	/**
	 * @return the checkinTime
	 */
	public Date getCheckinTime() {
		return checkinTime;
	}

	/**
	 * @param checkinTime the checkinTime to set
	 */
	public void setCheckinTime(Date checkinTime) {
		this.checkinTime = checkinTime;
	}

	/**
	 * @return the checkoutTime
	 */
	public Date getCheckoutTime() {
		return checkoutTime;
	}

	/**
	 * @param checkoutTime the checkoutTime to set
	 */
	public void setCheckoutTime(Date checkoutTime) {
		this.checkoutTime = checkoutTime;
	}

	public Object getRoomUpgradeDetail() {
		return roomUpgradeDetail;
	}

	public void setRoomUpgradeDetail(Object roomUpgradeDetail) {
		this.roomUpgradeDetail = roomUpgradeDetail;
	}
	
}