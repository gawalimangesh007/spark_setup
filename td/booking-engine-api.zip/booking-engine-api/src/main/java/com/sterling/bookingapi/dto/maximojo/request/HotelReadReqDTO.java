package com.sterling.bookingapi.dto.maximojo.request;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class HotelReadReqDTO.
 */
/**
 * @author tcs
 *
 */
public class HotelReadReqDTO {

	/** The hotel code. */
	@JacksonXmlProperty(localName = "xmlns", isAttribute = true)
	private String hotelCode;

	/** The selection criteria. */
	@JacksonXmlProperty(localName = "SelectionCriteria")
    private SelectionCriteriaReqDTO selectionCriteria;

	/**
	 * Gets the hotel code.
	 *
	 * @return the hotelCode
	 */
	public String getHotelCode() {
		return hotelCode;
	}

	/**
	 * Sets the hotel code.
	 *
	 * @param hotelCode the hotelCode to set
	 */
	public void setHotelCode(String hotelCode) {
		this.hotelCode = hotelCode;
	}

	/**
	 * Gets the selection criteria.
	 *
	 * @return the selectionCriteria
	 */
	public SelectionCriteriaReqDTO getSelectionCriteria() {
		return selectionCriteria;
	}

	/**
	 * Sets the selection criteria.
	 *
	 * @param selectionCriteria the selectionCriteria to set
	 */
	public void setSelectionCriteria(SelectionCriteriaReqDTO selectionCriteria) {
		this.selectionCriteria = selectionCriteria;
	}
	
	
}
