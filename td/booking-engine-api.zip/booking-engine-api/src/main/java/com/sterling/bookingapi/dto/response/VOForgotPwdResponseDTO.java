package com.sterling.bookingapi.dto.response;

import java.io.Serializable;

/**
 * @author tcs
 * @version 1.0
 */
public class VOForgotPwdResponseDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String email;
	
	public VOForgotPwdResponseDTO(String email) {
		super();
		this.email = email;
	}
	/**
	 * @return email
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * @param email
	 * set the email
	 */
	public void setEmail(String email) {
		this.email = email;
	}
}
