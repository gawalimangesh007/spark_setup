package com.sterling.bookingapi.dto.request;

import java.io.Serializable;

import javax.validation.constraints.NotEmpty;


/**
 * @author tcs
 * @version 1.0
 *
 */
public class HsdLoginRequestDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	@NotEmpty
	private String email;
	@NotEmpty
	private String password;
	
	/**
	 * @return email
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * @param email
	 * set the email
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	/**
	 * @return password
	 */
	public String getPassword() {
		return password;
	}
	/**
	 * @param password
	 * set the password
	 */
	public void setPassword(String password) {
		this.password = password;
	}
}
