package com.sterling.bookingapi.dto.maximojo.request;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class HotelReservationIDReqDTO.
 */
/**
 * @author tcs
 *
 */
public class HotelReservationIDReqDTO {

	/** The for guest. */
	@JacksonXmlProperty(localName = "ForGuest", isAttribute = true)
    private boolean forGuest;
	
	/** The res I D type. */
	@JacksonXmlProperty(localName = "ResID_Type", isAttribute = true)
	private int resID_Type;
	
	/** The res I D value. */
	@JacksonXmlProperty(localName = "ResID_Value", isAttribute = true)
    private String resID_Value;

	/**
	 * Gets the res I D type.
	 *
	 * @return the resID_Type
	 */
	public int getResID_Type() {
		return resID_Type;
	}

	/**
	 * Sets the res I D type.
	 *
	 * @param resID_Type the resID_Type to set
	 */
	public void setResID_Type(int resID_Type) {
		this.resID_Type = resID_Type;
	}


	/**
	 * Gets the res I D value.
	 *
	 * @return the res I D value
	 */
	public String getResID_Value() {
		return resID_Value;
	}

	/**
	 * Sets the res I D value.
	 *
	 * @param resID_Value the new res I D value
	 */
	public void setResID_Value(String resID_Value) {
		this.resID_Value = resID_Value;
	}

	/**
	 * Gets the for guest.
	 *
	 * @return the forGuest
	 */
	public boolean getForGuest() {
		return forGuest;
	}

	/**
	 * Sets the for guest.
	 *
	 * @param forGuest the forGuest to set
	 */
	public void setForGuest(boolean forGuest) {
		this.forGuest = forGuest;
	}
	
	

}
