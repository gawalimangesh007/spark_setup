package com.sterling.bookingapi.dto.response;

import java.util.Date;
import java.util.List;

import com.sterling.bookingapi.dto.HsdBookingPaymentDTO;
import com.sterling.bookingapi.utils.AppConstants;

/**
 * @author tcs
 * @version 1.0
 */
public class HsdBookingDetailsResponseDTO {
	
	/** The booking id. */
	private String bookingId;
	
	/** The user id. */
	private String userId;
	
	/** The user type. */
	private String userType;
	
	/** The booking for. */
	private String bookingFor;
	
	/** The arrival date. */
	private Date arrivalDate;
	
	/** The departure date. */
	private Date departureDate;
	
	private Date checkinTime;
	private Date checkoutTime;
	
	/** The adult count. */
	private int adultCount;
	
	/** The child count. */
	private int childCount;
	
	/** The total days. */
	private int totalDays;
	
	/** The total nights. */
	private int totalNights;
	
	/** The enhancement detail. */
	private String enhancementDetail;
	
	/** The roomUpgrade detail. */
	private String roomUpgradeDetail;
	
	/** The booked date. */
	private Date bookedDate;
	
	/** The package details. */
	private String packageDetails;

	/** The package name. */
	private String packageName;
	
	/** The offer details. */
	private String offerDetails;
	
	/** The maximojo sync date. */
	private Date maximojoSyncDate;
	
	/** The booking status. */
	private AppConstants.BookingStatus bookingStatus;
	
	/** The resort id. */
	private String resortId;
	
	/** The resort name. */
	private String resortName;
		
	/** The active. */
	private boolean active;
	
	/** The calc details. */
	private HsdBookingCalcDetailsResponseDTO calcDetails;
	
	/** The room details. */
	private List<HsdBookingRoomDetailsResponseDTO> roomDetails;
	
	/** The booking customer profile. */
	private HsdBookingCustomerProfileDetailsResponseDTO bookingCustomerProfile;

	/** The payment details. */
	private HsdBookingPaymentDTO paymentDetails;
	
	/**
	 * Gets the payment details.
	 *
	 * @return the payment details
	 */
	public HsdBookingPaymentDTO getPaymentDetails() {
		return paymentDetails;
	}

	/**
	 * Sets the payment details.
	 *
	 * @param paymentDetails the new payment details
	 */
	public void setPaymentDetails(HsdBookingPaymentDTO paymentDetails) {
		this.paymentDetails = paymentDetails;
	}

	/**
	 * Gets the booking id.
	 *
	 * @return the booking id
	 */
	public String getBookingId() {
		return bookingId;
	}

	/**
	 * Sets the booking id.
	 *
	 * @param bookingId the new booking id
	 */
	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}

	/**
	 * Gets the user id.
	 *
	 * @return the user id
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * Sets the user id.
	 *
	 * @param userId the new user id
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * Gets the user type.
	 *
	 * @return the user type
	 */
	public String getUserType() {
		return userType;
	}

	/**
	 * Sets the user type.
	 *
	 * @param userType the new user type
	 */
	public void setUserType(String userType) {
		this.userType = userType;
	}

	/**
	 * Gets the booking for.
	 *
	 * @return the booking for
	 */
	public String getBookingFor() {
		return bookingFor;
	}

	/**
	 * Sets the booking for.
	 *
	 * @param bookingFor the new booking for
	 */
	public void setBookingFor(String bookingFor) {
		this.bookingFor = bookingFor;
	}

	/**
	 * Gets the arrival date.
	 *
	 * @return the arrival date
	 */
	public Date getArrivalDate() {
		return arrivalDate;
	}

	/**
	 * Sets the arrival date.
	 *
	 * @param arrivalDate the new arrival date
	 */
	public void setArrivalDate(Date arrivalDate) {
		this.arrivalDate = arrivalDate;
	}

	/**
	 * Gets the departure date.
	 *
	 * @return the departure date
	 */
	public Date getDepartureDate() {
		return departureDate;
	}

	/**
	 * Sets the departure date.
	 *
	 * @param departureDate the new departure date
	 */
	public void setDepartureDate(Date departureDate) {
		this.departureDate = departureDate;
	}

	/**
	 * Gets the adult count.
	 *
	 * @return the adult count
	 */
	public int getAdultCount() {
		return adultCount;
	}

	/**
	 * Sets the adult count.
	 *
	 * @param adultCount the new adult count
	 */
	public void setAdultCount(int adultCount) {
		this.adultCount = adultCount;
	}

	/**
	 * Gets the child count.
	 *
	 * @return the child count
	 */
	public int getChildCount() {
		return childCount;
	}

	/**
	 * Sets the child count.
	 *
	 * @param childCount the new child count
	 */
	public void setChildCount(int childCount) {
		this.childCount = childCount;
	}

	/**
	 * Gets the total days.
	 *
	 * @return the total days
	 */
	public int getTotalDays() {
		return totalDays;
	}

	/**
	 * Sets the total days.
	 *
	 * @param totalDays the new total days
	 */
	public void setTotalDays(int totalDays) {
		this.totalDays = totalDays;
	}

	/**
	 * Gets the total nights.
	 *
	 * @return the total nights
	 */
	public int getTotalNights() {
		return totalNights;
	}

	/**
	 * Sets the total nights.
	 *
	 * @param totalNights the new total nights
	 */
	public void setTotalNights(int totalNights) {
		this.totalNights = totalNights;
	}

	/**
	 * Gets the enhancement detail.
	 *
	 * @return the enhancement detail
	 */
	public String getEnhancementDetail() {
		return enhancementDetail;
	}

	/**
	 * Sets the enhancement detail.
	 *
	 * @param enhancementDetail the new enhancement detail
	 */
	public void setEnhancementDetail(String enhancementDetail) {
		this.enhancementDetail = enhancementDetail;
	}

	/**
	 * Gets the booked date.
	 *
	 * @return the booked date
	 */
	public Date getBookedDate() {
		return bookedDate;
	}

	/**
	 * Sets the booked date.
	 *
	 * @param bookedDate the new booked date
	 */
	public void setBookedDate(Date bookedDate) {
		this.bookedDate = bookedDate;
	}

	/**
	 * Gets the package details.
	 *
	 * @return the package details
	 */
	public String getPackageDetails() {
		return packageDetails;
	}

	/**
	 * Sets the package details.
	 *
	 * @param packageDetails the new package details
	 */
	public void setPackageDetails(String packageDetails) {
		this.packageDetails = packageDetails;
	}

	/**
	 * Gets the offer details.
	 *
	 * @return the offer details
	 */
	public String getOfferDetails() {
		return offerDetails;
	}

	/**
	 * Sets the offer details.
	 *
	 * @param offerDetails the new offer details
	 */
	public void setOfferDetails(String offerDetails) {
		this.offerDetails = offerDetails;
	}

	/**
	 * Gets the maximojo sync date.
	 *
	 * @return the maximojo sync date
	 */
	public Date getMaximojoSyncDate() {
		return maximojoSyncDate;
	}

	/**
	 * Sets the maximojo sync date.
	 *
	 * @param maximojoSyncDate the new maximojo sync date
	 */
	public void setMaximojoSyncDate(Date maximojoSyncDate) {
		this.maximojoSyncDate = maximojoSyncDate;
	}

	/**
	 * Gets the calc details.
	 *
	 * @return the calc details
	 */
	public HsdBookingCalcDetailsResponseDTO getCalcDetails() {
		return calcDetails;
	}

	/**
	 * Sets the calc details.
	 *
	 * @param calcDetails the new calc details
	 */
	public void setCalcDetails(HsdBookingCalcDetailsResponseDTO calcDetails) {
		this.calcDetails = calcDetails;
	}

	/**
	 * Gets the room details.
	 *
	 * @return the room details
	 */
	public List<HsdBookingRoomDetailsResponseDTO> getRoomDetails() {
		return roomDetails;
	}

	/**
	 * Sets the room details.
	 *
	 * @param roomDetails the new room details
	 */
	public void setRoomDetails(List<HsdBookingRoomDetailsResponseDTO> roomDetails) {
		this.roomDetails = roomDetails;
	}

	/**
	 * Gets the booking customer profile.
	 *
	 * @return the booking customer profile
	 */
	public HsdBookingCustomerProfileDetailsResponseDTO getBookingCustomerProfile() {
		return bookingCustomerProfile;
	}

	/**
	 * Sets the booking customer profile.
	 *
	 * @param bookingCustomerProfile the new booking customer profile
	 */
	public void setBookingCustomerProfile(
			HsdBookingCustomerProfileDetailsResponseDTO bookingCustomerProfile) {
		this.bookingCustomerProfile = bookingCustomerProfile;
	}

	/**
	 * Gets the booking status.
	 *
	 * @return the booking status
	 */
	public AppConstants.BookingStatus getBookingStatus() {
		return bookingStatus;
	}

	/**
	 * Sets the booking status.
	 *
	 * @param bookingStatus the new booking status
	 */
	public void setBookingStatus(AppConstants.BookingStatus bookingStatus) {
		this.bookingStatus = bookingStatus;
	}

	/**
	 * Gets the resort id.
	 *
	 * @return the resort id
	 */
	public String getResortId() {
		return resortId;
	}

	/**
	 * Sets the resort id.
	 *
	 * @param resortId the new resort id
	 */
	public void setResortId(String resortId) {
		this.resortId = resortId;
	}

	/**
	 * Gets the resort name.
	 *
	 * @return the resort name
	 */
	public String getResortName() {
		return resortName;
	}

	/**
	 * Sets the resort name.
	 *
	 * @param resortName the new resort name
	 */
	public void setResortName(String resortName) {
		this.resortName = resortName;
	}

	/**
	 * Checks if is active.
	 *
	 * @return true, if is active
	 */
	public boolean isActive() {
		return active;
	}

	/**
	 * Sets the active.
	 *
	 * @param active the new active
	 */
	public void setActive(boolean active) {
		this.active = active;
	}

	/**
	 * @return the checkinTime
	 */
	public Date getCheckinTime() {
		return checkinTime;
	}

	/**
	 * @param checkinTime the checkinTime to set
	 */
	public void setCheckinTime(Date checkinTime) {
		this.checkinTime = checkinTime;
	}

	/**
	 * @return the checkoutTime
	 */
	public Date getCheckoutTime() {
		return checkoutTime;
	}

	/**
	 * @param checkoutTime the checkoutTime to set
	 */
	public void setCheckoutTime(Date checkoutTime) {
		this.checkoutTime = checkoutTime;
	}

	public String getPackageName() {
		return packageName;
	}

	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}

	public String getRoomUpgradeDetail() {
		return roomUpgradeDetail;
	}

	public void setRoomUpgradeDetail(String roomUpgradeDetail) {
		this.roomUpgradeDetail = roomUpgradeDetail;
	}
	
}
