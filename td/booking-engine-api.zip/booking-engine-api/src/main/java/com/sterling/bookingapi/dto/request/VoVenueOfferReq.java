package com.sterling.bookingapi.dto.request;

import java.io.Serializable;

import javax.validation.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author tcs
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class VoVenueOfferReq implements Serializable{
	private static final long serialVersionUID = 1L;
	@NotEmpty(message = "Vouchercode id should not be empty")
	private String voucherCode;

	/**
	 * @return vouchercode
	 */
	public String getVoucherCode() {
		return voucherCode;
	}

	/**
	 * @param voucherCode
	 * set the vouchercode
	 */
	public void setVoucherCode(String voucherCode) {
		this.voucherCode = voucherCode;
	}
}
