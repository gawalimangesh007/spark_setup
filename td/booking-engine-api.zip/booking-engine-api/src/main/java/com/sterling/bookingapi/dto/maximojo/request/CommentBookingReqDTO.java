package com.sterling.bookingapi.dto.maximojo.request;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class CommentBookingReqDTO.
 */
/**
 * @author tcs
 *
 */
public class CommentBookingReqDTO {
	
	 /** The guest viewable. */
 	@JacksonXmlProperty(localName = "GuestViewable", isAttribute = true)
	 private boolean guestViewable;
	
	 /** The text. */
 	@JacksonXmlProperty(localName = "Text")
	 private TextReqDTO text;

	/**
	 * Gets the text.
	 *
	 * @return the text
	 */
	public TextReqDTO getText() {
		return text;
	}

	/**
	 * Sets the text.
	 *
	 * @param text the new text
	 */
	public void setText(TextReqDTO text) {
		this.text = text;
	}

	/**
	 * Checks if is guest viewable.
	 *
	 * @return true, if is guest viewable
	 */
	public boolean isGuestViewable() {
		return guestViewable;
	}

	/**
	 * Sets the guest viewable.
	 *
	 * @param guestViewable the new guest viewable
	 */
	public void setGuestViewable(boolean guestViewable) {
		this.guestViewable = guestViewable;
	}

	
}
