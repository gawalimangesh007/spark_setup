package com.sterling.bookingapi.controller;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.sterling.bookingapi.dto.request.HsdBookingRequestDTO;
import com.sterling.bookingapi.dto.request.HsdCheckAvailabilityRequestDTO;
import com.sterling.bookingapi.dto.request.HsdGetBookingDetailsDTO;
import com.sterling.bookingapi.dto.response.ResponseDTO;
import com.sterling.bookingapi.exception.BookingEngineException;
import com.sterling.bookingapi.service.HsdBookingService;


/**
 * The Class HsdBookingController.
 */
/**
 * @author tcs
 *
 */
@RestController
@RequestMapping(value = "/hsd/booking")
public class HsdBookingController extends BaseController {

	/** The Constant logger. */
	private static final Logger logger = LogManager.getLogger(HsdBookingController.class);

	/** The hsd booking service. */
	@Autowired 
	private HsdBookingService hsdBookingService;
	
	/**
	 * Check availability.
	 *
	 * @param reqeust the reqeust
	 * @return the response DTO
	 * @throws BookingEngineException the booking engine exception
	 */
	@ResponseBody
	@RequestMapping(value = "/checkAvail", method = RequestMethod.POST)
	public ResponseDTO checkAvailability(@RequestBody final HsdCheckAvailabilityRequestDTO reqeust) throws BookingEngineException {
		logger.info(" HsdBookingController : checkAvailability : Entered.");
		ResponseDTO response = hsdBookingService.checkAvailability(reqeust);

		logger.info(" HsdBookingController : checkAvailability : Leaving.");
		return response;
	}

	/**
	 * Gets the booking details by id.
	 *
	 * @param bookingId the booking id
	 * @return the booking details by id
	 * @throws BookingEngineException the booking engine exception
	 */

	@ResponseBody
    @RequestMapping(value = "/get/Id", method = RequestMethod.GET)
	public ResponseDTO getBookingDetailsById(@Valid @RequestParam final String bookingId)throws BookingEngineException {
		logger.info("HsdBookingController : getBookingDetailsById : Entered.");
        ResponseDTO response = hsdBookingService.getBookingDetailsById(bookingId);
        logger.info("HsdBookingController : getBookingDetailsById : leaving.");
        return response;
    }
	
	/**
	 * Gets the booking details by user.
	 *
	 * @param userId the user id
	 * @return the booking details by user
	 * @throws BookingEngineException the booking engine exception
	 */
	//Commenting on 23/10/2017 for SF change
	/*@ResponseBody
    @RequestMapping(value = "/get/ByUser", method = RequestMethod.GET)
	public ResponseDTO getBookingDetailsByUser(@Valid @RequestParam final String userId)throws BookingEngineException {
		logger.info("HsdBookingController : getBookingDetailsById : Entered.");
        ResponseDTO response = hsdBookingService.getBookingDetailsByUser(userId);
        logger.info("HsdBookingController : getBookingDetailsById : leaving.");
        return response;
    }*/
	
	/**
	 * Creates the booking.
	 *
	 * @param reqeust the reqeust
	 * @return the response DTO
	 * @throws BookingEngineException the booking engine exception
	 */
	@ResponseBody
    @RequestMapping(value = "/createBooking", method = RequestMethod.POST)
	public ResponseDTO createBooking(@Valid @RequestBody final HsdBookingRequestDTO reqeust) throws BookingEngineException {
		logger.info("HsdBookingController : createBooking : Entered.");
		ResponseDTO response = hsdBookingService.createBooking(reqeust);
        logger.info("HsdBookingController : createBooking : leaving.");
        return response;
    }
	
	/**
	 * Download pdf.
	 *
	 * @param bookingId the booking id
	 * @return the response entity
	 * @throws BookingEngineException the booking engine exception
	 */
   
  	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public ResponseEntity<byte[]> downloadPdf(@PathVariable("id") String bookingId) throws BookingEngineException {
		  logger.info("HsdBookingController : downloadPdf : Entered.");
		HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.parseMediaType("application/pdf"));
	    
	    String filename = bookingId+".pdf";
	    
	    byte[] contents = hsdBookingService.getPDFContents(bookingId);
	    
	    headers.setContentDispositionFormData(filename, filename);
	    
	    headers.setCacheControl("must-revalidate, post-check=0, pre-check=0");
	    
	   
		ResponseEntity<byte[]> response = new ResponseEntity<>(contents, headers, HttpStatus.OK);
		  logger.info("HsdBookingController : downloadPdf : leaving.");
		return response;
	}
	
	/**
	 * Cancel booking.
	 *
	 * @param bookingId the booking id
	 * @return the response DTO
	 * @throws BookingEngineException the booking engine exception
	 */
	@ResponseBody
    @RequestMapping(value = "/cancelBooking", method = RequestMethod.POST)
	public ResponseDTO cancelBooking(@RequestBody HsdGetBookingDetailsDTO hsdGetBookingDetailsDTO)throws BookingEngineException {
		logger.info("HsdBookingController : cancelBooking : Entered.");
        ResponseDTO response = hsdBookingService.cancelBooking(hsdGetBookingDetailsDTO.getBookingId());
        logger.info("HsdBookingController : cancelBooking : leaving.");
        return response;
    }
	
	/**
	 * Send Email for specified users.
	 *
	 * @param bookingId the booking id
	 * @return the response DTO
	 * @throws BookingEngineException the booking engine exception
	 */
	@ResponseBody
    @RequestMapping(value = "/sendEmail", method = RequestMethod.GET)
	public void sendMailTrigger(@Valid @RequestParam final String bookingId, @Valid @RequestParam final String emailId)throws BookingEngineException {
		logger.info("HsdBookingController : sendEmail : Entered.");
        hsdBookingService.sendEmail(bookingId,emailId);
        logger.info("HsdBookingController : sendEmail : leaving.");
    }


}
