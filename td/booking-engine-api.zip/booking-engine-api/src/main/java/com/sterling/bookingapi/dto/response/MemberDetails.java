package com.sterling.bookingapi.dto.response;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author tcs
 * @version 1.0
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class MemberDetails implements Serializable  {
	
	private static final long serialVersionUID = 1L;

	private String rciMembershipId;
	private String rciMembershipEndDate;

	private String memberID;

	private String weekStartDate;
	private String weekNo;
	private String apartmentType;
	
	private String roomType;
	
	private String resortId;
	private String resortName;
	
	private String holidayEligibilityDate;
	
	private String holidayEligibilityFromDate;
	
	private String loginDate;

	private String purchaseDate;

	private String endDate;

	private Double tenure;

	private String memberSeasonId;
	
	private String memberSeason;
	
	private String productPurchased;

	private String productType;
	
	private String saleMonth;
	
	private String productId;

	private Double guestCharge;
	
	private String productCode;

	private String memberStatus;
	
	private Double pointsPurchased;
	
	private Double pointsOwnedTimeShare;
	
	private String recordType;
	
	private String utilityNotApplicable;
	private String annualChargeType;
	
	public String getAnnualChargeType() {
		return annualChargeType;
	}

	public void setAnnualChargeType(String annualChargeType) {
		this.annualChargeType = annualChargeType;
	}

	public Double getGuestCharge() {
		return guestCharge;
	}

	public void setGuestCharge(Double guestCharge) {
		this.guestCharge = guestCharge;
	}

	public String getMemberStatus() {
		return memberStatus;
	}

	public void setMemberStatus(String memberStatus) {
		this.memberStatus = memberStatus;
	}

	/**
	 * @return rciMembershipId
	 */
	public String getRciMembershipId() {
		return rciMembershipId;
	}

	/**
	 * @param rciMembershipId
	 * set the rciMembershipId
	 */
	public void setRciMembershipId(String rciMembershipId) {
		this.rciMembershipId = rciMembershipId;
	}

	/**
	 * @return memberID
	 */
	public String getMemberID() {
		return memberID;
	}

	/**
	 * @param memberID
	 * set the memberID
	 */
	public void setMemberID(String memberID) {
		this.memberID = memberID;
	}

	/**
	 * @return holidayEligibilityDate
	 */
	public String getHolidayEligibilityDate() {
		return holidayEligibilityDate;
	}

	/**
	 * @param holidayEligibilityDate
	 * set the holidayEligibilityDate
	 */
	public void setHolidayEligibilityDate(String holidayEligibilityDate) {
		this.holidayEligibilityDate = holidayEligibilityDate;
	}

	
	public String getHolidayEligibilityFromDate() {
		return holidayEligibilityFromDate;
	}

	public void setHolidayEligibilityFromDate(String holidayEligibilityFromDate) {
		this.holidayEligibilityFromDate = holidayEligibilityFromDate;
	}
	
	public String getLoginDate() {
		return loginDate;
	}

	public void setLoginDate(String loginDate) {
		this.loginDate = loginDate;
	}

	/**
	 * @return purchaseDate
	 */
	public String getPurchaseDate() {
		return purchaseDate;
	}

	/**
	 * @param purchaseDate
	 * set the purchaseDate
	 */
	public void setPurchaseDate(String purchaseDate) {
		this.purchaseDate = purchaseDate;
	}

	/**
	 * @return endDate
	 */
	public String getEndDate() {
		return endDate;
	}

	/**
	 * @param endDate
	 * set the endDate
	 */
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	/**
	 * @return tenure
	 */
	public Double getTenure() {
		return tenure;
	}

	/**
	 * @param tenure
	 * set the tenure
	 */
	public void setTenure(Double tenure) {
		this.tenure = tenure;
	}

	/**
	 * @return pointsPurchased
	 */
	public Double getPointsPurchased() {
		return pointsPurchased;
	}

	/**
	 * @param pointsPurchased
	 * set the pointsPurchased
	 */
	public void setPointsPurchased(Double pointsPurchased) {
		this.pointsPurchased = pointsPurchased;
	}

	/**
	 * @return memberSeason
	 */
	public String getMemberSeason() {
		return memberSeason;
	}

	/**
	 * @param memberSeason
	 * set the memberSeason
	 */
	public void setMemberSeason(String memberSeason) {
		this.memberSeason = memberSeason;
	}

	/**
	 * @return productPurchased
	 */
	public String getProductPurchased() {
		return productPurchased;
	}

	/**
	 * @param productPurchased
	 * set the productPurchased
	 */
	public void setProductPurchased(String productPurchased) {
		this.productPurchased = productPurchased;
	}

	/**
	 * @return saleMonth
	 */
	public String getSaleMonth() {
		return saleMonth;
	}

	/**
	 * @param saleMonth
	 * set the saleMonth
	 */
	public void setSaleMonth(String saleMonth) {
		this.saleMonth = saleMonth;
	}

	/**
	 * @return memberSeasonId
	 */
	public String getMemberSeasonId() {
		return memberSeasonId;
	}

	/**
	 * @param memberSeasonId
	 * set the memberSeasonId
	 */
	public void setMemberSeasonId(String memberSeasonId) {
		this.memberSeasonId = memberSeasonId;
	}


	/**
	 * @return rciMembershipEndDate
	 */
	public String getRciMembershipEndDate() {
		return rciMembershipEndDate;
	}

	/**
	 * @param rciMembershipEndDate
	 * set the rciMembershipEndDate
	 */
	public void setRciMembershipEndDate(String rciMembershipEndDate) {
		this.rciMembershipEndDate = rciMembershipEndDate;
	}

	/**
	 * @return productId
	 */
	public String getProductId() {
		return productId;
	}

	/**
	 * @param productId
	 * set the productId
	 */
	public void setProductId(String productId) {
		this.productId = productId;
	}

	/**
	 * @return productType
	 */
	public String getProductType() {
		return productType;
	}

	/**
	 * @param productType
	 * set the productType
	 */
	public void setProductType(String productType) {
		this.productType = productType;
	}

	public String getWeekStartDate() {
		return weekStartDate;
	}

	public void setWeekStartDate(String weekStartDate) {
		this.weekStartDate = weekStartDate;
	}

	public String getWeekNo() {
		return weekNo;
	}

	public void setWeekNo(String weekNo) {
		this.weekNo = weekNo;
	}

	public String getApartmentType() {
		return apartmentType;
	}

	public void setApartmentType(String apartmentType) {
		this.apartmentType = apartmentType;
	}

	public String getRoomType() {
		return roomType;
	}

	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}

	public String getResortName() {
		return resortName;
	}

	public void setResortName(String resortName) {
		this.resortName = resortName;
	}

	public String getResortId() {
		return resortId;
	}

	public void setResortId(String resortId) {
		this.resortId = resortId;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public Double getPointsOwnedTimeShare() {
		return pointsOwnedTimeShare;
	}

	public void setPointsOwnedTimeShare(Double pointsOwnedTimeShare) {
		this.pointsOwnedTimeShare = pointsOwnedTimeShare;
	}

	public String getRecordType() {
		return recordType;
	}

	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}

	public String getUtilityNotApplicable() {
		return utilityNotApplicable;
	}

	public void setUtilityNotApplicable(String utilityNotApplicable) {
		this.utilityNotApplicable = utilityNotApplicable;
	}
		
}
