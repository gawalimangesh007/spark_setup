package com.sterling.bookingapi.dto.response;

import java.io.Serializable;
import java.util.List;

/**
 * @author tcs
 * @version 1.0
 */
public class PaymentDetails  implements Serializable {

	private static final long serialVersionUID = 1L;

	private Double productCost;
	private Boolean paymentStatus;
	private Double discount;
	private Double emiPerMonth;

	private Double currentDp;
	private String emiPlanOpted;
	private Double amountPaid;
	private Double balanceAmount;

	private Double overdueAmount;
	private Double emiPaidPercent;
	private Double totalInterest;
	
	private List<Payments> transactionDetails;
	private List<DueDetails> dueDetails;

	
	
	public Double getTotalInterest() {
		return totalInterest;
	}
	public void setTotalInterest(Double totalInterest) {
		this.totalInterest = totalInterest;
	}
	/**
	 * @return productCost
	 */
	public Double getProductCost() {
		return productCost;
	}
	/**
	 * @param productCost
	 * set the productCost
	 */
	public void setProductCost(Double productCost) {
		this.productCost = productCost;
	}
	/**
	 * @return paymentStatus
	 */
	public Boolean getPaymentStatus() {
		return paymentStatus;
	}
	/**
	 * @param paymentStatus
	 * set the paymentStatus
	 */
	public void setPaymentStatus(Boolean paymentStatus) {
		this.paymentStatus = paymentStatus;
	}
	/**
	 * @return discount
	 */
	public Double getDiscount() {
		return discount;
	}
	/**
	 * @param discount
	 * set the discount
	 */
	public void setDiscount(Double discount) {
		this.discount = discount;
	}
	/**
	 * @return currentDp
	 */
	public Double getCurrentDp() {
		return currentDp;
	}
	/**
	 * @param currentDp
	 * set the currentDp
	 */
	public void setCurrentDp(Double currentDp) {
		this.currentDp = currentDp;
	}
	/**
	 * @return emiPlanOpted
	 */
	public String getEmiPlanOpted() {
		return emiPlanOpted;
	}
	/**
	 * @param emiPlanOpted
	 * set the emiPlanOpted
	 */
	public void setEmiPlanOpted(String emiPlanOpted) {
		this.emiPlanOpted = emiPlanOpted;
	}
	/**
	 * @return emiPerMonth
	 */
	public Double getEmiPerMonth() {
		return emiPerMonth;
	}
	/**
	 * @param emiPerMonth
	 * set the emiPerMonth
	 */
	public void setEmiPerMonth(Double emiPerMonth) {
		this.emiPerMonth = emiPerMonth;
	}
	/**
	 * @return amountPaid
	 */
	public Double getAmountPaid() {
		return amountPaid;
	}
	/**
	 * @param amountPaid
	 * set the amountPaid
	 */
	public void setAmountPaid(Double amountPaid) {
		this.amountPaid = amountPaid;
	}
	/**
	 * @return balanceAmount
	 */
	public Double getBalanceAmount() {
		return balanceAmount;
	}
	/**
	 * @param balanceAmount
	 * set the balanceAmount
	 */
	public void setBalanceAmount(Double balanceAmount) {
		this.balanceAmount = balanceAmount;
	}
	
	/**
	 * @return overdueAmount
	 */
	public Double getOverdueAmount() {
		return overdueAmount;
	}
	/**
	 * @param overdueAmount
	 * set the overdueAmount
	 */
	public void setOverdueAmount(Double overdueAmount) {
		this.overdueAmount = overdueAmount;
	}
	/**
	 * @return the transactionDetails
	 */
	public List<Payments> getTransactionDetails() {
		return transactionDetails;
	}
	/**
	 * @param transactionDetails the transactionDetails to set
	 */
	public void setTransactionDetails(List<Payments> transactionDetails) {
		this.transactionDetails = transactionDetails;
	}
	/**
	 * @return the dueDetails
	 */
	public List<DueDetails> getDueDetails() {
		return dueDetails;
	}
	/**
	 * @param dueDetails the dueDetails to set
	 */
	public void setDueDetails(List<DueDetails> dueDetails) {
		this.dueDetails = dueDetails;
	}
	public Double getEmiPaidPercent() {
		return emiPaidPercent;
	}
	public void setEmiPaidPercent(Double emiPaidPercent) {
		this.emiPaidPercent = emiPaidPercent;
	}
}
