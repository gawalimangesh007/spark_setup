package com.sterling.bookingapi.dto.request;

public class HsdRoomTypeUpdateDTO {

	/** The room type. */
	private String roomType;
	
	/** The occupancy detail. */
	private String occupancyDetail;
		
	public String getRoomType() {
		return roomType;
	}

	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}

	public String getOccupancyDetail() {
		return occupancyDetail;
	}

	public void setOccupancyDetail(String occupancyDetail) {
		this.occupancyDetail = occupancyDetail;
	}
}
