package com.sterling.bookingapi.exception;


/**
 * The Class SpecificFieldError.
 */
/**
 * @author tcs
 * @version 1.0
 *
 */
public class SpecificFieldError {
	
	/** The field name. */
	private String fieldName;
	
	/** The default message. */
	private String defaultMessage;
	
	/**
	 * Gets the field name.
	 *
	 * @return the field name
	 */
	public String getFieldName() {
		return fieldName;
	}
	
	/**
	 * Sets the field name.
	 *
	 * @param fieldName the new field name
	 */
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}
	
	/**
	 * Gets the default message.
	 *
	 * @return the default message
	 */
	public String getDefaultMessage() {
		return defaultMessage;
	}
	
	/**
	 * Sets the default message.
	 *
	 * @param defaultMessage the new default message
	 */
	public void setDefaultMessage(String defaultMessage) {
		this.defaultMessage = defaultMessage;
	}
}
