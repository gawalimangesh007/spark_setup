package com.sterling.bookingapi.dto.response;

public class HSDResortRateMappingResDTO {

	/** The rate plan id. */
	private int ratePlanId;
	
	/** The rate plan. */
	private String ratePlan;

	public int getRatePlanId() {
		return ratePlanId;
	}

	public void setRatePlanId(int ratePlanId) {
		this.ratePlanId = ratePlanId;
	}

	public String getRatePlan() {
		return ratePlan;
	}

	public void setRatePlan(String ratePlan) {
		this.ratePlan = ratePlan;
	}
	
}
