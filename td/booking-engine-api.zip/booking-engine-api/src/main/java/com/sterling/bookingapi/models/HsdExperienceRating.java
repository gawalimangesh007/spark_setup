package com.sterling.bookingapi.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * The Class HsdExperienceRating.
 */
/**
 * @author tcs
 *
 */
@Entity
@Table(name = "sh_hsd_experience_rating")
public class HsdExperienceRating extends BaseModel{
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The rating id. */
	@Id
	@GeneratedValue( strategy = GenerationType.IDENTITY )
	@Column(name = "rating_idx_id", unique = true)
	private int rating_id;
		
	/** The booking id. */
	@Column(name = "booking_id",nullable = false)
	private String bookingId;
	
	/** The rating. */
	@Column(name = "rating",nullable = false)
	private int rating;
	
	/** The comments. */
	@Column(name = "comments",nullable = true)
	private String comments;

	/**
	 * Gets the rating id.
	 *
	 * @return the rating id
	 */
	public int getRating_id() {
		return rating_id;
	}

	/**
	 * Sets the rating id.
	 *
	 * @param rating_id the new rating id
	 */
	public void setRating_id(int rating_id) {
		this.rating_id = rating_id;
	}

	/**
	 * Gets the booking id.
	 *
	 * @return the booking id
	 */
	public String getBookingId() {
		return bookingId;
	}

	/**
	 * Sets the booking id.
	 *
	 * @param bookingId the new booking id
	 */
	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}

	/**
	 * Gets the rating.
	 *
	 * @return the rating
	 */
	public int getRating() {
		return rating;
	}

	/**
	 * Sets the rating.
	 *
	 * @param rating the new rating
	 */
	public void setRating(int rating) {
		this.rating = rating;
	}

	/**
	 * Gets the comments.
	 *
	 * @return the comments
	 */
	public String getComments() {
		return comments;
	}

	/**
	 * Sets the comments.
	 *
	 * @param comments the new comments
	 */
	public void setComments(String comments) {
		this.comments = comments;
	}
		
	
}
