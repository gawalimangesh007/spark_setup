package com.sterling.bookingapi.dto;

import java.io.Serializable;

public class PDFChargeDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String chargeName;
	private String chargeDescription;
	private String chargeAmount;
	private String paymentStatus;
	
	public PDFChargeDTO() {
		super();
	}
	
	public PDFChargeDTO(String chargeName, String quantity, String chargeDescription, String chargeAmount, String paymentStatus) {
		super();
		this.chargeName = chargeName +  quantity;
		this.chargeDescription = chargeDescription;
		this.chargeAmount = chargeAmount;
		this.paymentStatus = paymentStatus;
	}

	public String getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public String getChargeName() {
		return chargeName;
	}
	public void setChargeName(String chargeName) {
		this.chargeName = chargeName;
	}
	public String getChargeDescription() {
		return chargeDescription;
	}
	public void setChargeDescription(String chargeDescription) {
		this.chargeDescription = chargeDescription;
	}
	public String getChargeAmount() {
		return chargeAmount;
	}
	public void setChargeAmount(String chargeAmount) {
		this.chargeAmount = chargeAmount;
	}
	
	
}
