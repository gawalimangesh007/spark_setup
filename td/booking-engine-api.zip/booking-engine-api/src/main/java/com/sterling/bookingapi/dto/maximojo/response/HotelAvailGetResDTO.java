package com.sterling.bookingapi.dto.maximojo.response;

import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;


/**
 * The Class HotelAvailGetResDTO.
 * @author tcs
 * @version 1.0
 */
@JacksonXmlRootElement(localName = "OTA_HotelAvailGetRS")
public class HotelAvailGetResDTO {

	/** The xmlns. */
	@JacksonXmlProperty(localName = "xmlns", isAttribute = true)
	private String xmlns;

	/** The echo token. */
	@JacksonXmlProperty(localName = "EchoToken", isAttribute = true)
	private String echoToken;

	/** The time stamp. */
	@JacksonXmlProperty(localName = "TimeStamp", isAttribute = true)
	private String timeStamp;

	/** The version. */
	@JacksonXmlProperty(localName = "Version", isAttribute = true)
	private String version;

	/** The success. */
	@JacksonXmlProperty(localName = "Success")
	private SuccessResDTO success;

	/** The avail status messages. */
	@JacksonXmlElementWrapper(useWrapping = false, localName = "AvailStatusMessages")
	@JacksonXmlProperty(localName = "AvailStatusMessages")
	private List<HotelAvailStatusMessagesResDTO> availStatusMessages;

	/**
	 * Gets the time stamp.
	 *
	 * @return the timeStamp
	 */
	public String getTimeStamp() {
		return timeStamp;
	}

	/**
	 * Sets the time stamp.
	 *
	 * @param timeStamp            the timeStamp to set
	 */
	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}

	/**
	 * Gets the avail status messages.
	 *
	 * @return the availStatusMessages
	 */
	public List<HotelAvailStatusMessagesResDTO> getAvailStatusMessages() {
		return availStatusMessages;
	}

	/**
	 * Sets the avail status messages.
	 *
	 * @param availStatusMessages            the availStatusMessages to set
	 */
	public void setAvailStatusMessages(
			List<HotelAvailStatusMessagesResDTO> availStatusMessages) {
		this.availStatusMessages = availStatusMessages;
	}

	/**
	 * Gets the xmlns.
	 *
	 * @return the xmlns
	 */
	public String getXmlns() {
		return xmlns;
	}

	/**
	 * Sets the xmlns.
	 *
	 * @param xmlns            the xmlns to set
	 */
	public void setXmlns(String xmlns) {
		this.xmlns = xmlns;
	}

	/**
	 * Gets the version.
	 *
	 * @return the version
	 */
	public String getVersion() {
		return version;
	}

	/**
	 * Sets the version.
	 *
	 * @param version            the version to set
	 */
	public void setVersion(String version) {
		this.version = version;
	}

	/**
	 * Gets the echo token.
	 *
	 * @return the echoToken
	 */
	public String getEchoToken() {
		return echoToken;
	}

	/**
	 * Sets the echo token.
	 *
	 * @param echoToken            the echoToken to set
	 */
	public void setEchoToken(String echoToken) {
		this.echoToken = echoToken;
	}

	/**
	 * Gets the success.
	 *
	 * @return the success
	 */
	public SuccessResDTO getSuccess() {
		return success;
	}

	/**
	 * Sets the success.
	 *
	 * @param success            the success to set
	 */
	public void setSuccess(SuccessResDTO success) {
		this.success = success;
	}

}
