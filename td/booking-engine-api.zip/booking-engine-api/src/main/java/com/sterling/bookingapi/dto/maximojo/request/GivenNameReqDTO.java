package com.sterling.bookingapi.dto.maximojo.request;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlText;


/**
 * The Class GivenNameReqDTO.
 */
/**
 * @author tcs
 *
 */
public class GivenNameReqDTO {
	
	/** The given name. */
	@JacksonXmlText
	private String givenName;

	/**
	 * Gets the given name.
	 *
	 * @return the given name
	 */
	public String getGivenName() {
		return givenName;
	}

	/**
	 * Sets the given name.
	 *
	 * @param givenName the new given name
	 */
	public void setGivenName(String givenName) {
		this.givenName = givenName;
	}


	
}
