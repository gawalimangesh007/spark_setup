package com.sterling.bookingapi.engine.rules;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.BooleanUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;

import com.sterling.bookingapi.dto.request.VOConfirmBookingRequest;
import com.sterling.bookingapi.dto.response.VODashboardResponse;
import com.sterling.bookingapi.engine.rules.models.BookingRule;
import com.sterling.bookingapi.engine.rules.models.Season;
import com.sterling.bookingapi.engine.rules.models.VOBookingRuleDTO;
import com.sterling.bookingapi.utils.BookingEngineUtils;


@Rule(name="BookingWindowsRule", description="BOOKING_WINDOW_RULE")
public class BookingWindowRule {

	private static final Logger logger = LogManager.getLogger(BookingWindowRule.class);
	
	@Condition
	public boolean when(@Fact("bookingRequest") VOConfirmBookingRequest req, 
			@Fact("productRules") Map<String, List<VOBookingRuleDTO>> rulesMap,
			@Fact("memberDetail") VODashboardResponse memberDetail) {
		//my rule conditions
		logger.info("################# excecuting condition");
		
		Date checkInDate = BookingEngineUtils.parseDate(req.getCheckInDate(), BookingEngineUtils.SF_DATE_FORMAT);
		Date checkOutDate = BookingEngineUtils.parseDate(req.getCheckOutDate(), BookingEngineUtils.SF_DATE_FORMAT);
		Long stayDaysCount = BookingEngineUtils.daysDiff(checkInDate, checkOutDate);

		Season bookingSeason = null;//Season.getByName(req.getSeasonCode());
		
		List<VOBookingRuleDTO> ruleList = rulesMap.get(BookingRule.BOOKING_WINDOW_RULE.getRuleName());
		
		for (VOBookingRuleDTO voBookingRuleDTO : ruleList) {
			
			if(BooleanUtils.isTrue(voBookingRuleDTO.getActive())) {
				int configDaysCount = Integer.parseInt(voBookingRuleDTO
						.getParameters().get(0).getValue());
				boolean isConfiguredSeason = BookingEngineUtils.havingSeason(
						bookingSeason, voBookingRuleDTO.getApplicableSeasons());
				if (isConfiguredSeason && stayDaysCount > configDaysCount) {
					return false;
				}
			}
		}
		
		return true;
	}

	@Action(order = 1)
	public void then() throws Exception {
		//my actions
		logger.info("################# excecuting action");
	}
}
