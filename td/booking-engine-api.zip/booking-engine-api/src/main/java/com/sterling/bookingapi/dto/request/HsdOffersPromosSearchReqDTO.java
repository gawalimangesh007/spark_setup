package com.sterling.bookingapi.dto.request;

import java.util.Date;

import com.sterling.bookingapi.utils.AppConstants;


/**
 * The Class HsdOffersPromosSearchReqDTO.
 */
/**
 * @author tcs
 *
 */
public class HsdOffersPromosSearchReqDTO extends SearchFilterDTO{

	
	/** The type. */
	private AppConstants.Type type;
	
	/** The sell start from date. */
	private Date sellStartFromDate;

	/** The sell start to date. */
	private Date sellStartToDate;

	/** The sell end from date. */
	private Date sellEndFromDate;

	/** The sell end to date. */
	private Date sellEndToDate;

	/** The booking start from date. */
	private Date bookingStartFromDate;
	
	/** The booking start to date. */
	private Date bookingStartToDate;
	
	/** The booking end from date. */
	private Date bookingEndFromDate;
	
	/** The booking end to date. */
	private Date bookingEndToDate;
	
	/** The offer promo category. */
	private String offerPromoCategory;

	/**
	 * Gets the type.
	 *
	 * @return the type
	 */
	public AppConstants.Type getType() {
		return type;
	}

	/**
	 * Sets the type.
	 *
	 * @param type the new type
	 */
	public void setType(AppConstants.Type type) {
		this.type = type;
	}

	/**
	 * Gets the sell start from date.
	 *
	 * @return the sell start from date
	 */
	public Date getSellStartFromDate() {
		return sellStartFromDate;
	}

	/**
	 * Sets the sell start from date.
	 *
	 * @param sellStartFromDate the new sell start from date
	 */
	public void setSellStartFromDate(Date sellStartFromDate) {
		this.sellStartFromDate = sellStartFromDate;
	}

	/**
	 * Gets the sell start to date.
	 *
	 * @return the sell start to date
	 */
	public Date getSellStartToDate() {
		return sellStartToDate;
	}

	/**
	 * Sets the sell start to date.
	 *
	 * @param sellStartToDate the new sell start to date
	 */
	public void setSellStartToDate(Date sellStartToDate) {
		this.sellStartToDate = sellStartToDate;
	}

	/**
	 * Gets the sell end from date.
	 *
	 * @return the sell end from date
	 */
	public Date getSellEndFromDate() {
		return sellEndFromDate;
	}

	/**
	 * Sets the sell end from date.
	 *
	 * @param sellEndFromDate the new sell end from date
	 */
	public void setSellEndFromDate(Date sellEndFromDate) {
		this.sellEndFromDate = sellEndFromDate;
	}

	/**
	 * Gets the sell end to date.
	 *
	 * @return the sell end to date
	 */
	public Date getSellEndToDate() {
		return sellEndToDate;
	}

	/**
	 * Sets the sell end to date.
	 *
	 * @param sellEndToDate the new sell end to date
	 */
	public void setSellEndToDate(Date sellEndToDate) {
		this.sellEndToDate = sellEndToDate;
	}

	/**
	 * Gets the booking start from date.
	 *
	 * @return the booking start from date
	 */
	public Date getBookingStartFromDate() {
		return bookingStartFromDate;
	}

	/**
	 * Sets the booking start from date.
	 *
	 * @param bookingStartFromDate the new booking start from date
	 */
	public void setBookingStartFromDate(Date bookingStartFromDate) {
		this.bookingStartFromDate = bookingStartFromDate;
	}

	/**
	 * Gets the booking start to date.
	 *
	 * @return the booking start to date
	 */
	public Date getBookingStartToDate() {
		return bookingStartToDate;
	}

	/**
	 * Sets the booking start to date.
	 *
	 * @param bookingStartToDate the new booking start to date
	 */
	public void setBookingStartToDate(Date bookingStartToDate) {
		this.bookingStartToDate = bookingStartToDate;
	}

	/**
	 * Gets the booking end from date.
	 *
	 * @return the booking end from date
	 */
	public Date getBookingEndFromDate() {
		return bookingEndFromDate;
	}

	/**
	 * Sets the booking end from date.
	 *
	 * @param bookingEndFromDate the new booking end from date
	 */
	public void setBookingEndFromDate(Date bookingEndFromDate) {
		this.bookingEndFromDate = bookingEndFromDate;
	}

	/**
	 * Gets the booking end to date.
	 *
	 * @return the booking end to date
	 */
	public Date getBookingEndToDate() {
		return bookingEndToDate;
	}

	/**
	 * Sets the booking end to date.
	 *
	 * @param bookingEndToDate the new booking end to date
	 */
	public void setBookingEndToDate(Date bookingEndToDate) {
		this.bookingEndToDate = bookingEndToDate;
	}

	/**
	 * Gets the offer promo category.
	 *
	 * @return the offer promo category
	 */
	public String getOfferPromoCategory() {
		return offerPromoCategory;
	}

	/**
	 * Sets the offer promo category.
	 *
	 * @param offerPromoCategory the new offer promo category
	 */
	public void setOfferPromoCategory(String offerPromoCategory) {
		this.offerPromoCategory = offerPromoCategory;
	}

	
}
