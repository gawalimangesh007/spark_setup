package com.sterling.bookingapi.dto.request;

import java.util.List;

public class HsdCreateResortRatePlanDTO {
		
	//private boolean status;
	
	private boolean allResortFlag;
	
	private boolean allRoomFlag;
	
	private List<HsdResortRoomDTO> roomDetails;
	
	private List<HsdResortInfoDTO> resortDetails;
	
	private HsdResortRateplanDTO rateDetails;

	
	/*public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}*/

	public boolean isAllResortFlag() {
		return allResortFlag;
	}

	public void setAllResortFlag(boolean allResortFlag) {
		this.allResortFlag = allResortFlag;
	}

	public List<HsdResortInfoDTO> getResortDetails() {
		return resortDetails;
	}

	public void setResortDetails(List<HsdResortInfoDTO> resortDetails) {
		this.resortDetails = resortDetails;
	}

	public HsdResortRateplanDTO getRateDetails() {
		return rateDetails;
	}

	public void setRateDetails(HsdResortRateplanDTO rateDetails) {
		this.rateDetails = rateDetails;
	}

	public boolean isAllRoomFlag() {
		return allRoomFlag;
	}

	public void setAllRoomFlag(boolean allRoomFlag) {
		this.allRoomFlag = allRoomFlag;
	}

	public List<HsdResortRoomDTO> getRoomDetails() {
		return roomDetails;
	}

	public void setRoomDetails(List<HsdResortRoomDTO> roomDetails) {
		this.roomDetails = roomDetails;
	}
}
