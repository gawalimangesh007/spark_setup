package com.sterling.bookingapi.dto.maximojo.request;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class HotelAvailRefReqDTO.
 */
/**
 * @author tcs
 *
 */
public class HotelAvailRefReqDTO {

	/** The hotel code. */
	@JacksonXmlProperty(localName = "HotelCode", isAttribute = true)
    private String hotelCode;

	/**
	 * Gets the hotel code.
	 *
	 * @return the hotelCode
	 */
	public String getHotelCode() {
		return hotelCode;
	}

	/**
	 * Sets the hotel code.
	 *
	 * @param hotelCode the hotelCode to set
	 */
	public void setHotelCode(String hotelCode) {
		this.hotelCode = hotelCode;
	}
	
	
}
