package com.sterling.bookingapi.dto.maximojo.request;

import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class CommentsBookingReqDTO.
 */
/**
 * @author tcs
 *
 */
public class CommentsBookingReqDTO {

	/** The comment. */
	@JacksonXmlElementWrapper(useWrapping=false)
	@JacksonXmlProperty(localName = "Comment")
	private List<CommentBookingReqDTO> comment;

	/**
	 * Gets the comment.
	 *
	 * @return the comment
	 */
	public List<CommentBookingReqDTO> getComment() {
		return comment;
	}

	/**
	 * Sets the comment.
	 *
	 * @param comment the new comment
	 */
	public void setComment(List<CommentBookingReqDTO> comment) {
		this.comment = comment;
	}
	
	
}
