package com.sterling.bookingapi.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sterling.bookingapi.auth.bean.AuthType;
import com.sterling.bookingapi.auth.bean.User;
import com.sterling.bookingapi.auth.bean.UserAuthentication;
import com.sterling.bookingapi.auth.bean.UserToken;
import com.sterling.bookingapi.auth.impl.TokenAuthenticationService;
import com.sterling.bookingapi.dto.response.ResponseDTO;
import com.sterling.bookingapi.utils.BookingEngineUtils;
import com.sterling.bookingapi.utils.ResponseUtility;
	/**
	 * Authentication API specification for Swagger documentation and Code Generation.
	 * Implemented by Spring Security.
	 */
//	@Api("Authentication")
//	@RequestMapping(value = "/", produces = MediaType.APPLICATION_JSON_VALUE)
	@RestController
	public class TempAuthSwaggerApi {
	    	
		@Autowired
		private TokenAuthenticationService tokenAuthenticationService;

		/**
	     * Implemented by Spring Security
	     */
//	    @ApiOperation(value = "Login", notes = "Login with the given credentials.")
	    @ApiImplicitParams({
		    @ApiImplicitParam(name = "Authorization", value = "Authorization token", 
		                     required = true, dataType = "string", paramType = "header")})
	    @ApiResponses({@ApiResponse(code = 200, message = "")})
	    @RequestMapping(value = "/login", method = RequestMethod.POST)
	    public void login() {
	        throw new IllegalStateException("Add Spring Security to handle authentication");
	    }

	    /**
	     * Implemented by Spring Security
	     */
//	    @ApiOperation(value = "Logout", notes = "Logout the current user.")
	    @ApiImplicitParams({
		    @ApiImplicitParam(name = "X-AUTH-TOKEN", value = "Authorization token", 
		                     required = true, dataType = "string", paramType = "header")})
	    @ApiResponses({@ApiResponse(code = 200, message = "")})
	    @RequestMapping(value = "/logout", method = RequestMethod.POST)
	    public void logout() {
	        throw new IllegalStateException("Add Spring Security to handle authentication");
	    }
	    
	    @ApiResponses({@ApiResponse(code = 200, message = "")})
	    @RequestMapping(value = "/getAuthHeader", method = RequestMethod.POST)
	    public ResponseDTO base64(@RequestParam(name="userId") String userId, @RequestParam(name="password") String password, @RequestParam(name="type", defaultValue="VO") String type) {
	    	String base64Encode = BookingEngineUtils.base64Encode(type + "|" + userId + ":" + password);
	        return new ResponseDTO("Basic " + base64Encode);
	    }

	    @ApiResponses({@ApiResponse(code = 200, message = "")})
	    @RequestMapping(value = "/mockAuth", method = RequestMethod.POST)
	    public ResponseDTO mockAuth(@RequestParam(name="userId") String userId, @RequestParam(name="password") String password, @RequestParam(name="type", defaultValue="VO") AuthType type, HttpServletRequest request, HttpServletResponse response) {
	    	
	    	User user = new User();
    		user.setAuthType(type);
    		user.setPassword(password);
    		user.setUserId(userId);
	    	
	    	UserAuthentication auth = new UserAuthentication(null);
			auth.setIpAddress(request.getRemoteAddr());
			auth.setUser(user);
			auth.setAuthenticated(true);
			auth.setAuthType(type);
			
			UserToken token = tokenAuthenticationService.addAuthentication(response, auth);
			
			SecurityContextHolder.getContext().setAuthentication(auth);

			/*HashMap<String, Object> information = new HashMap<>();
			information.put("USER", authResultObject.getUser());
			information.put("AUTH_TYPE", authResultObject.getAuthType());
			information.put("INFO", authResultObject.getInfo());
			*/

			ResponseDTO responseDTO = ResponseUtility.constructSuccessRes(auth.getUser().getUserObject());
			return responseDTO;
			
	    }
	}
