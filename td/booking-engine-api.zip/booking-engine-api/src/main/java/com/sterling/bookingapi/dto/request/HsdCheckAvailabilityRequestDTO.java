package com.sterling.bookingapi.dto.request;

import java.util.Date;
import java.util.List;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.sterling.bookingapi.utils.BookingEngineUtils;
import com.sterling.bookingapi.utils.CustomJsonDateDeserializer;


/**
 * The Class HsdCheckAvailabilityRequestDTO.
 */
/**
 * @author tcs
 *
 */
public class HsdCheckAvailabilityRequestDTO {

	/** The resort id. */
	@NotNull
	private String resortId;

	/** The check in. */
	@NotNull
	@JsonDeserialize(using = CustomJsonDateDeserializer.class)
	private Date checkIn;

	/** The check out. */
	@NotNull
	@JsonDeserialize(using = CustomJsonDateDeserializer.class)
	private Date checkOut;
		
	/** The room details. */
	/*@NotNull
	private RoomPeopleInfo roomDetails;
*/
	private int additonalSuggestedDays;
	
	private List<OccupancyDetailsDTO> occupancyDetails;
	
	private String recommendedResorts;

	/**
	 * Gets the resort id.
	 *
	 * @return the resort id
	 */
	public String getResortId() {
		return resortId;
	}

	/**
	 * Sets the resort id.
	 *
	 * @param resortId the new resort id
	 */
	public void setResortId(String resortId) {
		this.resortId = resortId;
	}

	/**
	 * Gets the check in.
	 *
	 * @return the check in
	 */
	public Date getCheckIn() {
		return checkIn;
	}

	/**
	 * Sets the check in.
	 *
	 * @param checkIn the new check in
	 */
	public void setCheckIn(Date checkIn) {
		this.checkIn = BookingEngineUtils.getZeroTimeDate(checkIn);
	}

	/**
	 * Gets the check out.
	 *
	 * @return the check out
	 */
	public Date getCheckOut() {
		return checkOut;
	}

	/**
	 * Sets the check out.
	 *
	 * @param checkOut the new check out
	 */
	public void setCheckOut(Date checkOut) {
		this.checkOut = BookingEngineUtils.getZeroTimeDate(checkOut);
	}


	/**
	 * Gets the room details.
	 *
	 * @return the room details
	 */
	/*	public RoomPeopleInfo getRoomDetails() {
		return roomDetails;
	}

	*//**
	 * Sets the room details.
	 *
	 * @param roomDetails the new room details
	 */
	/*public void setRoomDetails(RoomPeopleInfo roomDetails) {
		this.roomDetails = roomDetails;
	}*/
	
	public int getAdditonalSuggestedDays() {
		return additonalSuggestedDays;
	}

	public void setAdditonalSuggestedDays(int additonalSuggestedDays) {
		this.additonalSuggestedDays = additonalSuggestedDays;
	}

	public List<OccupancyDetailsDTO> getOccupancyDetails() {
		return occupancyDetails;
	}

	public void setOccupancyDetails(List<OccupancyDetailsDTO> occupancyDetails) {
		this.occupancyDetails = occupancyDetails;
	}

	public String getRecommendedResorts() {
		return recommendedResorts;
	}

	public void setRecommendedResorts(String recommendedResorts) {
		this.recommendedResorts = recommendedResorts;
	}
	
}
