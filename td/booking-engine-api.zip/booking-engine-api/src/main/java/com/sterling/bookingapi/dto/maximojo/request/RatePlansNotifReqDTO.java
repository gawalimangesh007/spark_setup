package com.sterling.bookingapi.dto.maximojo.request;

import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class RatePlansNotifReqDTO.
 */
/**
 * @author tcs
 *
 */
public class RatePlansNotifReqDTO {

	/** The hotel name. */
	@JacksonXmlProperty(localName = "HotelName", isAttribute = true)
	private String hotelName;

	/** The hotel code. */
	@JacksonXmlProperty(localName = "HotelCode", isAttribute = true)
    private String hotelCode;

	/** The rate plan. */
	@JacksonXmlElementWrapper(useWrapping=false)
	@JacksonXmlProperty(localName = "RatePlan")
    private List<RatePlanNotifReqDTO>ratePlan;

	/**
	 * Gets the hotel name.
	 *
	 * @return the hotelName
	 */
	public String getHotelName() {
		return hotelName;
	}

	/**
	 * Sets the hotel name.
	 *
	 * @param hotelName the hotelName to set
	 */
	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}

	/**
	 * Gets the hotel code.
	 *
	 * @return the hotelCode
	 */
	public String getHotelCode() {
		return hotelCode;
	}

	/**
	 * Sets the hotel code.
	 *
	 * @param hotelCode the hotelCode to set
	 */
	public void setHotelCode(String hotelCode) {
		this.hotelCode = hotelCode;
	}

	/**
	 * Gets the rate plan.
	 *
	 * @return the ratePlan
	 */
	public List<RatePlanNotifReqDTO> getRatePlan() {
		return ratePlan;
	}

	/**
	 * Sets the rate plan.
	 *
	 * @param ratePlan the ratePlan to set
	 */
	public void setRatePlan(List<RatePlanNotifReqDTO> ratePlan) {
		this.ratePlan = ratePlan;
	}
	
	
}
