package com.sterling.bookingapi.controller;

import static org.springframework.util.StringUtils.isEmpty;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.codec.binary.Base64;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.type.TypeReference;
import com.google.common.collect.Maps;
import com.sterling.bookingapi.auth.impl.TokenHandlerService;
import com.sterling.bookingapi.dto.FileUploadDTO;
import com.sterling.bookingapi.dto.OTPDto;
import com.sterling.bookingapi.dto.request.VoGetDashboardAccountRequestDTO;
import com.sterling.bookingapi.dto.response.HolidayDetails;
import com.sterling.bookingapi.dto.response.ResponseDTO;
import com.sterling.bookingapi.dto.response.VOConfigResponseDTO;
import com.sterling.bookingapi.dto.response.VOCustomerPersonalDetails;
import com.sterling.bookingapi.dto.response.VODashboardResponse;
import com.sterling.bookingapi.engine.rules.models.ProductRuleDTO;
import com.sterling.bookingapi.exception.BookingEngineException;
import com.sterling.bookingapi.exception.SalesForceException;
import com.sterling.bookingapi.restapi.SFRestAPI;
import com.sterling.bookingapi.service.VOBookingService;
import com.sterling.bookingapi.service.VOConfigService;
import com.sterling.bookingapi.service.VODashboardService;
import com.sterling.bookingapi.service.VacationOwnershipService;
import com.sterling.bookingapi.service.impl.TempVoOTPServiceImpl;
import com.sterling.bookingapi.sf.dto.request.VOBookingDetails;
import com.sterling.bookingapi.sf.dto.response.HsdMemberResponse;
import com.sterling.bookingapi.sf.dto.response.SalesForceResponse;
import com.sterling.bookingapi.sf.dto.response.VOCustomerDetailResponse;
import com.sterling.bookingapi.utils.AppConstants;
import com.sterling.bookingapi.utils.AppConstants.ContactType;
import com.sterling.bookingapi.utils.BookingEngineUtils;
import com.sterling.bookingapi.utils.ResponseUtility;
import com.sterling.bookingapi.utils.SFQuery;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import net.sf.ehcache.Ehcache;
import net.sf.ehcache.Element;

@RestController
@RequestMapping(value = "/temp")
public class TempVOOTPController extends BaseController {
	
	/** The Constant logger. */
	private static final Logger logger = LogManager.getLogger(TempVOOTPController.class);
	
	@Autowired
	private TempVoOTPServiceImpl tempOtp;
	
	@Autowired
	private VacationOwnershipService voService;

	@Autowired
	private VOConfigService configService;
	
	@Autowired
	private VOBookingService voBkService;

	@Autowired
	private VODashboardService voDashService;
	
	@Autowired
	private SFRestAPI restApi;
	
	@Autowired
	private CacheManager cacheManager;

	@Autowired
	private TokenHandlerService authTokenHandler;
	
	//@Value("${sterling.fileUpload.remotePath}")
	private String fileUploadPath;


	
//	@ApiOperation(value= "rekjsdhfjsdh", response=ResponseDTO.class, responseContainer="List", httpMethod="GET",authorizations={@Authorization(value="basicAuth")})
	@ApiImplicitParams({
	    @ApiImplicitParam(name = "Authorization", value = "Authorization token", 
	                     required = true, dataType = "string", paramType = "header")})
	@RequestMapping(value = "/getOtp", method = RequestMethod.GET, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO getOtp(@RequestParam("id") String id) throws SalesForceException {
		
		logger.info("TempVOOTPController : getProducts : Entered.");
	
		String currentUserEmail = BookingEngineUtils.getCurrentUserEmail();
		logger.info("Current user ::::::::::::::::::::::::: {}", currentUserEmail);
		
		OTPDto oTPDto = tempOtp.getOtp(id);
		logger.info("TempVOOTPController : getProducts : Leaving.");
		return ResponseUtility.constructSuccessRes(oTPDto);
	}

	@RequestMapping(value = "/getRule", method = RequestMethod.GET, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ProductRuleDTO getConfig(@RequestParam("prodCode") String code) throws SalesForceException {
		
		Cache cache = cacheManager.getCache("ruleEngineCache");
		String key = AppConstants.VO_BK_RULE_PREFIX + code;
		ProductRuleDTO rulesConfig = cache.get(key, ProductRuleDTO.class);
		if(rulesConfig  == null) {
			try {
				VOConfigResponseDTO voConfig = configService.getConfig(key);
				if(voConfig != null) {
					rulesConfig = BookingEngineUtils.convertJsonToObject(voConfig.getValue(), new TypeReference<ProductRuleDTO>() {});
				}
			} catch (Exception e) {
				throw new BookingEngineException("ERROR_ON_FETCHING_RULES_CONFIG",e);
			}
		}
		
		return rulesConfig;
	}

	@RequestMapping(value = "/getVOUserPass", method = RequestMethod.GET, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO getVOUser(@RequestParam("email") String email) throws SalesForceException {
		
		logger.info("TempVOOTPController : getSFCustomerDetails: Begin ");
		try {
			
			Map<String, Object> data = new HashMap<>();
			data.put("email", email);
			logger.info("TempVOOTPController : getSFCustomerDetails: End ");
			SalesForceResponse<VOCustomerDetailResponse> sfData = restApi.exchangeWithSF(SFQuery.voLogin.toString(), data, HttpMethod.GET, null, null, new ParameterizedTypeReference<SalesForceResponse<VOCustomerDetailResponse>>() {
			}, false);
			
			return ResponseUtility.constructSuccessRes(BookingEngineUtils.decryptPass(sfData.getRecords().get(0).getPassword()));
			

		} catch (BookingEngineException e) {
			logger.info("exception on get customer details from sales force: {}", e.getErrCode());
			throw e;
		}
	}

	@RequestMapping(value = "/getHSDUserPass", method = RequestMethod.GET, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO getHSDUser(@RequestParam("email") String email) throws SalesForceException {
		
		logger.info("TempVOOTPController : getSFCustomerDetails: Begin ");
		try {
			
			Map<String, Object> data = new HashMap<>();
			data.put("email", email);
			logger.info("TempVOOTPController : getSFCustomerDetails: End ");
			SalesForceResponse<HsdMemberResponse> sfData = restApi.encodeAndExchangeWithSF(SFQuery.hsdMemberDetailByEmail.toString(), data, HttpMethod.GET, null, null, new ParameterizedTypeReference<SalesForceResponse<HsdMemberResponse>>() {
			}, false);
			
			return ResponseUtility.constructSuccessRes(BookingEngineUtils.decryptPass(sfData.getRecords().get(0).getPassword()));
			
			
		} catch (BookingEngineException e) {
			logger.info("exception on get customer details from sales force: {}", e.getErrCode());
			throw e;
		}
	}

	@RequestMapping(value = "/nonSFGetCountry", method = RequestMethod.GET, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO nonSFGetCountry() throws SalesForceException {
		
		logger.info("TempVOOTPController : getSFCustomerDetails: Begin ");
		try {
			
			Object obj = restApi.exchange("http://services.groupkt.com/country/get/all", HttpMethod.GET, null, null, new ParameterizedTypeReference<Object>() {}, false);
			
			return ResponseUtility.constructSuccessRes(obj);
			
		} catch (BookingEngineException e) {
			logger.info("exception on get customer details from sales force: {}", e.getErrCode());
			throw e;
		}
	}

	@RequestMapping(value = "/removeAccount", method = RequestMethod.GET, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO revertAccount(@RequestParam("email") String email) throws SalesForceException {
		
		logger.info("TempVOOTPController : getSFCustomerDetails: Begin ");
		try {
			
			String url = SFQuery.voAccountURL.toString() + email;
			Object obj = restApi.exchangeWithSF(url, null, HttpMethod.DELETE, null, null, new ParameterizedTypeReference<Object>() {
			}, false);
			return ResponseUtility.constructSuccessRes(obj);
			
		} catch (BookingEngineException e) {
			logger.info("exception on get customer details from sales force: {}", e.getErrCode());
			throw e;
		}
	}

	@RequestMapping(value = "/authCache", method = RequestMethod.GET, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO authCache() throws SalesForceException {
		
		logger.info("TempVOOTPController : getSFCustomerDetails: Begin ");
		
		Map<Object, Object> map = Maps.newHashMap(); 
		try {
			
			Ehcache cache = (Ehcache) cacheManager.getCache(AppConstants.cacheGroups.authCache.name()).getNativeCache();
			
			for (Object key: cache.getKeys()) {
				Element element = cache.get(key);
				logger.info("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ {}, {}",key, element.getExpirationTime());
//				if (element != null 
//						&& element.getObjectValue() instanceof UserToken
//						&& userId.equals(((UserToken)element.getObjectValue()).getUser().getUserId())) {
					if (element != null) {
						map.put(key, element.getObjectValue());
						
					}
			}
			
			return ResponseUtility.constructSuccessRes(map);
			
		} catch (BookingEngineException e) {
			logger.info("exception on get customer details from sales force: {}", e.getErrCode());
			throw e;
		}
	}
	
	@RequestMapping(value = "/putSeasonForAllBkns", method = RequestMethod.GET, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO allocateSeason(@RequestParam("email") String email) throws SalesForceException {
		
		logger.info("TempVOOTPController : getProducts : Entered.");
	
		List<VOCustomerPersonalDetails> user = voService.getUserByEmailOrMobile(email, ContactType.EMAIL);
		
		for (VOCustomerPersonalDetails voCustomerPersonalDetails : user) {
			String sterlingContractId = voCustomerPersonalDetails.getSterlingContractId();
			
			VoGetDashboardAccountRequestDTO reqDTO = new VoGetDashboardAccountRequestDTO();
			reqDTO.setContractId(sterlingContractId);
			VODashboardResponse dash = voDashService.getDashboardAccountData(reqDTO).getBody();
			
			List<HolidayDetails> holidayDetails = dash.getHolidayDetails();
			
			for (HolidayDetails hDetails : holidayDetails) {
				if(hDetails.getSeason() == null) {
					VOBookingDetails voBookingRequest = new VOBookingDetails();
					voBookingRequest.setSeasonCode("Red");
					String url = BookingEngineUtils.getSFServiceURL(SFQuery.voBookingRequestURL);
					restApi.exchangeWithSF(url, true, HttpMethod.PATCH, voBookingRequest, null, new ParameterizedTypeReference<Object>() {});
				}
			}
		}
		
		return ResponseUtility.constructSuccessRes("");
	}
	
	@RequestMapping(value = "/uploadPdfFiles", method = RequestMethod.POST,  produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseDTO uploadingPost(@RequestParam(name ="uploadingFiles") MultipartFile[] uploadingFiles, @RequestParam String user) {

		logger.info("uploadingPost : fileUploadPath : {}", fileUploadPath);

			String output = "";
			String path = fileUploadPath + user;
			File file = null;
	        for(MultipartFile uploadedFile : uploadingFiles) {
	        	File newDirectory = new File(path);
	        	if (newDirectory.exists()) {
					file = new File(path +"/" + uploadedFile.getOriginalFilename());
				} else {
					boolean isCreated = newDirectory.mkdirs();
					if(isCreated)
						file = new File(path +"/" + uploadedFile.getOriginalFilename());	
				}
	            try {
	            	uploadedFile.transferTo(file);
				} catch (IllegalStateException | IOException e) {
					e.printStackTrace();
					logger.error("uploadingPost : Error : {}", e.getMessage());
				}
	            output = file.getAbsolutePath();
	            logger.info("uploadingPost : output : {}", output);
	        }

	        return ResponseUtility.constructSuccessRes( output);
	}



	@RequestMapping(value = "/uploadEncodedFiles", method = RequestMethod.POST,  produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseDTO uploadingPostStream(@RequestBody(required=false) FileUploadDTO[] requests) {

		logger.info("uploadingPost : fileUploadPath : {}", fileUploadPath);

		List<String> filePaths = new ArrayList<String>();
		for(FileUploadDTO req : requests) {
			String filename = ! isEmpty(req.getFileName()) ? req.getFileName() : "default.jpeg";
			String path = fileUploadPath + req.getUser();

			OutputStream out = null;
			try{
				File newDirectory = new File(path);
				if (newDirectory.exists()) {
					out = new FileOutputStream(new File(path+"/"+filename));
				} else {
					boolean isCreated = newDirectory.mkdirs();
					if(isCreated)
						out = new FileOutputStream(new File(path+"/"+filename));	
				}
				filePaths.add(path+"/"+filename);
				String encodedStr = req.getUploadingFiles();
				encodedStr = ! isEmpty(encodedStr) ? encodedStr.replace("data:image/jpeg;base64,", "") : null;

				out.write(Base64.decodeBase64(encodedStr));
				logger.info("Uploaded {}", path, "success"); 


			} catch(Exception e) {
				e.printStackTrace();
			} finally {
				try {
					out.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	return ResponseUtility.constructSuccessRes(filePaths);
}
	
	/*@RequestMapping(value = "/uploadfilesMultiStream", method = RequestMethod.POST,
			consumes = "multipart/form-data", produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO uploadingPostMultiPartStream(InputStream ioStream, HttpServletRequest  request) {

		logger.info("uploadingPost : fileUploadPath : {}", fileUploadPath);
		
		String boundary = "------WebKitFormBoundary";
		String filename = fileUploadPath + "abc.jpeg";
		ByteArrayOutputStream output = new ByteArrayOutputStream();
		
		OutputStream out = null;
		StringBuilder str = new StringBuilder();
		Scanner sc = new Scanner(ioStream);
		try {
			while (sc.hasNextLine()) {
				String s = sc.nextLine();
				str.append(s);
				output.write(s.getBytes());
			}
			out =  new FileOutputStream(new File(filename));
			out.write(Base64.decodeBase64(str.toString().getBytes()));
			out.flush();
			out.close();
			MultipartStream multipartStream = new MultipartStream(ioStream, boundary.getBytes(), output.size()*5, null);
			boolean nextPart = multipartStream.skipPreamble();
			while (nextPart) {
				String header = multipartStream.readHeaders();
				if(header.contains("filename")) {
					multipartStream.readBodyData(out);
					out.flush();
					out.close();
				}
				nextPart = multipartStream.readBoundary();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return ResponseUtility.constructSuccessRes(filename);
	}*/
	
	

}
