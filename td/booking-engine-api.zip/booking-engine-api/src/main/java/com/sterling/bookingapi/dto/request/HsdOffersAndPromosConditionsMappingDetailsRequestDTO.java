package com.sterling.bookingapi.dto.request;



/**
 * The Class HsdOffersAndPromosConditionsMappingDetailsRequestDTO.
 */
/**
 * @author tcs
 *
 */
public class HsdOffersAndPromosConditionsMappingDetailsRequestDTO {
	
	/** The condition id. */
	private int conditionId;
	
	/** The condition value. */
	private String conditionValue;
	
	/**
	 * Gets the condition id.
	 *
	 * @return the condition id
	 */
	public int getConditionId() {
		return conditionId;
	}
	
	/**
	 * Sets the condition id.
	 *
	 * @param conditionId the new condition id
	 */
	public void setConditionId(int conditionId) {
		this.conditionId = conditionId;
	}
	
	/**
	 * Gets the condition value.
	 *
	 * @return the condition value
	 */
	public String getConditionValue() {
		return conditionValue;
	}
	
	/**
	 * Sets the condition value.
	 *
	 * @param conditionValue the new condition value
	 */
	public void setConditionValue(String conditionValue) {
		this.conditionValue = conditionValue;
	}
	
}
