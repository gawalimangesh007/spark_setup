package com.sterling.bookingapi.dto.response;

import java.io.Serializable;
import java.util.Date;

public class BRWDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private String checkinDate;
	private String checkoutDate;
	
	public BRWDto(String checkinDate, String checkoutDate) {
		super();
		this.checkinDate = checkinDate;
		this.checkoutDate = checkoutDate;
	}

	public String getCheckinDate() {
		return checkinDate;
	}

	public void setCheckinDate(String checkinDate) {
		this.checkinDate = checkinDate;
	}

	public String getCheckoutDate() {
		return checkoutDate;
	}

	public void setCheckoutDate(String checkoutDate) {
		this.checkoutDate = checkoutDate;
	}
	
	
	
	
	
	
}
