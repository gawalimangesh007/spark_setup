package com.sterling.bookingapi.dto.response;

/**
 * @author tcs
 * @version 1.0
 */
public enum LoginType {

	CUSTOMER, LEAD, SALE, OPPORTUNITY
}
