package com.sterling.bookingapi.dto.maximojo.request;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlText;


/**
 * The Class SurNameReqDTO.
 */
/**
 * @author tcs
 *
 */
public class SurNameReqDTO {

	/** The sur name. */
	@JacksonXmlText
	private String surName;

	/**
	 * Gets the sur name.
	 *
	 * @return the sur name
	 */
	public String getSurName() {
		return surName;
	}

	/**
	 * Sets the sur name.
	 *
	 * @param surName the new sur name
	 */
	public void setSurName(String surName) {
		this.surName = surName;
	}
	
	

}
