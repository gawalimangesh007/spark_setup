package com.sterling.bookingapi.adapter;

import java.io.IOException;
import java.text.ParseException;

import com.sterling.bookingapi.bean.HsdRegisterResponse;
import com.sterling.bookingapi.bean.HsdRegisterRequest;
import com.sterling.bookingapi.exception.SalesForceException;


/**
 * The Interface HsdRegisterAdapterInterface.
 */
/**
 * @author tcs
 *
 */
public interface HsdRegisterAdapterInterface {
	
	/**
	 * Method to register the HSD user details.
	 *
	 * @param hsdRegisterReq - An object of HsdRegisterRequest
	 * @return the output as an object of HsdRegisterResponse.
	 * @throws ParseException the parse exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws SalesForceException the sales force exception
	 */ 
	HsdRegisterResponse getHsdRegisterStatus(HsdRegisterRequest hsdRegisterReq) throws ParseException, IOException, SalesForceException;
}
