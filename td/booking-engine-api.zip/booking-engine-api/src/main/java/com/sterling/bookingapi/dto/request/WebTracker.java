package com.sterling.bookingapi.dto.request;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonIgnoreProperties(ignoreUnknown = true)
public class WebTracker implements Serializable{
	
	private static final long serialVersionUID = 1L;

	private String browsernamenversion;
	private String osnamenversion;
	private String devicenamenversion;
	private Date timestamp;
	
	private PageInfo pageinfo;

	public String getBrowsernamenversion() {
		return browsernamenversion;
	}

	public void setBrowsernamenversion(String browsernamenversion) {
		this.browsernamenversion = browsernamenversion;
	}

	public String getOsnamenversion() {
		return osnamenversion;
	}

	public void setOsnamenversion(String osnamenversion) {
		this.osnamenversion = osnamenversion;
	}

	public String getDevicenamenversion() {
		return devicenamenversion;
	}

	public void setDevicenamenversion(String devicenamenversion) {
		this.devicenamenversion = devicenamenversion;
	}

	public Date getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}

	public PageInfo getPageinfo() {
		return pageinfo;
	}

	public void setPageinfo(PageInfo pageinfo) {
		this.pageinfo = pageinfo;
	}

	

		
}
