package com.sterling.bookingapi.dto.maximojo.request;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlText;


/**
 * The Class PostalCodeReqDTO.
 */
/**
 * @author tcs
 *
 */
public class PostalCodeReqDTO {

	/** The postal code. */
	@JacksonXmlText
	private String postalCode;

	/**
	 * Gets the postal code.
	 *
	 * @return the postal code
	 */
	public String getPostalCode() {
		return postalCode;
	}

	/**
	 * Sets the postal code.
	 *
	 * @param postalCode the new postal code
	 */
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}
	
	
}
