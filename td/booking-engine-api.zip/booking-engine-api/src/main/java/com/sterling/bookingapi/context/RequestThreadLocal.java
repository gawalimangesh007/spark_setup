package com.sterling.bookingapi.context;

import org.springframework.stereotype.Component;


/**
 * The Class RequestThreadLocal.
 */
/**
 * @author tcs
 *
 */
@Component
public class RequestThreadLocal {

	 /** The Constant requestThreadlocal. */
 	private static final ThreadLocal<RequestContext> requestThreadlocal= new ThreadLocal<>();

	/**
	 * Gets the.
	 *
	 * @return the request context
	 */
	public static RequestContext get() {
		if(requestThreadlocal.get() == null) {
			set(new RequestContext());
		}
		return requestThreadlocal.get();
	}
	
	/**
	 * Sets the.
	 *
	 * @param requestContext the request context
	 */
	public static void set(RequestContext requestContext) {
		requestThreadlocal.set(requestContext);
		}
	
	/**
	 * Unset.
	 */
	public static void unset() {
		requestThreadlocal.remove();
		}
	
	 
}
