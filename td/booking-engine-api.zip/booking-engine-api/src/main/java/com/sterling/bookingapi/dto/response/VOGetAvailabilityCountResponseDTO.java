package com.sterling.bookingapi.dto.response;


/**
 * @author tcs
 * @version 1.0
 */
public class VOGetAvailabilityCountResponseDTO {

	private String date;

	private String availableCount;
	
	private String bookingPoints;
	
	private String extraPersonCost;
	
	private String extraPersonWeekEndCost;
	
	private String extraChildCost;
	
	private String extraChildWeekEndCost;
	
	private String physicalRoomCount;
	
	private String waitlistTrack;
	
	public VOGetAvailabilityCountResponseDTO() {
	}

	/**
	 * @param date
	 * set the date
	 * @param availableCount
	 * set the availableCount
	 * @param bookingPoints
	 * set the bookingPoints
	 * @param extraPersonCost
	 * set the extraPersonCost
	 */
	public VOGetAvailabilityCountResponseDTO(String date,
			String availableCount, String bookingPoints, String extraPersonCost, String extraPersonWeekEndCost, String extraChildCost, String extraChildWeekEndCost) {
		this.date = date;
		this.availableCount = availableCount;
		this.bookingPoints = bookingPoints;
		this.extraPersonCost = extraPersonCost;
		this.extraChildWeekEndCost = extraChildWeekEndCost;
		this.extraChildCost = extraChildCost;
		this.extraChildWeekEndCost = extraChildWeekEndCost;
	}
	
	public VOGetAvailabilityCountResponseDTO(String date,
			String availableCount, String bookingPoints) {
		this.date = date;
		this.availableCount = availableCount;
		this.bookingPoints = bookingPoints;
	}

	
	public String getPhysicalRoomCount() {
		return physicalRoomCount;
	}

	public void setPhysicalRoomCount(String physicalRoomCount) {
		this.physicalRoomCount = physicalRoomCount;
	}

	public String getWaitlistTrack() {
		return waitlistTrack;
	}

	public void setWaitlistTrack(String waitlistTrack) {
		this.waitlistTrack = waitlistTrack;
	}

	public String getBookingPoints() {
		return bookingPoints;
	}

	public String getBookingjPoints() {
		return bookingPoints;
	}

	/**
	 * @param bookingPoints
	 * set the bookingPoints
	 */
	public void setBookingPoints(String bookingPoints) {
		this.bookingPoints = bookingPoints;
	}

	public String getExtraPersonWeekEndCost() {
		return extraPersonWeekEndCost;
	}

	public void setExtraPersonWeekEndCost(String extraPersonWeekEndCost) {
		this.extraPersonWeekEndCost = extraPersonWeekEndCost;
	}

	public String getExtraChildCost() {
		return extraChildCost;
	}

	public void setExtraChildCost(String extraChildCost) {
		this.extraChildCost = extraChildCost;
	}

	public String getExtraChildWeekEndCost() {
		return extraChildWeekEndCost;
	}

	public void setExtraChildWeekEndCost(String extraChildWeekEndCost) {
		this.extraChildWeekEndCost = extraChildWeekEndCost;
	}

	/**
	 * @return extraPersonCost
	 */
	public String getExtraPersonCost() {
		return extraPersonCost;
	}

	/**
	 * @param extraPersonCost
	 * set the extraPersonCost
	 */
	public void setExtraPersonCost(String extraPersonCost) {
		this.extraPersonCost = extraPersonCost;
	}

	/**
	 * @return date
	 */
	public String getDate() {
		return date;
	}

	/**
	 * @param date
	 * set the date
	 */
	public void setDate(String date) {
		this.date = date;
	}

	/**
	 * @return availableCount
	 */
	public String getAvailableCount() {
		return availableCount;
	}

	/**
	 * @param availableCount
	 * set the availableCount
	 */
	public void setAvailableCount(String availableCount) {
		this.availableCount = availableCount;
	}

	/**
	 * @param date
	 * set the date
	 * @param availableCount
	 * set the availableCount
	 */
	public VOGetAvailabilityCountResponseDTO(String date, String availableCount) {
		this.date = date;
		this.availableCount = availableCount;
	}


	


}
