package com.sterling.bookingapi.dto.request;

import java.io.Serializable;

import org.hibernate.validator.constraints.NotEmpty;

import com.sterling.bookingapi.dto.response.BaseRecord;

/**
 * @author tcs
 *
 */
public class TempVenueOfferReq  extends BaseRecord implements Serializable{
	
	private static final long serialVersionUID = 1L;
	@NotEmpty(message = "Voucher code should not be empty")
	private String voucherCode;
	private String checkinDate;
	private String checkoutDate;
	private Boolean isVenueOfferUsed;
	
	/**
	 * @return voucherCode
	 */
	public String getVoucherCode() {
		return voucherCode;
	}
	/**
	 * @param voucherCode
	 * set the voucherCode
	 */
	public void setVoucherCode(String voucherCode) {
		this.voucherCode = voucherCode;
	}
	
	/**
	 * @return checkin date
	 */
	public String getCheckinDate() {
		return checkinDate;
	}
	/**
	 * @param checkinDate
	 * set the checkinDate
	 */
	public void setCheckinDate(String checkinDate) {
		this.checkinDate = checkinDate;
	}
	/**
	 * @return checkoutDate
	 */
	public String getCheckoutDate() {
		return checkoutDate;
	}
	/**
	 * @param checkoutDate
	 * set the checkoutDate
	 */
	public void setCheckoutDate(String checkoutDate) {
		this.checkoutDate = checkoutDate;
	}
	/**
	 * @return venueoffered
	 */
	public Boolean getIsVenueOfferUsed() {
		return isVenueOfferUsed;
	}
	/**
	 * @param isVenueOfferUsed
	 * set the venue offer
	 */
	public void setIsVenueOfferUsed(Boolean isVenueOfferUsed) {
		this.isVenueOfferUsed = isVenueOfferUsed;
	}
	
}
