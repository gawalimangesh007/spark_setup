package com.sterling.bookingapi.adapter;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.entity.StringEntity;
import org.apache.http.util.EntityUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Repository;

import com.sterling.bookingapi.bean.HsdRegisterRequest;
import com.sterling.bookingapi.bean.HsdRegisterResponse;
import com.sterling.bookingapi.bean.HsdRegistrationData;
import com.sterling.bookingapi.exception.SalesForceException;
import com.sterling.bookingapi.utils.AppConstants;
import com.sterling.bookingapi.utils.RestAPIClient;


/**
 * The Class HsdRegisterDataAdapterImpl.
 */
@Repository
public class HsdRegisterDataAdapterImpl implements HsdRegisterAdapterInterface {

	private static final String ERROR_CODE = "errorCode";

	/** The Constant logger. */
	private static final Logger logger = LogManager.getLogger(HsdRegisterDataAdapterImpl.class);
	
	/** The rest API client. */
	@Autowired
	private RestAPIClient restAPIClient;

	/** The sales force rest API. */
	@Autowired
	private SalesForceRestAPI salesForceRestAPI;

	/* (non-Javadoc)
	 * @see com.sterling.bookingapi.adapter.HsdRegisterAdapterInterface#getHsdRegisterStatus(com.sterling.bookingapi.bean.HsdRegisterRequest)
	 */
	@Override
	public HsdRegisterResponse getHsdRegisterStatus(HsdRegisterRequest hsdRegisterDataReq) throws SalesForceException {

		logger.info(" HsdRegisterDataAdapterImpl : getHsdRegisterStatus : Entered.");
		HsdRegisterResponse hsdRegisterResponseDet = new HsdRegisterResponse();

		HsdRegistrationData hsdregisterdata = new HsdRegistrationData();
		String resultJson = "";
		HttpResponse response = null;
		try {
			if (hsdRegisterDataReq != null) {
				hsdregisterdata = hsdRegisterDataReq.getHsdregisterdata();

				salesForceRestAPI.authenticate();
				

				logger.info(hsdRegisterDataReq);

				logger.info("\n_______________ Lead INSERT _______________");

				String uri = AppConstants.Authorization.BASEURI + "/sobjects/Lead/";
				JSONObject json = new JSONObject();
				try {
					json.put("FirstName", hsdregisterdata.getFirstName());
					json.put("LastName", hsdregisterdata.getLastName());
					json.put("Alternate_Mobile__c", hsdregisterdata.getAlternate_Mobile__c());
					json.put("MobilePhone", hsdregisterdata.getMobilePhone());
					json.put("Email", hsdregisterdata.getEmail());
				} catch (JSONException e) {
					logger.error("Exception occuered in JSON onject construction: {}", e.getMessage());
				}

				String jsonInString = json.toString();
				StringEntity reqEntity = null;
				try {
					reqEntity = new StringEntity(jsonInString);
					reqEntity.setContentType("application/json");
				} catch (UnsupportedEncodingException e1) {
					logger.error("UnsupportedEncodingException: {}", e1.getMessage());
				}
				

				int statusCode = 401;
				try {
					response = restAPIClient.execute(uri, HttpMethod.POST, reqEntity, false);
				} catch (IOException e1) {
					logger.error("Exception occuered while calling rest client: {}", e1);
				}
				if (response != null) {
					statusCode = response.getStatusLine().getStatusCode();
					try {
						resultJson = EntityUtils.toString(response.getEntity());
					} catch (ParseException | IOException e1) {
						logger.error(
								"Exception occuered while JSON Parsing: {}", e1);
					}
					if (statusCode == 401) {
						try {
							resultJson = EntityUtils.toString(response
									.getEntity());
						} catch (ParseException | IOException e1) {
							logger.error(
									"Exception occuered while JSON Parsing: {}",
									e1);
						} 
						JSONArray resultJsonObjArr;
						try {
							resultJsonObjArr = new JSONArray(resultJson);
							JSONObject obj = (JSONObject) resultJsonObjArr
									.get(0);
							if ("INVALID_SESSION_ID".equalsIgnoreCase(obj.get(ERROR_CODE).toString())) {
								salesForceRestAPI.authenticate();
								try {
									response = restAPIClient.execute(uri,
											HttpMethod.POST, reqEntity, false);
								} catch (IOException e) {
									logger.error(
											"Exception occuered while calling rest client: {}",
											e);
								} 
							} else {
								logger.info("Insertion unsuccessful. Status code returned is "
										+ statusCode);
								try {
									resultJson = EntityUtils.toString(response
											.getEntity());
								} catch (ParseException|IOException e) {
									logger.error(
											"Exception occuered while JSON Parsing: {}",
											e);
								}
								JSONArray objArr = new JSONArray(resultJson);
								JSONObject jsonObj = (JSONObject) objArr.get(0);
								throw new SalesForceException(jsonObj.get(
										ERROR_CODE).toString()
										+ " "
										+ jsonObj.get("message").toString(),
										statusCode);
							}
						} catch (JSONException e) {
							logger.error(
									"Exception occuered while JSON Parsing: {}",
									e);
						}

					}
				}
				if (statusCode == 201) {
					String leadId = "";
					JSONObject jsonObj;
					try {
						jsonObj = new JSONObject(resultJson);
						leadId = jsonObj.getString("id");
					} catch (JSONException e) {
						logger.error("Exception occuered while JSON Parsing: {}", e);
					}
					// Store the retrieved lead id to use when we update the
					// lead.

					logger.info("New Lead id from response: " + leadId);
					hsdRegisterResponseDet.setStatus("success");
					hsdRegisterResponseDet.setLeadId(leadId);
				} else {
					logger.info("Query was unsuccessful. Status code returned is " + statusCode);
					logger.info(resultJson);
					JSONArray objArr;
					try {
						objArr = new JSONArray(resultJson);
						JSONObject jsonObj = (JSONObject) objArr.get(0);
						hsdRegisterResponseDet.setStatus("failure");
						hsdRegisterResponseDet.setLeadId("");
						throw new SalesForceException(jsonObj.get(ERROR_CODE).toString() + " " + jsonObj.get("message").toString(), statusCode);
					} catch (JSONException e) {
						logger.error("Exception occuered while JSON Parsing: {}", e);
					}

				}
			}
		} catch (Exception e) {
			logger.error("Exception occuered while Lead registration: {}", e);
			throw new SalesForceException(e.getMessage());
		}
		logger.info(" HsdRegisterDataAdapterImpl : getHsdRegisterStatus : Leaving.");
		return hsdRegisterResponseDet;
	}
}
