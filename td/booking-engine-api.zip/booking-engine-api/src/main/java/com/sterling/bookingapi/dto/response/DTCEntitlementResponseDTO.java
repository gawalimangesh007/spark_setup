package com.sterling.bookingapi.dto.response;

import java.io.Serializable;

public class DTCEntitlementResponseDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private Double advancementEntitlement;
	private Integer entitlementYear;
	private String advancementDate;
	
	
	public String getAdvancementDate() {
		return advancementDate;
	}

	public void setAdvancementDate(String advancementDate) {
		this.advancementDate = advancementDate;
	}
	public Double getAdvancementEntitlement() {
		return advancementEntitlement;
	}
	public void setAdvancementEntitlement(Double advancementEntitlement) {
		this.advancementEntitlement = advancementEntitlement;
	}
	
	public Integer getEntitlementYear() {
		return entitlementYear;
	}
	public void setEntitlementYear(Integer entitlementYear) {
		this.entitlementYear = entitlementYear;
	}

	
}
