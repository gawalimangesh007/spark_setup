package com.sterling.bookingapi.auth.bean;


/*@Configuration
//@EnableRedisHttpSession
public class SessionConfig extends AbstractHttpSessionApplicationInitializer {
	
}
*/