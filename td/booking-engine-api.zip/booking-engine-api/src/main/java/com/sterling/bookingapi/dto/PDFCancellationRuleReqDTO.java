package com.sterling.bookingapi.dto;

import java.io.Serializable;

public class PDFCancellationRuleReqDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private int cancellationTime;
	private int pointsDebit;
	
	public PDFCancellationRuleReqDTO() {
		super();
	}

	public int getCancellationTime() {
		return cancellationTime;
	}

	public void setCancellationTime(int cancellationTime) {
		this.cancellationTime = cancellationTime;
	}

	public int getPointsDebit() {
		return pointsDebit;
	}

	public void setPointsDebit(int pointsDebit) {
		this.pointsDebit = pointsDebit;
	}

	
	
	
}
