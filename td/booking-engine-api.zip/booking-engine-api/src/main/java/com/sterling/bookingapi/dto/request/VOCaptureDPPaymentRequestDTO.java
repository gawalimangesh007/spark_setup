package com.sterling.bookingapi.dto.request;

import java.io.Serializable;

import com.sterling.bookingapi.sf.dto.request.VOPGDetailsDTO;

/**
 * @author tcs
 *
 */
public class VOCaptureDPPaymentRequestDTO extends VoBaseRequestDTO implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private VOCaptureDownPaymentRequest voDPRequest;
	private VOPGDetailsDTO voPaymentGatewayDetails;
	
	public VOCaptureDownPaymentRequest getVoDPRequest() {
		return voDPRequest;
	}
	/**
	 * @param voDPRequest -- payment details
	 */
	public void setVoDPRequest(VOCaptureDownPaymentRequest voDPRequest) {
		this.voDPRequest = voDPRequest;
	}
	/**
	 * @return voPaymentGatewayDetails
	 */
	public VOPGDetailsDTO getVoPaymentGatewayDetails() {
		return voPaymentGatewayDetails;
	}
	/**
	 * @param voPaymentGatewayDetails
	 * set the voPaymentGatewayDetails
	 */
	public void setVoPaymentGatewayDetails(VOPGDetailsDTO voPaymentGatewayDetails) {
		this.voPaymentGatewayDetails = voPaymentGatewayDetails;
	}
}
