package com.sterling.bookingapi.dto.maximojo.request;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class POSBookingReqDTO.
 */
/**
 * @author tcs
 *
 */
public class POSBookingReqDTO {
	 
 	/** The source. */
 	@JacksonXmlProperty(localName = "Source")
	 private SourceBookingReqDTO source;

	/**
	 * Gets the source.
	 *
	 * @return the source
	 */
	public SourceBookingReqDTO getSource() {
		return source;
	}

	/**
	 * Sets the source.
	 *
	 * @param source the source to set
	 */
	public void setSource(SourceBookingReqDTO source) {
		this.source = source;
	}
	 
	 
}
