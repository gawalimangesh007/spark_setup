package com.sterling.bookingapi.dto.request;

import java.io.Serializable;

public class ManageBookingDTO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String bookingNo;
	private Integer mobileNo;
	public String getBookingNo() {
		return bookingNo;
	}
	public void setBookingNo(String bookingNo) {
		this.bookingNo = bookingNo;
	}
	public Integer getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(Integer mobileNo) {
		this.mobileNo = mobileNo;
	}
	public ManageBookingDTO(String bookingNo, Integer mobileNo) {
		super();
		this.bookingNo = bookingNo;
		this.mobileNo = mobileNo;
	}
	public ManageBookingDTO() {
		super();
	}
	
	

}
