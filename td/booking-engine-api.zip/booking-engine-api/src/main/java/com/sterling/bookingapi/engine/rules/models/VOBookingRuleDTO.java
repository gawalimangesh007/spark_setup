package com.sterling.bookingapi.engine.rules.models;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class VOBookingRuleDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String ruleId;
	private String ruleDescription;
	private String ruleName;
	private String onFailureMsg;
	private Boolean active;
	private RulesSeasons applicableSeasons;
	private List<RulesParameter> parameters;
	
	public String getRuleId() {
		return ruleId;
	}
	public void setRuleId(String ruleId) {
		this.ruleId = ruleId;
	}
	public String getRuleDescription() {
		return ruleDescription;
	}
	public void setRuleDescription(String ruleDescription) {
		this.ruleDescription = ruleDescription;
	}
	public String getRuleName() {
		return ruleName;
	}
	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}
	public String getOnFailureMsg() {
		return onFailureMsg;
	}
	public void setOnFailureMsg(String onFailureMsg) {
		this.onFailureMsg = onFailureMsg;
	}
	public Boolean getActive() {
		return active;
	}
	public void setActive(Boolean active) {
		this.active = active;
	}
	public RulesSeasons getApplicableSeasons() {
		return applicableSeasons;
	}
	public void setApplicableSeasons(RulesSeasons applicableSeasons) {
		this.applicableSeasons = applicableSeasons;
	}
	public List<RulesParameter> getParameters() {
		return parameters;
	}
	public void setParameters(List<RulesParameter> parameters) {
		this.parameters = parameters;
	}
	@Override
	public String toString() {
		return "VOBookingRuleDTO [ruleName=" + ruleName + ", active=" + active
				+ ", applicableSeasons=" + applicableSeasons + ", parameters="
				+ parameters + "]";
	}


	/*{
        "ruleId": "rule1",
        "ruleDescription": "",
        "ruleName": "minPointRule",
        "onFailureMsg": "",
        "active": false,
        "applicableSeasons": {
          "purple": false,
          "red": false,
          "blue": false,
          "white": false
        },
        "parameters": [
          {
            "parameter": "minpoints",
            "value": ""
          }
        ]
      }
	 */
	
	

}
