package com.sterling.bookingapi.dto.response;

import java.io.Serializable;
import java.util.List;

public class VOProductResponseDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String productId;
	private String productCategory;
	private String name;
	private String description;
	private VOServiceTaxResDTO serviceTax;

	private List<VOProdDPMappingResDTO> prodDPMapping;
	private List<VOProductsPlanResponseDTO> productPlanList;
	
	/**
	 * @return productId
	 */
	public String getProductId() {
		return productId;
	}
	/**
	 * @param productId
	 * set the productId
	 */
	public void setProductId(String productId) {
		this.productId = productId;
	}
	/**
	 * @return productCategory
	 */
	public String getProductCategory() {
		return productCategory;
	}
	/**
	 * @param productCategory
	 * set the productCategory
	 */
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}
	/**
	 * @return name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name
	 * set the name
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return prodDPMapping
	 */
	public List<VOProdDPMappingResDTO> getProdDPMapping() {
		return prodDPMapping;
	}
	/**
	 * @param prodDPMapping
	 * set the prodDPMapping
	 */
	public void setProdDPMapping(List<VOProdDPMappingResDTO> prodDPMapping) {
		this.prodDPMapping = prodDPMapping;
	}
	/**
	 * @return productPlanList
	 */
	public List<VOProductsPlanResponseDTO> getProductPlanList() {
		return productPlanList;
	}
	/**
	 * @param productPlanList
	 * set the productPlanList
	 */
	public void setProductPlanList(List<VOProductsPlanResponseDTO> productPlanList) {
		this.productPlanList = productPlanList;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public VOServiceTaxResDTO getServiceTax() {
		return serviceTax;
	}
	public void setServiceTax(VOServiceTaxResDTO serviceTax) {
		this.serviceTax = serviceTax;
	}
	
}
