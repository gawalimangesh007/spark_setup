package com.sterling.bookingapi.dto.response;

import java.io.Serializable;
import java.util.List;

public class DTCResponseWrapper implements Serializable {
	
	private static final long serialVersionUID = 1L;

	private DTCOverallSummaryResponseDTO overallSummary;
	private List<DTCBookingResponseDTO> confirmedBookings;
	private List<DTCBookingResponseDTO> cancelledBookings;
	private List<DTCBookingResponseDTO> rciBookings;
	private List<DTCBookingResponseDTO> wlBookings;

	private List<LapsedPointsResponseDTO> lapsedPoints;

	public DTCOverallSummaryResponseDTO getOverallSummary() {
		return overallSummary;
	}

	public void setOverallSummary(DTCOverallSummaryResponseDTO overallSummary) {
		this.overallSummary = overallSummary;
	}

	public List<DTCBookingResponseDTO> getConfirmedBookings() {
		return confirmedBookings;
	}

	public void setConfirmedBookings(
			List<DTCBookingResponseDTO> confirmedBookings) {
		this.confirmedBookings = confirmedBookings;
	}

	public List<DTCBookingResponseDTO> getCancelledBookings() {
		return cancelledBookings;
	}

	public void setCancelledBookings(List<DTCBookingResponseDTO> cancelledBookings) {
		this.cancelledBookings = cancelledBookings;
	}

	public List<DTCBookingResponseDTO> getRciBookings() {
		return rciBookings;
	}

	public void setRciBookings(List<DTCBookingResponseDTO> rciBookings) {
		this.rciBookings = rciBookings;
	}

	public List<DTCBookingResponseDTO> getWlBookings() {
		return wlBookings;
	}

	public void setWlBookings(List<DTCBookingResponseDTO> wlBookings) {
		this.wlBookings = wlBookings;
	}

	public List<LapsedPointsResponseDTO> getLapsedPoints() {
		return lapsedPoints;
	}

	public void setLapsedPoints(List<LapsedPointsResponseDTO> lapsedPoints) {
		this.lapsedPoints = lapsedPoints;
	}
	
}
