package com.sterling.bookingapi.dto.request;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author tcs
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class VoBaseRequestDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String sfToken;

	/**
	 * @return sftoken
	 */
	public String getSfToken() {
		return sfToken;
	}

	/**
	 * @param sfToken
	 * set the sftoken
	 */
	public void setSfToken(String sfToken) {
		this.sfToken = sfToken;
	}
}
