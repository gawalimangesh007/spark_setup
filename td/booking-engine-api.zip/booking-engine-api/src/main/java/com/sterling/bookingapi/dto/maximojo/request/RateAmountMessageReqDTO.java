package com.sterling.bookingapi.dto.maximojo.request;

import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class RateAmountMessageReqDTO.
 */
/**
 * @author tcs
 *
 */
public class RateAmountMessageReqDTO {

	/** The Status application control. */
	@JacksonXmlProperty(localName = "StatusApplicationControl")
	 private StatusApplicationControlNotifReqDTO statusApplicationControl;

	/** The ratePlan. */
	@JacksonXmlElementWrapper(useWrapping = true, localName ="RatePlans")
	@JacksonXmlProperty(localName = "RatePlan")
	private List<RatePlanReq> ratePlan;
	

	/**
	 * Gets the status application control.
	 *
	 * @return the status application control
	 */
	public StatusApplicationControlNotifReqDTO getStatusApplicationControl() {
		return statusApplicationControl;
	}

	/**
	 * Sets the status application control.
	 *
	 * @param statusApplicationControl the new status application control
	 */
	public void setStatusApplicationControl(
			StatusApplicationControlNotifReqDTO statusApplicationControl) {
		this.statusApplicationControl = statusApplicationControl;
	}

	public List<RatePlanReq> getRatePlan() {
		return ratePlan;
	}

	public void setRatePlan(List<RatePlanReq> ratePlan) {
		this.ratePlan = ratePlan;
	}
	
	
	
}
