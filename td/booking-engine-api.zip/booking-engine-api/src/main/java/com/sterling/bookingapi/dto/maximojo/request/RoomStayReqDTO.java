package com.sterling.bookingapi.dto.maximojo.request;

import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class RoomStayReqDTO.
 */
/**
 * @author tcs
 *
 */
public class RoomStayReqDTO {
	
		/** The source of business. */
		@JacksonXmlProperty(localName = "SourceOfBusiness", isAttribute = true)
		private String sourceOfBusiness;
		
		/** The room rate. */
		@JacksonXmlElementWrapper(useWrapping=true,localName = "RoomRates")
	    @JacksonXmlProperty(localName = "RoomRate")
	    private List<RoomRateReqDTO> roomRate;
				
		/** The time span. */
		@JacksonXmlProperty(localName = "TimeSpan")
	    private TimeSpanReqDTO timeSpan;
		
		/** The deposit payments. */
		@JacksonXmlProperty(localName = "DepositPayments")
	    private DepositPaymentsReqDTO depositPayments;
		
		/** The total. */
		@JacksonXmlProperty(localName = "Total")
	    private TotalReqDTO total;
		
		/** The basic property info. */
		@JacksonXmlProperty(localName = "BasicPropertyInfo")
	    private BasicPropertyInfoReqDTO basicPropertyInfo;
		
		/** The res guest RPH. */
		@JacksonXmlElementWrapper(useWrapping=true,localName = "ResGuestRPHs")
	    @JacksonXmlProperty(localName = "ResGuestRPH")
	    private List<ResGuestRPHReqDTO> resGuestRPH;
		
	    /** The comments. */
    	@JacksonXmlProperty(localName = "Comments")
	 	private CommentsBookingReqDTO comments;

    	/**
	     * Gets the comments.
	     *
	     * @return the comments
	     */
	    public CommentsBookingReqDTO getComments() {
			return comments;
		}

		/**
		 * Sets the comments.
		 *
		 * @param comments the new comments
		 */
		public void setComments(CommentsBookingReqDTO comments) {
			this.comments = comments;
		}

		/**
		 * Gets the room rate.
		 *
		 * @return the roomRate
		 */
		public List<RoomRateReqDTO> getRoomRate() {
			return roomRate;
		}

		/**
		 * Sets the room rate.
		 *
		 * @param roomRate the roomRate to set
		 */
		public void setRoomRate(List<RoomRateReqDTO> roomRate) {
			this.roomRate = roomRate;
		}

		/**
		 * Gets the basic property info.
		 *
		 * @return the basicPropertyInfo
		 */
		public BasicPropertyInfoReqDTO getBasicPropertyInfo() {
			return basicPropertyInfo;
		}

		/**
		 * Sets the basic property info.
		 *
		 * @param basicPropertyInfo the basicPropertyInfo to set
		 */
		public void setBasicPropertyInfo(BasicPropertyInfoReqDTO basicPropertyInfo) {
			this.basicPropertyInfo = basicPropertyInfo;
		}


		/**
		 * Gets the deposit payments.
		 *
		 * @return the deposit payments
		 */
		public DepositPaymentsReqDTO getDepositPayments() {
			return depositPayments;
		}

		/**
		 * Sets the deposit payments.
		 *
		 * @param depositPayments the new deposit payments
		 */
		public void setDepositPayments(DepositPaymentsReqDTO depositPayments) {
			this.depositPayments = depositPayments;
		}

		/**
		 * Gets the res guest RPH.
		 *
		 * @return the resGuestRPH
		 */
		public List<ResGuestRPHReqDTO> getResGuestRPH() {
			return resGuestRPH;
		}

		/**
		 * Sets the res guest RPH.
		 *
		 * @param resGuestRPH the resGuestRPH to set
		 */
		public void setResGuestRPH(List<ResGuestRPHReqDTO> resGuestRPH) {
			this.resGuestRPH = resGuestRPH;
		}

		/**
		 * Gets the time span.
		 *
		 * @return the timeSpan
		 */
		public TimeSpanReqDTO getTimeSpan() {
			return timeSpan;
		}

		/**
		 * Sets the time span.
		 *
		 * @param timeSpan the timeSpan to set
		 */
		public void setTimeSpan(TimeSpanReqDTO timeSpan) {
			this.timeSpan = timeSpan;
		}

		/**
		 * Gets the total.
		 *
		 * @return the total
		 */
		public TotalReqDTO getTotal() {
			return total;
		}

		/**
		 * Sets the total.
		 *
		 * @param total the total to set
		 */
		public void setTotal(TotalReqDTO total) {
			this.total = total;
		}

		/**
		 * Gets the source of business.
		 *
		 * @return the sourceOfBusiness
		 */
		public String getSourceOfBusiness() {
			return sourceOfBusiness;
		}

		/**
		 * Sets the source of business.
		 *
		 * @param sourceOfBusiness the sourceOfBusiness to set
		 */
		public void setSourceOfBusiness(String sourceOfBusiness) {
			this.sourceOfBusiness = sourceOfBusiness;
		}

	    
}
