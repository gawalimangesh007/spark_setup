package com.sterling.bookingapi.controller;

import java.io.IOException;
import java.text.ParseException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.sterling.bookingapi.bean.HsdRegisterRequest;
import com.sterling.bookingapi.bean.HsdRegisterResponse;
import com.sterling.bookingapi.exception.SalesForceException;
import com.sterling.bookingapi.service.HsdRegisterServiceInterface;


/**
 * The Class HsdRegistrationController.
 */
/**
 * @author tcs
 *
 */
@RestController
public class HsdRegistrationController extends BaseController {

	/** The hsd register service interface. */
	@Autowired
	private HsdRegisterServiceInterface hsdRegisterServiceInterface;
	/** The Constant logger. */
	private static final Logger logger = LogManager.getLogger(HsdRegistrationController.class);
	/**
	 * Method to store the HSD user details .
	 *
	 * @param hsdRegisterReq - An object of HsdRegisterRequest
	 * @return the output as an object of HsdRegisterResponse.
	 * @throws ParseException the parse exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws SalesForceException the sales force exception
	 */
	@ResponseBody
	@RequestMapping(value = "/hsdRegisteration", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	public HsdRegisterResponse createUser(
			@RequestBody final HsdRegisterRequest hsdRegisterReq) throws ParseException, IOException, SalesForceException {
		logger.info("HsdRegistrationController : createUser : Entered.");
		logger.info("HsdRegistrationController : createUser : Leaving.");
		return hsdRegisterServiceInterface.getHsdRegisterStatus(hsdRegisterReq);
	}
}