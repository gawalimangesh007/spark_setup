package com.sterling.bookingapi.dto.request;

public class OTPGenerateRequest {
	private String bookingId;
	private String emailId;
	private String userType;
	//private String OTPFor;
	//private String OTPMsg;
	
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	public String getBookingId() {
		return bookingId;
	}
	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}
	/*public String getOTPFor() {
		return OTPFor;
	}
	public void setOTPFor(String oTPFor) {
		OTPFor = oTPFor;
	}*/
	/*public String getOTPMsg() {
		return OTPMsg;
	}
	public void setOTPMsg(String oTPMsg) {
		OTPMsg = oTPMsg;
	}	*/
	
}
