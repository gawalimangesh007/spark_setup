package com.sterling.bookingapi.dto.maximojo.response;

import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class ResGlobalInfoResDTO.
 * @author tcs
 * @version 1.0
 */
public class ResGlobalInfoResDTO {

	/** The hotel reservation ID. */
	@JacksonXmlElementWrapper(useWrapping=true, localName = "HotelReservationIDs")
	@JacksonXmlProperty(localName = "HotelReservationID")
	private List<HotelReservationIDResDTO> hotelReservationID;

	/** The total. */
	@JacksonXmlProperty(localName = "Total")
    private TotalResDTO total;

	/**
	 * Gets the hotel reservation ID.
	 *
	 * @return the hotelReservationID
	 */
	public List<HotelReservationIDResDTO> getHotelReservationID() {
		return hotelReservationID;
	}

	/**
	 * Sets the hotel reservation ID.
	 *
	 * @param hotelReservationID the hotelReservationID to set
	 */
	public void setHotelReservationID(List<HotelReservationIDResDTO> hotelReservationID) {
		this.hotelReservationID = hotelReservationID;
	}

	/**
	 * Gets the total.
	 *
	 * @return the total
	 */
	public TotalResDTO getTotal() {
		return total;
	}

	/**
	 * Sets the total.
	 *
	 * @param total the total to set
	 */
	public void setTotal(TotalResDTO total) {
		this.total = total;
	}
	
	
	
}
