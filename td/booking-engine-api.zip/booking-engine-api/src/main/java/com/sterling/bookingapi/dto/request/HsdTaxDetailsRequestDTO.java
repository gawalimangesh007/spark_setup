package com.sterling.bookingapi.dto.request;


/**
 * The Class HsdTaxDetailsRequestDTO.
 */
/**
 * @author tcs
 *
 */
public class HsdTaxDetailsRequestDTO {
	
	/** The food tax amount. */
	private double foodTaxAmount;
	
	/** The spa tax amount. */
	private double spaTaxAmount;
	
	/**
	 * Gets the food tax amount.
	 *
	 * @return the food tax amount
	 */
	public double getFoodTaxAmount() {
		return foodTaxAmount;
	}
	
	/**
	 * Sets the food tax amount.
	 *
	 * @param foodTaxAmount the new food tax amount
	 */
	public void setFoodTaxAmount(double foodTaxAmount) {
		this.foodTaxAmount = foodTaxAmount;
	}
	
	/**
	 * Gets the spa tax amount.
	 *
	 * @return the spa tax amount
	 */
	public double getSpaTaxAmount() {
		return spaTaxAmount;
	}
	
	/**
	 * Sets the spa tax amount.
	 *
	 * @param spaTaxAmount the new spa tax amount
	 */
	public void setSpaTaxAmount(double spaTaxAmount) {
		this.spaTaxAmount = spaTaxAmount;
	}
}