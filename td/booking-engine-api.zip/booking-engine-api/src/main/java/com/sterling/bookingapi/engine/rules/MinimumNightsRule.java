package com.sterling.bookingapi.engine.rules;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;

import com.sterling.bookingapi.dto.request.VOConfirmBookingRequest;
import com.sterling.bookingapi.dto.response.VODashboardResponse;
import com.sterling.bookingapi.dto.response.VOUnitProductPointMatrixResDTO;
import com.sterling.bookingapi.engine.rules.models.VOBookingRuleDTO;


@Rule(name="MinimumNightsRule", description="MIN_NIGHT_RULE")
public class MinimumNightsRule {

	private static final Logger logger = LogManager.getLogger(MinimumNightsRule.class);
	
	@Condition
	public boolean when(@Fact("bookingRequest") VOConfirmBookingRequest req, 
			@Fact("productRules") Map<String, List<VOBookingRuleDTO>> rulesMap,
			@Fact("memberDetail") VODashboardResponse memberDetail,
			@Fact("pointMatrix") List<VOUnitProductPointMatrixResDTO> pointMatrixList,
			@Fact("bookingSeasons") Set<String> bookingSeason) {
		//my rule conditions
		logger.info("################# excecuting condition");
		
		
		return true;
	}

	@Action(order = 1)
	public void then() throws Exception {
		//my actions
		logger.info("################# excecuting action");
	}
}
