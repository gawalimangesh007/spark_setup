package com.sterling.bookingapi.dto.request;


/**
 * The Class UserGetDetailsReqeustDTO.
 */
/**
 * @author tcs
 *
 */
public class UserGetDetailsReqeustDTO {

	/** The email. */
	private String email;

	/**
	 * Gets the email.
	 *
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * Sets the email.
	 *
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}
}
