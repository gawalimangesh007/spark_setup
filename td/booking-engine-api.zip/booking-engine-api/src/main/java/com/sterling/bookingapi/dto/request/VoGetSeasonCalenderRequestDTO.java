package com.sterling.bookingapi.dto.request;

import java.io.Serializable;

import javax.validation.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


/**
 * The Class HsdBookingOfferDetailsDTO.
 */
/**
 * @author tcs
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class VoGetSeasonCalenderRequestDTO extends VoBaseRequestDTO implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@NotEmpty(message = "Resort master id should not be empty")
	private String resortMasterId;
	
	@NotEmpty(message = "productCode should not be empty")
	private String productCode;



	public String getProductCode() {
		return productCode;
	}


	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}


	/**
	 * @return resortMasterId
	 */
	public String getResortMasterId() {
		return resortMasterId;
	}


	/**
	 * @param resortMasterId
	 * set the resortMasterId
	 */
	public void setResortMasterId(String resortMasterId) {
		this.resortMasterId = resortMasterId;
	}
	
	
	
}