package com.sterling.bookingapi.dto.request;

public class HsdGetBookingDetailsDTO {

	private String bookingId;

	public String getBookingId() {
		return bookingId;
	}

	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}
		
}
