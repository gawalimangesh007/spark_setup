package com.sterling.bookingapi.engine;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.lang.BooleanUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jeasy.rules.api.Facts;
import org.jeasy.rules.api.Rule;
import org.jeasy.rules.api.Rules;
import org.jeasy.rules.api.RulesEngine;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.type.TypeReference;
import com.google.common.collect.Sets;
import com.sterling.bookingapi.dto.request.VOConfirmBookingRequest;
import com.sterling.bookingapi.dto.response.VOConfigResponseDTO;
import com.sterling.bookingapi.dto.response.VODashboardResponse;
import com.sterling.bookingapi.dto.response.VOSeasonWeekDTO;
import com.sterling.bookingapi.dto.response.VOUnitProductPointMatrixResDTO;
import com.sterling.bookingapi.engine.rules.BookingPointsRule;
import com.sterling.bookingapi.engine.rules.MaxBookingInYearRule;
import com.sterling.bookingapi.engine.rules.MaxUtilizationInYearRule;
import com.sterling.bookingapi.engine.rules.MaxVacationGuestRule;
import com.sterling.bookingapi.engine.rules.MaxVacationGuestYearRule;
import com.sterling.bookingapi.engine.rules.MaxVacationRule;
import com.sterling.bookingapi.engine.rules.MinimumNightsRule;
import com.sterling.bookingapi.engine.rules.PurpleTravelRule;
import com.sterling.bookingapi.engine.rules.RedTravelRule;
import com.sterling.bookingapi.engine.rules.models.BookingRule;
import com.sterling.bookingapi.engine.rules.models.ProductRuleDTO;
import com.sterling.bookingapi.engine.rules.models.VOBookingRuleDTO;
import com.sterling.bookingapi.exception.BookingEngineException;
import com.sterling.bookingapi.service.VOBookingService;
import com.sterling.bookingapi.service.VOConfigService;
import com.sterling.bookingapi.service.VODashboardService;
import com.sterling.bookingapi.service.VacationOwnershipService;
import com.sterling.bookingapi.sf.dto.response.VOConfigResDTO;
import com.sterling.bookingapi.utils.AppConstants;
import com.sterling.bookingapi.utils.BookingEngineUtils;

@Component
public class VOBookingRuleEngine {

	private static final String FACTS_BRD_FLAG = "brdFlag";


	private static final String FACTS_SEASONS_WEEKS = "seasonsWeeks";


	private static final String FACTS_BOOKING_SEASONS = "bookingSeasons";


	private static final String FACTS_POINT_MATRIX = "pointMatrix";


	private static final String FACTS_RULE_CONFIG = "ruleConfig";


	private static final String FACTS_PRODUCT_RULES = "productRules";


	private static final String FACTS_MEMBER_DETAIL = "memberDetail";


	private static final String FACTS_BOOKING_REQUEST = "bookingRequest";


	/** The Constant logger. */
	private static final Logger logger = LogManager.getLogger(VOBookingRuleEngine.class);
	
	
	@Autowired
	private RulesEngine rulesEngine;
	
	@Autowired
	private CacheManager cacheManager;

	@Autowired
	private VODashboardService dashboardService;
	
	@Autowired
	private VacationOwnershipService voService;

	@Autowired
	private VOBookingService voBkService;

		
	@Autowired
	private VOConfigService configService;


	@Value(value = "${sterling.booking.rule.engine.enabled}")
	private boolean isRuleEngineEnabled;
	
	//TODO autowire springRules
	
	public boolean validateRules(VOConfirmBookingRequest req, boolean brdFlag) {
		logger.info("====================== Checking rule ============================");
		logger.info("==== \nContract Id: {}, \nproduct Code : {}, \nProductId: {}, \nResortMasterId:{}",
				req.getContractId(), req.getProductCode(), req.getProductId(), req.getResortMasterId());
		
		VODashboardResponse memberDetails = dashboardService.getMemberDetailsFromCache(req.getContractId());
		List<VOSeasonWeekDTO> seasonsWeeks = voService.getSeasonsBetween(req.getCheckInDate(), req.getCheckOutDate(), req.getProductCode(), req.getResortSerielNo());
		Set<String> bookingSeasons = getBookingSeasons(seasonsWeeks); 
		ProductRuleDTO rulesConfig = getAdminRulesConfig(req.getProductCode());
		List<VOUnitProductPointMatrixResDTO> pointMatrixList = getPointMatrix(req.getProductId(), req.getResortMasterId());
		Map<String, List<VOBookingRuleDTO>> productRule = getProductRule(rulesConfig, memberDetails.getMembershipDetails().getProductCode());
		if(productRule.isEmpty()) {
			logger.error("rules not configured for the prodcut id {}", req.getProductCode());
		}
//		rulesEngine.clearRules();
		Rules rules = getRules(productRule);
		
		if(rules.isEmpty()) {
			logger.info("====================== No rules to excecute for this booking ============================");
			return true;
		}
		
		Facts facts = new Facts();
		facts.put(FACTS_BOOKING_REQUEST, req);
		facts.put(FACTS_MEMBER_DETAIL, memberDetails);
		facts.put(FACTS_PRODUCT_RULES, productRule);
		facts.put(FACTS_RULE_CONFIG, rulesConfig);
		facts.put(FACTS_POINT_MATRIX, pointMatrixList);
		facts.put(FACTS_BOOKING_SEASONS, bookingSeasons);
		facts.put(FACTS_SEASONS_WEEKS, seasonsWeeks);
		facts.put(FACTS_BRD_FLAG, brdFlag);
		
		
		Map<Rule, Boolean> rulesResult = rulesEngine.check(rules, facts);
		
		for (Entry<Rule, Boolean> entry : rulesResult.entrySet()) {
			if(!entry.getValue().booleanValue()) {
				String descCode = entry.getKey().getDescription();
				throw BookingEngineUtils.getBEException(descCode);
			}
		}
		
		return true;
		
	}

	private Set<String> getBookingSeasons(List<VOSeasonWeekDTO> seasonsWeeks) {
		Set<String> bookingSeasons = Sets.newHashSet();
		for (VOSeasonWeekDTO voSeasonWeekDTO : seasonsWeeks) {
			bookingSeasons.add(voSeasonWeekDTO.getSeason());
		}
		return bookingSeasons;
	}

	private List<VOUnitProductPointMatrixResDTO> getPointMatrix(
			String productId, String resortMasterId) {
		Cache cache = cacheManager.getCache(AppConstants.cacheGroups.dashboardCache.name());
		
		List<VOUnitProductPointMatrixResDTO> pointmatrix = cache.get(productId + resortMasterId, List.class);
		return pointmatrix;
	}

	/**
	 * returns a configured rule matched with the member product  
	 * @param rulesConfig
	 * @param memberProductId
	 * @return
	 */
	private Map<String, List<VOBookingRuleDTO>> getProductRule(ProductRuleDTO rule,
			String memberProductId) {
		Map<String, List<VOBookingRuleDTO>> ruleMap = new HashMap<String, List<VOBookingRuleDTO>>();

		if(rule != null) {
			//throw new BookingEngineException("RE_RULES_NOT_AVAILABLE_FOR_PRODUCT");

			for (VOBookingRuleDTO ruleConfig : rule.getRules()) {
				if(BooleanUtils.isFalse(ruleConfig.getActive())) {
					continue;//ignore inactive rules
				}

				List<VOBookingRuleDTO> bookRule = null;
				if(ruleMap.containsKey(ruleConfig.getRuleName())) {
					bookRule  = ruleMap.get(ruleConfig.getRuleName());
				} else {
					bookRule = new ArrayList<VOBookingRuleDTO>();
				}
				bookRule.add(ruleConfig);
				ruleMap.put(ruleConfig.getRuleName(), bookRule);
			}
		}
		return ruleMap;
	}

	/**
	 * Get the rules config from the cache,
	 * If not available in cache, get from the AEM node
	 * @param memberProduct 
	 * 
	 * @return
	 */
	public ProductRuleDTO getAdminRulesConfig(String productId) {
		Cache cache = cacheManager.getCache(AppConstants.cacheGroups.ruleEngineCache.toString());
		String key = AppConstants.VO_BK_RULE_PREFIX + productId;
		ProductRuleDTO rulesConfig = cache.get(key, ProductRuleDTO.class);
		if(rulesConfig  == null) {
			try {
				VOConfigResponseDTO voConfig = configService.getConfig(key);
				if(voConfig != null) {
					rulesConfig = BookingEngineUtils.convertJsonToObject(voConfig.getValue(), new TypeReference<ProductRuleDTO>() {});
				}
			} catch (Exception e) {
				throw new BookingEngineException("ERROR_ON_FETCHING_RULES_CONFIG",e);
			}
		}
		
		return rulesConfig;
	}

	private Rules getRules(Map<String, List<VOBookingRuleDTO>> productRule) {
		Rules rules = new Rules();
		
		//add booking point rule by default
		//rules.register(new BookingPointsRule());
		
		List<VOConfigResDTO> enabledRules = configService.getEnabledRules();
		
		if(!productRule.isEmpty()) {

			for (Entry<String, List<VOBookingRuleDTO>> ruleEntry : productRule.entrySet()) {
				String ruleName = ruleEntry.getValue().get(0).getRuleName();
				BookingRule bookingRule = BookingRule.getByName(ruleName);

				boolean isRuleEnabled = isRuleEnabled(enabledRules, bookingRule);
				
				if(bookingRule != null && isRuleEngineEnabled && isRuleEnabled) {

					switch (bookingRule) {
					case MIN_POINT_RULE:
						//rules.register(new MinimumPointsRule());
						break;
					case MIN_NIGHT_RULE:
						//rules.register(	new MinimumNightsRule());
						break;
					case PURPLE_TRAVEL_RULE:
						rules.register(	new PurpleTravelRule());
						break;
					case RED_TRAVEL_RULE:
						rules.register(	new RedTravelRule());
						break;
					case BLUE_TRAVEL_RULE:
						//rules.register(	new BlueTravelRule());
						break;
					case WHITE_TRAVEL_RULE:
						//rules.register(	new WhiteTravelRule());
						break;
					case BLUE_PRIOR_TRAVEL_RULE:
						//rules.register(	new BluePriorTravelRule());
						break;
					case WHITE_PRIOR_TRAVEL_RULE:
						//rules.register(	new WhitePriorTravelRule());
						break;
					case MAX_BOOK_IN_YEAR_RULE:
						rules.register(	new MaxBookingInYearRule());
						break;
					case MIN_VACATION_RULE:
						rules.register(	new MaxVacationRule());
						break;
					case MIN_VACATION_GUEST_RULE:
						rules.register(new MaxVacationGuestRule());
						break;
					case MIN_VACATION_GUEST_YR_RULE:
						rules.register(new MaxVacationGuestYearRule());
						break;
					case MAX_UTILIZATION_RULE:
						rules.register(	new MaxUtilizationInYearRule());
						break;
					case ADVANCE_FACILITY_RULE:
					//	rules.register(	new AdvanceFacilityRule());
						break;
					case BOOKING_WINDOW_RULE:
					//	rules.register(	new BookingWindowRule());
						break;
					default:
						break;
					}
				}
			}
		} else {
			logger.warn("rules not configured for the prodcut id {}");
		}

		return rules;
	}

	private boolean isRuleEnabled(List<VOConfigResDTO> enabledRules, BookingRule bookingRule) {
		if(bookingRule != null) {
			for (VOConfigResDTO voConfigResDTO : enabledRules) {
				if(voConfigResDTO.getKey().contains(bookingRule.getRuleName()) && voConfigResDTO.getValue().equalsIgnoreCase("false")) {
					return false;
				}
			}
		}
		return true;
	}

	public void cacheRuleConfig(String key, ProductRuleDTO rule) {
		Cache cache = cacheManager.getCache(AppConstants.cacheGroups.ruleEngineCache.name());
		cache.put(key, rule);
	}
}
