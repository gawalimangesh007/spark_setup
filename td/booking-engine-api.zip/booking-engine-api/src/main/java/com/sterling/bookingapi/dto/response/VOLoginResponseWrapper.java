package com.sterling.bookingapi.dto.response;

import java.io.Serializable;
import java.util.List;

import com.sterling.bookingapi.dto.request.VoCaptureKycRequestDTO;

/**
 * @author tcs
 * @version 1.0
 */
public class VOLoginResponseWrapper implements Serializable {
 
	private static final long serialVersionUID = 1L;
	
	private LoginType type;
	private boolean changePassword;
	private List<?> contracts;
	private String status;
	private VOLMSSaleResponse lmsSaleResponse;
	private VOLeadProduct leadProduct;
	private VoCaptureKycRequestDTO kycDetails;
	
	/**
	 * @return the kycDetails
	 */
	public VoCaptureKycRequestDTO getKycDetails() {
		return kycDetails;
	}
	/**
	 * @param kycDetails the kycDetails to set
	 */
	public void setKycDetails(VoCaptureKycRequestDTO kycDetails) {
		this.kycDetails = kycDetails;
	}
	/**
	 * @return type
	 */
	public LoginType getType() {
		return type;
	}
	/**
	 * @param type
	 * set the type
	 */
	public void setType(LoginType type) {
		this.type = type;
	}
	/**
	 * @return contracts
	 */
	public List<?> getContracts() {
		return contracts;
	}
	/**
	 * @param records
	 * set the records
	 */
	public void setContracts(List<?> records) {
		this.contracts = records;
	}
	/**
	 * @return status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status
	 * set the status
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @return lmsSaleResponse
	 */
	public VOLMSSaleResponse getLmsSaleResponse() {
		return lmsSaleResponse;
	}
	/**
	 * @param lmlSaleResponse
	 * set the lmsSaleResponse
	 */
	public void setLmsSaleResponse(VOLMSSaleResponse lmlSaleResponse) {
		this.lmsSaleResponse = lmlSaleResponse;
	}
	public VOLeadProduct getLeadProduct() {
		return leadProduct;
	}
	public void setLeadProduct(VOLeadProduct leadProduct) {
		this.leadProduct = leadProduct;
	}
	public boolean isChangePassword() {
		return changePassword;
	}
	public void setChangePassword(boolean changePassword) {
		this.changePassword = changePassword;
	}	
}
