package com.sterling.bookingapi.dto.request;

import java.io.Serializable;
import java.util.List;

public class VoEssentialsRequest implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String mobileNumber;
	
	private String bookingCV;
	
	private String resortName;
	
	private List<String> email;
	
	private String[] essentials;

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public List<String> getEmail() {
		return email;
	}

	public void setEmail(List<String> email) {
		this.email = email;
	}

	public String[] getEssentials() {
		return essentials;
	}

	public void setEssentials(String[] essentials) {
		this.essentials = essentials;
	}

	public String getBookingCV() {
		return bookingCV;
	}

	public void setBookingCV(String bookingCV) {
		this.bookingCV = bookingCV;
	}

	public String getResortName() {
		return resortName;
	}

	public void setResortName(String resortName) {
		this.resortName = resortName;
	}
	

}
