package com.sterling.bookingapi.dto.request;

import java.io.Serializable;

import javax.validation.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class VOLeadRegReq implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@NotEmpty(message = "leadId is mandatory")
	private String leadId;
	
	@NotEmpty(message = "OTP number is mandatory")
	private String otp;

	public String getLeadId() {
		return leadId;
	}

	public void setLeadId(String leadId) {
		this.leadId = leadId;
	}

	public String getOtp() {
		return otp;
	}

	public void setOtp(String otp) {
		this.otp = otp;
	}

}
