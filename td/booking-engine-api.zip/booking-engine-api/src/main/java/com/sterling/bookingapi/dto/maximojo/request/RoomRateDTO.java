package com.sterling.bookingapi.dto.maximojo.request;

import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

public class RoomRateDTO {
	@JacksonXmlProperty(localName = "Rate")
    private RateBooingReqDTO rate;
	
	@JacksonXmlProperty(localName = "Discounts")
    private DiscountsRatesDTO discounts;
	
	@JacksonXmlProperty(localName = "Taxes")
    private TaxRatesDTO taxes;
	
	@JacksonXmlProperty(localName = "ExtraPersonDetails")
    private ExtraPersonRateDTO extraPersonRate;


	/**
	 * @return the rate
	 */
	public RateBooingReqDTO getRate() {
		return rate;
	}


	/**
	 * @param rate the rate to set
	 */
	public void setRate(RateBooingReqDTO rate) {
		this.rate = rate;
	}


	/**
	 * @return the discounts
	 */
	public DiscountsRatesDTO getDiscounts() {
		return discounts;
	}


	/**
	 * @param discounts the discounts to set
	 */
	public void setDiscounts(DiscountsRatesDTO discounts) {
		this.discounts = discounts;
	}


	/**
	 * @return the taxes
	 */
	public TaxRatesDTO getTaxes() {
		return taxes;
	}


	/**
	 * @param taxes the taxes to set
	 */
	public void setTaxes(TaxRatesDTO taxes) {
		this.taxes = taxes;
	}


	/**
	 * @return the extraPersonRate
	 */
	public ExtraPersonRateDTO getExtraPersonRate() {
		return extraPersonRate;
	}


	/**
	 * @param extraPersonRate the extraPersonRate to set
	 */
	public void setExtraPersonRate(ExtraPersonRateDTO extraPersonRate) {
		this.extraPersonRate = extraPersonRate;
	}
	
}
