package com.sterling.bookingapi.dto.response;


/**
 * @author tcs
 * @version 1.0
 */
public class HsdBookingRoomTypeRentalAmountResponseDTO {

	/** The resort id. */
	private int resortId;
	
	/** The room type id. */
	private int roomTypeId;
	
	/** The room type. */
	private String roomType;
	
	/** The room count. */
	private int roomCount;
	
	/** The room rent. */
	private double roomRent;
	
	/** The is extra bed. */
	private boolean isExtraBed;
	
	/**
	 * Gets the resort id.
	 *
	 * @return the resort id
	 */
	public int getResortId() {
		return resortId;
	}
	
	/**
	 * Sets the resort id.
	 *
	 * @param resortId the new resort id
	 */
	public void setResortId(int resortId) {
		this.resortId = resortId;
	}
	
	/**
	 * Gets the room type id.
	 *
	 * @return the room type id
	 */
	public int getRoomTypeId() {
		return roomTypeId;
	}
	
	/**
	 * Sets the room type id.
	 *
	 * @param roomTypeId the new room type id
	 */
	public void setRoomTypeId(int roomTypeId) {
		this.roomTypeId = roomTypeId;
	}
	
	/**
	 * Gets the room count.
	 *
	 * @return the room count
	 */
	public int getRoomCount() {
		return roomCount;
	}
	
	/**
	 * Sets the room count.
	 *
	 * @param roomCount the new room count
	 */
	public void setRoomCount(int roomCount) {
		this.roomCount = roomCount;
	}
	
	/**
	 * Gets the room rent.
	 *
	 * @return the room rent
	 */
	public double getRoomRent() {
		return roomRent;
	}
	
	/**
	 * Sets the room rent.
	 *
	 * @param roomRent the new room rent
	 */
	public void setRoomRent(double roomRent) {
		this.roomRent = roomRent;
	}
	
	/**
	 * Checks if is extra bed.
	 *
	 * @return true, if is extra bed
	 */
	public boolean isExtraBed() {
		return isExtraBed;
	}
	
	/**
	 * Sets the extra bed.
	 *
	 * @param isExtraBed the new extra bed
	 */
	public void setExtraBed(boolean isExtraBed) {
		this.isExtraBed = isExtraBed;
	}
	
	/**
	 * Gets the room type.
	 *
	 * @return the room type
	 */
	public String getRoomType() {
		return roomType;
	}
	
	/**
	 * Sets the room type.
	 *
	 * @param roomType the new room type
	 */
	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}

	
}
