package com.sterling.bookingapi.dto.response;

import java.util.ArrayList;
import java.util.List;

import com.sterling.bookingapi.utils.AppConstants.VORoomTypes;

/**
 * @author tcs
 * @version 1.0
 */
public class VOGetAvailRoomsResponseDTO {

	private VORoomTypes roomType;

	private String pointsToBeDeducted;

	private List<VOGetAvailabilityCountResponseDTO> roomAvailabilityCount;


	/**
	 * @return pointsToBeDeducted
	 */
	public String getPointsToBeDeducted() {
		return pointsToBeDeducted;
	}

	/**
	 * @param pointsToBeDeducted
	 * set the pointsToBeDeducted
	 */
	public void setPointsToBeDeducted(String pointsToBeDeducted) {
		this.pointsToBeDeducted = pointsToBeDeducted;
	}

	/**
	 * @return roomType
	 */
	public VORoomTypes getRoomType() {
		return roomType;
	}

	/**
	 * @param roomType
	 * set the roomType
	 */
	public void setRoomType(VORoomTypes roomType) {
		this.roomType = roomType;
	}

	/**
	 * @return roomAvailabilityCount
	 */
	public List<VOGetAvailabilityCountResponseDTO> getRoomAvailabilityCount() {
		if (roomAvailabilityCount == null) {
			this.roomAvailabilityCount = new ArrayList<>();
		}
		return roomAvailabilityCount;
	}

	/**
	 * @param roomAvailabilityCount
	 * set the roomAvailabilityCount
	 */
	public void setRoomAvailabilityCount(List<VOGetAvailabilityCountResponseDTO> roomAvailabilityCount) {
		this.roomAvailabilityCount = roomAvailabilityCount;
	}

}
