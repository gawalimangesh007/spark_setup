package com.sterling.bookingapi.dto.request;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class VOOfferRequest implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String startDate;
	private String endDate;
	private String productCode;
	private String channelName;
	private String lmsProductPlanId;
	private String lmsDownpaymentId;
	
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getLmsProductPlanId() {
		return lmsProductPlanId;
	}
	public void setLmsProductPlanId(String lmsProductPlanId) {
		this.lmsProductPlanId = lmsProductPlanId;
	}
	public String getLmsDownpaymentId() {
		return lmsDownpaymentId;
	}
	public void setLmsDownpaymentId(String lmsDownpaymentId) {
		this.lmsDownpaymentId = lmsDownpaymentId;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getChannelName() {
		return channelName;
	}
	public void setChannelName(String channelName) {
		this.channelName = channelName;
	}
}
