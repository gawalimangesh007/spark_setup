package com.sterling.bookingapi.dto.maximojo.request;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;


/**
 * The Class HotelRefReqDTO.
 */
/**
 * @author tcs
 *
 */
@JacksonXmlRootElement(localName = "HotelRef")
public class HotelRefReqDTO {
	
	/** The hotel code. */
	@JacksonXmlProperty(localName = "HotelCode", isAttribute = true)
    private String hotelCode;

	/** The chain code. */
	@JacksonXmlProperty(localName = "ChainCode", isAttribute = true)
	private String chainCode;
	 
	/**
	 * Gets the hotel code.
	 *
	 * @return the hotel code
	 */
	public String getHotelCode() {
		return hotelCode;
	}

	/**
	 * Sets the hotel code.
	 *
	 * @param hotelCode the new hotel code
	 */
	public void setHotelCode(String hotelCode) {
		this.hotelCode = hotelCode;
	}

	/**
	 * Gets the chain code.
	 *
	 * @return the chain code
	 */
	public String getChainCode() {
		return chainCode;
	}

	/**
	 * Sets the chain code.
	 *
	 * @param chainCode the new chain code
	 */
	public void setChainCode(String chainCode) {
		this.chainCode = chainCode;
	}



}