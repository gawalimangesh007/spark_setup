package com.sterling.bookingapi.dto.maximojo.request;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class LengthOfStayReqDTO.
 */
/**
 * @author tcs
 *
 */
public class LengthOfStayReqDTO {


	/** The time. */
	@JacksonXmlProperty(localName = "Time", isAttribute = true)
	private int time;

	/** The min max message type. */
	@JacksonXmlProperty(localName = "MinMaxMessageType", isAttribute = true)
    private String minMaxMessageType;

	/**
	 * Gets the time.
	 *
	 * @return the time
	 */
	public int getTime() {
		return time;
	}

	/**
	 * Sets the time.
	 *
	 * @param time the time to set
	 */
	public void setTime(int time) {
		this.time = time;
	}

	/**
	 * Gets the min max message type.
	 *
	 * @return the minMaxMessageType
	 */
	public String getMinMaxMessageType() {
		return minMaxMessageType;
	}

	/**
	 * Sets the min max message type.
	 *
	 * @param minMaxMessageType the minMaxMessageType to set
	 */
	public void setMinMaxMessageType(String minMaxMessageType) {
		this.minMaxMessageType = minMaxMessageType;
	}
	
	

}
