package com.sterling.bookingapi.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.sterling.bookingapi.dto.request.HsdFeedbackQueryRequestDTO;
import com.sterling.bookingapi.dto.response.ResponseDTO;
import com.sterling.bookingapi.exception.BookingEngineException;
import com.sterling.bookingapi.service.HsdFeedbackQueryService;


/**
 * The Class HsdFeedbackQueryController.
 */
/**
 * @author tcs
 *
 */
@RestController

public class HsdFeedbackQueryController extends BaseController {

	/** The Constant logger. */
	private static final Logger logger = LogManager.getLogger(HsdFeedbackQueryController.class);
	
	/** The hsd feedback query service. */
	@Autowired
	private HsdFeedbackQueryService hsdFeedbackQueryService;
	
	
	/**
	 * Creates the package.
	 *
	 * @param hsdFeedbackQueries the hsd feedback queries
	 * @return the response DTO
	 * @throws BookingEngineException the booking engine exception
	 */
	@ResponseBody
	@RequestMapping(value = "/hsdFeedbackQuery", method = RequestMethod.POST)
	public ResponseDTO createPackage(@RequestBody final HsdFeedbackQueryRequestDTO hsdFeedbackQueries) 
						throws BookingEngineException {
		logger.info("hsdFeedbackQueryService : createFeedbackQuery : Entered.");
		ResponseDTO response = hsdFeedbackQueryService.createFeedbackQuery(hsdFeedbackQueries); 

		logger.info(" hsdFeedbackQueryService : createFeedbackQuery : Leaving.");
		return response;
	}
		
}
