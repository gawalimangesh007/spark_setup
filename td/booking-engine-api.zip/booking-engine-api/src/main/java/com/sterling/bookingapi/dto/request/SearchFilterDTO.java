package com.sterling.bookingapi.dto.request;


/**
 * The Class SearchFilterDTO.
 */
/**
 * @author tcs
 *
 */
public class SearchFilterDTO {

	/** The name. */
	private String name;
	
	/** The is active. */
	private boolean isActive;

	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Sets the name.
	 *
	 * @param name the new name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Checks if is active.
	 *
	 * @return true, if is active
	 */
	public boolean isActive() {
		return isActive;
	}

	/**
	 * Sets the active.
	 *
	 * @param isActive the new active
	 */
	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}
	
	
}
