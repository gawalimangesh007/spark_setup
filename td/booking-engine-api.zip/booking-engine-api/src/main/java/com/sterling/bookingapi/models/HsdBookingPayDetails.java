package com.sterling.bookingapi.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;


/**
 * The Class HsdBookingPayDetails.
 */
/**
 * @author tcs
 *
 */
@Entity
@Table(name = "sh_hsd_booking_payment_details")
public class HsdBookingPayDetails extends BaseModel{
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The pay id. */
	@Id
	@GeneratedValue( strategy = GenerationType.IDENTITY )
	@Column(name = "pay_idx_id", unique = true)
	private int payId;
	
	/** The hsd booking details. */
	@OneToOne
	@JoinColumn(name="booking_idx_id", unique = false)
	private HsdBookingDetails hsdBookingDetails;
	
	/** The payment status. */
	@Column(name = "payment_status",nullable = false)
	private String paymentStatus;
	
	/** The request object. */
	@Column(name = "request_object",nullable = false)
	private String requestObject;
	
	/** The reponse object. */
	@Column(name = "response_object",nullable = false)
	private String reponseObject;
		
	/** The txn ref id. */
	@Column(name = "txn_ref_id",nullable = false)
	private String txnRefId;

	/** The payment vendor. */
	@Column(name = "payment_vendor",nullable = false)
	private String paymentVendor;

	/**
	 * Gets the pay id.
	 *
	 * @return the pay id
	 */
	public int getPayId() {
		return payId;
	}

	/**
	 * Sets the pay id.
	 *
	 * @param payId the new pay id
	 */
	public void setPayId(int payId) {
		this.payId = payId;
	}

	/**
	 * Gets the hsd booking details.
	 *
	 * @return the hsd booking details
	 */
	public HsdBookingDetails getHsdBookingDetails() {
		return hsdBookingDetails;
	}

	/**
	 * Sets the hsd booking details.
	 *
	 * @param hsdBookingDetails the new hsd booking details
	 */
	public void setHsdBookingDetails(HsdBookingDetails hsdBookingDetails) {
		this.hsdBookingDetails = hsdBookingDetails;
	}

	/**
	 * Gets the payment status.
	 *
	 * @return the payment status
	 */
	public String getPaymentStatus() {
		return paymentStatus;
	}

	/**
	 * Sets the payment status.
	 *
	 * @param paymentStatus the new payment status
	 */
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	/**
	 * Gets the request object.
	 *
	 * @return the request object
	 */
	public String getRequestObject() {
		return requestObject;
	}

	/**
	 * Sets the request object.
	 *
	 * @param requestObject the new request object
	 */
	public void setRequestObject(String requestObject) {
		this.requestObject = requestObject;
	}

	/**
	 * Gets the reponse object.
	 *
	 * @return the reponse object
	 */
	public String getReponseObject() {
		return reponseObject;
	}

	/**
	 * Sets the reponse object.
	 *
	 * @param reponseObject the new reponse object
	 */
	public void setReponseObject(String reponseObject) {
		this.reponseObject = reponseObject;
	}

	/**
	 * Gets the txn ref id.
	 *
	 * @return the txn ref id
	 */
	public String getTxnRefId() {
		return txnRefId;
	}

	/**
	 * Sets the txn ref id.
	 *
	 * @param txnRefId the new txn ref id
	 */
	public void setTxnRefId(String txnRefId) {
		this.txnRefId = txnRefId;
	}

	/**
	 * Gets the payment vendor.
	 *
	 * @return the payment vendor
	 */
	public String getPaymentVendor() {
		return paymentVendor;
	}

	/**
	 * Sets the payment vendor.
	 *
	 * @param paymentVendor the new payment vendor
	 */
	public void setPaymentVendor(String paymentVendor) {
		this.paymentVendor = paymentVendor;
	}
}
