package com.sterling.bookingapi.controller;

import java.util.Date;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;



import com.sterling.bookingapi.dto.request.HsdRoomRateRequestDTO;
import com.sterling.bookingapi.dto.response.ResponseDTO;
import com.sterling.bookingapi.exception.BookingEngineException;
import com.sterling.bookingapi.service.ResortRatePlanService;


/**
 * The Class HsdBookingController.
 */
/**
 * @author tcs
 *
 */
@RestController
@RequestMapping(value = "/rateplan")
public class ResortRatePlanController extends BaseController {

	/** The Constant logger. */
	private static final Logger logger = LogManager.getLogger(ResortRatePlanController.class);

	/** The hsd booking service. */
	@Autowired 
	private ResortRatePlanService resortRatePlanService;
	
	/**
	 * Check availability.
	 *
	 * @param reqeust the reqeust
	 * @return the response DTO
	 * @throws BookingEngineException the booking engine exception
	 */
	@ResponseBody
	@RequestMapping(value = "/getRates", method = RequestMethod.GET)
	public ResponseDTO getResortRatePlans(@RequestParam final String resortId, @RequestParam final Date startDate, 
			@RequestParam final Date endDate) throws BookingEngineException {
		logger.info(" ResortRatePlanController : getResortRatePlans : Entered.");
		ResponseDTO response = resortRatePlanService.getResortRatePlans(resortId, startDate, endDate);
		
		
//		List<RoomRatePlanDetails> roomRatePlanList = hsdResortRatePlanRepository.checkForRoomAvailability(resortId);
		
		logger.info(" ResortRatePlanController : getResortRatePlans : Leaving.");
		return response;
	}

	
	/**
	 * Get resort room rates.
	 *
	 * @param reqeust the reqeust
	 * @return the response DTO
	 * @throws BookingEngineException the booking engine exception
	 */

	@ResponseBody
	@RequestMapping(value = "/getRoomRates", method = RequestMethod.POST)
	public ResponseDTO getRoomRates(@RequestBody final HsdRoomRateRequestDTO req) throws BookingEngineException {
		logger.info(" ResortRatePlanController : getResortRatePlans : Entering.");
		ResponseDTO response = resortRatePlanService.getResortRoomRates(req);
		return response;
	}
}
