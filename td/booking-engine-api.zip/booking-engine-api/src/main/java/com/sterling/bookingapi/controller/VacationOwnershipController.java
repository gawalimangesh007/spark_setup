package com.sterling.bookingapi.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.sterling.bookingapi.dto.request.RateAHolidayRequest;
import com.sterling.bookingapi.dto.request.TempUpdateWelcomeOfferReq;
import com.sterling.bookingapi.dto.request.TempVenueOfferReq;
import com.sterling.bookingapi.dto.request.VOCreateLeadRequest;
import com.sterling.bookingapi.dto.request.VOFeedbackRequest;
import com.sterling.bookingapi.dto.request.VOForgotPassReq;
import com.sterling.bookingapi.dto.request.VOPayASFRequestDTO;
import com.sterling.bookingapi.dto.request.VOPayDPRequestDTO;
import com.sterling.bookingapi.dto.request.VOPayEMIRequestDTO;
import com.sterling.bookingapi.dto.request.VOResetPassReq;
import com.sterling.bookingapi.dto.request.VOWelcomeOfferReq;
import com.sterling.bookingapi.dto.request.VoGetAccountRequestDTO;
import com.sterling.bookingapi.dto.request.VoGetSeasonCalenderRequestDTO;
import com.sterling.bookingapi.dto.request.VoPackageOfferReqWrapper;
import com.sterling.bookingapi.dto.request.VoVenueOfferReq;
import com.sterling.bookingapi.dto.response.PersonDetailsDTO;
import com.sterling.bookingapi.dto.response.ResponseDTO;
import com.sterling.bookingapi.dto.response.VOCustomerPersonalDetails;
import com.sterling.bookingapi.dto.response.VOLoginResponseWrapper;
import com.sterling.bookingapi.dto.response.VOSeasonCalenderResponseDTO;
import com.sterling.bookingapi.dto.response.VOOfferResponseDTO;
import com.sterling.bookingapi.exception.SalesForceException;
import com.sterling.bookingapi.models.VOLogin;
import com.sterling.bookingapi.service.VacationOwnershipService;
import com.sterling.bookingapi.sf.dto.request.CompositeTreeSFResponse;
import com.sterling.bookingapi.utils.ResponseUtility;

/**
 * @author tcs
 *
 */
@RestController
@RequestMapping(value = "/vo")
public class VacationOwnershipController extends BaseController {
	
	@Autowired
	private VacationOwnershipService vacationOwnershipService;
	
	/** The Constant logger. */
	private static final Logger logger = LogManager.getLogger(VacationOwnershipController.class);

	
	/**
	 * @param vacationOwnershipService
	 * set the vacationOwnershipService
	 */
	public void setVacationOwnershipService(
			VacationOwnershipService vacationOwnershipService) {
		this.vacationOwnershipService = vacationOwnershipService;
	}

	/**
	 * @param voLogin
	 * @return success after login
	 * @throws SalesForceException
	 */
	@RequestMapping(value = "/login", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO VOLogin(@RequestBody @Valid VOLogin voLogin) throws SalesForceException {
		logger.info("VacationOwnershipController : VOLogin : Entered.");
		VOLoginResponseWrapper voLoginEntity = vacationOwnershipService.voLogin(voLogin);
		logger.info("VacationOwnershipController : VOLogin : Leaving.");
		return ResponseUtility.constructSuccessRes(voLoginEntity);
	}
	
	/**
	 * @param reqDTO
	 * @return CustomerDetails
	 * @throws SalesForceException
	 */
	@RequestMapping(value = "/getCustomerDetails", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO getAccountData(@RequestBody @Valid VoGetAccountRequestDTO reqDTO) throws SalesForceException {
		logger.info("VacationOwnershipController : getAccountData : Entered.");
		ResponseEntity<VOCustomerPersonalDetails> accountData = vacationOwnershipService.getAccountData(reqDTO);
		logger.info("VacationOwnershipController : getAccountData : Leaving.");
		return ResponseUtility.constructSuccessRes(accountData.getBody());
	}
	
	/**
	 * @param request
	 * @param custDto
	 * @return success after updating customerDetails
	 * @throws SalesForceException
	 */
	@RequestMapping(value = "/updateCustomerDetails", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO updateAccount(HttpServletRequest request, @RequestBody @Valid VOCustomerPersonalDetails custDto) throws SalesForceException {
		logger.info("VacationOwnershipController : updateAccountData : Entered.");
		ResponseEntity<String> updateAccountData = vacationOwnershipService.updateAccountData(custDto, true);
		logger.info("VacationOwnershipController : updateAccountData : Leaving.");
		return ResponseUtility.constructSuccessRes(updateAccountData.getBody());
	}

	/**
	 * @param request
	 * @param custDto
	 * @return success after updating customerDetails
	 * @throws SalesForceException
	 */
	@RequestMapping(value = "/updateCustomerPreference", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO updateAccountData(HttpServletRequest request, @RequestBody @Valid VOCustomerPersonalDetails custDto) throws SalesForceException {
		logger.info("VacationOwnershipController : updateAccountData : Entered.");
		ResponseEntity<String> updateAccountData = vacationOwnershipService.updateAccountData(custDto, false);
		logger.info("VacationOwnershipController : updateAccountData : Leaving.");
		return ResponseUtility.constructSuccessRes(updateAccountData.getBody());
	}

	/**
	 * @param reqDTO
	 * @return success after adding Dependent
	 * @throws SalesForceException
	 */
	@RequestMapping(value = "/addDependent", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO addDependent(@RequestBody @Valid PersonDetailsDTO reqDTO) throws SalesForceException {
		// reqDTO.setSfToken(sfToken);
		logger.info("VacationOwnershipController : addDependent : Entered.");
		ResponseEntity<Object> addDependent = vacationOwnershipService.addDependent(reqDTO);
		logger.info("VacationOwnershipController : addDependent : Leaving.");
		return ResponseUtility.constructSuccessRes(addDependent.getBody());
	}
	
	/**
	 * @param voGetSeasonCalenderRequestDTO
	 * @return season calendar details
	 * @throws SalesForceException
	 */
	@RequestMapping(value = "/seasonCalender", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO getSeasonCalender(@RequestBody @Valid VoGetSeasonCalenderRequestDTO voGetSeasonCalenderRequestDTO) throws SalesForceException {
		logger.info("VacationOwnershipController : getSeasonCalender : Entered.");
		VOSeasonCalenderResponseDTO seasonCalender = vacationOwnershipService.getSeasonCalender(voGetSeasonCalenderRequestDTO);
		logger.info("VacationOwnershipController : getSeasonCalender : Leaving.");
		return ResponseUtility.constructSuccessRes(seasonCalender);
	}
	
	/**
	 * @param query
	 * @return dashboardAccountDetails
	 * @throws SalesForceException
	 */
	@RequestMapping(value = "/query", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO getDashboardAccountDetails(@RequestParam String query) throws SalesForceException {
		// reqDTO.setSfToken(sfToken);
		logger.info("VacationOwnershipController : getDashboardAccountDetails : Entered.");
		ResponseEntity<?> result = vacationOwnershipService.getResult(query);
		logger.info("VacationOwnershipController : getDashboardAccountDetails : Leaving.");
		return ResponseUtility.constructSuccessRes(result.getBody());
	}
	
	/**
	 * @param req
	 * @return success after creating lead 
	 * @throws SalesForceException
	 */
	@RequestMapping(value = "/createLead", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO createLead(@RequestBody @Valid VOCreateLeadRequest req) throws SalesForceException {
		// reqDTO.setSfToken(sfToken);
		logger.info("VacationOwnershipController : createLead : Entered.");
		ResponseEntity<?> result = vacationOwnershipService.createLead(req);
		logger.info("VacationOwnershipController : createLead : Leaving.");
		return ResponseUtility.constructSuccessRes(result.getBody());
	}
	
	@RequestMapping(value = "/updateLead", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	public ResponseDTO updateLead(@RequestBody VOCreateLeadRequest req) throws SalesForceException {
		// reqDTO.setSfToken(sfToken);
		logger.info("VacationOwnershipController : updateLead : Entered.");
		ResponseEntity<?> result = vacationOwnershipService.updateLead(req);
		logger.info("VacationOwnershipController : updateLead : Leaving.");
		return ResponseUtility.constructSuccessRes(result.getBody());
	}
			
	/**
	 * @param req
	 * @return success after creating feedback
	 * @throws SalesForceException
	 */
	@RequestMapping(value = "/feedback", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO createFeedback(@RequestBody @Valid VOFeedbackRequest req) throws SalesForceException {
		// reqDTO.setSfToken(sfToken);
		logger.info("VacationOwnershipController : createFeedback : Entered.");
		ResponseEntity<?> result = vacationOwnershipService.createFeedback(req);
		logger.info("VacationOwnershipController : createFeedback : Leaving.");
		return ResponseUtility.constructSuccessRes(result.getBody());
	}
	
	@RequestMapping(value = "/rateAHoliday", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO rateAHoliday(@RequestBody @Valid RateAHolidayRequest req) throws SalesForceException {
		logger.info("VacationOwnershipController : rateAHoliday : Entered.");
		ResponseEntity<?> result = vacationOwnershipService.rateAHoliday(req);
		logger.info("VacationOwnershipController : rateAHoliday : Leaving.");
		return ResponseUtility.constructSuccessRes(result.getBody());
	}

	/**
	 * @param req
	 * @return welcomeoffer details
	 * @throws SalesForceException
	 */
	@RequestMapping(value = "/welcomeOffer", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO welcomeOffer(@RequestBody @Valid VOWelcomeOfferReq req) throws SalesForceException {
		// reqDTO.setSfToken(sfToken);
		logger.info("VacationOwnershipController : welcomeOffer : Entered.");
		ResponseEntity<List<VOOfferResponseDTO>> result = vacationOwnershipService.getWelcomeOffer(req);
		logger.info("VacationOwnershipController : welcomeOffer : Leaving.");
		return ResponseUtility.constructSuccessRes(result.getBody());
	}
	
	/**
	 * @param request
	 * @param req
	 * @return success after updating welcome offer
	 * @throws SalesForceException
	 */
	@RequestMapping(value = "/updateWelcomeOffer", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	
	//TODO - url(/services/data/v39.0/sobjects/Offers_Connector__c/a1na00000079YRUAA2) from attributes in request must contain corresponding welcome offer ID 
	@ResponseBody
	public ResponseDTO updateWelcomeOffer(HttpServletRequest request, @RequestBody @Valid TempUpdateWelcomeOfferReq req) throws SalesForceException {
		logger.info("VacationOwnershipController : updateWelcomeOffer : Entered.");
		ResponseEntity<String> updateOfferData = vacationOwnershipService.updateWelcomeOffer(req);
		logger.info("VacationOwnershipController : updateWelcomeOffer : Leaving.");
		return ResponseUtility.constructSuccessRes(updateOfferData.getBody());
	}
	
	/**
	 * @param req
	 * @return venue offer details
	 * @throws SalesForceException
	 */
	@RequestMapping(value = "/getVenueOffer", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO getVenueOffer(@RequestBody @Valid VoVenueOfferReq req) {
		// reqDTO.setSfToken(sfToken);
		logger.info("VacationOwnershipController : getVenueOffer : Entered.");
		ResponseEntity<?> result = vacationOwnershipService.getVenueOffer(req);
		logger.info("VacationOwnershipController : getVenueOffer : Leaving.");
		return ResponseUtility.constructSuccessRes(result.getBody());
	}

	/**
	 * @param req
	 * @return offer details
	 * @throws SalesForceException
	 */
	@RequestMapping(value = "/getOffersByContract", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO getOffersByContract(@RequestBody @Valid VOWelcomeOfferReq req) {
		// reqDTO.setSfToken(sfToken);
		logger.info("VacationOwnershipController : getOffersByContract : Entered.");
		ResponseEntity<?> result = vacationOwnershipService.getOffersFor(req);
		logger.info("VacationOwnershipController : getOffersByContract : Leaving.");
		return ResponseUtility.constructSuccessRes(result.getBody());
	}
		
	/**
	 * @param req
	 * @return success after sending otp to mobile
	 * @throws SalesForceException
	 */
	@RequestMapping(value = "/forgotPwd", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO forgotPassword(@RequestBody @Valid VOForgotPassReq req) throws SalesForceException {
		logger.info("VacationOwnershipController : forgotPassword : Entered.");
		ResponseEntity<?> result = vacationOwnershipService.forgotPassword(req);
		logger.info("VacationOwnershipController : forgotPassword : Leaving.");
		return ResponseUtility.constructSuccessRes(result.getBody());
	}

	/**
	 * @param req
	 * @return success after sending otp to mobile
	 * @throws SalesForceException
	 */
	@RequestMapping(value = "/userOtp", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO userOtp(@RequestBody @Valid VOForgotPassReq req) throws SalesForceException {
		logger.info("VacationOwnershipController : forgotPassword : Entered.");
		ResponseEntity<?> result = vacationOwnershipService.forgotPassword(req);
		logger.info("VacationOwnershipController : forgotPassword : Leaving.");
		return ResponseUtility.constructSuccessRes(result.getBody());
	}
	
	/**
	 * @param req
	 * @return success after reseting password
	 * @throws SalesForceException
	 */
	@RequestMapping(value = "/resetPwd", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO resetPassword(@RequestBody @Valid VOResetPassReq req) throws SalesForceException {
		logger.info("VacationOwnershipController : forgotPassword : Entered.");
		ResponseEntity<?> result = vacationOwnershipService.resetPassword(req);
		logger.info("VacationOwnershipController : forgotPassword : Leaving.");
		return ResponseUtility.constructSuccessRes(result.getBody());
	}
	
	/**
	 * @param request
	 * @param req
	 * @return  success after update venue offer
	 * @throws SalesForceException
	 */
	@RequestMapping(value = "/updateVenueOffer", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	
	//TODO - url(/services/data/v39.0/sobjects/Offers_Connector__c/a1na00000079YRUAA2) from attributes in request must contain corresponding welcome offer ID 
	@ResponseBody
	public ResponseDTO updateVenueOffer(HttpServletRequest request, @RequestBody @Valid TempVenueOfferReq req) throws SalesForceException {
		ResponseEntity<String> updateOfferData = vacationOwnershipService.updateVenueOffer(req);
		return ResponseUtility.constructSuccessRes(updateOfferData.getBody());
	}
	
	/**
	 * @param request
	 * @param req
	 * @return  success after pay EMI
	 * @throws SalesForceException
	 */
	@RequestMapping(value = "/payEMI", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	//TODO - url(/services/data/v39.0/sobjects/Offers_Connector__c/a1na00000079YRUAA2) from attributes in request must contain corresponding welcome offer ID 
	@ResponseBody
	public ResponseDTO payEMI(HttpServletRequest request, @RequestBody VOPayEMIRequestDTO req) throws SalesForceException {
		ResponseEntity<?> payEMIDetails = vacationOwnershipService.payEMI(req);
		return ResponseUtility.constructSuccessRes(payEMIDetails.getBody());
	}
	
	/**
	 * @param request
	 * @param req
	 * @return  success after pat ASF
	 * @throws SalesForceException
	 */
	@RequestMapping(value = "/payASF", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	//TODO - url(/services/data/v39.0/sobjects/Offers_Connector__c/a1na00000079YRUAA2) from attributes in request must contain corresponding welcome offer ID 
	@ResponseBody
	public ResponseDTO payASF(HttpServletRequest request, @RequestBody VOPayASFRequestDTO req) throws SalesForceException {
		ResponseEntity<?> payASFDetails = vacationOwnershipService.payASF(req);
		return ResponseUtility.constructSuccessRes(payASFDetails.getBody());
	}
	
	/**
	 * @param request
	 * @param req
	 * @return  success after pay DP
	 * @throws SalesForceException
	 */
	@RequestMapping(value = "/payDP", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	//TODO - url(/services/data/v39.0/sobjects/Offers_Connector__c/a1na00000079YRUAA2) from attributes in request must contain corresponding welcome offer ID 
	@ResponseBody
	public ResponseDTO payDP(HttpServletRequest request, @RequestBody VOPayDPRequestDTO req) throws SalesForceException {
		ResponseEntity<?> payDPDetails = vacationOwnershipService.payDP(req);
		return ResponseUtility.constructSuccessRes(payDPDetails.getBody());
	}

	
	/**
	 * @param req
	 * @return list of id of created packages
	 * @throws SalesForceException
	 */
	@RequestMapping(value = "/package/create", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO createPackage(@RequestBody @Valid VoPackageOfferReqWrapper req) throws SalesForceException {
		CompositeTreeSFResponse packageRes = vacationOwnershipService.createPackageOffer(req);
		return ResponseUtility.constructSuccessRes(packageRes);
	}

}
