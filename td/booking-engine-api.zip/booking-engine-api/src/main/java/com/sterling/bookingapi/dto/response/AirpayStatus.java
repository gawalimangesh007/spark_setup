package com.sterling.bookingapi.dto.response;


public enum AirpayStatus {

	PAYMENT_SUCCESS("200"),
	PAYMENT_FAILURE("400"),
	PAYMENT_CANCELED("502");
	
	private String code;
	private AirpayStatus(String code) {
		this.code = code;
	}
	
	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public static AirpayStatus getByCode(String code) {
		for (AirpayStatus as : AirpayStatus.values()) {
			if(as.getCode().equalsIgnoreCase(code)) {
				return as;
			}
		}
		return null;
	}
}
