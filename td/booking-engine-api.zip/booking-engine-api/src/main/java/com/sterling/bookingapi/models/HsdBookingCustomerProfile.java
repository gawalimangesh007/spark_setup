package com.sterling.bookingapi.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;


/**
 * The Class HsdBookingCustomerProfile.
 */
@Entity
@Table(name = "sh_hsd_booking_customer_profile")
public class HsdBookingCustomerProfile extends BaseModel{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The cus prof id. */
	@Id
	@GeneratedValue( strategy = GenerationType.IDENTITY )
	@Column(name = "profile_idx_id", unique = true)
	private int cusProfId;
	
	/** The hsd booking details. */
	@OneToOne
	@JoinColumn(name="booking_idx_id", unique = false)
	private HsdBookingDetails hsdBookingDetails;
	
	/** The name. */
	@Column(name = "first_name",nullable = false)
	private String firstName;
	
	/** The name. */
	@Column(name = "last_name",nullable = false)
	private String lastName;
	
	/** The email. */
	@Column(nullable = false)
	private String email;
	
	/** The mobile number. */
	@Column(name = "mobile_no",nullable = false)
	private String mobileNumber;

	/**
	 * Gets the cus prof id.
	 *
	 * @return the cus prof id
	 */
	public int getCusProfId() {
		return cusProfId;
	}

	/**
	 * Sets the cus prof id.
	 *
	 * @param cusProfId the new cus prof id
	 */
	public void setCusProfId(int cusProfId) {
		this.cusProfId = cusProfId;
	}

	/**
	 * Gets the hsd booking details.
	 *
	 * @return the hsd booking details
	 */
	public HsdBookingDetails getHsdBookingDetails() {
		return hsdBookingDetails;
	}

	/**
	 * Sets the hsd booking details.
	 *
	 * @param hsdBookingDetails the new hsd booking details
	 */
	public void setHsdBookingDetails(HsdBookingDetails hsdBookingDetails) {
		this.hsdBookingDetails = hsdBookingDetails;
	}

	

	/**
	 * Gets the first name.
	 * 
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * Sets the email.
	 * 
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String first_name) {
		this.firstName = first_name;
	}

	/**
	 * Gets the last name.
	 * 
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * Sets the last name.
	 * 
	 * @param lastName the lastName to set
	 */
	public void setLastName(String last_name) {
		this.lastName = last_name;
	}

	/**
	 * Gets the email.
	 *
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * Sets the email.
	 *
	 * @param email the new email
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * Gets the mobile number.
	 *
	 * @return the mobile number
	 */
	public String getMobileNumber() {
		return mobileNumber;
	}

	/**
	 * Sets the mobile number.
	 *
	 * @param mobileNumber the new mobile number
	 */
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
				
}
