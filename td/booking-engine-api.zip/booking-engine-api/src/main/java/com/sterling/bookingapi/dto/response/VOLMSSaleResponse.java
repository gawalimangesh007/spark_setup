package com.sterling.bookingapi.dto.response;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author tcs
 * @version 1.0
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class VOLMSSaleResponse extends BaseRecord implements Serializable {

	private static final long serialVersionUID = 1L;

	public String saleId;
	public String name;
	public String mobileNumber;
	public String email;
	public String dob;
	public String saleStatus;
	
	private String productId;
	private String productCost;
	private String lmsDPId;
	private String dPAmount;
	private String emiAmount;
	private String emiTenureId;
	private String webUserFlow;
	
	private String webProductPlanId;
	private String opportunityId;
	/*private String applicationNo;
	private String idProof;
	private String idProofNumber;
	private String idType1Image;
	private String additionalProof;
	private String additionalProofNumber;
	private String idType2Image;*/

	
	/**
	 * @return saleId
	 */
	public String getSaleId() {
		return saleId;
	}
	/**
	 * @param saleId
	 * set the saleId
	 */
	public void setSaleId(String saleId) {
		this.saleId = saleId;
	}
	/**
	 * @return name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name
	 * set the name
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return mobileNumber
	 */
	public String getMobileNumber() {
		return mobileNumber;
	}
	/**
	 * @param mobileNumber
	 * set the mobileNumber
	 */
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	
	/**
	 * @return email
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * @param email
	 * set the email
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	/**
	 * @return dob
	 */
	public String getDob() {
		return dob;
	}
	/**
	 * @param dob
	 * set the dob
	 */
	public void setDob(String dob) {
		this.dob = dob;
	}
	/**
	 * @return saleStatus
	 */
	public String getSaleStatus() {
		return saleStatus;
	}
	/**
	 * @param saleStatus
	 * set the saleStatus
	 */
	public void setSaleStatus(String saleStatus) {
		this.saleStatus = saleStatus;
	}
	/**
	 * @return productId
	 */
	public String getProductId() {
		return productId;
	}
	/**
	 * @param productId
	 * set the productId
	 */
	public void setProductId(String productId) {
		this.productId = productId;
	}
	/**
	 * @return productCost
	 */
	public String getProductCost() {
		return productCost;
	}
	/**
	 * @param productCost
	 * set the productCost
	 */
	public void setProductCost(String productCost) {
		this.productCost = productCost;
	}
	/**
	 * @return lmsDPId
	 */
	public String getLmsDPId() {
		return lmsDPId;
	}
	/**
	 * @param lmsDPId
	 * set the lmsDPId
	 */
	public void setLmsDPId(String lmsDPId) {
		this.lmsDPId = lmsDPId;
	}
	/**
	 * @return dPAmount
	 */
	public String getdPAmount() {
		return dPAmount;
	}
	/**
	 * @param dPAmount
	 * set the dPAmount
	 */
	public void setdPAmount(String dPAmount) {
		this.dPAmount = dPAmount;
	}
	/**
	 * @return emiAmount
	 */
	public String getEmiAmount() {
		return emiAmount;
	}
	/**
	 * @param emiAmount
	 * set the emiAmount
	 */
	public void setEmiAmount(String emiAmount) {
		this.emiAmount = emiAmount;
	}
	/**
	 * @return emiTenureId
	 */
	public String getEmiTenureId() {
		return emiTenureId;
	}
	/**
	 * @param emiTenureId
	 * set the emiTenureId
	 */
	public void setEmiTenureId(String emiTenureId) {
		this.emiTenureId = emiTenureId;
	}
	public String getWebUserFlow() {
		return webUserFlow;
	}
	public void setWebUserFlow(String webUserFlow) {
		this.webUserFlow = webUserFlow;
	}
	public String getWebProductPlanId() {
		return webProductPlanId;
	}
	public void setWebProductPlanId(String webProductPlanId) {
		this.webProductPlanId = webProductPlanId;
	}
	public String getOpportunityId() {
		return opportunityId;
	}
	public void setOpportunityId(String opportunityId) {
		this.opportunityId = opportunityId;
	}
		
}
