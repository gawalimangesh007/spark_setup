package com.sterling.bookingapi.dto.request;


/**
 * The Class ChangePasswordRequestDTO.
 */
/**
 * @author tcs
 *
 */
public class ChangePasswordRequestDTO {

/** The password. */
private String password;

/**
 * Gets the password.
 *
 * @return the password
 */
public String getPassword() {
	return password;
}

/**
 * Sets the password.
 *
 * @param password the new password
 */
public void setPassword(String password) {
	this.password = password;
}


}
