package com.sterling.bookingapi.dto.maximojo.request;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class GuaranteePaymentReqDTO.
 */
/**
 * @author tcs
 *
 */
public class GuaranteePaymentReqDTO {
	
/** The amount percent. */
@JacksonXmlProperty(localName = "AmountPercent")
private TaxesReqDTO amountPercent;

/**
 * Gets the amount percent.
 *
 * @return the amountPercent
 */
public TaxesReqDTO getAmountPercent() {
	return amountPercent;
}

/**
 * Sets the amount percent.
 *
 * @param amountPercent the amountPercent to set
 */
public void setAmountPercent(TaxesReqDTO amountPercent) {
	this.amountPercent = amountPercent;
}


}
