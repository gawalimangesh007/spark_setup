package com.sterling.bookingapi.auth.filter;

import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.AbstractAuthenticationProcessingFilter;
import org.springframework.security.web.util.matcher.RequestMatcher;

import com.sterling.bookingapi.aop.LoggingAspect;
import com.sterling.bookingapi.auth.bean.Info;
import com.sterling.bookingapi.auth.bean.SterlingAuthException;
import com.sterling.bookingapi.auth.bean.UserAuthentication;
import com.sterling.bookingapi.auth.bean.UserToken;
import com.sterling.bookingapi.auth.impl.TokenAuthenticationService;
import com.sterling.bookingapi.config.ApplicationContextProvider;
import com.sterling.bookingapi.dto.response.ResponseDTO;
import com.sterling.bookingapi.exception.ErrorCodes;
import com.sterling.bookingapi.utils.BookingEngineUtils;
import com.sterling.bookingapi.utils.ResponseUtility;

/**
 * @author tcs
 *
 */

public class LoginFilter extends AbstractAuthenticationProcessingFilter {
	private static final String START_DATE = "START_DATE";

	private Logger loginFilterLogger = LogManager.getLogger(LoginFilter.class);

	@Autowired
	private TokenAuthenticationService tokenAuthenticationService;

	public LoginFilter(RequestMatcher requiresAuthenticationRequestMatcher) {
		super(requiresAuthenticationRequestMatcher);
		
		tokenAuthenticationService = (TokenAuthenticationService) ApplicationContextProvider.getApplicationContext()
				.getBean("tokenAuthenticationServiceImpl");
	}

	/* (non-Javadoc)
	 * @see org.springframework.security.web.authentication.AbstractAuthenticationProcessingFilter#attemptAuthentication(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response)
			throws AuthenticationException, IOException, ServletException { // NOSONAR
		loginFilterLogger.info("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% attemptAuthentication");
		
		request.setAttribute(START_DATE, new Date());
		UserAuthentication auth = (UserAuthentication) tokenAuthenticationService.getAuthenticationForLogin(request,
				response);
		
		return auth;
	}

	/* (non-Javadoc)
	 * @see org.springframework.security.web.authentication.AbstractAuthenticationProcessingFilter#successfulAuthentication(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse, javax.servlet.FilterChain, org.springframework.security.core.Authentication)
	 */
	@Override
	protected void successfulAuthentication(HttpServletRequest request, HttpServletResponse response,
			javax.servlet.FilterChain chain, Authentication authResult) throws IOException, ServletException {
		UserToken token = null;
		loginFilterLogger.info("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% successfulAuthentication");
		try {
			UserAuthentication authResultObject = (UserAuthentication) authResult;
			token = tokenAuthenticationService.addAuthentication(response, authResultObject);

			loginFilterLogger.info("Authentication SUCCESS. "

					+ BookingEngineUtils.getInputLogsSimple("userId, ip, token", authResultObject.getUser().getUserId(), authResultObject.getIpAddress(), token.getToken()));
			// Add the authentication to the Security context
			SecurityContextHolder.getContext().setAuthentication(authResult);

			/*HashMap<String, Object> information = new HashMap<>();
			information.put("USER", authResultObject.getUser());
			information.put("AUTH_TYPE", authResultObject.getAuthType());
			information.put("INFO", authResultObject.getInfo());
			*/

			ResponseDTO responseDTO = ResponseUtility.constructSuccessRes(authResultObject.getUser().getUserObject());
			response.setCharacterEncoding("UTF-8");
			response.setContentType("application/json");
			response.getWriter().write(BookingEngineUtils.convertObjectToString(responseDTO));
			
		} catch (Exception ex) {
			Info i = new Info();
			i.setCode(109L);
			i.setDesc("UNWANTED_EXCEPTION_RELOGIN_NEEDED");

			loginFilterLogger.fatal("Authentication EXCEPTION. " + BookingEngineUtils.getInputLogsSimple("token, exception", token));

			ResponseDTO dto = ResponseUtility.constructErrorRes("UNWANTED_EXCEPTION_RELOGIN_NEEDED", 401);
			
			response.getWriter().write(BookingEngineUtils.convertObjectToString(dto));
		} finally {
			printAspectLog(request);
		}
	}

	private void printAspectLog(HttpServletRequest request) {
		try {
			Date startDate = (Date) request.getAttribute(START_DATE);
			loginFilterLogger.info("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% printAspectLog {}", startDate);
			long hitTime = startDate.getTime();
			long nowTime = new Date().getTime();
			loginFilterLogger.info(LoggingAspect.PERFORMANCE_MARKER, "Login service total hit time {}", ((nowTime-hitTime)/1000));
		} catch (Exception e) {
			loginFilterLogger.error("error printing aspect on login", e);
		}
	}

	/* (non-Javadoc)
	 * @see org.springframework.security.web.authentication.AbstractAuthenticationProcessingFilter#unsuccessfulAuthentication(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse, org.springframework.security.core.AuthenticationException)
	 */
	@Override
	protected void unsuccessfulAuthentication(HttpServletRequest request, HttpServletResponse response,
			AuthenticationException authException) throws IOException, ServletException {
		loginFilterLogger.info("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% un successfull auth");
		
		try {
			ResponseDTO dto = ResponseUtility.constructErrorRes(
					authException.getMessage(), 401,
					ErrorCodes.INVALID_USER_PASS);
			if (authException instanceof SterlingAuthException) {
				SterlingAuthException ex = (SterlingAuthException) authException;
				dto.setData(ex.getData());
				if(ex.getExceptionId() != null) {
					dto.setErrors(ex.getExceptionId());
					dto.setApiError(BookingEngineUtils.getErrorMessage(ex.getExceptionId()));
				}
			}
			response.setCharacterEncoding("UTF-8");
			response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			response.setContentType("application/json");
			response.getWriter().write(
					BookingEngineUtils.convertObjectToString(dto));
		} finally {
			printAspectLog(request);
		}
	}

}
