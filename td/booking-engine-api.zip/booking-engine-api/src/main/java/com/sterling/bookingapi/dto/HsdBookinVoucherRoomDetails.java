
package com.sterling.bookingapi.dto;


/**
 * The Class HsdBookinVoucherRoomDetails.
 */
/**
 * @author tcs
 *
 */
public class HsdBookinVoucherRoomDetails {

	/** The room count. */
	private int roomCount;
	
	/** The first name. */
	private String firstName;
	
	/** The last name. */
	private String lastName;
	
	/** The email id. */
	private String emailId;
	
	/** The mobile no. */
	private String mobileNo;
	
	/** The room type. */
	private String roomType;

	/** The room rent. */
	private double roomRent;
	/** The extra person child count. */
	private int extraPersonChildCount;

	/** The extra person adult count. */
	private int extraPersonAdultCount;

	/** The extra person child cost. */
	private double extraPersonChildCost;

	/** The extra person adult cost. */
	private double extraPersonAdultCost;

	/**
	 * Gets the room count.
	 *
	 * @return the room count
	 */
	public int getRoomCount() {
		return roomCount;
	}


	/**
	 * Sets the room count.
	 *
	 * @param roomCount the new room count
	 */
	public void setRoomCount(int roomCount) {
		this.roomCount = roomCount;
	}


	/**
	 * Gets the first name.
	 *
	 * @return the first name
	 */
	public String getFirstName() {
		return firstName;
	}


	/**
	 * Sets the first name.
	 *
	 * @param firstName the new first name
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	/**
	 * Gets the email id.
	 *
	 * @return the email id
	 */
	public String getEmailId() {
		return emailId;
	}


	/**
	 * Sets the email id.
	 *
	 * @param emailId the new email id
	 */
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}


	/**
	 * Gets the mobile no.
	 *
	 * @return the mobile no
	 */
	public String getMobileNo() {
		return mobileNo;
	}


	/**
	 * Sets the mobile no.
	 *
	 * @param mobileNo the new mobile no
	 */
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}


	/**
	 * Gets the room type.
	 *
	 * @return the room type
	 */
	public String getRoomType() {
		return roomType;
	}


	/**
	 * Sets the room type.
	 *
	 * @param roomType the new room type
	 */
	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}


	/**
	 * Gets the room rent.
	 *
	 * @return the room rent
	 */
	public double getRoomRent() {
		return roomRent;
	}


	/**
	 * Sets the room rent.
	 *
	 * @param roomRent the new room rent
	 */
	public void setRoomRent(double roomRent) {
		this.roomRent = roomRent;
	}


	/**
	 * Gets the last name.
	 *
	 * @return the last name
	 */
	public String getLastName() {
		return lastName;
	}


	/**
	 * Sets the last name.
	 *
	 * @param lastName the new last name
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public int getExtraPersonChildCount() {
		return extraPersonChildCount;
	}

	public void setExtraPersonChildCount(int extraPersonChildCount) {
		this.extraPersonChildCount = extraPersonChildCount;
	}

	public int getExtraPersonAdultCount() {
		return extraPersonAdultCount;
	}

	public void setExtraPersonAdultCount(int extraPersonAdultCount) {
		this.extraPersonAdultCount = extraPersonAdultCount;
	}

	public double getExtraPersonChildCost() {
		return extraPersonChildCost;
	}

	public void setExtraPersonChildCost(double extraPersonChildCost) {
		this.extraPersonChildCost = extraPersonChildCost;
	}

	public double getExtraPersonAdultCost() {
		return extraPersonAdultCost;
	}

	public void setExtraPersonAdultCost(double extraPersonAdultCost) {
		this.extraPersonAdultCost = extraPersonAdultCost;
	}
	
	
}
