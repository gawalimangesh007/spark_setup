package com.sterling.bookingapi.models;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.CascadeType;



import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name = "sh_hsd_pagemodel")
public class PageModel extends BaseModel implements Serializable{
	
	private static final long serialVersionUID = 1L;

	/** The page id. */
	@Id
	@GeneratedValue( strategy = GenerationType.IDENTITY )
	@Column(name = "page_idx_id", unique = true)
	private int pageid;
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="web_tracker_id",nullable = false)
	@JsonIgnore
	private WebTrackerModel webTrackerModel;

	@Column(name = "is_logged_in", unique = true)
	private String isloggedin;
	
	@Column(name = "user_name", unique = true)
	private String username;
	
	
	@Column(name = "user_id", unique = true)
	private String userid;
	
	@Column(name = "page_name", unique = true)
	private String pagename;
	
	@Column(name = "referer_Domain", unique = true)
	private String refererDomain;
	
	/*@OneToOne(fetch = FetchType.LAZY,
	cascade =  CascadeType.ALL,
	mappedBy = "pageModel")
	private ActionModel actionModel;*/
	
	@OneToMany(fetch = FetchType.LAZY,cascade =  CascadeType.ALL,mappedBy = "pageModel")
	private Set<ActionModel> actionModel = new HashSet<ActionModel>(0);
	
	/*@OneToOne(fetch = FetchType.EAGER, mappedBy = "pageModel")
	@Cascade(value = {CascadeType.SAVE_UPDATE})
	private ActionModel actionInfo;*/
	
	/*@OneToOne(fetch = FetchType.LAZY,
	cascade =  CascadeType.ALL,
	mappedBy = "pageModel")
	private EventModel eventModel;*/
	@OneToMany(fetch = FetchType.LAZY,cascade =  CascadeType.ALL, mappedBy = "pageModel")
	private Set<EventModel> eventModel = new HashSet<EventModel>(0);
	
	/*@OneToOne(fetch = FetchType.EAGER, mappedBy = "pageModel")
	@Cascade(value = {CascadeType.SAVE_UPDATE})
	private EventModel eventInfo;*/
	
	
	public int getPageid() {
		return pageid;
	}
	public void setPageid(int pageid) {
		this.pageid = pageid;
	}
		
	
	public WebTrackerModel getWebTrackerModel() {
		return webTrackerModel;
	}
	public void setWebTrackerModel(WebTrackerModel webTrackerModel) {
		this.webTrackerModel = webTrackerModel;
	}
	public String getIsloggedin() {
		return isloggedin;
	}
	public void setIsloggedin(String isloggedin) {
		this.isloggedin = isloggedin;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getPagename() {
		return pagename;
	}
	public void setPagename(String pagename) {
		this.pagename = pagename;
	}
	public String getRefererDomain() {
		return refererDomain;
	}
	public void setRefererDomain(String refererDomain) {
		this.refererDomain = refererDomain;
	}
	public Set<ActionModel> getActionModel() {
		return actionModel;
	}
	public void setActionModel(Set<ActionModel> actionModel) {
		this.actionModel = actionModel;
	}
	public Set<EventModel> getEventModel() {
		return eventModel;
	}
	public void setEventModel(Set<EventModel> eventModel) {
		this.eventModel = eventModel;
	}
	/*public ActionModel getActionModel() {
		return actionModel;
	}
	public void setActionModel(ActionModel actionModel) {
		this.actionModel = actionModel;
	}
	public EventModel getEventModel() {
		return eventModel;
	}
	public void setEventModel(EventModel eventModel) {
		this.eventModel = eventModel;
	}*/
		
}
