package com.sterling.bookingapi.dto.request;

import java.io.Serializable;
import javax.validation.constraints.NotEmpty;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author tcs
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class VoPackageOfferReq implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@NotEmpty(message = "package Name should not be empty")
	private String packageName;
	
	@NotEmpty(message = "package Type should not be empty")
	private String packageType;
	
	@NotEmpty(message = "package Id should not be empty")
	private String packageId;
	
	@NotEmpty(message = "package Description should not be empty")
	private String packageDesc;

	public String getPackageName() {
		return packageName;
	}

	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}

	public String getPackageType() {
		return packageType;
	}

	public void setPackageType(String packageType) {
		this.packageType = packageType;
	}

	public String getPackageId() {
		return packageId;
	}

	public void setPackageId(String packageId) {
		this.packageId = packageId;
	}

	public String getPackageDesc() {
		return packageDesc;
	}

	public void setPackageDesc(String packageDesc) {
		this.packageDesc = packageDesc;
	}
}
