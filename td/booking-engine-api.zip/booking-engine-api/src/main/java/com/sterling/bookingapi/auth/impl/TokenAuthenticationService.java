package com.sterling.bookingapi.auth.impl;

import java.io.IOException;

import javax.security.sasl.AuthenticationException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.Authentication;

import com.sterling.bookingapi.auth.bean.UserAuthentication;
import com.sterling.bookingapi.auth.bean.UserToken;

/**
 * @author tcs
 *
 */
public interface TokenAuthenticationService {
	
	/**
	 * @param request
	 * @param response
	 * @return authentication details
	 * @throws AuthenticationException
	 */
	public Authentication getAuthenticationForLogin(HttpServletRequest request, HttpServletResponse response) throws AuthenticationException;

	public Authentication getAuthenticationForSocialLogin(HttpServletRequest request, HttpServletResponse response) throws AuthenticationException;
	
	/**
	 * @param request
	 * @param response
	 * @return authentication details
	 * @throws IOException
	 */
	public Authentication getAuthentication(HttpServletRequest request, HttpServletResponse response) throws IOException;
	
	/**
	 * @param response
	 * @param authResult
	 * @return userTokendetails
	 */
	public UserToken addAuthentication(HttpServletResponse response, UserAuthentication authResult);

	public void removeAuthentication(HttpServletRequest request, HttpServletResponse response);
	

}
