package com.sterling.bookingapi.dto.request;

import java.io.Serializable;
import java.util.Date;

import javax.validation.constraints.Future;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


/**
 * The Class HsdBookingOfferDetailsDTO.
 */
/**
 * @author tcs
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class VOGetAvailabilityRequestDTO extends VoBaseRequestDTO implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@NotNull(message="Resort id should not be null")
	private String resortId;
	
	private String suggestedResortId;
	
	@NotNull(message = "start date is mandotory")
	private Date startDate;
	
	@NotNull(message = "end date is mandotory")
	@Future(message = "end date should be a future date")
	private Date endDate;
	
	private String productId;
	
	private String productCode;
	
	private String productType;
	
	private boolean pointMatrixFlag;
	
	private String contractId;

	/**
	 * @return productId
	 */
	public String getProductId() {
		return productId;
	}

	/**
	 * @param productId
	 * set the productId
	 */
	public void setProductId(String productId) {
		this.productId = productId;
	}

	/**
	 * @return resortId
	 */
	public String getResortId() {
		return resortId;
	}

	/**
	 * @param resortId
	 * set the resortId
	 */
	public void setResortId(String resortId) {
		this.resortId = resortId;
	}

	/**
	 * @return resortId
	 */
	public Date getStartDate() {
		return startDate;
	}

	/**
	 * @param checkInDate
	 * set the resortId
	 */
	public void setStartDate(Date checkInDate) {
		this.startDate = checkInDate;
	}

	/**
	 * @return endDate
	 */
	public Date getEndDate() {
		return endDate;
	}

	/**
	 * @param checkOutDate
	 * set the checkOutDate
	 */
	public void setEndDate(Date checkOutDate) {
		this.endDate = checkOutDate;
	}

	public String getSuggestedResortId() {
		return suggestedResortId;
	}

	public void setSuggestedResortId(String suggestedResortId) {
		this.suggestedResortId = suggestedResortId;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public boolean isPointMatrixFlag() {
		return pointMatrixFlag;
	}

	public void setPointMatrixFlag(boolean pointMatrixFlag) {
		this.pointMatrixFlag = pointMatrixFlag;
	}

	public String getContractId() {
		return contractId;
	}

	public void setContractId(String contractId) {
		this.contractId = contractId;
	}

}