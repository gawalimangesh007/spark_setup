package com.sterling.bookingapi.dto.request;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PageInfo implements Serializable{
	
	private static final long serialVersionUID = 1L;

	private String pageid;
	private String isloggedin;
	private String username;
	private String userid;
	private String pagename;
	private String refererDomain;
	
	private ActionInfo actionInfo;
	
	private EventInfo eventInfo;
	
	public String getPageid() {
		return pageid;
	}
	public void setPageid(String pageid) {
		this.pageid = pageid;
	}
	public String getIsloggedin() {
		return isloggedin;
	}
	public void setIsloggedin(String isloggedin) {
		this.isloggedin = isloggedin;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getPagename() {
		return pagename;
	}
	public void setPagename(String pagename) {
		this.pagename = pagename;
	}
	public String getRefererDomain() {
		return refererDomain;
	}
	public void setRefererDomain(String refererDomain) {
		this.refererDomain = refererDomain;
	}
	public ActionInfo getActionInfo() {
		return actionInfo;
	}
	public void setActionInfo(ActionInfo actionInfo) {
		this.actionInfo = actionInfo;
	}
	public EventInfo getEventInfo() {
		return eventInfo;
	}
	public void setEventInfo(EventInfo eventInfo) {
		this.eventInfo = eventInfo;
	}
	
	
	
	
}
