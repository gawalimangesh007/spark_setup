package com.sterling.bookingapi.models;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.sterling.bookingapi.utils.AppConstants;


/**
 * The Class HsdOffersAndPromos.
 */
/**
 * @author tcs
 *
 */
@Entity
@Table(name = "sh_hsd_offer_promo")//delete
public class HsdOffersAndPromos extends BaseModel{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;
	 
	/** The offer promo id. */
	@Id
	@GeneratedValue( strategy = GenerationType.IDENTITY )
	@Column(name = "offer_promo_id", unique = true)
	private int offerPromoId;

	/** The offer promo type. */
	@Enumerated(value=EnumType.STRING)
	@Column(name = "offer_promo_type",nullable = false)
	private AppConstants.Type offerPromoType;
	
	/** The offer promo category. */
	@Column(name = "offer_promo_category",nullable = false)
	private String offerPromoCategory;
	
	/** The name. */
	@Column(name = "name",nullable = false)
	private String name;
	
	/** The details. */
	@Column(name = "details",nullable = true)
	private String details;
	
	/** The sell start date. */
	@Column(name = "sel_start_date",nullable = false)
	private Date sellStartDate;
	
	/** The sell end date. */
	@Column(name = "sel_end_date",nullable = false)
	private Date sellEndDate;
	
	/** The booking start date. */
	@Column(name = "book_start_date",nullable = false)
	private Date bookingStartDate;
	
	/** The booking end date. */
	@Column(name = "book_end_date",nullable = false)
	private Date bookingEndDate;
	
	/** The code. */
	@Column(name = "code",nullable = false)
	private String code;
	
	/** The discount amt. */
	@Column(name = "discount_amount",nullable = true)
	private Double discountAmt;
	
	/** The discount code. */
	@Enumerated(value=EnumType.STRING)
	@Column(name = "discount_code",nullable = true)
	private AppConstants.DiscountCode discountCode;
	
	/** The max discount amt. */
	@Column(name = "max_discount_amount",nullable = true)
	private Double maxDiscountAmt;
	
	/** The active. */
	@Column(name = "status",nullable = false)
	private boolean active = true;
	
	/** The terms and conditions. */
	@Column(name = "terms_and_conditions",nullable = true)
	private String termsAndConditions;
	
	/** The conditions list. */
	@OneToMany(mappedBy = "hsdOffersAndPromos")
	private List<HsdOffersAndPromosConditionsMapping> conditionsList;
	
	/** The restort room type. */
	@OneToMany(mappedBy = "hsdOffersAndPromos")
	private List<HsdMappingPackOfferPromo> restortRoomType;
	
	/**
	 * Gets the offer promo id.
	 *
	 * @return the offerPromoId
	 */
	public int getOfferPromoId() {
		return offerPromoId;
	}

	/**
	 * Sets the offer promo id.
	 *
	 * @param offerPromoId the offerPromoId to set
	 */
	public void setOfferPromoId(int offerPromoId) {
		this.offerPromoId = offerPromoId;
	}

	/**
	 * Gets the offer promo type.
	 *
	 * @return the offerPromoType
	 */
	public AppConstants.Type getOfferPromoType() {
		return offerPromoType;
	}

	/**
	 * Sets the offer promo type.
	 *
	 * @param offerPromoType the offerPromoType to set
	 */
	public void setOfferPromoType(AppConstants.Type offerPromoType) {
		this.offerPromoType = offerPromoType;
	}

	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Sets the name.
	 *
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Gets the code.
	 *
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * Sets the code.
	 *
	 * @param code the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * Gets the details.
	 *
	 * @return the details
	 */
	public String getDetails() {
		return details;
	}

	/**
	 * Sets the details.
	 *
	 * @param details the details to set
	 */
	public void setDetails(String details) {
		this.details = details;
	}

	/**
	 * Gets the sell start date.
	 *
	 * @return the sellStartDate
	 */
	public Date getSellStartDate() {
		return sellStartDate;
	}

	/**
	 * Sets the sell start date.
	 *
	 * @param sellStartDate the sellStartDate to set
	 */
	public void setSellStartDate(Date sellStartDate) {
		this.sellStartDate = sellStartDate;
	}

	/**
	 * Gets the sell end date.
	 *
	 * @return the sellEndDate
	 */
	public Date getSellEndDate() {
		return sellEndDate;
	}

	/**
	 * Sets the sell end date.
	 *
	 * @param sellEndDate the sellEndDate to set
	 */
	public void setSellEndDate(Date sellEndDate) {
		this.sellEndDate = sellEndDate;
	}

	/**
	 * Gets the booking start date.
	 *
	 * @return the bookingStartDate
	 */
	public Date getBookingStartDate() {
		return bookingStartDate;
	}

	/**
	 * Sets the booking start date.
	 *
	 * @param bookingStartDate the bookingStartDate to set
	 */
	public void setBookingStartDate(Date bookingStartDate) {
		this.bookingStartDate = bookingStartDate;
	}

	/**
	 * Gets the booking end date.
	 *
	 * @return the bookingEndDate
	 */
	public Date getBookingEndDate() {
		return bookingEndDate;
	}

	/**
	 * Sets the booking end date.
	 *
	 * @param bookingEndDate the bookingEndDate to set
	 */
	public void setBookingEndDate(Date bookingEndDate) {
		this.bookingEndDate = bookingEndDate;
	}

	/**
	 * Gets the discount amt.
	 *
	 * @return the discountAmt
	 */
	public Double getDiscountAmt() {
		return discountAmt;
	}

	/**
	 * Sets the discount amt.
	 *
	 * @param discountAmt the discountAmt to set
	 */
	public void setDiscountAmt(Double discountAmt) {
		this.discountAmt = discountAmt;
	}

	/**
	 * Gets the discount code.
	 *
	 * @return the DiscountCode
	 */
	public AppConstants.DiscountCode getDiscountCode() {
		return discountCode;
	}

	/**
	 * Sets the discount code.
	 *
	 * @param discountCode the new discount code
	 */
	public void setDiscountCode(AppConstants.DiscountCode discountCode) {
		this.discountCode = discountCode;
	}

	/**
	 * Gets the max discount amt.
	 *
	 * @return the maxDiscountAmt
	 */
	public Double getMaxDiscountAmt() {
		return maxDiscountAmt;
	}

	/**
	 * Sets the max discount amt.
	 *
	 * @param maxDiscountAmt the maxDiscountAmt to set
	 */
	public void setMaxDiscountAmt(Double maxDiscountAmt) {
		this.maxDiscountAmt = maxDiscountAmt;
	}


	/**
	 * Checks if is active.
	 *
	 * @return true, if is active
	 */
	public boolean isActive() {
		return active;
	}

	/**
	 * Sets the active.
	 *
	 * @param active the new active
	 */
	public void setActive(boolean active) {
		this.active = active;
	}

	/**
	 * Gets the terms and conditions.
	 *
	 * @return the termsAndConditions
	 */
	public String getTermsAndConditions() {
		return termsAndConditions;
	}

	/**
	 * Sets the terms and conditions.
	 *
	 * @param termsAndConditions the termsAndConditions to set
	 */
	public void setTermsAndConditions(String termsAndConditions) {
		this.termsAndConditions = termsAndConditions;
	}

	/**
	 * Gets the offer promo category.
	 *
	 * @return the offerPromoCategory
	 */
	public String getOfferPromoCategory() {
		return offerPromoCategory;
	}

	/**
	 * Sets the offer promo category.
	 *
	 * @param offerPromoCategory the offerPromoCategory to set
	 */
	public void setOfferPromoCategory(String offerPromoCategory) {
		this.offerPromoCategory = offerPromoCategory;
	}

	/**
	 * Gets the conditions list.
	 *
	 * @return the conditionsList
	 */
	public List<HsdOffersAndPromosConditionsMapping> getConditionsList() {
		return conditionsList;
	}

	/**
	 * Sets the conditions list.
	 *
	 * @param conditionsList the conditionsList to set
	 */
	public void setConditionsList(
			List<HsdOffersAndPromosConditionsMapping> conditionsList) {
		this.conditionsList = conditionsList;
	}

	/**
	 * Gets the restort room type.
	 *
	 * @return the restortRoomType
	 */
	public List<HsdMappingPackOfferPromo> getRestortRoomType() {
		return restortRoomType;
	}

	/**
	 * Sets the restort room type.
	 *
	 * @param restortRoomType the restortRoomType to set
	 */
	public void setRestortRoomType(
			List<HsdMappingPackOfferPromo> restortRoomType) {
		this.restortRoomType = restortRoomType;
	}

	

	
	
}
