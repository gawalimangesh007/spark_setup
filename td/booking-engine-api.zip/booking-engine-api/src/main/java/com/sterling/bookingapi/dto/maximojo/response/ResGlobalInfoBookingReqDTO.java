package com.sterling.bookingapi.dto.maximojo.response;

/**
 * The Class ResGlobalInfoBookingReqDTO.
 * @author tcs
 * @version 1.0
 */
public class ResGlobalInfoBookingReqDTO {

}
