package com.sterling.bookingapi.dto.maximojo.request;

import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class RateAmountMessagesReqDTO.
 */
/**
 * @author tcs
 *
 */
public class RateAmountMessagesReqDTO {

	 /** The hotel code. */
 	@JacksonXmlProperty(localName = "HotelCode", isAttribute = true)
	 private String hotelCode;

	 /** The rate amount message. */
 	@JacksonXmlElementWrapper(useWrapping=false)
	 @JacksonXmlProperty(localName = "RateAmountMessage")
	 private List<RateAmountMessageReqDTO> rateAmountMessage;

	/**
	 * Gets the hotel code.
	 *
	 * @return the hotelCode
	 */
	public String getHotelCode() {
		return hotelCode;
	}

	/**
	 * Sets the hotel code.
	 *
	 * @param hotelCode the hotelCode to set
	 */
	public void setHotelCode(String hotelCode) {
		this.hotelCode = hotelCode;
	}

	/**
	 * Gets the rate amount message.
	 *
	 * @return the rateAmountMessage
	 */
	public List<RateAmountMessageReqDTO> getRateAmountMessage() {
		return rateAmountMessage;
	}

	/**
	 * Sets the rate amount message.
	 *
	 * @param rateAmountMessage the rateAmountMessage to set
	 */
	public void setRateAmountMessage(List<RateAmountMessageReqDTO> rateAmountMessage) {
		this.rateAmountMessage = rateAmountMessage;
	}
	 
	 
}
