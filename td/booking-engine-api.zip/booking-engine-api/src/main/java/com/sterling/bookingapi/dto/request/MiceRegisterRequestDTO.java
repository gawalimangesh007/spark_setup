package com.sterling.bookingapi.dto.request;

import java.io.Serializable;

public class MiceRegisterRequestDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String eventType;
	private String resortId;
	private String seatingType;
	private String checkInDate;
	private String checkOutDate;
	private Integer totalRooms;
	private Integer totalG_rooms;
	private String remarks;
	private MiceContactDetails contactDetails;
	
	public String getEventType() {
		return eventType;
	}
	public void setEventType(String eventType) {
		this.eventType = eventType;
	}
	public String getResortId() {
		return resortId;
	}
	public void setResortId(String resortId) {
		this.resortId = resortId;
	}
	public String getSeatingType() {
		return seatingType;
	}
	public void setSeatingType(String seatingType) {
		this.seatingType = seatingType;
	}
	public String getCheckInDate() {
		return checkInDate;
	}
	public void setCheckInDate(String checkInDate) {
		this.checkInDate = checkInDate;
	}
	public String getCheckOutDate() {
		return checkOutDate;
	}
	public void setCheckOutDate(String checkOutDate) {
		this.checkOutDate = checkOutDate;
	}
	public Integer getTotalRooms() {
		return totalRooms;
	}
	public void setTotalRooms(Integer totalRooms) {
		this.totalRooms = totalRooms;
	}
	public Integer getTotalG_rooms() {
		return totalG_rooms;
	}
	public void setTotalG_rooms(Integer totalG_rooms) {
		this.totalG_rooms = totalG_rooms;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public MiceContactDetails getContactDetails() {
		return contactDetails;
	}
	public void setContactDetails(MiceContactDetails contactDetails) {
		this.contactDetails = contactDetails;
	}
}
