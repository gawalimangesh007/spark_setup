package com.sterling.bookingapi.dto.request;

import java.io.Serializable;

/**
 * @author tcs
 *
 */
public class HsdRegisterRequestDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String email;
	private String mobileNo;
	private String firstName;
	private String lastName;
	private String password;
	
	
	/**
	 * @return password
	 */
	public String getPassword() {
		return password;
	}
	/**
	 * @param password
	 * set the password
	 */
	public void setPassword(String password) {
		this.password = password;
	}
	/**
	 * @return email
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * @param email
	 * set the email
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	/**
	 * @return mobile number
	 */
	public String getMobileNo() {
		return mobileNo;
	}
	/**
	 * @param mobileNo
	 * set the mobile number
	 */
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	/**
	 * @return firstname
	 */
	public String getFirstName() {
		return firstName;
	}
	/**
	 * @param firstName
	 * set the firstname
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	/**
	 * @return lastname
	 */
	public String getLastName() {
		return lastName;
	}
	/**
	 * @param lastName
	 * set the last name
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
}
