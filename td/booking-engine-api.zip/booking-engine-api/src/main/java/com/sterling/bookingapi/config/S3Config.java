package com.sterling.bookingapi.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;

/**
 * @author tcs
 * @version 1.0
 *
 */
@Configuration
public class S3Config {

	@Value("${amazon.s3.endpoint.url}")
	private String endpointUrl;
	
	@Value("${amazon.s3.bucketname}")
	private String bucketName;
	
	@Value("${amazon.s3.accessKey}")
	private String accessKey;
	
	@Value("${amazon.s3.secretKey}")
	private String secretKey;
	
	@Value("${amazon.s3.region}")
	private String region;

	@Bean
	public AmazonS3 s3client() {

		BasicAWSCredentials awsCreds = new BasicAWSCredentials(accessKey, secretKey);
		AmazonS3 s3Client = AmazonS3ClientBuilder.standard()
				.withRegion(Regions.fromName(region))
				.withCredentials(new AWSStaticCredentialsProvider(awsCreds))
				.build();

		return s3Client;
	}

}
