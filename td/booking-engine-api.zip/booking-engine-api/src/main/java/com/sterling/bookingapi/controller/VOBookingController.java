package com.sterling.bookingapi.controller;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.view.RedirectView;

import com.sterling.bookingapi.dto.HsdBookingPaymentDTO;
import com.sterling.bookingapi.dto.request.VOBlockBookingRequest;
import com.sterling.bookingapi.dto.request.VOCancelBookingRequestDTO;
import com.sterling.bookingapi.dto.request.VOConfirmBookingRequest;
import com.sterling.bookingapi.dto.request.VOGetAvailabilityRequestDTO;
import com.sterling.bookingapi.dto.request.VoSeasonDataRequestDTO;
import com.sterling.bookingapi.dto.response.BookingResponseDTO;
import com.sterling.bookingapi.dto.response.ResponseDTO;
import com.sterling.bookingapi.dto.response.VOBookingDetailResponse;
import com.sterling.bookingapi.engine.rules.models.ProductRuleDTO;
import com.sterling.bookingapi.exception.BookingEngineException;
import com.sterling.bookingapi.exception.SalesForceException;
import com.sterling.bookingapi.service.VOBookingService;
import com.sterling.bookingapi.service.VacationOwnershipService;
import com.sterling.bookingapi.sf.dto.response.VOSeasonMonthlyResponse;
import com.sterling.bookingapi.utils.ResponseUtility;

@RestController
@RequestMapping(value = "/vo")
public class VOBookingController extends BaseController {

	private static final Logger logger = LogManager.getLogger(VOBookingController.class);
	
	private static final String HEADER_CACHE = "must-revalidate, post-check=0, pre-check=0";
	private static final String MEDIA_TYPE_PDF = "application/pdf";

	@Autowired
	private VOBookingService voBookingService;

	@Autowired
	private VacationOwnershipService voService;
	
	public void setVoBookingService(VOBookingService voBookingService) {
		//TODO Private method
		logger.info("VOBookingController : setVoBookingService : Entered.");
		this.voBookingService = voBookingService;
		logger.info("VOBookingController : setVoBookingService : Leaving.");
	}
	
	

	@RequestMapping(value = "/getAvailability", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO getAvailability(@RequestBody @Valid VOGetAvailabilityRequestDTO reqDTO) throws SalesForceException {
		// reqDTO.setSfToken(sfToken);
		logger.info("VOBookingController : getAvailability : Entered.");
		ResponseEntity<?> availability = voBookingService.getAvailability(reqDTO);
		logger.info("VOBookingController : getAvailability : Leaving.");
		return ResponseUtility.constructSuccessRes(availability.getBody());
	}
	
	@RequestMapping(value = "/confirmBooking", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO confirmBooking(@RequestBody @Valid VOConfirmBookingRequest reqDTO) throws SalesForceException {
		// reqDTO.setSfToken(sfToken);
		logger.info("VOBookingController : confirmBooking : Entered.");
		 ResponseEntity<?> res = voBookingService.confirmBooking(reqDTO);
			logger.info("VOBookingController : confirmBooking : Leaving.");
		return ResponseUtility.constructSuccessRes(res.getBody());
	}
	
	@RequestMapping(value = "/blockBooking", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO blockBooking(@RequestBody @Valid VOBlockBookingRequest reqDTO) throws SalesForceException {
		// reqDTO.setSfToken(sfToken);
		logger.info("VOBookingController : confirmBooking : Entered.");
		BookingResponseDTO res = voBookingService.blockBooking(reqDTO);
		logger.info("VOBookingController : confirmBooking : Leaving.");
		return ResponseUtility.constructSuccessRes(res);
	}
	
	@RequestMapping(value = "/booking/get", method = RequestMethod.GET, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO getBookingDetails(@Valid @RequestParam String cvNumber) {
		// reqDTO.setSfToken(sfToken);
		logger.info("VOBookingController : getBookingDetails : Entered.");
		 VOBookingDetailResponse res = voBookingService.getEntireBookingDetails(cvNumber);
			logger.info("VOBookingController : getBookingDetails : Leaving.");
		return ResponseUtility.constructSuccessRes(res);
	}
	
	@RequestMapping(value = "/booking/getByContractId", method = RequestMethod.GET, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO getBookingDetails(@Valid @RequestParam String cvNumber,@RequestParam String contractId) {
		// reqDTO.setSfToken(sfToken);
		logger.info("VOBookingController : getBookingDetails : Entered.");
		 VOBookingDetailResponse res = voBookingService.getBookingBy(cvNumber,contractId);
			logger.info("VOBookingController : getBookingDetails : Leaving.");
		return ResponseUtility.constructSuccessRes(res);
	}
	
	/**
	 * Download pdf.
	 *
	 * @param bookingId the booking id
	 * @return the response entity
	 * @throws BookingEngineException the booking engine exception
	 */
	@RequestMapping(value = "/{cvNumber}", method = RequestMethod.GET)
	public ResponseEntity<byte[]> downloadPdf(@PathVariable("cvNumber") String cvNumber) throws BookingEngineException {
		  logger.info("HsdBookingController : downloadPdf : Entered.");
		HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.parseMediaType(MEDIA_TYPE_PDF));
	    
	    String filename = cvNumber+".pdf";
	    
	    byte[] contents = voBookingService.getPDFContents(cvNumber);
	    
	    headers.setContentDispositionFormData(filename, filename);
	    
	    headers.setCacheControl(HEADER_CACHE);
	    
		ResponseEntity<byte[]> response = new ResponseEntity<>(contents, headers, HttpStatus.OK);
		  logger.info("HsdBookingController : downloadPdf : leaving.");
		return response;
	}
	/**
	 * Update payment.
	 *
	 * @param TRANSACTIONID the transactionid
	 * @param APTRANSACTIONID the aptransactionid
	 * @param AMOUNT the amount
	 * @param TRANSACTIONSTATUS the transactionstatus
	 * @param MESSAGE the message
	 * @param CUSTOMVAR the customvar
	 * @param CHMOD the chmod
	 * @param CARDISSUER the cardissuer
	 * @param CUSTOMER the customer
	 * @param CUSTOMEREMAIL the customeremail
	 * @param CUSTOMERPHONE the customerphone
	 * @param RISK the risk
	 * @param CURRENCYCODE the currencycode
	 * @param ap_SecureHash the ap secure hash
	 * @return the redirect view
	 * @throws BookingEngineException the booking engine exception
	 */
//		@ResponseBody
	    @RequestMapping(value = "/updatePayment", method = RequestMethod.POST)
	    public RedirectView updatePayment(@RequestParam final String TRANSACTIONID,@RequestParam(required = false) final String APTRANSACTIONID,
				 @RequestParam(required = false) final String AMOUNT, @RequestParam final String TRANSACTIONSTATUS,
@RequestParam(required = false) final String MESSAGE, @RequestParam final String CUSTOMVAR,
				 @RequestParam(required = false) final String CHMOD, @RequestParam(required = false) final String CARDISSUER,
				 @RequestParam(required = false) final String CUSTOMER, @RequestParam(required = false) final String CUSTOMEREMAIL,
@RequestParam(required = false) final String CUSTOMERPHONE, @RequestParam(required = false) final String RISK,
				 @RequestParam(required = false) final String CURRENCYCODE, @RequestParam(required = false) final String ap_SecureHash)throws BookingEngineException {
	    		logger.info("VOBookingController : updatePayment : Entered.");
			HsdBookingPaymentDTO request = new HsdBookingPaymentDTO();
			request.setTransactionId(TRANSACTIONID);
			request.setApTransactionId(APTRANSACTIONID);
			request.setAmount(AMOUNT);
			request.setTransactionStatus(TRANSACTIONSTATUS);
			request.setMessage(MESSAGE);
			request.setCustomVar(CUSTOMVAR);
			request.setChmod(CHMOD);
			request.setCardIssuer(CARDISSUER);
			request.setCustomer(CUSTOMER);
			request.setCustomerEmail(CUSTOMEREMAIL);
			request.setCustomerPhone(CUSTOMERPHONE);
			request.setRisk(RISK);
			request.setCurrencyCode(CURRENCYCODE);
			request.setApSecureHash(ap_SecureHash);
			
			
			String redirectUrl = voBookingService.updatePayment(request);
			 RedirectView redirectView = new RedirectView();
			redirectView.setUrl(redirectUrl);
			
	        logger.info("VOBookingController : updatePayment : leaving.");
	        return redirectView;
	}
	  
	    
    @RequestMapping(value = "/cancelBooking", method = RequestMethod.POST, produces = "application/json; charset=utf-8") 
	@ResponseBody
	public ResponseDTO cancelBooking(@RequestBody VOCancelBookingRequestDTO req) throws SalesForceException {
    	logger.info("VOBookingController : cancelBooking : Entered.");
		ResponseEntity<String> updateBookingDet = voBookingService.cancelBooking(req);
		logger.info("VOBookingController : cancelBooking : Leaving.");
		return ResponseUtility.constructSuccessRes(updateBookingDet.getBody());
	}
    
    @RequestMapping(value = "/initiateCancelBooking", method = RequestMethod.POST, produces = "application/json; charset=utf-8") 
	@ResponseBody
	public ResponseDTO initiateCancelBooking(@RequestBody VOCancelBookingRequestDTO req) throws SalesForceException {
    	logger.info("VOBookingController : cancelBooking : Entered.");
		ResponseEntity<String> updateBookingDet = voBookingService.initiateCancelBooking(req);
		logger.info("VOBookingController : cancelBooking : Leaving.");
		return ResponseUtility.constructSuccessRes(updateBookingDet.getBody());
	}
    
    @RequestMapping(value = "/ruleConfig", method = RequestMethod.POST, produces = "application/json; charset=utf-8") 
	@ResponseBody
	public ResponseDTO cacheRuleConfig(@RequestBody ProductRuleDTO req) throws SalesForceException {
    	logger.info("VOBookingController : cacheRuleConfig : Entered.");
		ResponseEntity<String> status = voBookingService.cacheRuleConfig(req);
		logger.info("VOBookingController : cacheRuleConfig : Leaving.");
		return ResponseUtility.constructSuccessRes(status.getBody());
	}
    
    @RequestMapping(value = "/seasonDetails", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO seasonData(@RequestBody @Valid VoSeasonDataRequestDTO reqDTO) throws SalesForceException {
		logger.info("VOBookingController : confirmBooking : Entered.");
		 VOSeasonMonthlyResponse res = voService.getSeasonCalender(reqDTO);
			logger.info("VOBookingController : confirmBooking : Leaving.");
		return ResponseUtility.constructSuccessRes(res);
	}
    
    /**
	 * Download Overdue pdf.
	 *
	 * @param bookingId the booking id
	 * @return the response entity
	 * @throws BookingEngineException the booking engine exception
	 */
	@RequestMapping(value = "/overdue/{cvNumber}", method = RequestMethod.GET)
	public ResponseEntity<byte[]> getOverDuePDFContents(@PathVariable("cvNumber") String cvNumber) throws BookingEngineException {
		logger.info("HsdBookingController : getOverDuePDFContents : Entered.");
		HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.parseMediaType(MEDIA_TYPE_PDF));
	    
	    String filename = cvNumber+".pdf";
	    
	    byte[] contents = voBookingService.getOverDuePDFContents(cvNumber);
	    
	    headers.setContentDispositionFormData(filename, filename);
	    
	    headers.setCacheControl(HEADER_CACHE);
	    
		ResponseEntity<byte[]> response = new ResponseEntity<>(contents, headers, HttpStatus.OK);
		logger.info("HsdBookingController : getOverDuePDFContents : leaving.");
		return response;
	}
    
}
