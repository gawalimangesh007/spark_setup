package com.sterling.bookingapi.dto;


public class RoomAvailableDetails {

	/** The resort room id. */
	private int resortRoomId;
	
	/** The resort id. */
	private String resortId;
	
	/** The room type id. */
	private String roomTypeId;
	
	/** The resort name. */
	private String resortName;
	
	
	/** The available rooms. */
	private int availableRooms;
	
	
	/**
	 * Instantiates a new room occupancy details.
	 *
	 * @param resortRoomId the resort room id
	 * @param resortId the resort id
	 * @param resortName the resort name
	 * @param roomTypeId the room type id
	 * @param occupancyDetail the occupancy detail
	 * @param extraPersonChildCost the extra person child cost
	 * @param maxOccupancyCount the max occupancy count
	 * @param availableRooms the available rooms
	 * @param baseOccupancyCount the base occupancy count
	 * @param extraOccupancyAdultCount the extra occupancy adult count
	 * @param extraOccupancyChildCount the extra occupancy child count
	 * @param totalBaseOccupancyCount the total base occupancy count
	 * @param totalExtraAdultOccupancyCount the total extra adult occupancy count
	 * @param totalExtraChildOccupancyCount the total extra child occupancy count
	 */
	public RoomAvailableDetails(int resortRoomId, String resortId,String resortName, String roomTypeId,  int availableRooms) {

		this.resortRoomId = resortRoomId;
		this.resortId = resortId;
		this.resortName = resortName;
		this.roomTypeId = roomTypeId;
		this.availableRooms = availableRooms;
	}

	
	/**
	 * Gets the resort room id.
	 *
	 * @return the resort room id
	 */
	public int getResortRoomId() {
		return resortRoomId;
	}


	/**
	 * Sets the resort room id.
	 *
	 * @param resortRoomId the new resort room id
	 */
	public void setResortRoomId(int resortRoomId) {
		this.resortRoomId = resortRoomId;
	}


	/**
	 * Gets the resort id.
	 *
	 * @return the resort id
	 */
	public String getResortId() {
		return resortId;
	}


	/**
	 * Sets the resort id.
	 *
	 * @param resortId the new resort id
	 */
	public void setResortId(String resortId) {
		this.resortId = resortId;
	}


	/**
	 * Gets the room type id.
	 *
	 * @return the room type id
	 */
	public String getRoomTypeId() {
		return roomTypeId;
	}


	/**
	 * Sets the room type id.
	 *
	 * @param roomTypeId the new room type id
	 */
	public void setRoomTypeId(String roomTypeId) {
		this.roomTypeId = roomTypeId;
	}


	/**
	 * Gets the occupancy detail.
	 *
	 * @return the occupancy detail
	 */
	

	/**
	 * Gets the available rooms.
	 *
	 * @return the available rooms
	 */
	public int getAvailableRooms() {
		return availableRooms;
	}


	/**
	 * Sets the available rooms.
	 *
	 * @param availableRooms the new available rooms
	 */
	public void setAvailableRooms(int availableRooms) {
		this.availableRooms = availableRooms;
	}


	/**
	 * Gets the resort name.
	 *
	 * @return the resort name
	 */
	public String getResortName() {
		return resortName;
	}

	/**
	 * Sets the resort name.
	 *
	 * @param resortName the new resort name
	 */
	public void setResortName(String resortName) {
		this.resortName = resortName;
	}
	
}

