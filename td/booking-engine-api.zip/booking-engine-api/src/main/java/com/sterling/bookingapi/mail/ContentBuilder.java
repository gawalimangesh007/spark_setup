package com.sterling.bookingapi.mail;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;
import org.springframework.util.StringUtils;

import com.sterling.bookingapi.exception.BookingEngineException;
import com.sterling.bookingapi.sf.dto.request.CompositeSFRequest;
import com.sterling.bookingapi.utils.AppConstants;
import com.sterling.bookingapi.utils.MessageConstants;
import com.sterling.bookingapi.utils.PropertiesConfig;

import freemarker.cache.MultiTemplateLoader;
import freemarker.cache.StringTemplateLoader;
import freemarker.cache.TemplateLoader;
import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateNotFoundException;

/**
 * The Class MailContentBuilder.
 */
/**
 * @author tcs
 * @version 1.0
 *
 */
@Component
public class ContentBuilder {

	/** The Constant logger. */
	private static final Logger logger = LogManager.getLogger(ContentBuilder.class);

	/** The freemarker configuration. */
	@Autowired
	private Configuration freemarkerConfiguration;

	@Autowired
	private PropertiesConfig propertiesConfig;

	/**
	 * Build the mail template.
	 *
	 * @param templateName
	 *            the template name
	 * @param data
	 *            the data
	 * @return the string
	 * @throws BookingEngineException
	 *             the booking engine exception
	 */
	public String build(String templateName, Map<String, Object> data) throws BookingEngineException {
		return build(templateName, data, false);
	}
	
	
	public String build(String template, Map<String, Object> data, boolean isTemplateString) throws BookingEngineException {
		String content = null;
		Template tmplt = null;
		try {

			//TODO load templates on startup
			if(isTemplateString) {
				tmplt = new Template("templateName", new StringReader(template), freemarkerConfiguration);				
			} else {
				tmplt = freemarkerConfiguration.getTemplate(template);
			}
			content = FreeMarkerTemplateUtils.processTemplateIntoString(tmplt, data);

		} catch (TemplateNotFoundException e) {
			logger.error("MailContentBuilder : build : Exception occurred : {}", e);
			throw new BookingEngineException(MessageConstants.TEMPLATE_NOT_FOUND);
		} catch (Exception e) {
			logger.error("MailContentBuilder : build : Exception occurred : {}", e);
			throw new BookingEngineException(MessageConstants.EXCEPTION_WHILE_PROCESSING_MAIL_TEMPLATE);
		}
		return content;
	}


	public String constructURL(String queryString, Map<String, Object> data, boolean isTemplateString) {
		return constructURL(queryString, data, isTemplateString, false);
	}

	public String constructURL(String queryString, Map<String, Object> data, boolean isTemplateString, boolean isService) {
//		StringBuffer baseUrl = new StringBuffer("https://cs1.salesforce.com/services/data/v39.0/query?q=");
		StringBuffer baseUrl;
		if(isService) {
			baseUrl = new StringBuffer(AppConstants.Authorization.SERVICE_URI);
		} else {
			baseUrl = new StringBuffer(AppConstants.Authorization.BASEURI);
		}
		if(queryString != null) {
			baseUrl.append("/query?q=");
			
			if(data != null) {
				baseUrl.append(build(queryString, data, isTemplateString));
			} else {
				baseUrl.append(queryString);
			}
		}
		return baseUrl.toString();
	}


	public String constructURL(String relativeUrl) {
		StringBuffer baseUrl = new StringBuffer(AppConstants.Authorization.INSTANCEURL);
		if(!StringUtils.isEmpty(relativeUrl)) {
			baseUrl.append(relativeUrl);
		}
		return baseUrl.toString();
	}
	
	public String constructURL(String relativeUrl, boolean withBaseURL) {
		String url;
		if(withBaseURL) {
			StringBuffer baseUrl = new StringBuffer(AppConstants.Authorization.BASEURI);
			if(!StringUtils.isEmpty(relativeUrl)) {
				baseUrl.append(relativeUrl);
			}
			url = baseUrl.toString();
		} else {
			url = constructURL(relativeUrl);
		}
		return url;
	}
	
	@PostConstruct
	public void loadTemplates() {
		logger.info("ContentBuilder : loadTemplates: Entered   ");
		StringTemplateLoader stringLoader = new StringTemplateLoader();

		List<String> fileList = new ArrayList<>();
		fileList.add("sf_queries.properties");

		Map<String, String> propertyMap = PropertiesConfig.getAllPropertyValues(fileList);

		propertyMap.forEach((k, v) -> stringLoader.putTemplate(k, v));
		
		TemplateLoader ftl1 = freemarkerConfiguration.getTemplateLoader();
		MultiTemplateLoader mtl = new MultiTemplateLoader(new TemplateLoader[] { ftl1 , stringLoader });

		freemarkerConfiguration.setTemplateLoader(mtl);

//		freemarkerConfiguration.setTemplateLoader(stringLoader);
		logger.info("ContentBuilder : loadTemplates: Leaving   ");
	}


	public CompositeSFRequest buildCompositeRequest(HttpMethod method, String refId,
			String query, Map<String, Object> data) {
		CompositeSFRequest req = new CompositeSFRequest();
		req.setMethod(method.name());
		req.setReferenceId(refId);
		req.setUrl(constructURL(query, data, false, true));
		return req;
	}

	public CompositeSFRequest buildCompositeRequest(HttpMethod method, String refId,
			String url, Object data) {
		CompositeSFRequest req = new CompositeSFRequest();
		req.setMethod(method.name());
		req.setReferenceId(refId);
		req.setUrl(url);
		req.setBody(data);
		return req;
	}

}
