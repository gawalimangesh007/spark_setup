package com.sterling.bookingapi.models;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * The Class HsdRateMaster.
 */
/**
 * @author tcs
 *
 */
@Entity
@Table(name = "sh_hsd_rate_master")//delete
public class HsdRateMaster extends BaseModel{
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@GeneratedValue( strategy = GenerationType.IDENTITY )
	@Column(name = "rate_id", unique = true)
	private int id;
	
	/** The resort id. */
	@Column(name = "resort_id",nullable = false)
	private String resortId;
	
	/** The room type id. */
	@Column(name = "room_type_id",nullable = false)
	private String roomTypeId;
		
	/** The start date. */
	@Column(name = "start_date",nullable = false)
	private Date startDate;
	
	/** The end date. */
	@Column(name = "end_date",nullable = false)
	private Date endDate;
	
	/** The room rent. */
	@Column(name = "room_rent",nullable = false)
	private Double roomRent;
	
	/** The extra bed cost adult. */
	@Column(name = "extrabed_cost_adult",nullable = false)
	private Double extraBedCostAdult;
	
	/** The extra bed cost child. */
	@Column(name = "extrabed_cost_child",nullable = false)
	private Double extraBedCostChild;
	
	/** The tax amount. */
	@Column(name = "tax_amount",nullable = false)
	private Double taxAmount;
	
	/** The tax description. */
	@Column(name = "tax_description",nullable = false)
	private String taxDescription;
	
	/** The lunch cost child. */
	@Column(name = "lunch_cost_child",nullable = false)
	private Double lunchCostChild;
	
	/** The lunch cost adult. */
	@Column(name = "lunch_cost_adult",nullable = false)
	private Double lunchCostAdult;
	
	/** The dinner cost child. */
	@Column(name = "dinner_cost_child",nullable = false)
	private Double dinnerCostChild;
	
	/** The dinner cost adult. */
	@Column(name = "dinner_cost_adult",nullable = false)
	private Double dinnerCostAdult;
	
	/** The rate plan code. */
	@Column(name = "rate_plan_code",nullable = false)
	private String ratePlanCode;
	
	/** The rate plan desc. */
	@Column(name = "rate_plan_desc",nullable = false)
	private String ratePlanDesc;
	
	/** The currency code. */
	@Column(name = "currency_code",nullable = false)
	private String currencyCode;
	
	/** The active. */
	@Column(name = "status",nullable = false)
	private boolean active;

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * Gets the resort id.
	 *
	 * @return the resort id
	 */
	public String getResortId() {
		return resortId;
	}

	/**
	 * Sets the resort id.
	 *
	 * @param resortId the new resort id
	 */
	public void setResortId(String resortId) {
		this.resortId = resortId;
	}

	/**
	 * Gets the room type id.
	 *
	 * @return the room type id
	 */
	public String getRoomTypeId() {
		return roomTypeId;
	}

	/**
	 * Sets the room type id.
	 *
	 * @param roomTypeId the new room type id
	 */
	public void setRoomTypeId(String roomTypeId) {
		this.roomTypeId = roomTypeId;
	}

	/**
	 * Gets the start date.
	 *
	 * @return the start date
	 */
	public Date getStartDate() {
		return startDate;
	}

	/**
	 * Sets the start date.
	 *
	 * @param startDate the new start date
	 */
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	/**
	 * Gets the end date.
	 *
	 * @return the end date
	 */
	public Date getEndDate() {
		return endDate;
	}

	/**
	 * Sets the end date.
	 *
	 * @param endDate the new end date
	 */
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	/**
	 * Gets the room rent.
	 *
	 * @return the room rent
	 */
	public Double getRoomRent() {
		return roomRent;
	}

	/**
	 * Sets the room rent.
	 *
	 * @param roomRent the new room rent
	 */
	public void setRoomRent(Double roomRent) {
		this.roomRent = roomRent;
	}

	/**
	 * Gets the extra bed cost adult.
	 *
	 * @return the extra bed cost adult
	 */
	public Double getExtraBedCostAdult() {
		return extraBedCostAdult;
	}

	/**
	 * Sets the extra bed cost adult.
	 *
	 * @param extraBedCostAdult the new extra bed cost adult
	 */
	public void setExtraBedCostAdult(Double extraBedCostAdult) {
		this.extraBedCostAdult = extraBedCostAdult;
	}

	/**
	 * Gets the extra bed cost child.
	 *
	 * @return the extra bed cost child
	 */
	public Double getExtraBedCostChild() {
		return extraBedCostChild;
	}

	/**
	 * Sets the extra bed cost child.
	 *
	 * @param extraBedCostChild the new extra bed cost child
	 */
	public void setExtraBedCostChild(Double extraBedCostChild) {
		this.extraBedCostChild = extraBedCostChild;
	}

	/**
	 * Gets the tax amount.
	 *
	 * @return the tax amount
	 */
	public Double getTaxAmount() {
		return taxAmount;
	}

	/**
	 * Sets the tax amount.
	 *
	 * @param taxAmount the new tax amount
	 */
	public void setTaxAmount(Double taxAmount) {
		this.taxAmount = taxAmount;
	}

	/**
	 * Gets the tax description.
	 *
	 * @return the tax description
	 */
	public String getTaxDescription() {
		return taxDescription;
	}

	/**
	 * Sets the tax description.
	 *
	 * @param taxDescription the new tax description
	 */
	public void setTaxDescription(String taxDescription) {
		this.taxDescription = taxDescription;
	}

	/**
	 * Gets the lunch cost child.
	 *
	 * @return the lunch cost child
	 */
	public Double getLunchCostChild() {
		return lunchCostChild;
	}

	/**
	 * Sets the lunch cost child.
	 *
	 * @param lunchCostChild the new lunch cost child
	 */
	public void setLunchCostChild(Double lunchCostChild) {
		this.lunchCostChild = lunchCostChild;
	}

	/**
	 * Gets the lunch cost adult.
	 *
	 * @return the lunch cost adult
	 */
	public Double getLunchCostAdult() {
		return lunchCostAdult;
	}

	/**
	 * Sets the lunch cost adult.
	 *
	 * @param lunchCostAdult the new lunch cost adult
	 */
	public void setLunchCostAdult(Double lunchCostAdult) {
		this.lunchCostAdult = lunchCostAdult;
	}

	/**
	 * Gets the dinner cost child.
	 *
	 * @return the dinner cost child
	 */
	public Double getDinnerCostChild() {
		return dinnerCostChild;
	}

	/**
	 * Sets the dinner cost child.
	 *
	 * @param dinnerCostChild the new dinner cost child
	 */
	public void setDinnerCostChild(Double dinnerCostChild) {
		this.dinnerCostChild = dinnerCostChild;
	}

	/**
	 * Gets the dinner cost adult.
	 *
	 * @return the dinner cost adult
	 */
	public Double getDinnerCostAdult() {
		return dinnerCostAdult;
	}

	/**
	 * Sets the dinner cost adult.
	 *
	 * @param dinnerCostAdult the new dinner cost adult
	 */
	public void setDinnerCostAdult(Double dinnerCostAdult) {
		this.dinnerCostAdult = dinnerCostAdult;
	}

	/**
	 * Gets the rate plan code.
	 *
	 * @return the rate plan code
	 */
	public String getRatePlanCode() {
		return ratePlanCode;
	}

	/**
	 * Sets the rate plan code.
	 *
	 * @param ratePlanCode the new rate plan code
	 */
	public void setRatePlanCode(String ratePlanCode) {
		this.ratePlanCode = ratePlanCode;
	}

	/**
	 * Gets the rate plan desc.
	 *
	 * @return the rate plan desc
	 */
	public String getRatePlanDesc() {
		return ratePlanDesc;
	}

	/**
	 * Sets the rate plan desc.
	 *
	 * @param ratePlanDesc the new rate plan desc
	 */
	public void setRatePlanDesc(String ratePlanDesc) {
		this.ratePlanDesc = ratePlanDesc;
	}

	/**
	 * Gets the currency code.
	 *
	 * @return the currency code
	 */
	public String getCurrencyCode() {
		return currencyCode;
	}

	/**
	 * Sets the currency code.
	 *
	 * @param currencyCode the new currency code
	 */
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	/**
	 * Checks if is active.
	 *
	 * @return true, if is active
	 */
	public boolean isActive() {
		return active;
	}

	/**
	 * Sets the active.
	 *
	 * @param active the new active
	 */
	public void setActive(boolean active) {
		this.active = active;
	}
}
