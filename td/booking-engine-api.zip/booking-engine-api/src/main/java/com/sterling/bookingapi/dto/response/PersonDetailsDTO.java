package com.sterling.bookingapi.dto.response;



/**
 * @author tcs
 * @version 1.0
 */
public class PersonDetailsDTO extends BaseRecord {

	private static final long serialVersionUID = 1L;

	private String id;
	private String relation;
	private String title;
	private String name;
	private String firstName;
	private String lastName;
	private String gender;
	private String dob;
	private String mobileNumber;
	private String contactEmail;
	private String alternateEmail;
	private String fixedLineNumber;
	private String alternateFixedLine;
	private String correspondenceAddress;
	private String maritalStatus;
	private String permanentAddress;
	private String customer;
	private String profileImage;
	private String city;
	private String state;
	private String country;
	private String addressLine1;
	private String pincode;
	
	private Preferences preferences;
	
	
	private String type;

	/**
	 * @return relation
	 */
	public String getRelation() {
		return relation;
	}
	/**
	 * @param relation
	 * set the relation
	 */
	public void setRelation(String relation) {
		this.relation = relation;
	}
	/**
	 * @return title
	 */
	public String getTitle() {
		return title;
	}
	/**
	 * @param title
	 * set the title
	 */
	public void setTitle(String title) {
		this.title = title;
	}
	/**
	 * @return firstName
	 */
	public String getFirstName() {
		return firstName;
	}
	/**
	 * @param firstName
	 * set the firstName
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	/**
	 * @return lastName
	 */
	public String getLastName() {
		return lastName;
	}
	/**
	 * @param lastName
	 * set the lastName
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	/**
	 * @return gender
	 */
	public String getGender() {
		return gender;
	}
	/**
	 * @param gender
	 * set the gender
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}
	/**
	 * @return dob
	 */
	public String getDob() {
		return dob;
	}
	/**
	 * @param dob
	 * set the dob
	 */
	public void setDob(String dob) {
		this.dob = dob;
	}
	/**
	 * @return mobileNumber
	 */
	public String getMobileNumber() {
		return mobileNumber;
	}
	/**
	 * @param mobileNumber
	 * set the mobileNumber
	 */
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	/**
	 * @return contactEmail
	 */
	public String getContactEmail() {
		return contactEmail;
	}
	/**
	 * @param contactEmail
	 * set the contactEmail
	 */
	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}
	/**
	 * @return alternateEmail
	 */
	public String getAlternateEmail() {
		return alternateEmail;
	}
	/**
	 * @param alternateEmail
	 * set the alternateEmail
	 */
	public void setAlternateEmail(String alternateEmail) {
		this.alternateEmail = alternateEmail;
	}
	/**
	 * @return fixedLineNumber
	 */
	public String getFixedLineNumber() {
		return fixedLineNumber;
	}
	/**
	 * @param fixedLineNumber
	 * set the fixedLineNumber
	 */
	public void setFixedLineNumber(String fixedLineNumber) {
		this.fixedLineNumber = fixedLineNumber;
	}
	/**
	 * @return alternateFixedLine
	 */
	public String getAlternateFixedLine() {
		return alternateFixedLine;
	}
	/**
	 * @param alternateFixedLine
	 * set the alternateFixedLine
	 */
	public void setAlternateFixedLine(String alternateFixedLine) {
		this.alternateFixedLine = alternateFixedLine;
	}
	/**
	 * @return correspondenceAddress
	 */
	public String getCorrespondenceAddress() {
		return correspondenceAddress;
	}
	/**
	 * @param correspondenceAddress
	 * set the correspondenceAddress
	 */
	public void setCorrespondenceAddress(String correspondenceAddress) {
		this.correspondenceAddress = correspondenceAddress;
	}
	/**
	 * @return maritalStatus
	 */
	public String getMaritalStatus() {
		return maritalStatus;
	}
	/**
	 * @param maritalStatus
	 * set the maritalStatus
	 */
	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}
	/**
	 * @return permanentAddress
	 */
	public String getPermanentAddress() {
		return permanentAddress;
	}
	/**
	 * @param permanentAddress
	 * set the permanentAddress
	 */
	public void setPermanentAddress(String permanentAddress) {
		this.permanentAddress = permanentAddress;
	}
	/**
	 * @return type
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type
	 * set the type
	 */
	public void setType(String type) {
		this.type = type;
	}
	/**
	 * @return name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name
	 * set the name
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return customer
	 */
	public String getCustomer() {
		return customer;
	}
	/**
	 * @param customer
	 * set the customer
	 */
	public void setCustomer(String customer) {
		this.customer = customer;
	}
	/**
	 * @return profileImage
	 */
	public String getProfileImage() {
		return profileImage;
	}
	/**
	 * @param profileImage
	 * set the profileImage
	 */
	public void setProfileImage(String profileImage) {
		this.profileImage = profileImage;
	}
	/**
	 * @return preferences
	 */
	public Preferences getPreferences() {
		return preferences;
	}
	/**
	 * @param preferences
	 * set the preferences
	 */
	public void setPreferences(Preferences preferences) {
		this.preferences = preferences;
	}
	/**
	 * @return id
	 */
	public String getId() {
		return id;
	}
	/**
	 * @param id
	 * set the id
	 */
	public void setId(String id) {
		this.id = id;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getAddressLine1() {
		return addressLine1;
	}
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	
}
