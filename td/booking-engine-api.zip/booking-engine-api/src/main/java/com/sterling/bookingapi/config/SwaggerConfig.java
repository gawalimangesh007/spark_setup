package com.sterling.bookingapi.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import io.swagger.models.Contact;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;


/**
 * The Class SwaggerConfig.
 */
/**
 * @author tcs
 *
 */
@Configuration
@EnableSwagger2
@Profile("dev")
public class SwaggerConfig {
	
	/**
	 * Api.
	 *
	 * @return the docket
	 */
	@Bean
    public Docket voApi() { 
        return new Docket(DocumentationType.SWAGGER_2)  
          .groupName("VO")
          .apiInfo(apiInfo("VO"))
          .select()                                  
//          .includePatterns("/vo/.*");
          .apis(RequestHandlerSelectors.basePackage("com.sterling.bookingapi.controller")) 
//          .paths(PathSelectors.regex("/(.*?vo.*?|.*?hsd.*?)"))
          .paths(PathSelectors.regex("/(.*?(vo|temp|dtc).*?)")) 
          .build();                                           
    }

	@Bean
	public Docket auth() { 
		return new Docket(DocumentationType.SWAGGER_2)  
		.groupName("Auth")
		.apiInfo(apiInfo("Auth"))
		.select()                                  
//          .includePatterns("/vo/.*");
		.apis(RequestHandlerSelectors.basePackage("com.sterling.bookingapi.controller")) 
//          .paths(PathSelectors.regex("/(.*?vo.*?|.*?hsd.*?)"))
		.paths(PathSelectors.regex("/(.*?(login|mockAuth|getAuthHeader|logout).*?)")) 
		.build();                                           
	}
	
	@Bean
    public Docket miceApi() { 
        return new Docket(DocumentationType.SWAGGER_2)  
          .groupName("MICE")
          .apiInfo(apiInfo("MICE"))
          .select()                                  
//          .includePatterns("/vo/.*");
          .apis(RequestHandlerSelectors.basePackage("com.sterling.bookingapi.controller")) 
//          .paths(PathSelectors.regex("/(.*?vo.*?|.*?hsd.*?)"))
          .paths(PathSelectors.regex("/(.*?(mice|temp).*?)")) 
          .build();                                           
    }
	
	@Bean
	public Docket OTPApi() {
		 return new Docket(DocumentationType.SWAGGER_2)  
         .groupName("Common")
         .apiInfo(apiInfo("Common"))
         .select()                                  
//         .includePatterns("/vo/.*");
         .apis(RequestHandlerSelectors.basePackage("com.sterling.bookingapi.controller")) 
//         .paths(PathSelectors.regex("/(.*?vo.*?|.*?hsd.*?)"))
         .paths(PathSelectors.regex("/(.*?(otp|temp|common).*?)")) 
         .build();   
	}
	
	@Bean
    public Docket hsdApi() { 
        return new Docket(DocumentationType.SWAGGER_2)  
          .groupName("SF_HSD")
          .apiInfo(apiInfo("SF_HSD"))
          .select()                                  
          .apis(RequestHandlerSelectors.basePackage("com.sterling.bookingapi.sf.hsd.controller"))
          .paths(PathSelectors.regex("/(.*?hsd.*?)"))                         
          .build();                                           
    }
	
	@Bean
    public Docket oHsdApi() { 
        return new Docket(DocumentationType.SWAGGER_2)  
          .groupName("bookingEngineAPI")
          .apiInfo(apiInfo("HSD"))
          .select()
          .apis(RequestHandlerSelectors.basePackage("com.sterling.bookingapi.controller"))
          .apis(RequestHandlerSelectors.any())
          .paths(PathSelectors.regex("/(.*?(hsd|rateplan).*?)"))                         
          .build();                                           
    }
    /**
     * Api info.
     *
     * @return the api info
     */
    private ApiInfo apiInfo(String type) {
        return new ApiInfoBuilder()
                .title(type + " -- Booking Engine API")
                .description("Booking Engine application for Sterling Holiday Resorts.")
//                .contact(createContact())
                .contact("TCS")
                .license("TCS License V 1.0")
                .version("2.0")
                .build();
    }


	/**
	 * Creates the contact.
	 *
	 * @return the contact
	 */
	private Contact createContact() {
		Contact contact = new Contact();
		contact.setName("TCS");
		contact.setUrl("www.tcs.com");
		contact.setEmail("mail@tcs.com");
		return contact;
	}
    
    
}
