package com.sterling.bookingapi.auth.impl;

import java.util.UUID;

import net.sf.ehcache.Ehcache;
import net.sf.ehcache.Element;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.stereotype.Service;

import com.sterling.bookingapi.auth.bean.SterlingAuthException;
import com.sterling.bookingapi.auth.bean.User;
import com.sterling.bookingapi.auth.bean.UserToken;
import com.sterling.bookingapi.utils.AppConstants;

@Service
public class TokenHandlerServiceImpl implements TokenHandlerService {
	private Logger logger = LogManager.getLogger(TokenHandlerServiceImpl.class);
	
	@Autowired
	private CacheManager cacheManager;

	@Override
	public User parseUserFromToken(String token) throws SterlingAuthException {
		
		Cache userCache = cacheManager.getCache(AppConstants.cacheGroups.authCache.name());
		UserToken userToken = userCache.get(token, UserToken.class);
		if(userToken  == null){ 
			throw new SterlingAuthException(token, "TOKEN_NOT_FOUND_IN_CACHE", null);
		}
		return userToken.getUser();
	}

	@Override
	public String calculateTokenForUser(User srcUser) {
		return UUID.randomUUID().toString();
	}

	@Override
	public void insertToCache(String token, UserToken userToken) {
		if(token != null && userToken != null) {
			Cache userCache = cacheManager.getCache(AppConstants.cacheGroups.authCache.name());
			userCache.put(token, userToken);
		}
	}

	@Override
	public void removeFromCache(String token) {
		logger.info("remove item from cache {}", token);
		if(token != null) {
			Cache userCache = cacheManager.getCache(AppConstants.cacheGroups.authCache.name());
			userCache.evict(token);
		}
	}
	
	@Override
	public synchronized void mapUserToken(String token, String userId) {
		AppConstants.userTokenMap.put(userId, token);
	}

	@Override
	public synchronized String getLoggedUserToken(String userId) {
		return AppConstants.userTokenMap.get(userId);
	}

	@Override
	public Object getLoggedUser(String token) {
		Cache cache = cacheManager.getCache(AppConstants.cacheGroups.authCache.name());
		return cache.get(token);
	}
}
