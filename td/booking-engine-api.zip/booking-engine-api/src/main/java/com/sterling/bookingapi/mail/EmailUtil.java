package com.sterling.bookingapi.mail;

import java.util.List;

import javax.activation.DataSource;
import javax.activation.MimetypesFileTypeMap;
import javax.mail.MessagingException;
import javax.mail.util.ByteArrayDataSource;

import org.apache.commons.lang.ArrayUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.sterling.bookingapi.exception.BookingEngineException;
import com.sterling.bookingapi.utils.MessageConstants;

/**
 * The Class EmailUtil.
 */
/**
 * @author tcs
 * @version 1.0
 *
 */
@Component
public class EmailUtil {

	/** The Constant logger. */
	private static final Logger logger = LogManager.getLogger(EmailUtil.class);

	/** The java mail sender. */
	@Autowired
	private JavaMailSender javaMailSender;

	/** The mail content builder. */
	@Autowired
	private ContentBuilder contentBuilder;

	/**
	 * Prepare and send.
	 *
	 * @param request
	 *            the request
	 * @return the string
	 * @throws BookingEngineException
	 *             the booking engine exception
	 */
	@Async
	public String prepareAndSend(MailRequestDTO request) throws BookingEngineException {
		logger.info("EmailUtil : prepareAndSend : Entered ");
		validateRequest(request);
		logger.info("EmailUtil : prepareAndSend : Leaving ");
		return createAndSendMail(request);
	}
	
	/**
	 * Validate request.
	 *
	 * @param request
	 *            the request
	 * @throws BookingEngineException
	 *             the booking engine exception
	 */
	private void validateRequest(MailRequestDTO request) throws BookingEngineException {
		logger.info("EmailUtil : validateRequest : Entered ");
		boolean isRecipientsPresent = false;
		if(!ArrayUtils.isEmpty(request.getTo())) {
			isRecipientsPresent = true;
		}
		
		if(!ArrayUtils.isEmpty(request.getCc())) {
			isRecipientsPresent = true;
		}
		
		if(!ArrayUtils.isEmpty(request.getBcc())) {
			isRecipientsPresent = true;
		}
		if(!isRecipientsPresent) {
		logger.error("EmailUtil : validateRequest : Recipient list is empty. Atleast one email should be present for sending e-mails. ");
		throw new BookingEngineException(MessageConstants.ATLEASE_ONE_RECIPIENT_SHOULD_PRESENT);
		}
		
		if(request.isAttachmentAvailable()) {
			if(CollectionUtils.isEmpty(request.getAttachments())) {
				logger.error("EmailUtil : validateRequest :  Attachment is missing in the reqeust. ");
				throw new BookingEngineException(MessageConstants.ATTACHMENT_IS_MISSING);		
			}
		}
		
		logger.info("EmailUtil : validateRequest : Leaving ");
	}

	/**
	 * Creates the and send mail.
	 *
	 * @param request
	 *            the request
	 * @return the string
	 * @throws BookingEngineException
	 *             the booking engine exception
	 */
	private String createAndSendMail(MailRequestDTO request) throws BookingEngineException {
		logger.info("EmailUtil : CreateAndSendMail : Entered ");
		MimeMessagePreparator messagePreparator = mimeMessage -> {
			MimeMessageHelper messageHelper = new MimeMessageHelper(mimeMessage, true);
			
			if(!StringUtils.isEmpty(request.getSender())) {
				messageHelper.setFrom(request.getSender());
			}
			
			if(!ArrayUtils.isEmpty(request.getTo())) {
				messageHelper.setTo(request.getTo());
			}
			
			if(!ArrayUtils.isEmpty(request.getCc())) {
				messageHelper.setCc(request.getCc());
			}
			
			if(!ArrayUtils.isEmpty(request.getBcc())) {
				messageHelper.setBcc(request.getBcc());
			}
			if(!StringUtils.isEmpty(request.getSubject())) {
				messageHelper.setSubject(request.getSubject());
			}
			String textBody =  null;
			
			if(!StringUtils.isEmpty(request.getTextBody())){
				textBody = request.getTextBody();
			} else if(request.getTemplateAction() != null ) {
				textBody = contentBuilder.build(request.getTemplateAction().getTemplateFile(), request.getData());
			}
			
			if(!StringUtils.isEmpty(textBody)) {
			messageHelper.setText(textBody, true);
			}
			
			logger.info("EmailUtil : CreateAndSendMail : Email body ::::: {}", textBody);
			
			if(request.isAttachmentAvailable()) {
				addAttachment(messageHelper,request.getAttachments());
			}
		};
		String response = null;
		

		if(doSend(messagePreparator))
			response = MessageConstants.SUCCESS;
		else
			response = MessageConstants.FAIL;
		
		logger.info("EmailUtil : CreateAndSendMail : Leaving ");
		return response;
	}

	/**
	 * Adds the attachment.
	 *
	 * @param messageHelper
	 *            the message helper
	 * @param attachments
	 *            the attachments
	 * @throws MessagingException
	 *             the messaging exception
	 */
	private void addAttachment(MimeMessageHelper messageHelper, List<AttachmentReqDTO> attachments) throws MessagingException {
		logger.info("EmailUtil : addAttachment : Entered ");
		String mime = null;
		
		DataSource dataSource = null;
		
		for (AttachmentReqDTO attachment : attachments) {
			
			 mime = new MimetypesFileTypeMap().getContentType(attachment.getFileName());
			 if(!StringUtils.isEmpty(attachment.getMimeType())) {
				 mime = attachment.getMimeType();
			 }
			 dataSource = new ByteArrayDataSource(attachment.getBytes(), mime);
			 messageHelper.addAttachment(attachment.getFileName(), dataSource);
			 
		}
		logger.info("EmailUtil : addAttachment : Leaving ");
	}
	
	/**
	 * Do send.
	 *
	 * @param messagePreparator
	 *            the message preparator
	 * @return true, if successful
	 * @throws MailException
	 *             the mail exception
	 */
	private boolean doSend(MimeMessagePreparator messagePreparator) throws MailException {
		boolean status;
		try {
			javaMailSender.send(messagePreparator);
			logger.info("EmailUtil : prepareAndSendWithAttachment : Leaving ");
			status =  true;
		}
		catch (MailException e) {
			logger.error("EmailUtil : prepareAndSendWithAttachment : Exception : {} ", e);
			status =  false;
		}
		logger.info("EmailUtil : addAttachment : Leaving ");
		return status;
	}
	
}