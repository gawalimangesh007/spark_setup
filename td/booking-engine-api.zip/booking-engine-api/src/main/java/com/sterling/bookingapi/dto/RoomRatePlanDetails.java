package com.sterling.bookingapi.dto;

import com.sterling.bookingapi.utils.BookingEngineUtils;


/**
 * The Class RoomRatePlanDetails.
 */
/**
 * @author tcs
 *
 */
public class RoomRatePlanDetails {

	/** The resort room id. */
	private int resortRoomId;
	
	/** The rate plan id. */
	private String ratePlan; 
	
	/** The rate plan id. */
	private int ratePlanId; 
	
	/** The room Type id. */
	private String roomTypeId;
	
	/** The rate plan detail. */
	private String ratePlanDetail;

	/** The extra person charge. */
	private double extraPersonCharge;
	
	/** The single occupancy rate. */
	private double singleOccupancyRate;
	
	/** The double occupancy rate. */
	private double doubleOccupancyRate;
	
	/** The triple occupancy rate. */
	private double tripleOccupancyRate;
	
	/** The quadruple occupancy rate. */
	private double quadrupleOccupancyRate;
	
	/** The min stay days. */
	private int minStayDays;
	
	/** The max stay days. */
	private int maxStayDays;

	
	/**
	 * Instantiates a new room rate plan details.
	 *
	 * @param resortRoomId the resort room id
	 * @param ratePlan the rate plan
	 * @param ratePlanDetail the rate plan detail
	 * @param extraPersonCharge the extra person charge
	 * @param singleOccupancyRate the single occupancy rate
	 * @param doubleOccupancyRate the double occupancy rate
	 * @param tripleOccupancyRate the triple occupancy rate
	 * @param quadrupleOccupancyRate the quadruple occupancy rate
	 * @param minStayDays the min stay days
	 * @param maxStayDays the max stay days
	 */
	public RoomRatePlanDetails(int resortRoomId, String ratePlan, String ratePlanDetail, double extraPersonCharge, 
			double singleOccupancyRate, double doubleOccupancyRate, double tripleOccupancyRate, double quadrupleOccupancyRate, 
			int minStayDays, int maxStayDays) {
		this.resortRoomId = resortRoomId;
		this.ratePlan = ratePlan;
		this.ratePlanDetail = ratePlanDetail;
		this.extraPersonCharge = BookingEngineUtils.roundDouble(extraPersonCharge, 2);
		this.singleOccupancyRate = BookingEngineUtils.roundDouble(singleOccupancyRate, 2);
		this.doubleOccupancyRate = BookingEngineUtils.roundDouble(doubleOccupancyRate, 2);
		this.tripleOccupancyRate = BookingEngineUtils.roundDouble(tripleOccupancyRate, 2);
		this.quadrupleOccupancyRate = BookingEngineUtils.roundDouble(quadrupleOccupancyRate, 2);
		this.minStayDays = minStayDays;
		this.maxStayDays = maxStayDays;
	}

	/**
	 * Instantiates a new room rate plan details.
	 *
	 * @param resortRoomId the resort room id
	 * @param ratePlan the rate plan
	 * @param ratePlanDetail the rate plan detail
	 * @param extraPersonCharge the extra person charge
	 * @param singleOccupancyRate the single occupancy rate
	 * @param doubleOccupancyRate the double occupancy rate
	 * @param tripleOccupancyRate the triple occupancy rate
	 * @param quadrupleOccupancyRate the quadruple occupancy rate
	 */
	public RoomRatePlanDetails(int resortRoomId, String ratePlan, String ratePlanDetail, double extraPersonCharge, 
			double singleOccupancyRate, double doubleOccupancyRate, double tripleOccupancyRate, double quadrupleOccupancyRate) {
		this.resortRoomId = resortRoomId;
		this.ratePlan = ratePlan;
		this.ratePlanDetail = ratePlanDetail;
		this.extraPersonCharge = BookingEngineUtils.roundDouble(extraPersonCharge, 2);
		this.singleOccupancyRate = BookingEngineUtils.roundDouble(singleOccupancyRate, 2);
		this.doubleOccupancyRate = BookingEngineUtils.roundDouble(doubleOccupancyRate, 2);
		this.tripleOccupancyRate = BookingEngineUtils.roundDouble(tripleOccupancyRate, 2);
		this.quadrupleOccupancyRate = BookingEngineUtils.roundDouble(quadrupleOccupancyRate, 2);
	}
	
	public RoomRatePlanDetails(int resortRoomId, String ratePlan, int ratePlanId, String ratePlanDetail, double extraPersonCharge, 
			double singleOccupancyRate, double doubleOccupancyRate, double tripleOccupancyRate, double quadrupleOccupancyRate) {
		this.resortRoomId = resortRoomId;
		this.ratePlan = ratePlan;
		this.ratePlanId = ratePlanId;
		this.ratePlanDetail = ratePlanDetail;
		this.extraPersonCharge = BookingEngineUtils.roundDouble(extraPersonCharge, 2);
		this.singleOccupancyRate = BookingEngineUtils.roundDouble(singleOccupancyRate, 2);
		this.doubleOccupancyRate = BookingEngineUtils.roundDouble(doubleOccupancyRate, 2);
		this.tripleOccupancyRate = BookingEngineUtils.roundDouble(tripleOccupancyRate, 2);
		this.quadrupleOccupancyRate = BookingEngineUtils.roundDouble(quadrupleOccupancyRate, 2);
	}
	
	public RoomRatePlanDetails(int resortRoomId, String ratePlan, int ratePlanId, String ratePlanDetail, double extraPersonCharge, 
			double singleOccupancyRate, double doubleOccupancyRate, double tripleOccupancyRate, double quadrupleOccupancyRate, String roomTypeId) {
		this.resortRoomId = resortRoomId;
		this.ratePlan = ratePlan;
		this.ratePlanId = ratePlanId;
		this.ratePlanDetail = ratePlanDetail;
		this.extraPersonCharge = BookingEngineUtils.roundDouble(extraPersonCharge, 2);
		this.singleOccupancyRate = BookingEngineUtils.roundDouble(singleOccupancyRate, 2);
		this.doubleOccupancyRate = BookingEngineUtils.roundDouble(doubleOccupancyRate, 2);
		this.tripleOccupancyRate = BookingEngineUtils.roundDouble(tripleOccupancyRate, 2);
		this.quadrupleOccupancyRate = BookingEngineUtils.roundDouble(quadrupleOccupancyRate, 2);
		this.roomTypeId = roomTypeId;
	}
	
	/**
	 * Gets the resort room id.
	 *
	 * @return the resort room id
	 */
	public int getResortRoomId() {
		return resortRoomId;
	}

	/**
	 * Sets the resort room id.
	 *
	 * @param resortRoomId the new resort room id
	 */
	public void setResortRoomId(int resortRoomId) {
		this.resortRoomId = resortRoomId;
	}

	/**
	 * Gets the rate plan.
	 *
	 * @return the rate plan
	 */
	public String getRatePlan() {
		return ratePlan;
	}

	/**
	 * Sets the rate plan.
	 *
	 * @param ratePlan the new rate plan
	 */
	public void setRatePlan(String ratePlan) {
		this.ratePlan = ratePlan;
	}

	/**
	 * Gets the rate plan detail.
	 *
	 * @return the rate plan detail
	 */
	public String getRatePlanDetail() {
		return ratePlanDetail;
	}

	/**
	 * Sets the rate plan detail.
	 *
	 * @param ratePlanDetail the new rate plan detail
	 */
	public void setRatePlanDetail(String ratePlanDetail) {
		this.ratePlanDetail = ratePlanDetail;
	}

	/**
	 * Gets the extra person charge.
	 *
	 * @return the extra person charge
	 */
	public double getExtraPersonCharge() {
		return extraPersonCharge;
	}

	/**
	 * Sets the extra person charge.
	 *
	 * @param extraPersonCharge the new extra person charge
	 */
	public void setExtraPersonCharge(double extraPersonCharge) {
		this.extraPersonCharge = BookingEngineUtils.roundDouble(extraPersonCharge, 2);;
	}

	/**
	 * Gets the double occupancy rate.
	 *
	 * @return the double occupancy rate
	 */
	public double getDoubleOccupancyRate() {
		return doubleOccupancyRate;
	}

	/**
	 * Sets the double occupancy rate.
	 *
	 * @param doubleOccupancyRate the new double occupancy rate
	 */
	public void setDoubleOccupancyRate(double doubleOccupancyRate) {
		this.doubleOccupancyRate = BookingEngineUtils.roundDouble(doubleOccupancyRate, 2);;
	}

	/**
	 * Gets the min stay days.
	 *
	 * @return the min stay days
	 */
	public int getMinStayDays() {
		return minStayDays;
	}

	/**
	 * Sets the min stay days.
	 *
	 * @param minStayDays the new min stay days
	 */
	public void setMinStayDays(int minStayDays) {
		this.minStayDays = minStayDays;
	}

	/**
	 * Gets the max stay days.
	 *
	 * @return the max stay days
	 */
	public int getMaxStayDays() {
		return maxStayDays;
	}

	/**
	 * Sets the max stay days.
	 *
	 * @param maxStayDays the new max stay days
	 */
	public void setMaxStayDays(int maxStayDays) {
		this.maxStayDays = maxStayDays;
	}

	/**
	 * Gets the single occupancy rate.
	 *
	 * @return the single occupancy rate
	 */
	public double getSingleOccupancyRate() {
		return singleOccupancyRate;
	}

	/**
	 * Sets the single occupancy rate.
	 *
	 * @param singleOccupancyRate the new single occupancy rate
	 */
	public void setSingleOccupancyRate(double singleOccupancyRate) {
		this.singleOccupancyRate = singleOccupancyRate;
	}

	/**
	 * Gets the triple occupancy rate.
	 *
	 * @return the triple occupancy rate
	 */
	public double getTripleOccupancyRate() {
		return tripleOccupancyRate;
	}

	/**
	 * Sets the triple occupancy rate.
	 *
	 * @param tripleOccupancyRate the new triple occupancy rate
	 */
	public void setTripleOccupancyRate(double tripleOccupancyRate) {
		this.tripleOccupancyRate = tripleOccupancyRate;
	}

	/**
	 * Gets the quadruple occupancy rate.
	 *
	 * @return the quadruple occupancy rate
	 */
	public double getQuadrupleOccupancyRate() {
		return quadrupleOccupancyRate;
	}

	/**
	 * Sets the quadruple occupancy rate.
	 *
	 * @param quadrupleOccupancyRate the new quadruple occupancy rate
	 */
	public void setQuadrupleOccupancyRate(double quadrupleOccupancyRate) {
		this.quadrupleOccupancyRate = quadrupleOccupancyRate;
	}

	public int getRatePlanId() {
		return ratePlanId;
	}

	public void setRatePlanId(int ratePlanId) {
		this.ratePlanId = ratePlanId;
	}

	public String getRoomTypeId() {
		return roomTypeId;
	}

	public void setRoomTypeId(String roomTypeId) {
		this.roomTypeId = roomTypeId;
	}
	
}
