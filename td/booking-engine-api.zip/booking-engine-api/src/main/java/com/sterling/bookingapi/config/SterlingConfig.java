package com.sterling.bookingapi.config;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.dozer.DozerBeanMapper;
import org.jeasy.rules.api.RulesEngine;
import org.jeasy.rules.core.RulesEngineBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.sterling.bookingapi.engine.SterlingRuleListener;
import com.sterling.bookingapi.utils.AppConstants;
import com.sterling.bookingapi.utils.PropertiesConfig;

/**
 * @author tcs
 *
 */
@Configuration
public class SterlingConfig {

	@Value("${config.location}")
	private String configLocation;

	@Value("${property.filenames}")
	private String[] properties;
	
	@Value("${sf.password.encrypt.key}")
	private String encryptKey;

	/**
	 * @return property config
	 */
	@Bean
	public PropertiesConfig proeprtyConfig() {
		return new PropertiesConfig(configLocation, properties);

	}

	/**
	 * @return  DozerBeanMapper
	 */
	@Bean
	public DozerBeanMapper getBeanMapper() {
		DozerBeanMapper beanMapper = new DozerBeanMapper();
		List<String> mappingFileUrls = new ArrayList<>();
		mappingFileUrls.add("dozer-mapping.xml");
		beanMapper.setMappingFiles(mappingFileUrls );
		
		return beanMapper;
	}

	@Bean
	public RulesEngine getRulesEngine() {
		RulesEngine rulesEngine = RulesEngineBuilder.aNewRulesEngine()
//			    .withRulePriorityThreshold(10)
//			    .withSkipOnFirstAppliedRule(true)
//			    .withSkipOnFirstFailedRule(true)
//			    .withSkipOnFirstNonTriggeredRule(true)
//			    .withSilentMode(false)
			    .withRuleListener(new SterlingRuleListener())
			    .build();
		return rulesEngine;
	}
	
	 @PostConstruct
	 public void init() {
	        AppConstants.PASSWORD_ENCRYPT_KEY = encryptKey;
	 }
}
