package com.sterling.bookingapi.dto.maximojo.request;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class StateProvReqDTO.
 */
/**
 * @author tcs
 *
 */
public class StateProvReqDTO {

	/** The state code. */
	@JacksonXmlProperty(localName = "StateCode", isAttribute = true)
	private String stateCode;

	/**
	 * Gets the state code.
	 *
	 * @return the stateCode
	 */
	public String getStateCode() {
		return stateCode;
	}

	/**
	 * Sets the state code.
	 *
	 * @param stateCode the stateCode to set
	 */
	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}
	
	
}
