package com.sterling.bookingapi.engine.rules;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.BooleanUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;

import com.sterling.bookingapi.dto.request.VOConfirmBookingRequest;
import com.sterling.bookingapi.dto.response.VODashboardResponse;
import com.sterling.bookingapi.engine.rules.models.BookingRule;
import com.sterling.bookingapi.engine.rules.models.VOBookingRuleDTO;
import com.sterling.bookingapi.utils.BookingEngineUtils;


@Rule(name = "minPointRule", description = "MIN_POINT_RULE")
public class MinimumPointsRule {

	private static final Logger logger = LogManager.getLogger(MinimumPointsRule.class);

	
	@Condition
	public boolean when(@Fact("bookingRequest") VOConfirmBookingRequest req, 
			@Fact("productRules") Map<String, List<VOBookingRuleDTO>> rulesMap,
			@Fact("memberDetail") VODashboardResponse memberDetail,
		@Fact("bookingSeasons") Set<String> bookingSeason) {
		//my rule conditions
		
		List<VOBookingRuleDTO> ruleList = rulesMap.get(BookingRule.MIN_POINT_RULE.getRuleName());
		
		//Season bookingSeason = null;//Season.getByName(req.getSeasonCode());
		Double purchasedPoints = memberDetail.getMembershipDetails().getPointsPurchased();

		for (VOBookingRuleDTO rule : ruleList) {
			if (BooleanUtils.isTrue(rule.getActive())) {
				if (BookingEngineUtils.havingAnySeason(bookingSeason,
						rule.getApplicableSeasons())) {
					double confMinPoints = Double.parseDouble(rule
							.getParameters().get(0).getValue()); //minpoints
					if (purchasedPoints != null
							&& confMinPoints > purchasedPoints.doubleValue()) {
						return false;//failed
					}

				}
			}
		}
		
		logger.info("################# excecuting condition " + req.getCheckInDate());
		return true;
	}

	@Action(order = 1)
	public void then() throws Exception {
		//my actions
		logger.info("################# excecuting action");
	}
}
