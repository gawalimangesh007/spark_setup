package com.sterling.bookingapi.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.sterling.bookingapi.utils.AppConstants;


/**
 * The Class HsdOffersAndPromosConditionsMaster.
 */
/**
 * @author tcs
 *
 */
@Entity
@Table(name = "sh_hsd_conditions_master")//delete
public class HsdOffersAndPromosConditionsMaster extends BaseModel{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@GeneratedValue( strategy = GenerationType.IDENTITY )
	@Column(name = "condition_id", unique = true)
	private int id;
	
	/** The condition code. */
	@Column(name = "condition_code",nullable = true)
	private String conditionCode;
	
	/** The condition name. */
	@Column(name = "condition_name",nullable = false)
	private String conditionName;
	
	/** The condition data type. */
	@Column(name = "condition_datatype",nullable = false)
	private String conditionDataType;

	/** The condition type. */
	@Enumerated(value=EnumType.STRING)
	@Column(name = "condition_type",nullable = false)
	private AppConstants.Type conditionType;
	
	/** The details. */
	@Column(name = "details")
	private String details;
	
	/** The active. */
	@Column(name = "is_active")
	private boolean active = true;

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * Gets the condition code.
	 *
	 * @return the condition code
	 */
	public String getConditionCode() {
		return conditionCode;
	}

	/**
	 * Sets the condition code.
	 *
	 * @param conditionCode the new condition code
	 */
	public void setConditionCode(String conditionCode) {
		this.conditionCode = conditionCode;
	}

	/**
	 * Gets the condition name.
	 *
	 * @return the condition name
	 */
	public String getConditionName() {
		return conditionName;
	}

	/**
	 * Sets the condition name.
	 *
	 * @param conditionName the new condition name
	 */
	public void setConditionName(String conditionName) {
		this.conditionName = conditionName;
	}

	/**
	 * Gets the condition data type.
	 *
	 * @return the condition data type
	 */
	public String getConditionDataType() {
		return conditionDataType;
	}

	/**
	 * Sets the condition data type.
	 *
	 * @param conditionDataType the new condition data type
	 */
	public void setConditionDataType(String conditionDataType) {
		this.conditionDataType = conditionDataType;
	}


	/**
	 * Gets the condition type.
	 *
	 * @return the condition type
	 */
	public AppConstants.Type getConditionType() {
		return conditionType;
	}

	/**
	 * Sets the condition type.
	 *
	 * @param conditionType the new condition type
	 */
	public void setConditionType(AppConstants.Type conditionType) {
		this.conditionType = conditionType;
	}

	/**
	 * Gets the details.
	 *
	 * @return the details
	 */
	public String getDetails() {
		return details;
	}

	/**
	 * Sets the details.
	 *
	 * @param details the new details
	 */
	public void setDetails(String details) {
		this.details = details;
	}

	/**
	 * Checks if is active.
	 *
	 * @return true, if is active
	 */
	public boolean isActive() {
		return active;
	}

	/**
	 * Sets the active.
	 *
	 * @param active the new active
	 */
	public void setActive(boolean active) {
		this.active = active;
	}
	
	
}
