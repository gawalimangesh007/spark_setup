package com.sterling.bookingapi.dto.response;

import java.io.Serializable;

public class VOServiceTaxResDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String taxId;
	private Double serviceTax;
	
	public String getTaxId() {
		return taxId;
	}
	public void setTaxId(String taxId) {
		this.taxId = taxId;
	}
	public Double getServiceTax() {
		return serviceTax;
	}
	public void setServiceTax(Double serviceTax) {
		this.serviceTax = serviceTax;
	}
	
}
