package com.sterling.bookingapi.dto.request;

public class HsdRatePlanUpdateDTO {
	
	private String ratePlan;
	private String ratePlanDescription;
	
	public String getRatePlan() {
		return ratePlan;
	}
	public void setRatePlan(String ratePlan) {
		this.ratePlan = ratePlan;
	}
	public String getRatePlanDescription() {
		return ratePlanDescription;
	}
	public void setRatePlanDescription(String ratePlanDescription) {
		this.ratePlanDescription = ratePlanDescription;
	}
}
