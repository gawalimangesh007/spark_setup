package com.sterling.bookingapi.dto.request;


/**
 * The Class HsdBookingRoomsRequestDTO.
 */
/**
 * @author tcs
 *
 */
public class HsdBookingRoomsRequestDTO {
	
	/** The first name. */
	private String firstName;
	
	/** The last name. */
	private String lastName;
	
	/** The email id. */
	private String emailId;
	
	/** The mobile no. */
	private String mobileNo;
	
	/** The type of stay. */
	private String typeOfStay;
	
	/** The room rent. */
	private double roomRent;
	
	/** The room type id. */
	private String roomTypeId;
	
	/** The rate plan. */
	private String ratePlan;
	
	/** The room count. */
	private int roomCount;
	
	/** The adult count. */
	private int adultCount;
	
	/** The child count. */
	private int childCount;
	
	/** The extra person child count. */
	private int extraPersonChildCount;
	
	/** The extra person adult count. */
	private int extraPersonAdultCount;
	
	/** The extra person child cost. */
	private double extraPersonChildCost;
	
	/** The extra person adult cost. */
	private double extraPersonAdultCost;
	
	
	/** The roomUpgrade cost. */
	private double roomUpgradeCost;
	
	/** The roomUpgrade cost summary. */
	private String roomUpgradeCostSummary;
	
	/** The tax details. */
	private Object taxDetails;
	
	/**
	 * Gets the first name.
	 *
	 * @return the first name
	 */
	public String getFirstName() {
		return firstName;
	}
	
	/**
	 * Sets the first name.
	 *
	 * @param firstName the new first name
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	/**
	 * Gets the last name.
	 *
	 * @return the last name
	 */
	public String getLastName() {
		return lastName;
	}
	
	/**
	 * Sets the last name.
	 *
	 * @param lastName the new last name
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	/**
	 * Gets the email id.
	 *
	 * @return the email id
	 */
	public String getEmailId() {
		return emailId;
	}
	
	/**
	 * Sets the email id.
	 *
	 * @param emailId the new email id
	 */
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	
	/**
	 * Gets the mobile no.
	 *
	 * @return the mobile no
	 */
	public String getMobileNo() {
		return mobileNo;
	}
	
	/**
	 * Sets the mobile no.
	 *
	 * @param mobileNo the new mobile no
	 */
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	
	/**
	 * Gets the type of stay.
	 *
	 * @return the type of stay
	 */
	public String getTypeOfStay() {
		return typeOfStay;
	}
	
	/**
	 * Sets the type of stay.
	 *
	 * @param typeOfStay the new type of stay
	 */
	public void setTypeOfStay(String typeOfStay) {
		this.typeOfStay = typeOfStay;
	}
	
	/**
	 * Gets the room rent.
	 *
	 * @return the room rent
	 */
	public double getRoomRent() {
		return roomRent;
	}
	
	/**
	 * Sets the room rent.
	 *
	 * @param roomRent the new room rent
	 */
	public void setRoomRent(double roomRent) {
		this.roomRent = roomRent;
	}
	
	/**
	 * Gets the room type id.
	 *
	 * @return the room type id
	 */
	public String getRoomTypeId() {
		return roomTypeId;
	}
	
	/**
	 * Sets the room type id.
	 *
	 * @param roomTypeId the new room type id
	 */
	public void setRoomTypeId(String roomTypeId) {
		this.roomTypeId = roomTypeId;
	}
	
	/**
	 * Gets the rate plan.
	 *
	 * @return the rate plan
	 */
	public String getRatePlan() {
		return ratePlan;
	}
	
	/**
	 * Sets the rate plan.
	 *
	 * @param ratePlan the new rate plan
	 */
	public void setRatePlan(String ratePlan) {
		this.ratePlan = ratePlan;
	}
	
	/**
	 * Gets the room count.
	 *
	 * @return the room count
	 */
	public int getRoomCount() {
		return roomCount;
	}
	
	/**
	 * Sets the room count.
	 *
	 * @param roomCount the new room count
	 */
	public void setRoomCount(int roomCount) {
		this.roomCount = roomCount;
	}
	
	/**
	 * Gets the adult count.
	 *
	 * @return the adult count
	 */
	public int getAdultCount() {
		return adultCount;
	}
	
	/**
	 * Sets the adult count.
	 *
	 * @param adultCount the new adult count
	 */
	public void setAdultCount(int adultCount) {
		this.adultCount = adultCount;
	}
	
	/**
	 * Gets the child count.
	 *
	 * @return the child count
	 */
	public int getChildCount() {
		return childCount;
	}
	
	/**
	 * Sets the child count.
	 *
	 * @param childCount the new child count
	 */
	public void setChildCount(int childCount) {
		this.childCount = childCount;
	}
	
	/**
	 * Gets the extra person child count.
	 *
	 * @return the extra person child count
	 */
	public int getExtraPersonChildCount() {
		return extraPersonChildCount;
	}
	
	/**
	 * Sets the extra person child count.
	 *
	 * @param extraPersonChildCount the new extra person child count
	 */
	public void setExtraPersonChildCount(int extraPersonChildCount) {
		this.extraPersonChildCount = extraPersonChildCount;
	}
	
	/**
	 * Gets the extra person adult count.
	 *
	 * @return the extra person adult count
	 */
	public int getExtraPersonAdultCount() {
		return extraPersonAdultCount;
	}
	
	/**
	 * Sets the extra person adult count.
	 *
	 * @param extraPersonAdultCount the new extra person adult count
	 */
	public void setExtraPersonAdultCount(int extraPersonAdultCount) {
		this.extraPersonAdultCount = extraPersonAdultCount;
	}
	
	/**
	 * Gets the extra person child cost.
	 *
	 * @return the extra person child cost
	 */
	public double getExtraPersonChildCost() {
		return extraPersonChildCost;
	}
	
	/**
	 * Sets the extra person child cost.
	 *
	 * @param extraPersonChildCost the new extra person child cost
	 */
	public void setExtraPersonChildCost(double extraPersonChildCost) {
		this.extraPersonChildCost = extraPersonChildCost;
	}
	
	/**
	 * Gets the extra person adult cost.
	 *
	 * @return the extra person adult cost
	 */
	public double getExtraPersonAdultCost() {
		return extraPersonAdultCost;
	}
	
	/**
	 * Sets the extra person adult cost.
	 *
	 * @param extraPersonAdultCost the new extra person adult cost
	 */
	public void setExtraPersonAdultCost(double extraPersonAdultCost) {
		this.extraPersonAdultCost = extraPersonAdultCost;
	}

	public double getRoomUpgradeCost() {
		return roomUpgradeCost;
	}

	public void setRoomUpgradeCost(double roomUpgradeCost) {
		this.roomUpgradeCost = roomUpgradeCost;
	}

	public String getRoomUpgradeCostSummary() {
		return roomUpgradeCostSummary;
	}

	public void setRoomUpgradeCostSummary(String roomUpgradeCostSummary) {
		this.roomUpgradeCostSummary = roomUpgradeCostSummary;
	}

	public Object getTaxDetails() {
		return taxDetails;
	}

	public void setTaxDetails(Object taxDetails) {
		this.taxDetails = taxDetails;
	}
	
}