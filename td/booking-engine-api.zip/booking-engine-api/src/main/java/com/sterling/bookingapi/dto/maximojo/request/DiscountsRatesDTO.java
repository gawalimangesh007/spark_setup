package com.sterling.bookingapi.dto.maximojo.request;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

public class DiscountsRatesDTO {
	
	@JacksonXmlProperty(localName = "DiscountType", isAttribute = true)
    private String discountType;
	
	@JacksonXmlProperty(localName = "DiscountValue", isAttribute = true)
    private String discountValue;
	
	@JacksonXmlProperty(localName = "DiscountedAmount", isAttribute = true)
    private double discountedAmount;

	@JacksonXmlProperty(localName = "CurrencyCode", isAttribute = true)
    private String currencyCode;

	/**
	 * @return the discountType
	 */
	public String getDiscountType() {
		return discountType;
	}

	/**
	 * @param discountType the discountType to set
	 */
	public void setDiscountType(String discountType) {
		this.discountType = discountType;
	}

	/**
	 * @return the discountValue
	 */
	public String getDiscountValue() {
		return discountValue;
	}

	/**
	 * @param discountValue the discountValue to set
	 */
	public void setDiscountValue(String discountValue) {
		this.discountValue = discountValue;
	}

	/**
	 * @return the discountedAmount
	 */
	public double getDiscountedAmount() {
		return discountedAmount;
	}

	/**
	 * @param discountedAmount the discountedAmount to set
	 */
	public void setDiscountedAmount(double discountedAmount) {
		this.discountedAmount = discountedAmount;
	}

	/**
	 * @return the currencyCode
	 */
	public String getCurrencyCode() {
		return currencyCode;
	}

	/**
	 * @param currencyCode the currencyCode to set
	 */
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

}
