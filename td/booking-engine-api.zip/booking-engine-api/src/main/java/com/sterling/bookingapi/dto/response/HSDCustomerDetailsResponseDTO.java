package com.sterling.bookingapi.dto.response;

import java.io.Serializable;

/**
 * @author tcs
 * @version 1.0
 */
public class HSDCustomerDetailsResponseDTO extends BaseRecord implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private String id;
	private String firstName;
	private String lastName;
	private String title;
	private String interestDetails;
	private String travellerInfo;
	private boolean marketEmailOption;
	private boolean marketPhoneOption;
	private String profileImage;
	private String dateOfBirth;
	private String mobileNo;
	private String gender;
	private String emailId;
	private transient  AdditionalInformationDTO additionalInformation;
	private boolean mailFlag;
	
	
	public boolean getMailFlag() {
		return mailFlag;
	}
	public void setMailFlag(boolean mailFlag) {
		this.mailFlag = mailFlag;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	/**
	 * @return id
	 */
	public String getId() {
		return id;
	}
	/**
	 * @param id
	 * set the id
	 */
	public void setId(String id) {
		this.id = id;
	}
	/**
	 * @return firstName
	 */
	public String getFirstName() {
		return firstName;
	}
	/**
	 * @param firstName
	 * set the firstName
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	/**
	 * @return lastName
	 */
	public String getLastName() {
		return lastName;
	}
	/**
	 * @param lastName
	 * set the lastName
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	/**
	 * @return title
	 */
	public String getTitle() {
		return title;
	}
	/**
	 * @param title
	 * set the title
	 */
	public void setTitle(String title) {
		this.title = title;
	}
	/**
	 * @return profileImage
	 */
	public String getProfileImage() {
		return profileImage;
	}
	/**
	 * @param profileImage
	 * set the profileImage
	 */
	public void setProfileImage(String profileImage) {
		this.profileImage = profileImage;
	}
	/**
	 * @return dateOfBirth
	 */
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	/**
	 * @param dateOfBirth
	 * set the dateOfBirth
	 */
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	/**
	 * @return mobileNo
	 */
	public String getMobileNo() {
		return mobileNo;
	}
	/**
	 * @param mobileNo
	 * set the mobileNo
	 */
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	/**
	 * @return gender
	 */
	public String getGender() {
		return gender;
	}
	/**
	 * @param gender
	 * set the gender
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}
	/**
	 * @return additionalInformation
	 */
	public AdditionalInformationDTO getAdditionalInformation() {
		return additionalInformation;
	}
	/**
	 * @param additionalInformation
	 * set the additionalInformation
	 */
	public void setAdditionalInformation(
			AdditionalInformationDTO additionalInformation) {
		this.additionalInformation = additionalInformation;
	}
	public String getInterestDetails() {
		return interestDetails;
	}
	public void setInterestDetails(String interestDetails) {
		this.interestDetails = interestDetails;
	}
	public String getTravellerInfo() {
		return travellerInfo;
	}
	public void setTravellerInfo(String travellerInfo) {
		this.travellerInfo = travellerInfo;
	}
	public boolean isMarketEmailOption() {
		return marketEmailOption;
	}
	public void setMarketEmailOption(boolean marketEmailOption) {
		this.marketEmailOption = marketEmailOption;
	}
	public boolean isMarketPhoneOption() {
		return marketPhoneOption;
	}
	public void setMarketPhoneOption(boolean marketPhoneOption) {
		this.marketPhoneOption = marketPhoneOption;
	}
}
