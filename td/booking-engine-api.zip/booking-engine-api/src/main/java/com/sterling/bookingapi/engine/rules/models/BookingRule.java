package com.sterling.bookingapi.engine.rules.models;

public enum BookingRule {

	MIN_POINT_RULE("minPointRule"),
	MIN_NIGHT_RULE("minNignts"), 
	VACATION_HOLIDAY_RULE("vacationholidays"),
	NATIONAL_HOLIDAY_RULE("nationalholidays"),
	
	PURPLE_TRAVEL_RULE("purpleTravel"), 
	RED_TRAVEL_RULE("redTravel"),
	WHITE_TRAVEL_RULE("whiteTravel"),
	BLUE_TRAVEL_RULE("blueTravel"),

	BLUE_PRIOR_TRAVEL_RULE("bluelowToHighTravel"),
	WHITE_PRIOR_TRAVEL_RULE("whitelowToHighTravel"),

	MIN_NIGHT_POINTS_RULE("minNightsPoint"),
	MIN_VACATION_RULE("minVacation"),
	MIN_VACATION_GUEST_RULE("guestminVacation"),
	MIN_VACATION_GUEST_YR_RULE("guestminVacationYear"),
	MAX_BOOK_IN_YEAR_RULE("maxBookYear"),//Same DR rule
	MAX_UTILIZATION_RULE("maxUtil"),

	ADVANCE_FACILITY_RULE("advanceFacility"),
	
	BOOKING_WINDOW_RULE("bookingWindow");
	
	
	private String ruleName;
	
	private BookingRule(String ruleName) {
		this.ruleName = ruleName;
	}
	
	public String getRuleName() {
		return ruleName;
	}
	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}

	public static BookingRule getByName(String ruleName) {
		BookingRule bookingRule = null;
		if(ruleName != null) {
			for (BookingRule br : BookingRule.values()) {
				if(br.getRuleName().equalsIgnoreCase(ruleName)) {
					bookingRule = br;
					break;
				}
			}
		}
		return bookingRule;
	}
	
}
