package com.sterling.bookingapi.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;


/**
 * The Class HsdOffersAndPromosConditionsMapping.
 */
/**
 * @author tcs
 *
 */
@Entity
@Table(name = "sh_hsd_offer_promo_conditions")//delete
public class HsdOffersAndPromosConditionsMapping extends BaseModel{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@GeneratedValue( strategy = GenerationType.IDENTITY )
	@Column(name = "pk_idx_id", unique = true)
	private int id;
	
	/** The condition value. */
	@Column(name = "condition_value",nullable = false)
	private String conditionValue;
	
	/** The details. */
	@Column(name = "details",nullable = true)
	private String details;
	
	/** The active. */
	@Column(name = "status",nullable = true)
	private boolean active = true;
	
	/** The condition name. */
	@Column(name = "condition_name")
	private String conditionName;

	/** The hsd offers and promos conditions master. */
	@ManyToOne(optional = false)
	@Cascade(CascadeType.SAVE_UPDATE)
	@JoinColumn(name="condition_id",nullable = false)
	private HsdOffersAndPromosConditionsMaster hsdOffersAndPromosConditionsMaster;
	
	/** The hsd offers and promos. */
	@ManyToOne(optional = false)
	@Cascade(CascadeType.SAVE_UPDATE)
	@JoinColumn(name="offer_promo_id",nullable = false)
	private HsdOffersAndPromos hsdOffersAndPromos;
	
	/**
	 * Gets the hsd offers and promos conditions master.
	 *
	 * @return the hsdOffersAndPromosConditionsMaster
	 */
	public HsdOffersAndPromosConditionsMaster getHsdOffersAndPromosConditionsMaster() {
		return hsdOffersAndPromosConditionsMaster;
	}

	/**
	 * Sets the hsd offers and promos conditions master.
	 *
	 * @param hsdOffersAndPromosConditionsMaster the hsdOffersAndPromosConditionsMaster to set
	 */
	public void setHsdOffersAndPromosConditionsMaster(
			HsdOffersAndPromosConditionsMaster hsdOffersAndPromosConditionsMaster) {
		this.hsdOffersAndPromosConditionsMaster = hsdOffersAndPromosConditionsMaster;
	}

	/**
	 * Gets the hsd offers and promos.
	 *
	 * @return the hsdOffersAndPromos
	 */
	public HsdOffersAndPromos getHsdOffersAndPromos() {
		return hsdOffersAndPromos;
	}

	/**
	 * Sets the hsd offers and promos.
	 *
	 * @param hsdOffersAndPromos the hsdOffersAndPromos to set
	 */
	public void setHsdOffersAndPromos(HsdOffersAndPromos hsdOffersAndPromos) {
		this.hsdOffersAndPromos = hsdOffersAndPromos;
	}

	/**
	 * Gets the condition value.
	 *
	 * @return the conditionValue
	 */
	public String getConditionValue() {
		return conditionValue;
	}

	/**
	 * Sets the condition value.
	 *
	 * @param conditionValue the conditionValue to set
	 */
	public void setConditionValue(String conditionValue) {
		this.conditionValue = conditionValue;
	}

	/**
	 * Gets the details.
	 *
	 * @return the details
	 */
	public String getDetails() {
		return details;
	}

	/**
	 * Sets the details.
	 *
	 * @param details the details to set
	 */
	public void setDetails(String details) {
		this.details = details;
	}



	/**
	 * Checks if is active.
	 *
	 * @return true, if is active
	 */
	public boolean isActive() {
		return active;
	}

	/**
	 * Sets the active.
	 *
	 * @param active the new active
	 */
	public void setActive(boolean active) {
		this.active = active;
	}

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * Gets the condition name.
	 *
	 * @return the condition name
	 */
	public String getConditionName() {
		return conditionName;
	}

	/**
	 * Sets the condition name.
	 *
	 * @param conditionName the new condition name
	 */
	public void setConditionName(String conditionName) {
		this.conditionName = conditionName;
	}

	
	
}
