package com.sterling.bookingapi.dto.response;

/**
 * @author tcs
 * @version 1.0
 */
public class ResortAvailabilityInfoDTO {

	/** The room type id. */
	private String roomTypeId;

	/** The total room count. */
	private int totalRoomCount;

	/** The available rooms. */
	private int availableRooms;

	/** The current rate. */
	private Double currentRate;

	/** The bar rate. */
	private Double barRate;

	/** The active. */
	private boolean active;

	/**
	 * Gets the room type id.
	 *
	 * @return the room type id
	 */
	public String getRoomTypeId() {
		return roomTypeId;
	}

	/**
	 * Sets the room type id.
	 *
	 * @param roomTypeId the new room type id
	 */
	public void setRoomTypeId(String roomTypeId) {
		this.roomTypeId = roomTypeId;
	}

	/**
	 * Gets the total room count.
	 *
	 * @return the total room count
	 */
	public int getTotalRoomCount() {
		return totalRoomCount;
	}

	/**
	 * Sets the total room count.
	 *
	 * @param totalRoomCount the new total room count
	 */
	public void setTotalRoomCount(int totalRoomCount) {
		this.totalRoomCount = totalRoomCount;
	}

	/**
	 * Gets the available rooms.
	 *
	 * @return the available rooms
	 */
	public int getAvailableRooms() {
		return availableRooms;
	}

	/**
	 * Sets the available rooms.
	 *
	 * @param availableRooms the new available rooms
	 */
	public void setAvailableRooms(int availableRooms) {
		this.availableRooms = availableRooms;
	}

	/**
	 * Gets the current rate.
	 *
	 * @return the current rate
	 */
	public Double getCurrentRate() {
		return currentRate;
	}

	/**
	 * Sets the current rate.
	 *
	 * @param currentRate the new current rate
	 */
	public void setCurrentRate(Double currentRate) {
		this.currentRate = currentRate;
	}

	/**
	 * Gets the bar rate.
	 *
	 * @return the bar rate
	 */
	public Double getBarRate() {
		return barRate;
	}

	/**
	 * Sets the bar rate.
	 *
	 * @param barRate the new bar rate
	 */
	public void setBarRate(Double barRate) {
		this.barRate = barRate;
	}

	/**
	 * Checks if is active.
	 *
	 * @return true, if is active
	 */
	public boolean isActive() {
		return active;
	}

	/**
	 * Sets the active.
	 *
	 * @param active the new active
	 */
	public void setActive(boolean active) {
		this.active = active;
	}

}
