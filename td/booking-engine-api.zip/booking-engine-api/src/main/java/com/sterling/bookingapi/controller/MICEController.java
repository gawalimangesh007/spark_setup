package com.sterling.bookingapi.controller;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.sterling.bookingapi.dto.request.MiceRegisterRequestDTO;
import com.sterling.bookingapi.dto.response.ResponseDTO;
import com.sterling.bookingapi.exception.SalesForceException;
import com.sterling.bookingapi.service.MiceService;
import com.sterling.bookingapi.utils.ResponseUtility;


@RestController
@RequestMapping(value = "/mice")
public class MICEController extends BaseController {
	
	@Autowired
	private MiceService miceService;
	
	/** The Constant logger. */
	private static final Logger logger = LogManager.getLogger(MICEController.class);

	
	/**
	 * @param MiceService
	 * set the MiceService
	 */
	public void setMiceServiceService(
			MiceService miceService) {
		this.miceService = miceService;
	}

	
	@RequestMapping(value = "/register", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO MICERegister(@RequestBody @Valid MiceRegisterRequestDTO req) throws SalesForceException {
		logger.info("MICEController : MICERegister : Entered.");
		ResponseEntity<?> res = miceService.miceRegister(req);
		logger.info("MICEController : MICERegister : Leaving.");
		return ResponseUtility.constructSuccessRes(res.getBody());
	}
	
}
