package com.sterling.bookingapi.engine.rules.models;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ProductRuleDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	@JsonProperty("productId")
	private String productIds;
	private String productName;
	private String productType;

	private List<PointsTable> pointsTable;
	private List<VOBookingRuleDTO> rules;


	public String getProductIds() {
		return productIds;
	}

	public void setProductIds(String productIds) {
		this.productIds = productIds;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public List<VOBookingRuleDTO> getRules() {
		return rules;
	}

	public void setRules(List<VOBookingRuleDTO> rules) {
		this.rules = rules;
	}

	public List<PointsTable> getPointsTable() {
		return pointsTable;
	}

	public void setPointsTable(List<PointsTable> pointsTable) {
		this.pointsTable = pointsTable;
	}
	

	/*
{

    "rules": [
      {
        "ruleId": "rule1",
        "ruleDescription": "",
        "ruleName": "minPointRule",
        "onFailureMsg": "",
        "active": false,
        "applicableSeasons": {
          "purple": false,
          "red": false,
          "blue": false,
          "white": false
        },
        "parameters": [
          {
            "parameter": "minpoints",
            "value": ""
          }
        ]
      },
      {
        "ruleId": "rule2",
        "ruleDescription": "",
        "ruleName": "minNignts",
        "onFailureMsg": "",
        "active": false,
        "applicableSeasons": {
          "purple": false,
          "red": false,
          "blue": false,
          "white": false
        },
        "parameters": [
          {
            "parameter": "minNignts",
            "value": ""
          }
        ]
      },
      {
        "ruleId": "rule3",
        "ruleDescription": "",
        "ruleName": "minNightsPoint",
        "onFailureMsg": "",
        "active": false,
        "applicableSeasons": {
          "purple": false,
          "red": false,
          "blue": false,
          "white": false
        },
        "parameters": [
          {
            "parameter": "minNightsPoint",
            "value": ""
          }
        ]
      },
      {
        "ruleId": "rule4",
        "ruleDescription": "",
        "ruleName": "purpleTravel",
        "onFailureMsg": "",
        "active": false,
        "applicableSeasons": {
          "purple": false,
          "red": false,
          "blue": false,
          "white": false
        },
        "parameters": [
          {
            "parameter": "purpleTravel",
            "value": "null"
          }
        ]
      },
      {
        "ruleId": "rule5",
        "ruleDescription": "",
        "ruleName": "blueTravel",
        "onFailureMsg": "",
        "active": false,
        "applicableSeasons": {
          "purple": false,
          "red": false,
          "blue": false,
          "white": false
        },
        "parameters": [
          {
            "parameter": "blueTravel",
            "value": "null"
          }
        ]
      },
      {
        "ruleId": "rule6",
        "ruleDescription": "",
        "ruleName": "whiteTravel",
        "onFailureMsg": "",
        "active": false,
        "applicableSeasons": {
          "purple": false,
          "red": false,
          "blue": false,
          "white": false
        },
        "parameters": [
          {
            "parameter": "whiteTravel",
            "value": "null"
          }
        ]
      },
      {
        "ruleId": "rule7",
        "ruleDescription": "",
        "ruleName": "redTravel",
        "onFailureMsg": "",
        "active": false,
        "applicableSeasons": {
          "purple": false,
          "red": false,
          "blue": false,
          "white": false
        },
        "parameters": [
          {
            "parameter": "redTravel",
            "value": "null"
          }
        ]
      },
      {
        "ruleId": "rule8",
        "ruleDescription": "",
        "ruleName": "minVacation",
        "onFailureMsg": "",
        "active": false,
        "applicableSeasons": {
          "purple": false,
          "red": false,
          "blue": false,
          "white": false
        },
        "parameters": [
          {
            "parameter": "minVacation",
            "value": ""
          },
          {
            "parameter": "duringSeason",
            "value": ""
          }
        ]
      },
      {
        "ruleId": "rule1",
        "ruleDescription": "",
        "ruleName": "maxBookYear",
        "onFailureMsg": "",
        "active": false,
        "applicableSeasons": {
          "purple": false,
          "red": false,
          "blue": false,
          "white": false
        },
        "parameters": [
          {
            "parameter": "maxBookYear",
            "value": ""
          }
        ]
      },
      {
        "ruleId": "rule9",
        "ruleDescription": "",
        "ruleName": "maxUtil",
        "onFailureMsg": "",
        "active": false,
        "applicableSeasons": {
          "purple": false,
          "red": false,
          "blue": false,
          "white": false
        },
        "parameters": [
          {
            "parameter": "maxUtil",
            "value": ""
          }
        ]
      },
      {
        "ruleId": "rule10",
        "ruleDescription": "",
        "ruleName": "bookingWindow",
        "onFailureMsg": "",
        "active": false,
        "applicableSeasons": {
          "purple": false,
          "red": false,
          "blue": false,
          "white": false
        },
        "parameters": [
          {
            "parameter": "bookingWindow",
            "value": ""
          }
        ]
      },
      {
        "ruleId": "rule11",
        "ruleDescription": "",
        "ruleName": "advanceFacility",
        "onFailureMsg": "",
        "active": false,
        "applicableSeasons": {
          "purple": false,
          "red": false,
          "blue": false,
          "white": false
        },
        "parameters": [
          {
            "parameter": "advanceFacility",
            "value": ""
          }
        ]
      }
    ]
  }*/

}
