package com.sterling.bookingapi.dto.response;


/**
 * @author tcs
 * @version 1.0
 */
public class HsdPackageResortResDTO {
	
	
	/** The resort id. */
	private String resortId;
	
	/** The room type id. */
	private String roomTypeId;
	
	
	/**
	 * Instantiates a new hsd package resort res DTO.
	 *
	 * @param resortId the resort id
	 * @param roomTypeId the room type id
	 */
	public HsdPackageResortResDTO(String resortId, String roomTypeId) {
		this.resortId = resortId;
		this.roomTypeId = roomTypeId;
	}
	
	/**
	 * Instantiates a new hsd package resort res DTO.
	 */
	public HsdPackageResortResDTO(){
		super();
	}


	
}
