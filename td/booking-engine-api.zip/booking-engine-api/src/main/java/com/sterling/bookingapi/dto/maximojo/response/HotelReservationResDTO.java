package com.sterling.bookingapi.dto.maximojo.response;

import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class HotelReservationResDTO.
 * @author tcs
 * @version 1.0
 */
public class HotelReservationResDTO {

	/** The create date time. */
	@JacksonXmlProperty(localName = "CreateDateTime", isAttribute = true)
	private String createDateTime;
	
	/** The res status. */
	@JacksonXmlProperty(localName = "ResStatus", isAttribute = true)
    private String resStatus;

	/** The res global info. */
	@JacksonXmlProperty(localName = "ResGlobalInfo")
    private ResGlobalInfoResDTO resGlobalInfo;

	/** The res guest. */
	@JacksonXmlElementWrapper(useWrapping=true, localName = "ResGuests")
	@JacksonXmlProperty(localName = "ResGuest")
    private List<ResGuestResDTO> resGuest;

	/** The unique ID. */
	@JacksonXmlProperty(localName = "UniqueID")
    private UniqueIDResDTO uniqueID;

	/** The pos. */
	@JacksonXmlProperty(localName = "POS")
    private POSResDTO POS;

	/** The room stay. */
	@JacksonXmlElementWrapper(useWrapping=true, localName = "RoomStays")
	@JacksonXmlProperty(localName = "RoomStay")
    private List<RoomStayResDTO> roomStay;

	

	/**
	 * Gets the creates the date time.
	 *
	 * @return the createDateTime
	 */
	public String getCreateDateTime() {
		return createDateTime;
	}

	/**
	 * Sets the creates the date time.
	 *
	 * @param createDateTime the createDateTime to set
	 */
	public void setCreateDateTime(String createDateTime) {
		this.createDateTime = createDateTime;
	}

	/**
	 * Gets the res global info.
	 *
	 * @return the resGlobalInfo
	 */
	public ResGlobalInfoResDTO getResGlobalInfo() {
		return resGlobalInfo;
	}

	/**
	 * Sets the res global info.
	 *
	 * @param resGlobalInfo the resGlobalInfo to set
	 */
	public void setResGlobalInfo(ResGlobalInfoResDTO resGlobalInfo) {
		this.resGlobalInfo = resGlobalInfo;
	}

	/**
	 * Gets the res guest.
	 *
	 * @return the resGuest
	 */
	public List<ResGuestResDTO> getResGuest() {
		return resGuest;
	}

	/**
	 * Sets the res guest.
	 *
	 * @param resGuest the resGuest to set
	 */
	public void setResGuest(List<ResGuestResDTO> resGuest) {
		this.resGuest = resGuest;
	}

	/**
	 * Gets the unique ID.
	 *
	 * @return the uniqueID
	 */
	public UniqueIDResDTO getUniqueID() {
		return uniqueID;
	}

	/**
	 * Sets the unique ID.
	 *
	 * @param uniqueID the uniqueID to set
	 */
	public void setUniqueID(UniqueIDResDTO uniqueID) {
		this.uniqueID = uniqueID;
	}

	/**
	 * Gets the pos.
	 *
	 * @return the pOS
	 */
	public POSResDTO getPOS() {
		return POS;
	}

	/**
	 * Sets the pos.
	 *
	 * @param pOS the pOS to set
	 */
	public void setPOS(POSResDTO pOS) {
		POS = pOS;
	}


	/**
	 * Gets the room stay.
	 *
	 * @return the roomStay
	 */
	public List<RoomStayResDTO> getRoomStay() {
		return roomStay;
	}

	/**
	 * Sets the room stay.
	 *
	 * @param roomStay the roomStay to set
	 */
	public void setRoomStay(List<RoomStayResDTO> roomStay) {
		this.roomStay = roomStay;
	}

	/**
	 * Gets the res status.
	 *
	 * @return the resStatus
	 */
	public String getResStatus() {
		return resStatus;
	}

	/**
	 * Sets the res status.
	 *
	 * @param resStatus the resStatus to set
	 */
	public void setResStatus(String resStatus) {
		this.resStatus = resStatus;
	}
    
    
}
