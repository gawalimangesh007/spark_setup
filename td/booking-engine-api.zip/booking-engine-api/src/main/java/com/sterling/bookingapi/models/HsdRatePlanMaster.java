package com.sterling.bookingapi.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * The Class HsdRatePlanMaster.
 */
/**
 * @author tcs
 *
 */
@Entity
@Table(name = "sh_hsd_rate_plan_master")
public class HsdRatePlanMaster extends BaseModel{

	/** The rate plan id. */
	@Id
	@GeneratedValue( strategy = GenerationType.IDENTITY )
	@Column(name = "rate_plan_id", unique = false)
	private int ratePlanId;
	
	/** The rate plan. */
	@Column(name = "ratePlan",nullable = false)
	private String ratePlan;
	
	/** The rate plan detail. */
	@Column(name = "rate_plan_detail",nullable = true)
	private String ratePlanDetail;
	
	/** The active. */
	@Column(name = "status",nullable = false)
	private boolean active;

	/**
	 * Gets the rate plan id.
	 *
	 * @return the rate plan id
	 */
	public int getRatePlanId() {
		return ratePlanId;
	}

	/**
	 * Sets the rate plan id.
	 *
	 * @param ratePlanId the new rate plan id
	 */
	public void setRatePlanId(int ratePlanId) {
		this.ratePlanId = ratePlanId;
	}

	/**
	 * Gets the rate plan.
	 *
	 * @return the rate plan
	 */
	public String getRatePlan() {
		return ratePlan;
	}

	/**
	 * Sets the rate plan.
	 *
	 * @param ratePlan the new rate plan
	 */
	public void setRatePlan(String ratePlan) {
		this.ratePlan = ratePlan;
	}

	/**
	 * Gets the rate plan detail.
	 *
	 * @return the rate plan detail
	 */
	public String getRatePlanDetail() {
		return ratePlanDetail;
	}

	/**
	 * Sets the rate plan detail.
	 *
	 * @param ratePlanDetail the new rate plan detail
	 */
	public void setRatePlanDetail(String ratePlanDetail) {
		this.ratePlanDetail = ratePlanDetail;
	}

	/**
	 * Checks if is active.
	 *
	 * @return the active
	 */
	public boolean isActive() {
		return active;
	}

	/**
	 * Sets the active.
	 *
	 * @param active the active to set
	 */
	public void setActive(boolean active) {
		this.active = active;
	}

}
