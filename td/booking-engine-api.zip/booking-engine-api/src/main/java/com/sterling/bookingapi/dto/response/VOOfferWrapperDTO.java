package com.sterling.bookingapi.dto.response;

import java.io.Serializable;
import java.util.List;

public class VOOfferWrapperDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private List<VOOffertResponseDTO> offerList;

	public List<VOOffertResponseDTO> getOfferList() {
		return offerList;
	}

	public void setOfferList(List<VOOffertResponseDTO> offerList) {
		this.offerList = offerList;
	}
	
}
