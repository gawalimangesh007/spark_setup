package com.sterling.bookingapi.dto.maximojo.response;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class ResGuestResDTO.
 * @author tcs
 * @version 1.0
 */
public class ResGuestResDTO {
	
	/** The res guest RPH. */
	@JacksonXmlProperty(localName = "ResGuestRPH", isAttribute = true)
	private String resGuestRPH;

	/** The profile info. */
	@JacksonXmlElementWrapper(useWrapping=true, localName = "Profiles")
    @JacksonXmlProperty(localName = "ProfileInfo")
    private ProfileInfoResDTO profileInfo;

    /** The arrival time. */
    @JacksonXmlProperty(localName = "ArrivalTime", isAttribute = true)
    private String arrivalTime;

	/**
	 * Gets the res guest RPH.
	 *
	 * @return the resGuestRPH
	 */
	public String getResGuestRPH() {
		return resGuestRPH;
	}

	/**
	 * Sets the res guest RPH.
	 *
	 * @param resGuestRPH the resGuestRPH to set
	 */
	public void setResGuestRPH(String resGuestRPH) {
		this.resGuestRPH = resGuestRPH;
	}

	/**
	 * Gets the profile info.
	 *
	 * @return the profileInfo
	 */
	public ProfileInfoResDTO getProfileInfo() {
		return profileInfo;
	}

	/**
	 * Sets the profile info.
	 *
	 * @param profileInfo the profileInfo to set
	 */
	public void setProfileInfo(ProfileInfoResDTO profileInfo) {
		this.profileInfo = profileInfo;
	}

	/**
	 * Gets the arrival time.
	 *
	 * @return the arrivalTime
	 */
	public String getArrivalTime() {
		return arrivalTime;
	}

	/**
	 * Sets the arrival time.
	 *
	 * @param arrivalTime the arrivalTime to set
	 */
	public void setArrivalTime(String arrivalTime) {
		this.arrivalTime = arrivalTime;
	}
    
    
}
