package com.sterling.bookingapi.dto.request;

/**
 * @author tcs
 *
 */
public class VOSeasonDetails {

	private String startDate;
	
	private String endDate;
	
	private String seasonCode;
	
	/**
	 * @return startDate
	 */
	public String getStartDate() {
		return startDate;
	}

	/**
	 * @param startDate
	 * set the startDate
	 */
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	/**
	 * @return endDate
	 */
	public String getEndDate() {
		return endDate;
	}

	/**
	 * @param endDate
	 * set the endDate
	 */
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	/**
	 * @return seasonCode
	 */
	public String getSeasonCode() {
		return seasonCode;
	}

	/**
	 * @param seasonCode
	 * set the seasonCode
	 */
	public void setSeasonCode(String seasonCode) {
		this.seasonCode = seasonCode;
	}

}
