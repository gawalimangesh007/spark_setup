package com.sterling.bookingapi.dto.request;

import java.io.Serializable;

import javax.validation.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class HsdGroupBookingRequestDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String comments;
	@NotEmpty(message="Email id should not be empty")
	private String emailId;
	private String firstName;
	private String lastName;
	@NotEmpty(message="Mobile Number should not be empty")
	private String mobileNo;
	private String nonMemberId;
	@NotEmpty(message="Person Count should not be empty")
	private String personCount;
	@NotEmpty(message="Room Count should not be empty")
	private String roomCount;
	private String memberId;
	private String userType;
	private String bookedTime;
	private boolean termCondFlag;
	
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getNonMemberId() {
		return nonMemberId;
	}
	public void setNonMemberId(String nonMemberId) {
		this.nonMemberId = nonMemberId;
	}
	public String getPersonCount() {
		return personCount;
	}
	public void setPersonCount(String personCount) {
		this.personCount = personCount;
	}
	public String getRoomCount() {
		return roomCount;
	}
	public void setRoomCount(String roomCount) {
		this.roomCount = roomCount;
	}
	public String getMemberId() {
		return memberId;
	}
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	public String getBookedTime() {
		return bookedTime;
	}
	public void setBookedTime(String bookedTime) {
		this.bookedTime = bookedTime;
	}
	public boolean isTermCondFlag() {
		return termCondFlag;
	}
	public void setTermCondFlag(boolean termCondFlag) {
		this.termCondFlag = termCondFlag;
	}	
}