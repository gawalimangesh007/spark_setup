package com.sterling.bookingapi.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.view.RedirectView;

import com.sterling.bookingapi.dto.request.ChangePasswordRequestDTO;
import com.sterling.bookingapi.dto.request.OTPGenerateRequest;
import com.sterling.bookingapi.dto.request.OTPVerifyRequest;
import com.sterling.bookingapi.dto.response.ResponseDTO;
import com.sterling.bookingapi.exception.BookingEngineException;
import com.sterling.bookingapi.mail.EmailUtil;
import com.sterling.bookingapi.service.HsdOTPService;
import com.sterling.bookingapi.service.PasswordService;
import com.sterling.bookingapi.utils.MessageConstants;


/**
 * The Class PasswordController.
 */
/**
 * @author tcs
 *
 */
@RestController
@RequestMapping(value = "/user/password")
public class PasswordController extends BaseController {

/** The Constant logger. */
private static final Logger logger = LogManager.getLogger(PasswordController.class);
	
	/** The password service. */
	@Autowired
	private PasswordService passwordService;
	
	/** The otp service. */
	@Autowired
	private HsdOTPService otpService;
	
	/** The email util. */
	@Autowired
	private EmailUtil emailUtil;
	
	/**
	 * Forgot password.
	 *
	 * @param email the email
	 * @return the response DTO
	 * @throws BookingEngineException the booking engine exception
	 */
	@ResponseBody
	@RequestMapping(value = "/forgot", method = RequestMethod.POST)
	public ResponseDTO forgotPassword(@RequestParam String email) 
						throws BookingEngineException {
		logger.info("PasswordController : forgotPassword : Entered.");
		
		passwordService.generateForgotPassword(email);

		ResponseDTO response = new ResponseDTO();
		response.setStatusMessage(MessageConstants.FORGOT_XXX_LINK_GENERATED_SUCCESSFULLY);
		
		logger.info("PasswordController : forgotPassword : Leaving.");
		return response;
	}
	
/**
 * Verify forgot link.
 *
 * @param token the token
 * @return the redirect view
 * @throws BookingEngineException the booking engine exception
 */
//	@ResponseBody
	@RequestMapping(value = "/{token}", method = RequestMethod.GET)
	public RedirectView verifyForgotLink(@PathVariable(value="token", required = true) String token) 
						throws BookingEngineException {
		logger.info("PasswordController : forgotPassword : Entered.");
		
		String redirect = passwordService.verifyForgotLink(token);

		 RedirectView redirectView = new RedirectView();
		 redirectView.setUrl(redirect);
		logger.info("PasswordController : forgotPassword : Leaving.");
		return redirectView;
	}
	
	/**
	 * Change password.
	 *
	 * @param request the request
	 * @param token the token
	 * @return the response DTO
	 * @throws BookingEngineException the booking engine exception
	 */
	@ResponseBody
	@RequestMapping(value = "/{token}", method = RequestMethod.POST)
	public ResponseDTO changePassword(@RequestBody final ChangePasswordRequestDTO request , 
			@PathVariable(value="token", required = true) String token) 
						throws BookingEngineException {
		logger.info("PasswordController : forgotPassword : Entered.");

		ResponseDTO response = passwordService.changePassword(token, request);

		passwordService.changePassword(token,request);

		logger.info("PasswordController : forgotPassword : Leaving.");
		return response;
	}
	
	/**
	 * Generate OTP.
	 *
	  * @param email the email
	 * @return the response DTO
	 * @throws BookingEngineException the booking engine exception
	 */
	
	@ResponseBody
	@RequestMapping(value = "/OTP/Generate", method = RequestMethod.POST)
	public ResponseDTO SendOTP(@RequestBody final OTPGenerateRequest reqeust) 
						throws BookingEngineException {
		logger.info("PasswordController : SendOTP : Entered.");
		
		otpService.generateOTP(reqeust);

		ResponseDTO response = new ResponseDTO();
		response.setStatusMessage("OTP send Successfully");
		
		logger.info("PasswordController : SendOTP : Leaving.");
		return response;
		
	}
	
	/**
	 * Verify OTP.
	 *
	 * @param OTP and userID
	 * @return the response DTO
	 * @throws BookingEngineException the booking engine exception
	 */
	@ResponseBody
	@RequestMapping(value = "/OTP/Verify", method = RequestMethod.POST)
	public ResponseDTO verifyOTP(@RequestBody final OTPVerifyRequest reqeust) 
						throws BookingEngineException {
		logger.info("PasswordController : verifyOTP : Entered.");
		
		otpService.verifyOTP(reqeust);

		ResponseDTO response = new ResponseDTO();
		response.setStatusMessage("Valid OTP");
		
		logger.info("PasswordController : verifyOTP : Leaving.");
		return response;
	}
	
	
}
