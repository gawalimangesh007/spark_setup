package com.sterling.bookingapi.dto.response;

import java.io.Serializable;
import java.util.List;

public class VOSeasonCalenderResponseDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String resortName;

	private String location;

	private String resortMaster;

	private Object productCalenderMaster;

	private List<VOSeasonCalenderWeekDataDTO> weekData;

	/**
	 * @return resortName
	 */
	public String getResortName() {
		return resortName;
	}

	/**
	 * @param resortNName
	 * set the resortName
	 */
	public void setResortName(String resortNName) {
		this.resortName = resortNName;
	}

	/**
	 * @return location
	 */
	public String getLocation() {
		return location;
	}

	/**
	 * @param location
	 * set the location
	 */
	public void setLocation(String location) {
		this.location = location;
	}

	/**
	 * @return resortMaster
	 */
	public String getResortMaster() {
		return resortMaster;
	}

	/**
	 * @param resortMaster
	 * set the resortMaster
	 */
	public void setResortMaster(String resortMaster) {
		this.resortMaster = resortMaster;
	}

	/**
	 * @return productCalenderMaster
	 */
	public Object getProductCalenderMaster() {
		return productCalenderMaster;
	}

	/**
	 * @param productCalenderMaster
	 * set the productCalenderMaster
	 */
	public void setProductCalenderMaster(Object productCalenderMaster) {
		this.productCalenderMaster = productCalenderMaster;
	}

	/**
	 * @return weekData
	 */
	public List<VOSeasonCalenderWeekDataDTO> getWeekData() {
		return weekData;
	}

	/**
	 * @param weekData
	 * set the weekData
	 */
	public void setWeekData(List<VOSeasonCalenderWeekDataDTO> weekData) {
		this.weekData = weekData;
	}

}
