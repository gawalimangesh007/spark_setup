package com.sterling.bookingapi.dto.response;

import java.util.List;

import com.sterling.bookingapi.sf.dto.response.HsdResortRoomsResDTO;

/**
 * @author tcs
 * @version 1.0
 */
public class HsdResortRoomMasterResDTO {
	
    /** The location id. */
    private String locationId;
	
	/** The location name. */
	private String locationName;
	
	/** The resort id. */
	private String resortId;
	
	/** The resort name. */
	private String resortName;
		
	/** The active. */
	private boolean active;
	
	private List<HsdResortRoomsResDTO> roomDetails;
	
	/**
	 * Gets the location id.
	 *
	 * @return the locationId
	 */
	public String getLocationId() {
		return locationId;
	}

	/**
	 * Sets the location id.
	 *
	 * @param locationId the locationId to set
	 */
	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}

	/**
	 * Gets the location name.
	 *
	 * @return the locationName
	 */
	public String getLocationName() {
		return locationName;
	}

	/**
	 * Sets the location name.
	 *
	 * @param locationName the locationName to set
	 */
	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}

	/**
	 * Gets the resort id.
	 *
	 * @return the resortId
	 */
	public String getResortId() {
		return resortId;
	}

	/**
	 * Sets the resort id.
	 *
	 * @param resortId the resortId to set
	 */
	public void setResortId(String resortId) {
		this.resortId = resortId;
	}

	/**
	 * Gets the resort name.
	 *
	 * @return the resortName
	 */
	public String getResortName() {
		return resortName;
	}

	/**
	 * Sets the resort name.
	 *
	 * @param resortName the resortName to set
	 */
	public void setResortName(String resortName) {
		this.resortName = resortName;
	}


	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public List<HsdResortRoomsResDTO> getRoomDetails() {
		return roomDetails;
	}

	public void setRoomDetails(List<HsdResortRoomsResDTO> roomDetails) {
		this.roomDetails = roomDetails;
	}
	
}
