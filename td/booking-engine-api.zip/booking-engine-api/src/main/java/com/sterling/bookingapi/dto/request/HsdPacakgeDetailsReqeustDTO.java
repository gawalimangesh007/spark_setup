package com.sterling.bookingapi.dto.request;

import java.util.Date;
import java.util.List;

import javax.validation.constraints.NotNull;

import com.sterling.bookingapi.dto.ResortRoomMappingDTO;


/**
 * The Class HsdPacakgeDetailsReqeustDTO.
 */
/**
 * @author tcs
 *
 */
public class HsdPacakgeDetailsReqeustDTO {
	
	/** The package type. */
	@NotNull
	private String packageType;
	
	/** The package name. */
	@NotNull
	private String packageName;
	
	/** The package details. */
	private String packageDetails;
	
	/** The package inclusion. */
	private String packageInclusion;
	
	/** The package cost. */
	@NotNull
	private String packageCost;
	
	/** The package start date. */
	private Date packageStartDate;
	
	/** The package end date. */
	private Date packageEndDate;
	
	/** The adults count. */
	private String adultsCount;
	
	/** The kids count. */
	private String kidsCount;
	
	/** The package duration. */
	private int packageDuration;
	
	/** The room type. */
	private List<ResortRoomMappingDTO> roomType;
	
	/**
	 * @return the packageType
	 */
	public String getPackageType() {
		return packageType;
	}
	
	/**
	 * Sets the package type.
	 *
	 * @param packageType the packageType to set
	 */
	public void setPackageType(String packageType) {
		this.packageType = packageType;
	}
	
	/**
	 * Gets the package name.
	 *
	 * @return the packageName
	 */
	public String getPackageName() {
		return packageName;
	}
	
	/**
	 * Sets the package name.
	 *
	 * @param packageName the packageName to set
	 */
	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}
	
	/**
	 * Gets the package details.
	 *
	 * @return the packageDetails
	 */
	public String getPackageDetails() {
		return packageDetails;
	}
	
	/**
	 * Sets the package details.
	 *
	 * @param packageDetails the packageDetails to set
	 */
	public void setPackageDetails(String packageDetails) {
		this.packageDetails = packageDetails;
	}
	
	/**
	 * Gets the package inclusion.
	 *
	 * @return the packageInclusion
	 */
	public String getPackageInclusion() {
		return packageInclusion;
	}
	
	/**
	 * Sets the package inclusion.
	 *
	 * @param packageInclusion the packageInclusion to set
	 */
	public void setPackageInclusion(String packageInclusion) {
		this.packageInclusion = packageInclusion;
	}
	
	/**
	 * Gets the package cost.
	 *
	 * @return the packageCost
	 */
	public String getPackageCost() {
		return packageCost;
	}
	
	/**
	 * Sets the package cost.
	 *
	 * @param packageCost the packageCost to set
	 */
	public void setPackageCost(String packageCost) {
		this.packageCost = packageCost;
	}
	
	/**
	 * Gets the package start date.
	 *
	 * @return the packageStartDate
	 */
	public Date getPackageStartDate() {
		return packageStartDate;
	}
	
	/**
	 * Sets the package start date.
	 *
	 * @param packageStartDate the packageStartDate to set
	 */
	public void setPackageStartDate(Date packageStartDate) {
		this.packageStartDate = packageStartDate;
	}
	
	/**
	 * Gets the package end date.
	 *
	 * @return the packageEndDate
	 */
	public Date getPackageEndDate() {
		return packageEndDate;
	}
	
	/**
	 * Sets the package end date.
	 *
	 * @param packageEndDate the packageEndDate to set
	 */
	public void setPackageEndDate(Date packageEndDate) {
		this.packageEndDate = packageEndDate;
	}
	
	/**
	 * Gets the adults count.
	 *
	 * @return the adultsCount
	 */
	public String getAdultsCount() {
		return adultsCount;
	}
	
	/**
	 * Sets the adults count.
	 *
	 * @param adultsCount the adultsCount to set
	 */
	public void setAdultsCount(String adultsCount) {
		this.adultsCount = adultsCount;
	}
	
	/**
	 * Gets the kids count.
	 *
	 * @return the kidsCount
	 */
	public String getKidsCount() {
		return kidsCount;
	}
	
	/**
	 * Sets the kids count.
	 *
	 * @param kidsCount the kidsCount to set
	 */
	public void setKidsCount(String kidsCount) {
		this.kidsCount = kidsCount;
	}
	
	/**
	 * Gets the room type.
	 *
	 * @return the roomType
	 */
	public List<ResortRoomMappingDTO> getRoomType() {
		return roomType;
	}
	
	/**
	 * Sets the room type.
	 *
	 * @param roomType the roomType to set
	 */
	public void setRoomType(List<ResortRoomMappingDTO> roomType) {
		this.roomType = roomType;
	}
	
	/**
	 * Gets the package duration.
	 *
	 * @return the package duration
	 */
	public int getPackageDuration() {
		return packageDuration;
	}
	
	/**
	 * Sets the package duration.
	 *
	 * @param packageDuration the new package duration
	 */
	public void setPackageDuration(int packageDuration) {
		this.packageDuration = packageDuration;
	}
	
	
}
