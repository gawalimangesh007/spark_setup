package com.sterling.bookingapi.dto.maximojo.response;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class SourceResDTO.
 * @author tcs
 * @version 1.0
 */
public class SourceResDTO {

	/** The requestor ID. */
	@JacksonXmlProperty(localName = "RequestorID")
	 private RequestorIDResDTO requestorID;

	/** The booking channel. */
	@JacksonXmlProperty(localName = "BookingChannel")
	 private BookingChannelResDTO bookingChannel;

	/**
	 * Gets the requestor ID.
	 *
	 * @return the requestorID
	 */
	public RequestorIDResDTO getRequestorID() {
		return requestorID;
	}

	/**
	 * Sets the requestor ID.
	 *
	 * @param requestorID the requestorID to set
	 */
	public void setRequestorID(RequestorIDResDTO requestorID) {
		this.requestorID = requestorID;
	}

	/**
	 * Gets the booking channel.
	 *
	 * @return the bookingChannel
	 */
	public BookingChannelResDTO getBookingChannel() {
		return bookingChannel;
	}

	/**
	 * Sets the booking channel.
	 *
	 * @param bookingChannel the bookingChannel to set
	 */
	public void setBookingChannel(BookingChannelResDTO bookingChannel) {
		this.bookingChannel = bookingChannel;
	}
	 
	 
}
