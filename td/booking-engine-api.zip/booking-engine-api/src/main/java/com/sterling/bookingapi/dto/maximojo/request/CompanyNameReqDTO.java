package com.sterling.bookingapi.dto.maximojo.request;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class CompanyNameReqDTO.
 */
/**
 * @author tcs
 *
 */
public class CompanyNameReqDTO {
	
	/** The code. */
	@JacksonXmlProperty(localName = "Code",isAttribute = true)
	private int code;

	/** The company short name. */
	@JacksonXmlProperty(localName = "CompanyShortName",isAttribute = true)
	private String companyShortName;
	
	/**
	 * Gets the company short name.
	 *
	 * @return the companyShortName
	 */
	public String getCompanyShortName() {
		return companyShortName;
	}

	/**
	 * Sets the company short name.
	 *
	 * @param companyShortName the companyShortName to set
	 */
	public void setCompanyShortName(String companyShortName) {
		this.companyShortName = companyShortName;
	}

	/**
	 * Gets the code.
	 *
	 * @return the code
	 */
	public int getCode() {
		return code;
	}

	/**
	 * Sets the code.
	 *
	 * @param code the code to set
	 */
	public void setCode(int code) {
		this.code = code;
	}
	
	
}
