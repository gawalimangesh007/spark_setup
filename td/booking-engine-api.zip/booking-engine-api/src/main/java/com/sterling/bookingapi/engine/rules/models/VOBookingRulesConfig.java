package com.sterling.bookingapi.engine.rules.models;

import java.io.Serializable;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class VOBookingRulesConfig implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Map<String, ProductRuleDTO> products;

	public Map<String, ProductRuleDTO> getProducts() {
		return products;
	}

	public void setProducts(Map<String, ProductRuleDTO> products) {
		this.products = products;
	}

	
	
}
