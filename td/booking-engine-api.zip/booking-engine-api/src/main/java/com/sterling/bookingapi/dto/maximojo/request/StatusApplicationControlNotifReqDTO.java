package com.sterling.bookingapi.dto.maximojo.request;

import java.util.Date;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class StatusApplicationControlNotifReqDTO.
 */
/**
 * @author tcs
 *
 */
public class StatusApplicationControlNotifReqDTO {

	/** The end. */
	@JacksonXmlProperty(localName = "End", isAttribute = true)
	private Date end;

	/** The start. */
	@JacksonXmlProperty(localName = "Start", isAttribute = true)
    private Date start;

	/**
	 * Gets the end.
	 *
	 * @return the end
	 */
	public Date getEnd() {
		return end;
	}

	/**
	 * Sets the end.
	 *
	 * @param end the end to set
	 */
	public void setEnd(Date end) {
		this.end = end;
	}

	/**
	 * Gets the start.
	 *
	 * @return the start
	 */
	public Date getStart() {
		return start;
	}

	/**
	 * Sets the start.
	 *
	 * @param start the start to set
	 */
	public void setStart(Date start) {
		this.start = start;
	}

}
