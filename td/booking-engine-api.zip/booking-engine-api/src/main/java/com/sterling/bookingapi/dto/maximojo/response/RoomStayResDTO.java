package com.sterling.bookingapi.dto.maximojo.response;

import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class RoomStayResDTO.
 * @author tcs
 * @version 1.0
 */
public class RoomStayResDTO {

	/** The comment. */
	@JacksonXmlElementWrapper(useWrapping=true, localName = "Comments")
	@JacksonXmlProperty(localName = "Comment")
	private List<CommentResDTO> comment;

	/** The guest count. */
	@JacksonXmlElementWrapper(useWrapping=true, localName = "GuestCounts")
	@JacksonXmlProperty(localName = "GuestCount")
	private List<GuestCountResDTO> guestCount;

	/** The room rate. */
	@JacksonXmlElementWrapper(useWrapping=true, localName = "RoomRates")
	@JacksonXmlProperty(localName = "RoomRate")   
	private List<RoomRateResDTO> roomRate;

	/** The basic property info. */
	@JacksonXmlProperty(localName = "BasicPropertyInfo")
	private BasicPropertyInfoResDTO basicPropertyInfo;

	/** The res guest RPH. */
	@JacksonXmlElementWrapper(useWrapping=true, localName = "ResGuestRPHs")
    @JacksonXmlProperty(localName = "ResGuestRPH")
	private List<ResGuestRPHResDTO> resGuestRPH;

	/** The time span. */
	@JacksonXmlProperty(localName = "TimeSpan")
	private TimeSpanResDTO timeSpan;

	/** The total. */
	@JacksonXmlProperty(localName = "Total")
	private TotalResDTO total;

	/**
	 * Gets the comment.
	 *
	 * @return the comment
	 */
	public List<CommentResDTO> getComment() {
		return comment;
	}

	/**
	 * Sets the comment.
	 *
	 * @param comment the comment to set
	 */
	public void setComment(List<CommentResDTO> comment) {
		this.comment = comment;
	}

	/**
	 * Gets the guest count.
	 *
	 * @return the guestCount
	 */
	public List<GuestCountResDTO> getGuestCount() {
		return guestCount;
	}

	/**
	 * Sets the guest count.
	 *
	 * @param guestCount the guestCount to set
	 */
	public void setGuestCount(List<GuestCountResDTO> guestCount) {
		this.guestCount = guestCount;
	}

	/**
	 * Gets the room rate.
	 *
	 * @return the roomRate
	 */
	public List<RoomRateResDTO> getRoomRate() {
		return roomRate;
	}

	/**
	 * Sets the room rate.
	 *
	 * @param roomRate the roomRate to set
	 */
	public void setRoomRate(List<RoomRateResDTO> roomRate) {
		this.roomRate = roomRate;
	}

	/**
	 * Gets the basic property info.
	 *
	 * @return the basicPropertyInfo
	 */
	public BasicPropertyInfoResDTO getBasicPropertyInfo() {
		return basicPropertyInfo;
	}

	/**
	 * Sets the basic property info.
	 *
	 * @param basicPropertyInfo the basicPropertyInfo to set
	 */
	public void setBasicPropertyInfo(BasicPropertyInfoResDTO basicPropertyInfo) {
		this.basicPropertyInfo = basicPropertyInfo;
	}

	/**
	 * Gets the res guest RPH.
	 *
	 * @return the resGuestRPH
	 */
	public List<ResGuestRPHResDTO> getResGuestRPH() {
		return resGuestRPH;
	}

	/**
	 * Sets the res guest RPH.
	 *
	 * @param resGuestRPH the resGuestRPH to set
	 */
	public void setResGuestRPH(List<ResGuestRPHResDTO> resGuestRPH) {
		this.resGuestRPH = resGuestRPH;
	}

	/**
	 * Gets the time span.
	 *
	 * @return the timeSpan
	 */
	public TimeSpanResDTO getTimeSpan() {
		return timeSpan;
	}

	/**
	 * Sets the time span.
	 *
	 * @param timeSpan the timeSpan to set
	 */
	public void setTimeSpan(TimeSpanResDTO timeSpan) {
		this.timeSpan = timeSpan;
	}

	/**
	 * Gets the total.
	 *
	 * @return the total
	 */
	public TotalResDTO getTotal() {
		return total;
	}

	/**
	 * Sets the total.
	 *
	 * @param total the total to set
	 */
	public void setTotal(TotalResDTO total) {
		this.total = total;
	}
	
	
}
