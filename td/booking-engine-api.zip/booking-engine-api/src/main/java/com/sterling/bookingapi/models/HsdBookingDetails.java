package com.sterling.bookingapi.models;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;

import com.sterling.bookingapi.utils.AppConstants;


/**
 * The Class HsdBookingDetails.
 */
/**
 * @author tcs
 *
 */
@Entity
@Table(name = "sh_hsd_booking_details")
public class HsdBookingDetails extends BaseModel{
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;
	
	/** The id. */
	//@SequenceGenerator(name="Booking", initialValue=1000)
	@Id
	@GeneratedValue( strategy = GenerationType.IDENTITY )
	//TODO - Need to change this as sequence number based on sterling
	
	@Column(name = "booking_idx_id", unique = true)
	private int id;
	
	/** The booking id. */
	@Column(name = "booking_id", unique = true)
	private String  bookingId;
		
	/** The user type. */
	@Column(name = "user_type",nullable = false)
	private String userType;
	
	/** The user id. */
	@Column(name = "user_id",nullable = false)
	private String userId;
	
	/** The gift booking. */
	@Column(name = "gift_booking",nullable = false)
	private boolean giftBooking;
		
	/** The arrival date. */
	@Column(name = "arrival_date",nullable = false)
	private Date arrivalDate;
		
	/** The departure date. */
	@Column(name = "departure_date",nullable = false)
	private Date departureDate;
			
	/** The total nights. */
	@Column(name = "total_nights",nullable = false)
	private int totalNights;
		
	/** The enhancement detail. */
	@Column(name = "enhancement_detail",nullable = false)
	private String enhancementDetail;
	
	/** The roomupgrade detail. */
	@Column(name = "roomupgrade_detail",nullable = false)
	private String roomUpgradeDetail;
	
	/** The package details. */
	@Column(name = "package_details",nullable = false)
	private String packageDetails;
	
	/** The offer details. */
	@Column(name = "offer_details",nullable = false)
	private String offerDetails;
			
	/** The adult count. */
	@Column(name = "adult_count",nullable = false)
	private int adultCount;
	
	/** The child count. */
	@Column(name = "child_count",nullable = false)
	private int childCount;
	
	/** The booked date. */
	@Column(name = "booked_date",nullable = false)
	private Date bookedDate;
	
	@Column(name = "checkin_time")
	@Temporal(TemporalType.TIME)
	private Date checkinTime;
	
	@Column(name = "checkout_time")
	@Temporal(TemporalType.TIME)
	private Date checkoutTime;
	
	
	/** The booked status. */
	@Column(name = "booking_status",nullable = false)
	@Enumerated(EnumType.STRING)
	private AppConstants.BookingStatus bookedStatus;
			
	/** The maximojo sync date. */
	@Column(name = "maximojo_sync_date",nullable = true)
	private Date maximojoSyncDate;
			
	/** The hsd booking calc details. */
	@OneToOne(fetch = FetchType.EAGER, mappedBy = "hsdBookingDetails")
	@Cascade(value = {CascadeType.SAVE_UPDATE})
	private HsdBookingCalcDetails hsdBookingCalcDetails;
	
	/** The hsd booking pay details. */
	@OneToOne(fetch = FetchType.EAGER, mappedBy = "hsdBookingDetails")
	@Cascade(value = {CascadeType.SAVE_UPDATE})
	private HsdBookingPayDetails hsdBookingPayDetails;
	
	/** The hsd booking customer profile. */
	@OneToOne(fetch = FetchType.EAGER, mappedBy = "hsdBookingDetails")
	@Cascade(value = {CascadeType.SAVE_UPDATE})
	private HsdBookingCustomerProfile hsdBookingCustomerProfile;
	
	/** The room details. */
	@OneToMany(mappedBy = "hsdBookingDetails", fetch = FetchType.LAZY)
	private List<HsdBookingGuestRoomDetails> roomDetails;

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * Gets the booking id.
	 *
	 * @return the booking id
	 */
	public String getBookingId() {
		return bookingId;
	}

	/**
	 * Sets the booking id.
	 *
	 * @param bookingId the new booking id
	 */
	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}

	/**
	 * Gets the user type.
	 *
	 * @return the user type
	 */
	public String getUserType() {
		return userType;
	}

	/**
	 * Sets the user type.
	 *
	 * @param userType the new user type
	 */
	public void setUserType(String userType) {
		this.userType = userType;
	}

	/**
	 * Gets the user id.
	 *
	 * @return the user id
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * Sets the user id.
	 *
	 * @param userId the new user id
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * Checks if is gift booking.
	 *
	 * @return true, if is gift booking
	 */
	public boolean isGiftBooking() {
		return giftBooking;
	}

	/**
	 * Sets the gift booking.
	 *
	 * @param giftBooking the new gift booking
	 */
	public void setGiftBooking(boolean giftBooking) {
		this.giftBooking = giftBooking;
	}

	/**
	 * Gets the arrival date.
	 *
	 * @return the arrival date
	 */
	public Date getArrivalDate() {
		return arrivalDate;
	}

	/**
	 * Sets the arrival date.
	 *
	 * @param arrivalDate the new arrival date
	 */
	public void setArrivalDate(Date arrivalDate) {
		this.arrivalDate = arrivalDate;
	}

	/**
	 * Gets the departure date.
	 *
	 * @return the departure date
	 */
	public Date getDepartureDate() {
		return departureDate;
	}

	/**
	 * Sets the departure date.
	 *
	 * @param departureDate the new departure date
	 */
	public void setDepartureDate(Date departureDate) {
		this.departureDate = departureDate;
	}

	/**
	 * Gets the total nights.
	 *
	 * @return the total nights
	 */
	public int getTotalNights() {
		return totalNights;
	}

	/**
	 * Sets the total nights.
	 *
	 * @param totalNights the new total nights
	 */
	public void setTotalNights(int totalNights) {
		this.totalNights = totalNights;
	}

	/**
	 * Gets the enhancement detail.
	 *
	 * @return the enhancement detail
	 */
	public String getEnhancementDetail() {
		return enhancementDetail;
	}

	/**
	 * Sets the enhancement detail.
	 *
	 * @param enhancementDetail the new enhancement detail
	 */
	public void setEnhancementDetail(String enhancementDetail) {
		this.enhancementDetail = enhancementDetail;
	}

	/**
	 * Gets the package details.
	 *
	 * @return the package details
	 */
	public String getPackageDetails() {
		return packageDetails;
	}

	/**
	 * Sets the package details.
	 *
	 * @param packageDetails the new package details
	 */
	public void setPackageDetails(String packageDetails) {
		this.packageDetails = packageDetails;
	}

	/**
	 * Gets the offer details.
	 *
	 * @return the offer details
	 */
	public String getOfferDetails() {
		return offerDetails;
	}

	/**
	 * Sets the offer details.
	 *
	 * @param offerDetails the new offer details
	 */
	public void setOfferDetails(String offerDetails) {
		this.offerDetails = offerDetails;
	}

	/**
	 * Gets the booked date.
	 *
	 * @return the booked date
	 */
	public Date getBookedDate() {
		return bookedDate;
	}

	/**
	 * Sets the booked date.
	 *
	 * @param bookedDate the new booked date
	 */
	public void setBookedDate(Date bookedDate) {
		this.bookedDate = bookedDate;
	}

	/**
	 * Gets the booked status.
	 *
	 * @return the booked status
	 */
	public AppConstants.BookingStatus getBookedStatus() {
		return bookedStatus;
	}

	/**
	 * Sets the booked status.
	 *
	 * @param bookedStatus the new booked status
	 */
	public void setBookedStatus(AppConstants.BookingStatus bookedStatus) {
		this.bookedStatus = bookedStatus;
	}

	/**
	 * Gets the maximojo sync date.
	 *
	 * @return the maximojo sync date
	 */
	public Date getMaximojoSyncDate() {
		return maximojoSyncDate;
	}

	/**
	 * Sets the maximojo sync date.
	 *
	 * @param maximojoSyncDate the new maximojo sync date
	 */
	public void setMaximojoSyncDate(Date maximojoSyncDate) {
		this.maximojoSyncDate = maximojoSyncDate;
	}

	/**
	 * Gets the hsd booking calc details.
	 *
	 * @return the hsd booking calc details
	 */
	public HsdBookingCalcDetails getHsdBookingCalcDetails() {
		return hsdBookingCalcDetails;
	}

	/**
	 * Sets the hsd booking calc details.
	 *
	 * @param hsdBookingCalcDetails the new hsd booking calc details
	 */
	public void setHsdBookingCalcDetails(HsdBookingCalcDetails hsdBookingCalcDetails) {
		this.hsdBookingCalcDetails = hsdBookingCalcDetails;
	}

	/**
	 * Gets the hsd booking pay details.
	 *
	 * @return the hsd booking pay details
	 */
	public HsdBookingPayDetails getHsdBookingPayDetails() {
		return hsdBookingPayDetails;
	}

	/**
	 * Sets the hsd booking pay details.
	 *
	 * @param hsdBookingPayDetails the new hsd booking pay details
	 */
	public void setHsdBookingPayDetails(HsdBookingPayDetails hsdBookingPayDetails) {
		this.hsdBookingPayDetails = hsdBookingPayDetails;
	}

	/**
	 * Gets the hsd booking customer profile.
	 *
	 * @return the hsd booking customer profile
	 */
	public HsdBookingCustomerProfile getHsdBookingCustomerProfile() {
		return hsdBookingCustomerProfile;
	}

	/**
	 * Sets the hsd booking customer profile.
	 *
	 * @param hsdBookingCustomerProfile the new hsd booking customer profile
	 */
	public void setHsdBookingCustomerProfile(
			HsdBookingCustomerProfile hsdBookingCustomerProfile) {
		this.hsdBookingCustomerProfile = hsdBookingCustomerProfile;
	}

	/**
	 * Gets the room details.
	 *
	 * @return the room details
	 */
	public List<HsdBookingGuestRoomDetails> getRoomDetails() {
		return roomDetails;
	}

	/**
	 * Sets the room details.
	 *
	 * @param roomDetails the new room details
	 */
	public void setRoomDetails(List<HsdBookingGuestRoomDetails> roomDetails) {
		this.roomDetails = roomDetails;
	}

	/**
	 * Gets the adult count.
	 *
	 * @return the adult count
	 */
	public int getAdultCount() {
		return adultCount;
	}

	/**
	 * Sets the adult count.
	 *
	 * @param adultCount the new adult count
	 */
	public void setAdultCount(int adultCount) {
		this.adultCount = adultCount;
	}

	/**
	 * Gets the child count.
	 *
	 * @return the child count
	 */
	public int getChildCount() {
		return childCount;
	}

	/**
	 * Sets the child count.
	 *
	 * @param childCount the new child count
	 */
	public void setChildCount(int childCount) {
		this.childCount = childCount;
	}

	public Date getCheckinTime() {
		return checkinTime;
	}

	public void setCheckinTime(Date checkinTime) {
		this.checkinTime = checkinTime;
	}

	public Date getCheckoutTime() {
		return checkoutTime;
	}

	public void setCheckoutTime(Date checkoutTime) {
		this.checkoutTime = checkoutTime;
	}

	public String getRoomUpgradeDetail() {
		return roomUpgradeDetail;
	}

	public void setRoomUpgradeDetail(String roomUpgradeDetail) {
		this.roomUpgradeDetail = roomUpgradeDetail;
	}
}