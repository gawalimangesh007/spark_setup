package com.sterling.bookingapi.dto.maximojo.request;

import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

public class RatePlanReq {
	
	/** The room type code. */
	@JacksonXmlProperty(localName = "RoomCode", isAttribute = true)
    private String roomCode;

	/** The rate plan code. */
	@JacksonXmlProperty(localName = "RatePlanCode", isAttribute = true)
    private String ratePlanCode;

	/** The rate. */
	@JacksonXmlElementWrapper(useWrapping=true, localName = "Rates")
	@JacksonXmlProperty(localName = "Rate")
	private List<RateReqDTO> rate;
	
	
	/**
	 * Gets the room type code.
	 *
	 * @return the roomCode
	 */
	public String getRoomCode() {
		return roomCode;
	}

	
	/**
	 * Sets the room type code.
	 *
	 * @param roomCode the roomCode to set
	 */
	public void setRoomCode(String roomCode) {
		this.roomCode = roomCode;
	}
	
	/**
	 * Gets the rate plan code.
	 *
	 * @return the ratePlanCode
	 */
	public String getRatePlanCode() {
		return ratePlanCode;
	}

	/**
	 * Sets the rate plan code.
	 *
	 * @param ratePlanCode the ratePlanCode to set
	 */
	public void setRatePlanCode(String ratePlanCode) {
		this.ratePlanCode = ratePlanCode;
	}
	
	/**
	 * Gets the rate.
	 *
	 * @return the rate
	 */
	public List<RateReqDTO> getRate() {
		return rate;
	}

	/**
	 * Sets the rate.
	 *
	 * @param rate the new rate
	 */
	public void setRate(List<RateReqDTO> rate) {
		this.rate = rate;
	}
}
