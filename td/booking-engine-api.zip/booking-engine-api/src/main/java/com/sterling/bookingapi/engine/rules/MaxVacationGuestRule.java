package com.sterling.bookingapi.engine.rules;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.BooleanUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;

import com.sterling.bookingapi.dto.request.VOConfirmBookingRequest;
import com.sterling.bookingapi.dto.response.HolidayDetails;
import com.sterling.bookingapi.dto.response.VODashboardResponse;
import com.sterling.bookingapi.engine.rules.models.BookingRule;
import com.sterling.bookingapi.engine.rules.models.VOBookingRuleDTO;
import com.sterling.bookingapi.utils.BookingEngineUtils;
import com.sterling.bookingapi.utils.AppConstants.VOBookingType;


@Rule(name="minVacationGuest", description="MIN_VACATION_GUEST_RULE")
public class MaxVacationGuestRule {

	private static final Logger logger = LogManager.getLogger(MaxVacationGuestRule.class);

	@Condition
	public boolean when(@Fact("bookingRequest") VOConfirmBookingRequest req, 
			@Fact("productRules") Map<String, List<VOBookingRuleDTO>> rulesMap,
			@Fact("memberDetail") VODashboardResponse memberDetail,
			@Fact("bookingSeasons") Set<String> bookingSeason) {
		//my rule conditions
		logger.info("=========== MIN_VACATION_GUEST_RULE executing");

		if(!isGuestBooking(req.getBookingType())) {
			return true;
		}
		
		Date reqCheckinDate = BookingEngineUtils.parseDate(req.getCheckInDate(), BookingEngineUtils.SF_DATE_FORMAT);
		Date reqCheckoutDate = BookingEngineUtils.parseDate(req.getCheckOutDate(), BookingEngineUtils.SF_DATE_FORMAT);

		int reqYear = BookingEngineUtils.getYear(reqCheckinDate);
		//Set<String> bookingSeason = BookingEngineUtils.parseSeasons(req.getSeasonDetail());

		List<HolidayDetails> holidayDetails = memberDetail.getHolidayDetails();

		int yrBookingCount = 0;
		int bookedSeasonCount = 0;

		//loop booking history and check the booking is present already with matched criterias
		for (HolidayDetails holidayDetail : holidayDetails) {
			int bookedYr = BookingEngineUtils.getYear(holidayDetail.getCheckinDate());
			if(holidayDetail.getSeason() != null) {
				List<String> bookedSeason = new ArrayList<String>(Arrays.asList(holidayDetail.getSeason().split(",")));
				if(reqYear == bookedYr && holidayDetail.getTravelingType().equalsIgnoreCase("Guest")) {
					yrBookingCount++;

					if(CollectionUtils.containsAny(bookedSeason, bookingSeason)) {
						bookedSeasonCount++;
					}
				}
			}
		}

		logger.debug("=========== MIN_VACATION_GUEST_RULE :: total No. of booking in this year {} is {} of which season count is {}", reqYear, yrBookingCount, bookedSeasonCount);
		
		List<VOBookingRuleDTO> ruleList = rulesMap.get(BookingRule.MIN_VACATION_GUEST_RULE.getRuleName());
		for (VOBookingRuleDTO rule : ruleList) {
			if (BooleanUtils.isTrue(rule.getActive())) {
				boolean havingSeason = BookingEngineUtils.havingAnySeason(
						bookingSeason, rule.getApplicableSeasons());
				int minVacation = Integer.parseInt(rule.getParameters().get(0)
						.getValue()); //minVacation
				int duringSeason = Integer.parseInt(rule.getParameters().get(1)
						.getValue()); //duringSeason
				if (yrBookingCount >= minVacation) {
					logger.debug("=========== MIN_VACATION_GUEST_RULE :: total No. of guest booking is {} which exceeded the configure count {}", yrBookingCount, minVacation);
					return false;
				}
				if (havingSeason) {
					if (bookedSeasonCount >= duringSeason) {
						logger.debug("=========== MIN_VACATION_GUEST_RULE :: total No. of guest booking in season is {} which exceeded the configure count {}", bookedSeasonCount, duringSeason);
						return false;
					}
				}
			}
		}

		return true;
	}

	@Action(order = 1)
	public void then() throws Exception {
		//my actions
		logger.info("################# excecuting action");
	}
	
	private boolean isGuestBooking(String bkType) {
		return VOBookingType.GUEST.getType().equalsIgnoreCase(bkType);
	}
	
}
