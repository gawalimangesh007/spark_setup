
package com.sterling.bookingapi.controller;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.sterling.bookingapi.dto.request.HsdGroupBookingRequestDTO;
import com.sterling.bookingapi.dto.response.ResponseDTO;
import com.sterling.bookingapi.exception.BookingEngineException;
import com.sterling.bookingapi.service.HsdGroupBookingService;
import com.sterling.bookingapi.sf.dto.response.VORecordEntryResponse;
import com.sterling.bookingapi.utils.ResponseUtility;


/**
 * The Class HsdGroupBookingController.
 */
/**
 * @author tcs
 *
 */
@RestController

public class HsdGroupBookingController extends BaseController {

	/** The Constant logger. */
	private static final Logger logger = LogManager.getLogger(HsdGroupBookingController.class);
	
	/** The hsd group booking service. */
	@Autowired
	private HsdGroupBookingService hsdGroupBookingService;
	
	
	/**
	 * Creates the group booking.
	 *
	 * @param request the request
	 * @return the response DTO
	 * @throws BookingEngineException the booking engine exception
	 */
	@ResponseBody
	@RequestMapping(value = "/hsdGroupBooking", method = RequestMethod.POST)
	public ResponseDTO createGroupBooking(@Valid @RequestBody final HsdGroupBookingRequestDTO request) 
						throws BookingEngineException {
		logger.info("HsdGroupBookingController : createGroupBooking : Entered.");
		VORecordEntryResponse hsdLoginEntity = hsdGroupBookingService.createGroupBooking(request); 

		logger.info("HsdGroupBookingController : createGroupBooking : Leaving.");
		return ResponseUtility.constructSuccessRes(hsdLoginEntity);  
	}
		
}
