package com.sterling.bookingapi.dto.response;

import java.util.List;

import com.sterling.bookingapi.sf.dto.response.VOUtilityChargesMasterDTO;

/**
 * @author tcs
 * @version 1.0
 */
public class VOGetAvailabilityResponseDTO {

	private String checkInDate;

	private String checkOutDate;
	
	private String resortId;

	private VOGetApartmentResponseDTO apartmentDetails;

	private VOUtilityChargesMasterDTO utilityChargesMaster;
	
	private List<VOUnitProductPointMatrixResDTO> pointMatrix;
	
	
	public String getResortId() {
		return resortId;
	}

	public void setResortId(String resortId) {
		this.resortId = resortId;
	}

	public List<VOUnitProductPointMatrixResDTO> getPointMatrix() {
		return pointMatrix;
	}

	public void setPointMatrix(List<VOUnitProductPointMatrixResDTO> pointMatrix) {
		this.pointMatrix = pointMatrix;
	}

	/**
	 * @return utilityChargesMaster
	 */
	public VOUtilityChargesMasterDTO getUtilityChargesMaster() {
		return utilityChargesMaster;
	}

	/**
	 * @param utilityChargesMaster
	 * set the utilityChargesMaster
	 */
	public void setUtilityChargesMaster(
			VOUtilityChargesMasterDTO utilityChargesMaster) {
		this.utilityChargesMaster = utilityChargesMaster;
	}

	/**
	 * @return checkInDate
	 */
	public String getCheckInDate() {
		return checkInDate;
	}

	/**
	 * @param checkInDate
	 * set the checkInDate
	 */
	public void setCheckInDate(String checkInDate) {
		this.checkInDate = checkInDate;
	}

	/**
	 * @return checkOutDate
	 */
	public String getCheckOutDate() {
		return checkOutDate;
	}

	/**
	 * @param checkOutDate
	 * set the checkOutDate
	 */
	public void setCheckOutDate(String checkOutDate) {
		this.checkOutDate = checkOutDate;
	}

	/**
	 * @return apartmentDetails
	 */
	public VOGetApartmentResponseDTO getApartmentDetails() {
		if (apartmentDetails == null) {
			this.apartmentDetails = new VOGetApartmentResponseDTO();
		}
		return apartmentDetails;
	}

	/**
	 * @param apartmentDetails
	 * set the apartmentDetails
	 */
	public void setApartmentDetails(VOGetApartmentResponseDTO apartmentDetails) {
		this.apartmentDetails = apartmentDetails;
	}

}
