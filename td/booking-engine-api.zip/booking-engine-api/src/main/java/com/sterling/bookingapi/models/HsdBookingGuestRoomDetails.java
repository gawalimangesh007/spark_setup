package com.sterling.bookingapi.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;
import org.hibernate.validator.constraints.Email;


/**
 * The Class HsdBookingGuestRoomDetails.
 */
/**
 * @author tcs
 *
 */
@Entity
@Table(name = "sh_hsd_booking_guest_room_details")
public class HsdBookingGuestRoomDetails extends BaseModel{
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The rooms id. */
	@Id
	@GeneratedValue( strategy = GenerationType.IDENTITY )
	@Column(name = "room_idx_id", unique = true)
	private int roomsId;
	
	/** The hsd booking details. */
	@ManyToOne
	@Cascade(CascadeType.SAVE_UPDATE)
	@JoinColumn(name="booking_idx_id", unique = false)
	private HsdBookingDetails hsdBookingDetails;
	
	/** The hsd resort room master. */
	@ManyToOne(fetch = FetchType.LAZY,optional = false)
	@JoinColumn(name="resort_room_id",nullable = false)
	private HsdResortRoomMaster hsdResortRoomMaster;
		
	/** The hsd rate plan master. */
	@ManyToOne(fetch = FetchType.LAZY,optional = false)
	@JoinColumn(name="rate_plan_id",nullable = false)
	private HsdRatePlanMaster hsdRatePlanMaster ;
		
	/** The first name. */
	@Column(name = "first_name",nullable = false)
	private String firstName;
	
	/** The last name. */
	@Column(name = "last_name",nullable = false)
	private String lastName;
	
	/** The email id. */
	@Column(name = "email",nullable = false)
	private String emailId;
	
	/** The mobile no. */
	@Column(name = "mobile_no",nullable = false)
	private String mobileNo;
	
	/** The type of stay. */
	@Column(name = "booking_for",nullable = false)
	private String typeOfStay;
			
	/** The room rent. */
	@Column(name = "room_rent",nullable = false)
	private double roomRent;
	
	/** The room count. */
	@Column(name = "room_count",nullable = false)
	private int roomCount;
		
	/** The adult count. */
	@Column(name = "adult_count",nullable = false)
	private int adultCount;
	
	/** The child count. */
	@Column(name = "child_count",nullable = false)
	private int childCount;
		
	/** The extra person child count. */
	@Column(name = "extra_person_child_count",nullable = false)
	private int extraPersonChildCount;
	
	/** The extra person adult count. */
	@Column(name = "extra_person_adult_count",nullable = false)
	private int extraPersonAdultCount;
	
	/** The extra person child cost. */
	@Column(name = "extra_person_cost_child",nullable = false)
	private double extraPersonChildCost;
	
	/** The extra person adult cost. */
	@Column(name = "extra_person_cost_adult",nullable = false)
	private double extraPersonAdultCost;
	
	/** The room upgrade cost summary. */
	@Column(name = "room_upgrade_cost_summary",nullable = false)
	private String roomUpgradeCostSummary;
	
	/** The room upgrade cost. */
	@Column(name = "room_upgrade_cost",nullable = false)
	private double roomUpgradeCost;

	/** The tax details. */
	@Column(name = "tax_details",nullable = false)
	private String taxDetails;

	/**
	 * Gets the rooms id.
	 *
	 * @return the rooms id
	 */
	public int getRoomsId() {
		return roomsId;
	}

	/**
	 * Sets the rooms id.
	 *
	 * @param roomsId the new rooms id
	 */
	public void setRoomsId(int roomsId) {
		this.roomsId = roomsId;
	}

	/**
	 * Gets the hsd booking details.
	 *
	 * @return the hsd booking details
	 */
	public HsdBookingDetails getHsdBookingDetails() {
		return hsdBookingDetails;
	}

	/**
	 * Sets the hsd booking details.
	 *
	 * @param hsdBookingDetails the new hsd booking details
	 */
	public void setHsdBookingDetails(HsdBookingDetails hsdBookingDetails) {
		this.hsdBookingDetails = hsdBookingDetails;
	}

	/**
	 * Gets the hsd resort room master.
	 *
	 * @return the hsd resort room master
	 */
	public HsdResortRoomMaster getHsdResortRoomMaster() {
		return hsdResortRoomMaster;
	}

	/**
	 * Sets the hsd resort room master.
	 *
	 * @param hsdResortRoomMaster the new hsd resort room master
	 */
	public void setHsdResortRoomMaster(HsdResortRoomMaster hsdResortRoomMaster) {
		this.hsdResortRoomMaster = hsdResortRoomMaster;
	}

	/**
	 * Gets the hsd rate plan master.
	 *
	 * @return the hsd rate plan master
	 */
	public HsdRatePlanMaster getHsdRatePlanMaster() {
		return hsdRatePlanMaster;
	}

	/**
	 * Sets the hsd rate plan master.
	 *
	 * @param hsdRatePlanMaster the new hsd rate plan master
	 */
	public void setHsdRatePlanMaster(HsdRatePlanMaster hsdRatePlanMaster) {
		this.hsdRatePlanMaster = hsdRatePlanMaster;
	}

	/**
	 * Gets the first name.
	 *
	 * @return the first name
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * Sets the first name.
	 *
	 * @param firstName the new first name
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * Gets the last name.
	 *
	 * @return the last name
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * Sets the last name.
	 *
	 * @param lastName the new last name
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * Gets the email id.
	 *
	 * @return the email id
	 */
	public String getEmailId() {
		return emailId;
	}

	/**
	 * Sets the email id.
	 *
	 * @param emailId the new email id
	 */
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	/**
	 * Gets the mobile no.
	 *
	 * @return the mobile no
	 */
	public String getMobileNo() {
		return mobileNo;
	}

	/**
	 * Sets the mobile no.
	 *
	 * @param mobileNo the new mobile no
	 */
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	/**
	 * Gets the type of stay.
	 *
	 * @return the type of stay
	 */
	public String getTypeOfStay() {
		return typeOfStay;
	}

	/**
	 * Sets the type of stay.
	 *
	 * @param typeOfStay the new type of stay
	 */
	public void setTypeOfStay(String typeOfStay) {
		this.typeOfStay = typeOfStay;
	}

	/**
	 * Gets the room rent.
	 *
	 * @return the room rent
	 */
	public double getRoomRent() {
		return roomRent;
	}

	/**
	 * Sets the room rent.
	 *
	 * @param roomRent the new room rent
	 */
	public void setRoomRent(double roomRent) {
		this.roomRent = roomRent;
	}

	/**
	 * Gets the room count.
	 *
	 * @return the room count
	 */
	public int getRoomCount() {
		return roomCount;
	}

	/**
	 * Sets the room count.
	 *
	 * @param roomCount the new room count
	 */
	public void setRoomCount(int roomCount) {
		this.roomCount = roomCount;
	}

	/**
	 * Gets the adult count.
	 *
	 * @return the adult count
	 */
	public int getAdultCount() {
		return adultCount;
	}

	/**
	 * Sets the adult count.
	 *
	 * @param adultCount the new adult count
	 */
	public void setAdultCount(int adultCount) {
		this.adultCount = adultCount;
	}

	/**
	 * Gets the child count.
	 *
	 * @return the child count
	 */
	public int getChildCount() {
		return childCount;
	}

	/**
	 * Sets the child count.
	 *
	 * @param childCount the new child count
	 */
	public void setChildCount(int childCount) {
		this.childCount = childCount;
	}

	/**
	 * Gets the extra person child count.
	 *
	 * @return the extra person child count
	 */
	public int getExtraPersonChildCount() {
		return extraPersonChildCount;
	}

	/**
	 * Sets the extra person child count.
	 *
	 * @param extraPersonChildCount the new extra person child count
	 */
	public void setExtraPersonChildCount(int extraPersonChildCount) {
		this.extraPersonChildCount = extraPersonChildCount;
	}

	/**
	 * Gets the extra person adult count.
	 *
	 * @return the extra person adult count
	 */
	public int getExtraPersonAdultCount() {
		return extraPersonAdultCount;
	}

	/**
	 * Sets the extra person adult count.
	 *
	 * @param extraPersonAdultCount the new extra person adult count
	 */
	public void setExtraPersonAdultCount(int extraPersonAdultCount) {
		this.extraPersonAdultCount = extraPersonAdultCount;
	}

	/**
	 * Gets the extra person child cost.
	 *
	 * @return the extra person child cost
	 */
	public double getExtraPersonChildCost() {
		return extraPersonChildCost;
	}

	/**
	 * Sets the extra person child cost.
	 *
	 * @param extraPersonChildCost the new extra person child cost
	 */
	public void setExtraPersonChildCost(double extraPersonChildCost) {
		this.extraPersonChildCost = extraPersonChildCost;
	}

	/**
	 * Gets the extra person adult cost.
	 *
	 * @return the extra person adult cost
	 */
	public double getExtraPersonAdultCost() {
		return extraPersonAdultCost;
	}

	/**
	 * Sets the extra person adult cost.
	 *
	 * @param extraPersonAdultCost the new extra person adult cost
	 */
	public void setExtraPersonAdultCost(double extraPersonAdultCost) {
		this.extraPersonAdultCost = extraPersonAdultCost;
	}

	public String getRoomUpgradeCostSummary() {
		return roomUpgradeCostSummary;
	}

	public void setRoomUpgradeCostSummary(String roomUpgradeCostSummary) {
		this.roomUpgradeCostSummary = roomUpgradeCostSummary;
	}

	public double getRoomUpgradeCost() {
		return roomUpgradeCost;
	}

	public void setRoomUpgradeCost(double roomUpgradeCost) {
		this.roomUpgradeCost = roomUpgradeCost;
	}

	public String getTaxDetails() {
		return taxDetails;
	}

	public void setTaxDetails(String taxDetails) {
		this.taxDetails = taxDetails;
	}
}