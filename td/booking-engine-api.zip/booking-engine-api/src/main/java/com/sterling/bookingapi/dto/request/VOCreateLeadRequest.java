package com.sterling.bookingapi.dto.request;

import java.io.Serializable;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author tcs
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class VOCreateLeadRequest implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String leadId;
	private String title;
	
	@NotEmpty(message="firstName should not be empty")
	@Pattern(regexp="^[A-Za-z]*$", message="firstName should not contains number/special charactors")
	private String firstName;

	@NotEmpty(message="lastName should not be empty")
	@Pattern(regexp="^[A-Za-z]*$", message="lastName should not contains number/special charactors")
	private String lastName;
	
	@NotEmpty(message="mobilePhone should not be empty")
	@Size(min = 10,max = 15)
	private String mobilePhone;

	private String postalCode;
	
	@NotEmpty(message="email should not be empty")
	@Email(message="Invalid email format")
	private String email;

	private String ageGroup;
	private String city;
	private String maritalStatus;
	private String noOfChildren;
	private String educations;
	private String occupation;
	private String monthlyHouseholdIncome;
	private String yearlyHolidayFrequency;
	private String creditCardType;
	private String carOwned;
	private Boolean home;
	private Boolean gymMembership;
	private Boolean lEDTV40InchAbove;
	private Boolean dSLRCamera;
	private Boolean clubMembership;
	/**
	 * @return  title
	 */
	
	private String webProductCode;
	private String productName;
	private String webSeasonCode;
	private String webRoomType;
	private Double webProductCost;
	private Double webProductPoints;
	private String webProductPlanId;
	private String addressLine1;
	private String billingState;
	private String country;
	
	//private String otp;
	//private String otpUniqueId;

	
	public String getTitle() {
		return title;
	}

	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	/**
	 * @param title
	 * set the  title
	 */
	public void setTitle(String title) {
		this.title = title;
	}
	/**
	 * @return firstname
	 */
	public String getFirstName() {
		return firstName;
	}
	/**
	 * @param firstName
	 * set the firstname
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	/**
	 * @return lastname
	 */
	public String getLastName() {
		return lastName;
	}
	/**
	 * @param lastName
	 * set the lastName
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	/**
	 * @return mobilePhone
	 */
	public String getMobilePhone() {
		return mobilePhone;
	}
	/**
	 * @param mobilePhone
	 * set the mobilePhone
	 */
	public void setMobilePhone(String mobilePhone) {
		this.mobilePhone = mobilePhone;
	}
	/**
	 * @return email
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * @param email
	 * set the email
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * @return ageGroup
	 */
	public String getAgeGroup() {
		return ageGroup;
	}
	/**
	 * @param ageGroup
	 * set the ageGroup
	 */
	public void setAgeGroup(String ageGroup) {
		this.ageGroup = ageGroup;
	}
	/**
	 * @return city
	 */
	public String getCity() {
		return city;
	}
	/**
	 * @param city
	 * set the city
	 */
	public void setCity(String city) {
		this.city = city;
	}
	
	/**
	 * @return maritalStatus
	 */
	public String getMaritalStatus() {
		return maritalStatus;
	}
	/**
	 * @param maritalStatus
	 *  set the maritalStatus
	 */
	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}
	/**
	 * @return noOfChildren
	 */
	public String getNoOfChildren() {
		return noOfChildren;
	}
	/**
	 * @param noOfChildren
	 * set the noOfChildren
	 */
	public void setNoOfChildren(String noOfChildren) {
		this.noOfChildren = noOfChildren;
	}
	/**
	 * @return educations
	 */
	public String getEducations() {
		return educations;
	}
	/**
	 * @param educations
	 * set the educations
	 */
	public void setEducations(String educations) {
		this.educations = educations;
	}
	/**
	 * @return occupation
	 */
	public String getOccupation() {
		return occupation;
	}
	/**
	 * @param occupation
	 * set the occupation
	 */
	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}
	/**
	 * @return monthlyHouseholdIncome
	 */
	public String getMonthlyHouseholdIncome() {
		return monthlyHouseholdIncome;
	}
	/**
	 * @param monthlyHouseholdIncome
	 * set the monthlyHouseholdIncome
	 */
	public void setMonthlyHouseholdIncome(String monthlyHouseholdIncome) {
		this.monthlyHouseholdIncome = monthlyHouseholdIncome;
	}
	/**
	 * @return yearlyHolidayFrequency
	 */
	public String getYearlyHolidayFrequency() {
		return yearlyHolidayFrequency;
	}
	/**
	 * @param yearlyHolidayFrequency
	 * set the yearlyHolidayFrequency
	 */
	public void setYearlyHolidayFrequency(String yearlyHolidayFrequency) {
		this.yearlyHolidayFrequency = yearlyHolidayFrequency;
	}
	/**
	 * @return creditCardType
	 */
	public String getCreditCardType() {
		return creditCardType;
	}
	/**
	 * @param creditCardType
	 * set the creditCardType
	 */
	public void setCreditCardType(String creditCardType) {
		this.creditCardType = creditCardType;
	}
	/**
	 * @return carOwned
	 */
	public String getCarOwned() {
		return carOwned;
	}
	/**
	 * @param carOwned
	 * set the carOwned
	 */
	public void setCarOwned(String carOwned) {
		this.carOwned = carOwned;
	}
	/**
	 * @return home
	 */
	public Boolean getHome() {
		return home;
	}
	/**
	 * @param home
	 * set the home
	 */
	public void setHome(Boolean home) {
		this.home = home;
	}
	/**
	 * @return gymMembership
	 */
	public Boolean getGymMembership() {
		return gymMembership;
	}
	/**
	 * @param gymMembership
	 * set the gymMembership
	 */
	public void setGymMembership(Boolean gymMembership) {
		this.gymMembership = gymMembership;
	}
	/**
	 * @return lEDTV40InchAbove
	 */
	public Boolean getlEDTV40InchAbove() {
		return lEDTV40InchAbove;
	}
	/**
	 * @param lEDTV40InchAbove
	 * set the lEDTV40InchAbove
	 */
	public void setlEDTV40InchAbove(Boolean lEDTV40InchAbove) {
		this.lEDTV40InchAbove = lEDTV40InchAbove;
	}
	/**
	 * @return dSLRCamera
	 */ 
	public Boolean getdSLRCamera() {
		return dSLRCamera;
	}
	/**
	 * @param dSLRCamera
	 * set the dSLRCamera
	 */
	public void setdSLRCamera(Boolean dSLRCamera) {
		this.dSLRCamera = dSLRCamera;
	}
	/** 
	 * @return clubMembership
	 */
	public Boolean getClubMembership() {
		return clubMembership;
	}
	/**
	 * @param clubMembership
	 * set the clubMembership
	 */
	public void setClubMembership(Boolean clubMembership) {
		this.clubMembership = clubMembership;
	}
	public String getWebProductCode() {
		return webProductCode;
	}
	public void setWebProductCode(String webProductCode) {
		this.webProductCode = webProductCode;
	}
	public String getWebSeasonCode() {
		return webSeasonCode;
	}
	public void setWebSeasonCode(String webSeasonCode) {
		this.webSeasonCode = webSeasonCode;
	}
	public String getWebRoomType() {
		return webRoomType;
	}
	public void setWebRoomType(String webRoomType) {
		this.webRoomType = webRoomType;
	}
	public Double getWebProductCost() {
		return webProductCost;
	}
	public void setWebProductCost(Double webProductCost) {
		this.webProductCost = webProductCost;
	}
	public Double getWebProductPoints() {
		return webProductPoints;
	}
	public void setWebProductPoints(Double webProductPoints) {
		this.webProductPoints = webProductPoints;
	}
	public String getLeadId() {
		return leadId;
	}
	public void setLeadId(String leadId) {
		this.leadId = leadId;
	}
	public String getWebProductPlanId() {
		return webProductPlanId;
	}
	public void setWebProductPlanId(String webProductPlanId) {
		this.webProductPlanId = webProductPlanId;
	}
	public String getPostalCode() {
		return postalCode;
	}
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}
	public String getBillingState() {
		return billingState;
	}
	public void setBillingState(String billingState) {
		this.billingState = billingState;
	}
	/*public String getOtp() {
		return otp;
	}
	public void setOtp(String otp) {
		this.otp = otp;
	}
	public String getOtpUniqueId() {
		return otpUniqueId;
	}
	public void setOtpUniqueId(String otpUniqueId) {
		this.otpUniqueId = otpUniqueId;
	}*/
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getAddressLine1() {
		return addressLine1;
	}
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}
}
