package com.sterling.bookingapi.dto.response;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class InterestDetailsDTO implements Serializable  {

	private static final long serialVersionUID = 1L;

	private String interestDetails;
	private String travellerInfo;
	
	public String getInterestDetails() {
		return interestDetails;
	}
	public void setInterestDetails(String interestDetails) {
		this.interestDetails = interestDetails;
	}
	public String getTravellerInfo() {
		return travellerInfo;
	}
	public void setTravellerInfo(String travellerInfo) {
		this.travellerInfo = travellerInfo;
	}
}
