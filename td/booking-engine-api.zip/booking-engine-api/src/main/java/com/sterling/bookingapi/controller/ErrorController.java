package com.sterling.bookingapi.controller;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.sterling.bookingapi.dto.response.ResponseDTO;
import com.sterling.bookingapi.exception.BookingEngineException;
import com.sterling.bookingapi.exception.ErrorCodes;
import com.sterling.bookingapi.exception.SalesForceException;
import com.sterling.bookingapi.exception.ValidationErrorBuilder;
import com.sterling.bookingapi.utils.BookingEngineUtils;
import com.sterling.bookingapi.utils.MessageConstants;


/**
 * The Class ErrorController.
 */
/**
 * @author tcs
 *
 */
@RestControllerAdvice
public class ErrorController extends ResponseEntityExceptionHandler{

	/**
	 * Handle conflict.
	 *
	 * @param ex the ex
	 * @param request the request
	 * @return the response entity
	 */
	/** The Constant logger. */
	private static final Logger logger = LogManager.getLogger(ErrorController.class);
	
	@ExceptionHandler(value = { SalesForceException.class})
	public ResponseDTO handleConflict(Exception ex, WebRequest request) {
		logger.info(" ErrorController : handleConflict : Entered.");
		ResponseDTO response = new ResponseDTO();
		response.setStatus(MessageConstants.FAIL);
		response.setStatusMessage(ex.getMessage());
		
		if (ex instanceof SalesForceException) {
			SalesForceException exception = (SalesForceException) ex;
			response.setStatusCode(exception.getErrCode());
			String errLabel = exception.getErrLabel();
			response.setErrors(errLabel);
			response.setApiError(getApiErrorCode(errLabel));
			
		}
		logger.info(" ErrorController : bookingEngineInternalException : Leaving.");
		return response;
    }

	/**
	 * Booking engine internal exception.
	 *
	 * @param ex the ex
	 * @return the response DTO
	 */
	@ExceptionHandler(value = {BookingEngineException.class})
	@ResponseStatus(value = HttpStatus.OK)
    public @ResponseBody ResponseDTO bookingEngineInternalException(Exception ex) {
		logger.info(" ErrorController : bookingEngineInternalException : Entered.");
		ResponseDTO response = new ResponseDTO();
		response.setStatus(MessageConstants.FAIL);
		response.setStatusMessage(ex.getMessage());
		
		if (ex instanceof BookingEngineException) {
			BookingEngineException exception = (BookingEngineException) ex;
			response.setStatusCode(exception.getErrCode()); 
			String errLabel = exception.getErrLabel();
			response.setErrors(errLabel);
			response.setApiError(getApiErrorCode(errLabel));
		}
		logger.info(" ErrorController : bookingEngineInternalException : Leaving.");
		return response;
	}
	
	@ExceptionHandler(value = {Exception.class})
	@ResponseStatus(value = HttpStatus.OK)
    public @ResponseBody ResponseDTO generalException(Exception ex) {
		logger.info(" ErrorController : generalException: Entered.");
		logger.error(" ErrorController : generalException: trace.", ex);
		
		ResponseDTO response = new ResponseDTO();
		response.setStatus(MessageConstants.FAIL);
		response.setStatusMessage(ex.getMessage());
		response.setApiError(getApiErrorCode(null));
		
		logger.info(" ErrorController : generalException : Leaving.");
		return response;
	}
	
	/* (non-Javadoc)
 * @see org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler#handleMethodArgumentNotValid(org.springframework.web.bind.MethodArgumentNotValidException, org.springframework.http.HttpHeaders, org.springframework.http.HttpStatus, org.springframework.web.context.request.WebRequest)
 */
@Override
//	@ExceptionHandler(MethodArgumentNotValidException.class)
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
	logger.info(" ErrorController : handleMethodArgumentNotValid : Entered.");
		ResponseDTO response = new ResponseDTO();
		response.setStatus(MessageConstants.FAIL);
		response.setStatusMessage(MessageConstants.REQUEST_VALIDATION_FAILS);
		response.setErrors(ValidationErrorBuilder.fromBindingErrors(ex.getBindingResult()));
	
		logger.info(" ErrorController : handleMethodArgumentNotValid : Leaving.");
		return handleExceptionInternal(ex, response, headers, status, request);
	}


	private String getApiErrorCode(String errLabel) {
		String code = null;
		if(errLabel != null) {
			code = BookingEngineUtils.getErrorMessage(errLabel);
		}
		
		if(code == null) {
			code = BookingEngineUtils.getErrorMessage(ErrorCodes.GENERAL_TECH_ERROR);
		}
		
		return code;
	}
	
	
}
