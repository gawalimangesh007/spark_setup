package com.sterling.bookingapi.dto.request;

import java.util.List;


/**
 * The Class HsdResortRoomTypeDTO.
 */
/**
 * @author tcs
 *
 */
public class HsdCreateResortRoomTypeDTO {

	private HsdResortRoomDTO roomDetails;
	
	//private boolean status;
	
	private boolean allResortFlag;
	
	private boolean allRateFlag;
	
	private List<HsdResortInfoDTO> resortDetails;
	
	private List<HsdResortRateplanDTO> rateDetails;

	
	public HsdResortRoomDTO getRoomDetails() {
		return roomDetails;
	}

	public void setRoomDetails(HsdResortRoomDTO roomDetails) {
		this.roomDetails = roomDetails;
	}

	/*public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}*/

	/**
	 * @return the allResortFlag
	 */
	public boolean isAllResortFlag() {
		return allResortFlag;
	}

	/**
	 * @param allResortFlag the allResortFlag to set
	 */
	public void setAllResortFlag(boolean allResortFlag) {
		this.allResortFlag = allResortFlag;
	}

	/**
	 * @return the resortDetails
	 */
	public List<HsdResortInfoDTO> getResortDetails() {
		return resortDetails;
	}

	/**
	 * @param resortDetails the resortDetails to set
	 */
	public void setResortDetails(List<HsdResortInfoDTO> resortDetails) {
		this.resortDetails = resortDetails;
	}

	public boolean isAllRateFlag() {
		return allRateFlag;
	}

	public void setAllRateFlag(boolean allRateFlag) {
		this.allRateFlag = allRateFlag;
	}

	public List<HsdResortRateplanDTO> getRateDetails() {
		return rateDetails;
	}

	public void setRateDetails(List<HsdResortRateplanDTO> rateDetails) {
		this.rateDetails = rateDetails;
	}
	
}
