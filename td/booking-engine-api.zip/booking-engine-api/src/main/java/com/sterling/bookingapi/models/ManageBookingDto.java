package com.sterling.bookingapi.models;

import com.sterling.bookingapi.dto.request.VOLeadRegReq;

public class ManageBookingDto {
	private String mobileNo;
	private String bookingNo;
	private VOLeadRegReq vOLeadRegReq;
	private String memberId;
	private String userType;
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getBookingNo() {
		return bookingNo;
	}
	public void setBookingNo(String bookingNo) {
		this.bookingNo = bookingNo;
	}
	public VOLeadRegReq getvOLeadRegReq() {
		return vOLeadRegReq;
	}
	public void setvOLeadRegReq(VOLeadRegReq vOLeadRegReq) {
		this.vOLeadRegReq = vOLeadRegReq;
	}
	public String getMemberId() {
		return memberId;
	}
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	public ManageBookingDto(String mobileNo, String bookingNo, VOLeadRegReq vOLeadRegReq, String memberId,
			String userType) {
		super();
		this.mobileNo = mobileNo;
		this.bookingNo = bookingNo;
		this.vOLeadRegReq = vOLeadRegReq;
		this.memberId = memberId;
		this.userType = userType;
	}
	public ManageBookingDto() {
		super();
	}
	
	
	
	
	

}
