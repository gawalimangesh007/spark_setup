package com.sterling.bookingapi.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.sterling.bookingapi.dto.request.DTCTransactionRequestDTO;
import com.sterling.bookingapi.dto.request.VoCaptureASFPaymentRequestDTO;
import com.sterling.bookingapi.dto.request.VoCaptureEMIPaymentRequestDTO;
import com.sterling.bookingapi.dto.request.VoEssentialsRequest;
import com.sterling.bookingapi.dto.request.VoGetDashboardAccountRequestDTO;
import com.sterling.bookingapi.dto.request.VoReferAFriendRequest;
import com.sterling.bookingapi.dto.response.DTCResponseWrapper;
import com.sterling.bookingapi.dto.response.ResponseDTO;
import com.sterling.bookingapi.exception.BookingEngineException;
import com.sterling.bookingapi.exception.SalesForceException;
import com.sterling.bookingapi.service.DTCService;
import com.sterling.bookingapi.service.VODashboardService;
import com.sterling.bookingapi.service.impl.VODashboardServiceImpl;
import com.sterling.bookingapi.utils.ResponseUtility;

/**
 * @author tcs
 *
 */
@RestController
@RequestMapping(value = "/dtc")
public class DTCController extends BaseController {
	
	/** The Constant logger. */
	private static final Logger logger = LogManager.getLogger(DTCController.class);
	private static final String HEADER_CACHE = "must-revalidate, post-check=0, pre-check=0";
	private static final String MEDIA_TYPE_PDF = "application/pdf";
	
	@Autowired
	private DTCService dtcService;
		
	/**
	 * @return the dtcService
	 */
	public DTCService getDtcService() {
		return dtcService;
	}
	/**
	 * @param dtcService the dtcService to set
	 */
	public void setDtcService(DTCService dtcService) {
		this.dtcService = dtcService;
	}

	/**
	 * @param reqDTO
	 * @return dashboard account details
	 * @throws SalesForceException
	 */
	@RequestMapping(value = "/summary", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO dtcSummary(@RequestBody DTCTransactionRequestDTO reqDTO) throws SalesForceException {
		// reqDTO.setSfToken(sfToken);
		logger.info("DTCController : lapsedPoints : Entered.");
		ResponseEntity<DTCResponseWrapper> entity  = dtcService.getDTCSummary(reqDTO);
		logger.info("DTCController : lapsedPoints : Leaving.");
		return ResponseUtility.constructSuccessRes(entity.getBody());
	
	}

	/**
	 * Download pdf.
	 *
	 */
	@RequestMapping(value = "/getDTCPdf", method = RequestMethod.POST)
	public ResponseEntity<byte[]> downloadPdf(@RequestBody DTCTransactionRequestDTO reqDTO) throws BookingEngineException {
		logger.info("DTCController : downloadPdf : Entered.");
		
		HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.parseMediaType(MEDIA_TYPE_PDF));
	    
	    String filename = "DTC_"+reqDTO.getDtcType().toUpperCase()+".pdf";
	    
	    byte[] contents = dtcService.getDtcPDFContents(reqDTO);
	    
	    headers.setContentDispositionFormData(filename, filename);
	    
	    headers.setCacheControl(HEADER_CACHE);
	    
		ResponseEntity<byte[]> response = new ResponseEntity<>(contents, headers, HttpStatus.OK);
		
		logger.info("DTCController : downloadPdf : Leaving.");
		return response;
	}
}
