package com.sterling.bookingapi.dto.response;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


/**
 * The Class LapsedPointsResponseDTO.
 *
 * @author tcs
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class LapsedPointsResponseDTO implements Serializable {
	
	
	private static final long serialVersionUID = 1L;
	
	private Integer entitlementYear;
	
	private Double lapsedPoints;
	
	private Double lapsedUtilizedPoints;
	
	private Double balanceLapsedPoints;

	public Integer getEntitlementYear() {
		return entitlementYear;
	}

	public void setEntitlementYear(Integer entitlementYear) {
		this.entitlementYear = entitlementYear;
	}

	public Double getLapsedPoints() {
		return lapsedPoints;
	}

	public void setLapsedPoints(Double lapsedPoints) {
		this.lapsedPoints = lapsedPoints;
	}

	public Double getLapsedUtilizedPoints() {
		return lapsedUtilizedPoints;
	}

	public void setLapsedUtilizedPoints(Double lapsedUtilizedPoints) {
		this.lapsedUtilizedPoints = lapsedUtilizedPoints;
	}

	public Double getBalanceLapsedPoints() {
		return balanceLapsedPoints;
	}

	public void setBalanceLapsedPoints(Double balanceLapsedPoints) {
		this.balanceLapsedPoints = balanceLapsedPoints;
	}
	
}