package com.sterling.bookingapi.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;


/**
 * The Class HsdMappingPackOfferPromo.
 */
/**
 * @author tcs
 *
 */
@Entity
@Table(name = "sh_hsd_map_pkg_ofr_promo")//delete
public class HsdMappingPackOfferPromo extends BaseModel{
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@GeneratedValue( strategy = GenerationType.IDENTITY )
	@Column(name = "map_id", unique = true)
	private int id;
	
	/** The resort id. */
	@Column(name = "resort_id",nullable = true)
	private String resortId;
	
	/** The room type id. */
	@Column(name = "room_type_id",nullable = true)
	private String roomTypeId;
	
	/** The hsd packages. */
	@ManyToOne
	@Cascade(CascadeType.SAVE_UPDATE)
	@JoinColumn(name="package_id", unique = false)
	private HsdPackages hsdPackages;
	
	/** The hsd offers and promos. */
	@ManyToOne
	@Cascade(CascadeType.SAVE_UPDATE)
	@JoinColumn(name="offer_promo_id",nullable = true)
	private HsdOffersAndPromos hsdOffersAndPromos;
	
	/** The active. */
	@Column(name = "status",nullable = false)
	private boolean active;

	/**
	 * Gets the active.
	 *
	 * @return the active
	 */
	public boolean getActive() {
		return active;
	}

	/**
	 * Sets the active.
	 *
	 * @param active the new active
	 */
	public void setActive(boolean active) {
		this.active = active;
	}

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * Gets the resort id.
	 *
	 * @return the resort id
	 */
	public String getResortId() {
		return resortId;
	}

	/**
	 * Sets the resort id.
	 *
	 * @param resortId the new resort id
	 */
	public void setResortId(String resortId) {
		this.resortId = resortId;
	}

	/**
	 * Gets the room type id.
	 *
	 * @return the room type id
	 */
	public String getRoomTypeId() {
		return roomTypeId;
	}

	/**
	 * Sets the room type id.
	 *
	 * @param roomTypeId the new room type id
	 */
	public void setRoomTypeId(String roomTypeId) {
		this.roomTypeId = roomTypeId;
	}


	/**
	 * Gets the hsd packages.
	 *
	 * @return the hsd packages
	 */
	public HsdPackages getHsdPackages() {
		return hsdPackages;
	}

	/**
	 * Sets the hsd packages.
	 *
	 * @param hsdPackages the new hsd packages
	 */
	public void setHsdPackages(HsdPackages hsdPackages) {
		this.hsdPackages = hsdPackages;
	}

	/**
	 * Gets the hsd offers and promos.
	 *
	 * @return the hsd offers and promos
	 */
	public HsdOffersAndPromos getHsdOffersAndPromos() {
		return hsdOffersAndPromos;
	}

	/**
	 * Sets the hsd offers and promos.
	 *
	 * @param hsdOffersAndPromos the new hsd offers and promos
	 */
	public void setHsdOffersAndPromos(HsdOffersAndPromos hsdOffersAndPromos) {
		this.hsdOffersAndPromos = hsdOffersAndPromos;
	}
	
}
