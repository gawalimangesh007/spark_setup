package com.sterling.bookingapi.dto.response;

import java.io.Serializable;


/**
 * @author tcs
 * @version 1.0
 */
public class Preferences implements Serializable {

	private static final long serialVersionUID = 1L;

	private String foodPreference;
	private String allergies;
	private String roomPreferences;
	private String additionalInformation;
	
	/**
	 * @return foodPreference
	 */
	public String getFoodPreference() {
		return foodPreference;
	}
	/**
	 * @param foodPreference
	 * set the foodPreference
	 */
	public void setFoodPreference(String foodPreference) {
		this.foodPreference = foodPreference;
	}
	/**
	 * @return allergies
	 */
	public String getAllergies() {
		return allergies;
	}
	/**
	 * @param allergies
	 * set the foodPreference
	 */
	public void setAllergies(String allergies) {
		this.allergies = allergies;
	}
	/**
	 * @return roomPreferences
	 */
	public String getRoomPreferences() {
		return roomPreferences;
	}
	/**
	 * @param roomPreferences
	 * set the roomPreferences
	 */
	public void setRoomPreferences(String roomPreferences) {
		this.roomPreferences = roomPreferences;
	}
	/**
	 * @return additionalInformation
	 */
	public String getAdditionalInformation() {
		return additionalInformation;
	}
	/**
	 * @param additionalInformation
	 * set the additionalInformation
	 */
	public void setAdditionalInformation(String additionalInformation) {
		this.additionalInformation = additionalInformation;
	}
	
}
