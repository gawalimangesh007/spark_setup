package com.sterling.bookingapi.dto.request;

import java.util.Date;
import java.util.List;

import javax.persistence.Enumerated;
import javax.validation.constraints.NotNull;

import com.sterling.bookingapi.dto.ResortRoomMappingDTO;
import com.sterling.bookingapi.utils.AppConstants;


/**
 * The Class UpdateHsdOffersAndPromosRequestDTO.
 */
/**
 * @author tcs
 *
 */
public class UpdateHsdOffersAndPromosRequestDTO{
	
	/** The offer promo id. */
	@NotNull
	private Integer offerPromoId;
	
	/** The offer promo type. */
	@Enumerated
	private AppConstants.Type offerPromoType;
	
	/** The discount code. */
	@Enumerated
	private AppConstants.DiscountCode discountCode;
	
	/** The offer promo category. */
	private String offerPromoCategory;
	
	/** The name. */
	@NotNull 
	private String name;
	
	/** The details. */
	private String details;
	
	
	/** The sell start date. */
	private Date sellStartDate;
	 
	/** The sell end date. */
	private Date sellEndDate;
	 
	/** The booking start date. */
	private Date bookingStartDate;
	 
	/** The booking end date. */
	private Date bookingEndDate;
	
	 
	/** The code. */
	private String code;
	 
	/** The discount amt. */
	private Double discountAmt;
	 
	/** The max discount amt. */
	private Double maxDiscountAmt;
	 
	/** The terms and conditions. */
	private String termsAndConditions;
	
	/** The conditions. */
	private List<HsdOffersAndPromosConditionsMappingDetailsRequestDTO> conditions;
	
	/** The restort room type. */
	private List<ResortRoomMappingDTO> restortRoomType;
	
	/**
	 * Gets the offer promo id.
	 *
	 * @return the offerPromoId
	 */
	public Integer getOfferPromoId() {
		return offerPromoId;
	}
	
	/**
	 * Gets the restort room type.
	 *
	 * @return the restortRoomType
	 */
	public List<ResortRoomMappingDTO> getRestortRoomType() {
		return restortRoomType;
	}
	
	/**
	 * Sets the restort room type.
	 *
	 * @param restortRoomType the restortRoomType to set
	 */
	public void setRestortRoomType(
			List<ResortRoomMappingDTO> restortRoomType) {
		this.restortRoomType = restortRoomType;
	}
	
	/**
	 * Sets the offer promo id.
	 *
	 * @param offerPromoId the offerPromoId to set
	 */
	public void setOfferPromoId(Integer offerPromoId) {
		this.offerPromoId = offerPromoId;
	}
	
	/**
	 * Gets the offer promo type.
	 *
	 * @return the offerPromoType
	 */
	public AppConstants.Type getOfferPromoType() {
		return offerPromoType;
	}
	
	/**
	 * Sets the offer promo type.
	 *
	 * @param offerPromoType the offerPromoType to set
	 */
	public void setOfferPromoType(AppConstants.Type offerPromoType) {
		this.offerPromoType = offerPromoType;
	}
	
	/**
	 * Gets the offer promo category.
	 *
	 * @return the offerPromoCategory
	 */
	public String getOfferPromoCategory() {
		return offerPromoCategory;
	}
	
	/**
	 * Sets the offer promo category.
	 *
	 * @param offerPromoCategory the offerPromoCategory to set
	 */
	public void setOfferPromoCategory(String offerPromoCategory) {
		this.offerPromoCategory = offerPromoCategory;
	}
	
	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * Sets the name.
	 *
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * Gets the details.
	 *
	 * @return the details
	 */
	public String getDetails() {
		return details;
	}
	
	/**
	 * Sets the details.
	 *
	 * @param details the details to set
	 */
	public void setDetails(String details) {
		this.details = details;
	}
	
	/**
	 * Gets the sell start date.
	 *
	 * @return the sellStartDate
	 */
	public Date getSellStartDate() {
		return sellStartDate;
	}
	
	/**
	 * Sets the sell start date.
	 *
	 * @param sellStartDate the sellStartDate to set
	 */
	public void setSellStartDate(Date sellStartDate) {
		this.sellStartDate = sellStartDate;
	}
	
	/**
	 * Gets the sell end date.
	 *
	 * @return the sellEndDate
	 */
	public Date getSellEndDate() {
		return sellEndDate;
	}
	
	/**
	 * Sets the sell end date.
	 *
	 * @param sellEndDate the sellEndDate to set
	 */
	public void setSellEndDate(Date sellEndDate) {
		this.sellEndDate = sellEndDate;
	}
	
	/**
	 * Gets the booking start date.
	 *
	 * @return the bookingStartDate
	 */
	public Date getBookingStartDate() {
		return bookingStartDate;
	}
	
	/**
	 * Sets the booking start date.
	 *
	 * @param bookingStartDate the bookingStartDate to set
	 */
	public void setBookingStartDate(Date bookingStartDate) {
		this.bookingStartDate = bookingStartDate;
	}
	
	/**
	 * Gets the booking end date.
	 *
	 * @return the bookingEndDate
	 */
	public Date getBookingEndDate() {
		return bookingEndDate;
	}
	
	/**
	 * Sets the booking end date.
	 *
	 * @param bookingEndDate the bookingEndDate to set
	 */
	public void setBookingEndDate(Date bookingEndDate) {
		this.bookingEndDate = bookingEndDate;
	}
	
	/**
	 * Gets the code.
	 *
	 * @return the code
	 */
	public String getCode() {
		return code;
	}
	
	/**
	 * Sets the code.
	 *
	 * @param code the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}
	
	/**
	 * Gets the discount amt.
	 *
	 * @return the discountAmt
	 */
	public Double getDiscountAmt() {
		return discountAmt;
	}
	
	/**
	 * Sets the discount amt.
	 *
	 * @param discountAmt the discountAmt to set
	 */
	public void setDiscountAmt(Double discountAmt) {
		this.discountAmt = discountAmt;
	}
	
	/**
	 * Gets the discount code.
	 *
	 * @return the DiscountCode
	 */
	public AppConstants.DiscountCode getDiscountCode() {
		return discountCode;
	}
	
	/**
	 * Sets the discount code.
	 *
	 * @param discountCode the new discount code
	 */
	public void setDiscountCode(AppConstants.DiscountCode discountCode) {
		this.discountCode = discountCode;
	}
	
	/**
	 * Gets the max discount amt.
	 *
	 * @return the maxDiscountAmt
	 */
	public Double getMaxDiscountAmt() {
		return maxDiscountAmt;
	}
	
	/**
	 * Sets the max discount amt.
	 *
	 * @param maxDiscountAmt the maxDiscountAmt to set
	 */
	public void setMaxDiscountAmt(Double maxDiscountAmt) {
		this.maxDiscountAmt = maxDiscountAmt;
	}
	
	/**
	 * Gets the terms and conditions.
	 *
	 * @return the terms and conditions
	 */
	public String getTermsAndConditions() {
		return termsAndConditions;
	}
	
	/**
	 * Sets the terms and conditions.
	 *
	 * @param termsAndConditions the new terms and conditions
	 */
	public void setTermsAndConditions(String termsAndConditions) {
		this.termsAndConditions = termsAndConditions;
	}
	
	/**
	 * Gets the conditions.
	 *
	 * @return the conditions
	 */
	public List<HsdOffersAndPromosConditionsMappingDetailsRequestDTO> getConditions() {
		return conditions;
	}
	
	/**
	 * Sets the conditions.
	 *
	 * @param conditions the new conditions
	 */
	public void setConditions(
			List<HsdOffersAndPromosConditionsMappingDetailsRequestDTO> conditions) {
		this.conditions = conditions;
	}
	
	
}
