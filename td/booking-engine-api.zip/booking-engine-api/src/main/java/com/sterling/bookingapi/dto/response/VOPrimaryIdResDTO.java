package com.sterling.bookingapi.dto.response;

import java.io.Serializable;

public class VOPrimaryIdResDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String id;
	private String val;
	
	/**
	 * @return id
	 */
	public String getId() {
		return id;
	}
	/**
	 * @param id
	 * set the id
	 */
	public void setId(String id) {
		this.id = id;
	}
	/**
	 * @return val
	 */
	public String getVal() {
		return val;
	}
	/**
	 * @param val
	 * set the val
	 */
	public void setVal(String val) {
		this.val = val;
	}
	
}
