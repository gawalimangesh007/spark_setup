package com.sterling.bookingapi.dto.maximojo.request;

import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class GuestCountsReqDTO.
 */
/**
 * @author tcs
 *
 */
public class GuestCountsReqDTO {

	/** The is per room. */
	@JacksonXmlProperty(localName = "IsPerRoom", isAttribute = true)
    private boolean isPerRoom;
	
	/** The guest count. */
	@JacksonXmlElementWrapper(useWrapping=false)
	@JacksonXmlProperty(localName = "GuestCount")
	private List<GuestCountReqDTO> guestCount;

	

	/**
	 * Gets the guest count.
	 *
	 * @return the guestCount
	 */
	public List<GuestCountReqDTO> getGuestCount() {
		return guestCount;
	}

	/**
	 * Sets the guest count.
	 *
	 * @param guestCount the guestCount to set
	 */
	public void setGuestCount(List<GuestCountReqDTO> guestCount) {
		this.guestCount = guestCount;
	}

	/**
	 * Gets the checks if is per room.
	 *
	 * @return the isPerRoom
	 */
	public boolean getIsPerRoom() {
		return isPerRoom;
	}

	/**
	 * Sets the checks if is per room.
	 *
	 * @param isPerRoom the isPerRoom to set
	 */
	public void setIsPerRoom(boolean isPerRoom) {
		this.isPerRoom = isPerRoom;
	}
	
	
}
