package com.sterling.bookingapi.auth.filter;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.GenericFilterBean;

import com.sterling.bookingapi.auth.bean.UserAuthentication;
import com.sterling.bookingapi.auth.impl.ServerUtils;
import com.sterling.bookingapi.auth.impl.TokenAuthenticationService;
import com.sterling.bookingapi.config.ApplicationContextProvider;
import com.sterling.bookingapi.dto.response.ResponseDTO;
import com.sterling.bookingapi.exception.ErrorCodes;
import com.sterling.bookingapi.utils.BookingEngineUtils;
import com.sterling.bookingapi.utils.ResponseUtility;

/**
 * @author tcs
 *
 */
public class AuthFilter extends GenericFilterBean {
	private Logger filterLogger = LogManager.getLogger(AuthFilter.class);

	@Autowired
	private TokenAuthenticationService tokenAuthenticationService;

	public AuthFilter() {
		tokenAuthenticationService = (TokenAuthenticationService) ApplicationContextProvider.getApplicationContext()
				.getBean("tokenAuthenticationServiceImpl");
	}
	
	/* (non-Javadoc)
	 * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest, javax.servlet.ServletResponse, javax.servlet.FilterChain)
	 */
	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain filterChain) throws IOException, ServletException {
		HttpServletRequest httpRequest = (HttpServletRequest) request;
		HttpServletResponse httpResponse = (HttpServletResponse) response;
		
		UserAuthentication auth = (UserAuthentication) tokenAuthenticationService.getAuthentication(httpRequest, httpResponse);
		SecurityContextHolder.getContext().setAuthentication(auth);
		
		filterLogger.info("roles ############# {}", auth.getAuthorities());
		
		if(auth.isAuthenticated())
			filterChain.doFilter(request, response);
		else{
			
			filterLogger.info("ACCESS_DENIED.{}",  BookingEngineUtils.getInputLogsSimple("ip, info, server", auth.getIpAddress(), auth.getInfo(), ServerUtils.convertHTTPServletRequestToHostMap(request)));
			
			ResponseDTO dto = ResponseUtility.constructErrorRes("Invalid Session", 401, ErrorCodes.INVALID_SESSION);
			response.setCharacterEncoding("UTF-8");
			response.setContentType("application/json");
			response.getWriter().write(BookingEngineUtils.convertObjectToString(dto));
		}
		
	}

}
