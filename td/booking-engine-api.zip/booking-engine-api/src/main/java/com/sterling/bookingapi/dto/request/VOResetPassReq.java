package com.sterling.bookingapi.dto.request;

import java.io.Serializable;

import javax.validation.constraints.NotEmpty;

import com.sterling.bookingapi.utils.AppConstants.RegisterUserType;


/**
 * @author tcs
 *
 */
public class VOResetPassReq implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@NotEmpty(message = "Email is mandatory")
	private String email;
	
	@NotEmpty(message = "OTP number is mandatory")
	private String otp;
	
	@NotEmpty(message = "password is mandotory")
	private String newPassword;
	
	@NotEmpty(message = "password is mandotory")
	private String confirmPassword;
	
	private String currentPassword;
	
	private String webStatus;
	
	private RegisterUserType userType;

	/**
	 * @return otp
	 */
	public String getOtp() {
		return otp;
	}

	/**
	 * @param otp
	 * set the otp
	 */
	public void setOtp(String otp) {
		this.otp = otp;
	}

	/**
	 * @return newPassword
	 */
	public String getNewPassword() {
		return newPassword;
	}

	/**
	 * @param newPassword
	 * set the newPassword
	 */
	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}

	/**
	 * @return confirmPassword
	 */
	public String getConfirmPassword() {
		return confirmPassword;
	}

	/**
	 * @param confirmPassword
	 * set the confirmPassword
	 */
	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

	/**
	 * @return email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email
	 * set the email
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * @return currentPassword
	 */
	public String getCurrentPassword() {
		return currentPassword;
	}

	/**
	 * @param currentPassword
	 * set the currentPassword
	 */
	public void setCurrentPassword(String currentPassword) {
		this.currentPassword = currentPassword;
	}

	public String getWebStatus() {
		return webStatus;
	}

	public void setWebStatus(String webStatus) {
		this.webStatus = webStatus;
	}

	public RegisterUserType getUserType() {
		return userType;
	}

	public void setUserType(RegisterUserType userType) {
		this.userType = userType;
	}
	
}
