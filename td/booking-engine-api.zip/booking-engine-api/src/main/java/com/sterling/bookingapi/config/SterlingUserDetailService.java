package com.sterling.bookingapi.config;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

public class SterlingUserDetailService implements UserDetailsService {

	/** The Constant logger. */
	private static final Logger logger = LogManager.getLogger(SterlingUserDetailService.class);

	
	@Override
	public UserDetails loadUserByUsername(String arg0)
			throws UsernameNotFoundException {
		
		logger.info("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ coming to user detail service");
		
		
		return null;
	}

}
