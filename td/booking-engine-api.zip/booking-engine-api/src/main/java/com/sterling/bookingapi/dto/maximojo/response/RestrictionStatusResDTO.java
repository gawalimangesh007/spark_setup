package com.sterling.bookingapi.dto.maximojo.response;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class RestrictionStatusResDTO.
 * @author tcs
 * @version 1.0
 */
public class RestrictionStatusResDTO {

	/** The status. */
	@JacksonXmlProperty(localName = "Status", isAttribute = true)
	private String status;

	/** The restriction. */
	@JacksonXmlProperty(localName = "Restriction", isAttribute = true)
    private String restriction;

	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * Sets the status.
	 *
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * Gets the restriction.
	 *
	 * @return the restriction
	 */
	public String getRestriction() {
		return restriction;
	}

	/**
	 * Sets the restriction.
	 *
	 * @param restriction the restriction to set
	 */
	public void setRestriction(String restriction) {
		this.restriction = restriction;
	}
	
	
}
