package com.sterling.bookingapi.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;


/**
 * The Class HsdBookingCalcDetails.
 */
/**
 * @author tcs
 *
 */
@Entity
@Table(name = "sh_hsd_booking_calc_details")
public class HsdBookingCalcDetails extends BaseModel{
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The calc id. */
	@Id
	@GeneratedValue( strategy = GenerationType.IDENTITY )
	@Column(name = "calc_idx_id", unique = true)
	private int calcId;
	
	/** The hsd booking details. */
	@OneToOne
	@JoinColumn(name="booking_idx_id")
	private HsdBookingDetails hsdBookingDetails;
	
	/** The room rental amount. */
	@Column(name = "room_rental_amount",nullable = false)
	private double roomRentalAmount;
	
	/** The extra person cost. */
	@Column(name = "extra_person_cost",nullable = true)
	private double extraPersonCost;
	
	/** The tax details. */
	@Column(name = "tax_details",nullable = false)
	private String taxDetails;
	
	/** The tax amount. */
	@Column(name = "tax_amount",nullable = false)
	private double taxAmount;
	
	/** The enhancement cost summary. */
	@Column(name = "enhancement_cost_summary",nullable = false)
	private String enhancementCostSummary;
	
	/** The enhancement cost. */
	@Column(name = "enhancement_cost",nullable = false)
	private double enhancementCost;
	
	/** The room upgrade cost summary. */
	/*@Column(name = "room_upgrade_cost_summary",nullable = false)
	private String roomUpgradeCostSummary;*/
	
	/** The room upgrade cost. */
	@Column(name = "room_upgrade_cost",nullable = false)
	private double roomUpgradeCost;
			
	/** The sub total cost. */
	@Column(name = "sub_total_cost",nullable = false)
	private double subTotalCost;
	
	/** The discount amount. */
	@Column(name = "discount_amount",nullable = false)
	private double discountAmount;
	
	/** The total cost. */
	@Column(name = "total_cost",nullable = false)
	private double totalCost;
	
	/** The currency code. */
	@Column(name = "currency_code",nullable = false)
	private String currencyCode;

	/**
	 * Gets the calc id.
	 *
	 * @return the calc id
	 */
	public int getCalcId() {
		return calcId;
	}

	/**
	 * Sets the calc id.
	 *
	 * @param calcId the new calc id
	 */
	public void setCalcId(int calcId) {
		this.calcId = calcId;
	}

	/**
	 * Gets the hsd booking details.
	 *
	 * @return the hsd booking details
	 */
	public HsdBookingDetails getHsdBookingDetails() {
		return hsdBookingDetails;
	}

	/**
	 * Sets the hsd booking details.
	 *
	 * @param hsdBookingDetails the new hsd booking details
	 */
	public void setHsdBookingDetails(HsdBookingDetails hsdBookingDetails) {
		this.hsdBookingDetails = hsdBookingDetails;
	}

	/**
	 * Gets the room rental amount.
	 *
	 * @return the room rental amount
	 */
	public double getRoomRentalAmount() {
		return roomRentalAmount;
	}

	/**
	 * Sets the room rental amount.
	 *
	 * @param roomRentalAmount the new room rental amount
	 */
	public void setRoomRentalAmount(double roomRentalAmount) {
		this.roomRentalAmount = roomRentalAmount;
	}

	/**
	 * Gets the extra person cost.
	 *
	 * @return the extra person cost
	 */
	public double getExtraPersonCost() {
		return extraPersonCost;
	}

	/**
	 * Sets the extra person cost.
	 *
	 * @param extraPersonCost the new extra person cost
	 */
	public void setExtraPersonCost(double extraPersonCost) {
		this.extraPersonCost = extraPersonCost;
	}

	/**
	 * Gets the tax details.
	 *
	 * @return the tax details
	 */
	public String getTaxDetails() {
		return taxDetails;
	}

	/**
	 * Sets the tax details.
	 *
	 * @param taxDetails the new tax details
	 */
	public void setTaxDetails(String taxDetails) {
		this.taxDetails = taxDetails;
	}

	/**
	 * Gets the tax amount.
	 *
	 * @return the tax amount
	 */
	public double getTaxAmount() {
		return taxAmount;
	}

	/**
	 * Sets the tax amount.
	 *
	 * @param taxAmount the new tax amount
	 */
	public void setTaxAmount(double taxAmount) {
		this.taxAmount = taxAmount;
	}

	/**
	 * Gets the enhancement cost summary.
	 *
	 * @return the enhancement cost summary
	 */
	public String getEnhancementCostSummary() {
		return enhancementCostSummary;
	}

	/**
	 * Sets the enhancement cost summary.
	 *
	 * @param enhancementCostSummary the new enhancement cost summary
	 */
	public void setEnhancementCostSummary(String enhancementCostSummary) {
		this.enhancementCostSummary = enhancementCostSummary;
	}

	/**
	 * Gets the enhancement cost.
	 *
	 * @return the enhancement cost
	 */
	public double getEnhancementCost() {
		return enhancementCost;
	}

	/**
	 * Sets the enhancement cost.
	 *
	 * @param enhancementCost the new enhancement cost
	 */
	public void setEnhancementCost(double enhancementCost) {
		this.enhancementCost = enhancementCost;
	}

	/**
	 * Gets the sub total cost.
	 *
	 * @return the sub total cost
	 */
	public double getSubTotalCost() {
		return subTotalCost;
	}

	/**
	 * Sets the sub total cost.
	 *
	 * @param subTotalCost the new sub total cost
	 */
	public void setSubTotalCost(double subTotalCost) {
		this.subTotalCost = subTotalCost;
	}

	/**
	 * Gets the discount amount.
	 *
	 * @return the discount amount
	 */
	public double getDiscountAmount() {
		return discountAmount;
	}

	/**
	 * Sets the discount amount.
	 *
	 * @param discountAmount the new discount amount
	 */
	public void setDiscountAmount(double discountAmount) {
		this.discountAmount = discountAmount;
	}

	/**
	 * Gets the total cost.
	 *
	 * @return the total cost
	 */
	public double getTotalCost() {
		return totalCost;
	}

	/**
	 * Sets the total cost.
	 *
	 * @param totalCost the new total cost
	 */
	public void setTotalCost(double totalCost) {
		this.totalCost = totalCost;
	}

	/**
	 * Gets the currency code.
	 *
	 * @return the currency code
	 */
	public String getCurrencyCode() {
		return currencyCode;
	}

	/**
	 * Sets the currency code.
	 *
	 * @param currencyCode the new currency code
	 */
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	/*public String getRoomUpgradeCostSummary() {
		return roomUpgradeCostSummary;
	}

	public void setRoomUpgradeCostSummary(String roomUpgradeCostSummary) {
		this.roomUpgradeCostSummary = roomUpgradeCostSummary;
	}*/

	public double getRoomUpgradeCost() {
		return roomUpgradeCost;
	}

	public void setRoomUpgradeCost(double roomUpgradeCost) {
		this.roomUpgradeCost = roomUpgradeCost;
	}
}
