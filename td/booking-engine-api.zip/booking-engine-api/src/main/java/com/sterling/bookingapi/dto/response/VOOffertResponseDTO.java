package com.sterling.bookingapi.dto.response;

import java.io.Serializable;

public class VOOffertResponseDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String offerId;
	private String offerName;
	private Boolean webOfferRedeemOnline;
	private String startDate;
	private String endDate;
	private Double offer;
	private String offerMeasurement;
	private String productId;
	private String productCode;
	private String productPlanId;
	private String productPlan;
	private String downPaymentId;
	private String downPaymentName;
	private String downPaymentPercent;
		

	public Double getOffer() {
		return offer;
	}
	public void setOffer(Double offer) {
		this.offer = offer;
	}
	public String getOfferMeasurement() {
		return offerMeasurement;
	}
	public void setOfferMeasurement(String offerMeasurement) {
		this.offerMeasurement = offerMeasurement;
	}
	public String getOfferId() {
		return offerId;
	}
	public void setOfferId(String offerId) {
		this.offerId = offerId;
	}
	public String getOfferName() {
		return offerName;
	}
	public void setOfferName(String offerName) {
		this.offerName = offerName;
	}
	
	public Boolean getWebOfferRedeemOnline() {
		return webOfferRedeemOnline;
	}
	public void setWebOfferRedeemOnline(Boolean webOfferRedeemOnline) {
		this.webOfferRedeemOnline = webOfferRedeemOnline;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getProductPlan() {
		return productPlan;
	}
	public void setProductPlan(String productPlan) {
		this.productPlan = productPlan;
	}
	public String getDownPaymentPercent() {
		return downPaymentPercent;
	}
	public void setDownPaymentPercent(String downPaymentPercent) {
		this.downPaymentPercent = downPaymentPercent;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getProductPlanId() {
		return productPlanId;
	}
	public void setProductPlanId(String productPlanId) {
		this.productPlanId = productPlanId;
	}
	public String getDownPaymentId() {
		return downPaymentId;
	}
	public void setDownPaymentId(String downPaymentId) {
		this.downPaymentId = downPaymentId;
	}
	public String getDownPaymentName() {
		return downPaymentName;
	}
	public void setDownPaymentName(String downPaymentName) {
		this.downPaymentName = downPaymentName;
	}
	
}
