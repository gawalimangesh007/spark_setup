package com.sterling.bookingapi.dto.maximojo.response;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class ErrorsResDTO.
 * @author tcs
 * @version 1.0
 */
public class ErrorsResDTO {
	
	/** The xmlns. */
	@JacksonXmlProperty(localName = "xmlns", isAttribute = true)
    private String xmlns;
	
	/** The error. */
	@JacksonXmlProperty(localName = "Error")
	private ErrorResDTO error;

	/**
	 * Gets the xmlns.
	 *
	 * @return the xmlns
	 */
	public String getXmlns() {
		return xmlns;
	}

	/**
	 * Sets the xmlns.
	 *
	 * @param xmlns the xmlns to set
	 */
	public void setXmlns(String xmlns) {
		this.xmlns = xmlns;
	}

	/**
	 * Gets the error.
	 *
	 * @return the error
	 */
	public ErrorResDTO getError() {
		return error;
	}

	/**
	 * Sets the error.
	 *
	 * @param error the error to set
	 */
	public void setError(ErrorResDTO error) {
		this.error = error;
	}

}
