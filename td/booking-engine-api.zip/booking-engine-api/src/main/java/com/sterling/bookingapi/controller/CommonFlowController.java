package com.sterling.bookingapi.controller;

import java.lang.reflect.Field;
import java.util.List;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.sterling.bookingapi.aop.LoggingAspect;
import com.sterling.bookingapi.dto.FileContentDTO;
import com.sterling.bookingapi.dto.FileUploadDTO;
import com.sterling.bookingapi.dto.request.ActionInfo;
import com.sterling.bookingapi.dto.request.AnalyticsReq;
import com.sterling.bookingapi.dto.request.EventInfo;
import com.sterling.bookingapi.dto.request.OTPRequestDTO;
import com.sterling.bookingapi.dto.request.PageInfo;
import com.sterling.bookingapi.dto.request.VOFeedbackRequest;
import com.sterling.bookingapi.dto.request.VOLeadRegReq;
import com.sterling.bookingapi.dto.request.VoGetAccountRequestDTO;
import com.sterling.bookingapi.dto.request.VoGetDashboardAccountRequestDTO;
import com.sterling.bookingapi.dto.request.WebTracker;
import com.sterling.bookingapi.dto.request.WebTrackerErrorDTO;
import com.sterling.bookingapi.dto.response.AnalyticsRes;
import com.sterling.bookingapi.dto.response.CityMasterDTO;
import com.sterling.bookingapi.dto.response.OTPResponseDTO;
import com.sterling.bookingapi.dto.response.ResponseDTO;
import com.sterling.bookingapi.dto.response.VOBookingDetailResponse;
import com.sterling.bookingapi.dto.response.VOCustomerPersonalDetails;
import com.sterling.bookingapi.dto.response.WebTrackerReportResponseDTO;
import com.sterling.bookingapi.exception.SalesForceException;
import com.sterling.bookingapi.models.ManageBookingDto;
import com.sterling.bookingapi.service.FileUploadService;
import com.sterling.bookingapi.service.OTPFlowService;
import com.sterling.bookingapi.service.VOBookingService;
import com.sterling.bookingapi.service.VODashboardService;
import com.sterling.bookingapi.service.VacationOwnershipService;
import com.sterling.bookingapi.service.WebTrackerService;
import com.sterling.bookingapi.sf.dto.request.SFHsdBookingRequest;
import com.sterling.bookingapi.sf.dto.request.VOBookingDetails;
import com.sterling.bookingapi.sf.dto.response.VOCustomerDetailResponse;
import com.sterling.bookingapi.sf.hsd.dto.response.HsdMemberResponseDTO;
import com.sterling.bookingapi.sf.hsd.service.HsdUserService;
import com.sterling.bookingapi.sf.hsd.service.SFHsdBookingService;
import com.sterling.bookingapi.utils.AppConstants;
import com.sterling.bookingapi.utils.BookingEngineUtils;
import com.sterling.bookingapi.utils.MessageConstants;
import com.sterling.bookingapi.utils.ResponseUtility;

@RestController
@RequestMapping(value = {"/otp", "/common"})
public class CommonFlowController extends BaseController {
	

	/** The Constant logger. */
	private static final Logger logger = LogManager.getLogger(CommonFlowController.class);
	
	@Autowired
	private OTPFlowService service;
	@Autowired
	public VODashboardService dashboardService;

	@Autowired
	private VacationOwnershipService vacationOwnershipService;
	
	@Autowired
	private WebTrackerService webTrackerService;
	
	@Autowired
	private FileUploadService fileUploadService;
	
	@Autowired
	private CacheManager cacheMngr;
	
	@Autowired
	private HsdUserService hsdUserService;
	@Autowired
	private SFHsdBookingService hsdBookingService;
	@Autowired
	private VOBookingService voBookingService;

	
	/**
	 * @param vacationOwnershipService
	 * set the vacationOwnershipService
	 */
	public void setVacationOwnershipService(
			VacationOwnershipService vacationOwnershipService) {
		this.vacationOwnershipService = vacationOwnershipService;
	}
	
	/**
	 * @param req
	 * @return success after sending otp to mobile
	 * @throws SalesForceException
	 */
	
	@RequestMapping(value = {"/sendRegistrationOTP", "/sendOTP"}, method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO sendRegistrationOTP(@RequestBody  @Valid OTPRequestDTO req ) {
		logger.info("OTPController : sendRegistrationOTP : Entered.");
		OTPResponseDTO result = service.sendOTP(req);
		logger.info("OTPController : sendRegistrationOTP : Leaving.");
		return ResponseUtility.constructSuccessRes(result);	
	}

	@RequestMapping(value = {"/manageBookingUsingOtp", "/manageBookingThroughOtp"}, method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO manageBookingUsingOtp(@RequestBody  @Valid OTPRequestDTO req ) {
		logger.info("OTPController : sendRegistrationOTP : Entered.");
		OTPResponseDTO result = null;
		SFHsdBookingRequest sFHsdBookingRequest=hsdBookingService.getBookingDetailsForManageBooking(req.getCvNumber());
		if(sFHsdBookingRequest!=null) {
			HsdMemberResponseDTO hsdUser = hsdUserService.getHsdUserByEmailOrMobile(null, req.getMobileNo());

			if(hsdUser!=null) {
				hsdUser.setMobileNo(req.getMobileNo());
				result = service.manageBookingSendOtp(hsdUser);
				result.setUserType("hsdUser");
				return ResponseUtility.constructSuccessRes(result);	
			}else {
				return ResponseUtility.constructErrorRes("Please enter valid mobile number",5014);	
			}
		}else {
			VOBookingDetails vOBookingDetails= voBookingService.getBookingDetails(req.getCvNumber());
			VOCustomerDetailResponse vOCustomerDetailResponse= vacationOwnershipService.getSFCustomerDetailsByContract(vOBookingDetails.getContractId());
			if(vOCustomerDetailResponse!=null && req.getMobileNo().equals(vOCustomerDetailResponse.getMobileNumber())) {
				HsdMemberResponseDTO hsdUser=new HsdMemberResponseDTO();
				hsdUser.setMobileNo(req.getMobileNo());
				hsdUser.setFirstName(vOCustomerDetailResponse.getFirstName());
				result = service.manageBookingSendOtp(hsdUser);
				result.setUserType("voUser");
				return ResponseUtility.constructSuccessRes(result);	

			}else {
				return ResponseUtility.constructErrorRes("Please enter valid mobile number",5014);	

			}

		}		
		
	}


	@RequestMapping(value = {"/manageBooking", "/manageBookingUsingMobile"}, method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO manageBooking(@RequestBody  @Valid ManageBookingDto manageBookingDto ) {
		logger.info("SFHsdBookingController : manageBooking : Entering.");
		ResponseEntity<?> result = vacationOwnershipService.validateRegOTP(manageBookingDto.getvOLeadRegReq());
		VOCustomerDetailResponse vOCustomerDetailResponse=null;
		HsdMemberResponseDTO hsdUser=null;
		if(result!=null && manageBookingDto.getUserType().equals("voUser")) {
			VOBookingDetails vOBookingDetails= voBookingService.getBookingDetails(manageBookingDto.getBookingNo());
			vOCustomerDetailResponse=vacationOwnershipService.getSFCustomerDetailsByContract(vOBookingDetails.getContractId());
			vOCustomerDetailResponse.setPassword(BookingEngineUtils.decryptPass(vOCustomerDetailResponse.getPassword()));
			return ResponseUtility.constructSuccessRes(vOCustomerDetailResponse);
		}else if(result!=null && manageBookingDto.getUserType().equals("hsdUser")) {
			hsdUser = hsdUserService.getHsdUserByEmailOrMobile(null, manageBookingDto.getMobileNo());
			if(hsdUser!=null) {
				hsdUser.setMobileNo(manageBookingDto.getMobileNo());
			}
			return ResponseUtility.constructSuccessRes(hsdUser);
		}else {
			return ResponseUtility.constructErrorRes("Please enter a valid OTP",6300);
		}

	}
	@RequestMapping(value = "/getDashboardAccountDetailsForManageBooking", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO getDashboardAccountDetails(@RequestBody VoGetDashboardAccountRequestDTO reqDTO) throws SalesForceException {
		// reqDTO.setSfToken(sfToken);
		logger.info("VODashboardController : getDashboardAccountDetails : Entered.");
		ResponseEntity<?> dashboardAccountData = dashboardService.getDashboardAccountData(reqDTO);
		logger.info("VODashboardController : getDashboardAccountDetails : Leaving.");
		return ResponseUtility.constructSuccessRes(dashboardAccountData.getBody());
	}

	
	@RequestMapping(value ="/validateLeadRegOTP", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO validateRegOTP(@RequestBody @Valid VOLeadRegReq req){
		logger.info("VacationOwnershipController : validateRegOTP : Entered.");
		ResponseEntity<?> result = vacationOwnershipService.validateRegOTP(req);
		logger.info("VacationOwnershipController : validateRegOTP : Leaving.");
		return ResponseUtility.constructSuccessRes(result.getBody());
		
	}

	@RequestMapping(value ="/analytics", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO validateRegOTP(@RequestBody @Valid AnalyticsReq req){
		logger.info("VacationOwnershipController : validateRegOTP : Entered.");
		
		logger.info("VacationOwnershipController : validateRegOTP : Leaving.");
		AnalyticsRes data = new AnalyticsRes();
		data.setMessage(req.getMessage());
		data.setType(req.getType());
		data.setUrl(req.getUrl());

		return ResponseUtility.constructSuccessRes(data);
		
	}
	
	@RequestMapping(value ="/webtracker", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO webtracker(@RequestBody @Valid WebTracker req){
		logger.info("CommonFlowController : webtracker : Entered.");
		
		for (Field field : req.getClass().getDeclaredFields()) {
			//do stuff
			System.out.println(field);
			
			}
		
		String browsernamenversion = req.getBrowsernamenversion();
		String osnamenversion = req.getOsnamenversion();
		String devicenamenversion = req.getDevicenamenversion();
		String timestamp = BookingEngineUtils.formatDate(req.getTimestamp(), BookingEngineUtils.DATE_TIME_FORMAT);
		
		PageInfo pageinfo = req.getPageinfo();
		String pageid = pageinfo.getPageid() ;
		String isloggedin = pageinfo.getIsloggedin();
		String username = pageinfo.getUsername();
		String userid = pageinfo.getUserid();
		String pagename = pageinfo.getPagename();
		String refererDomain = pageinfo.getRefererDomain();
		
		
		ActionInfo actionInfo = pageinfo.getActionInfo();
		long actionrefid = actionInfo.getActionrefid();
		String actionid = actionInfo.getActionid();
		String actiontype = actionInfo.getActiontype();
		String actiondesc = actionInfo.getActiondesc();
		String chanel = actionInfo.getChanel();
		String resort = actionInfo.getResort();
		String startedate = actionInfo.getStartedate();
		String enddate = actionInfo.getEnddate();
		String noofguest = actionInfo.getNoofguest();
		String eventtype = actionInfo.getEventtype();
		String name = actionInfo.getName();
		String email = actionInfo.getEmail();
		String mobile = actionInfo.getMobile();
		
		String ratePlan = actionInfo.getRatePlan();
		String roomType = actionInfo.getRoomType();
		String promoCode = actionInfo.getPromoCode();
		
		EventInfo eventInfo = pageinfo.getEventInfo();
		long eventrefid = eventInfo.getEventrefid();
		String eventid = eventInfo.getEventid();
		String eventtypeE = eventInfo.getEventtype();
		String eventdec = eventInfo.getEventdec();
		String value = eventInfo.getValue();
		
		webTrackerService.recordWebTracking(req);
		
		logger.info(LoggingAspect.WEB_TRACKER_MARKER_CSV, "Web Tracker", 
				browsernamenversion, osnamenversion, devicenamenversion, timestamp,
				pageid, isloggedin, username, userid, pagename, refererDomain,
				actionrefid, actionid, actiontype, actiondesc, chanel, resort, startedate, enddate, noofguest, eventtype, name, email, mobile, ratePlan, roomType, promoCode, 
				eventrefid, eventid, eventtypeE, eventdec, value);
		
		logger.info("CommonFlowController : webtracker : Leaving.");
		
		return ResponseUtility.constructSuccessRes(req);
		
	}

	@RequestMapping(value ="/webtracker/error", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO webtrackerError(@RequestBody @Valid WebTrackerErrorDTO req){
		logger.info("CommonFlowController : webtrackerError : Entered.");
		
		String url = req.getUrl();
		String message = req.getMessage();
		String type = req.getType();
		String stacktrace = req.getStacktrace();
		String cause = req.getCause();
		
		webTrackerService.recordWebTrackingError(req);
		
		logger.info(LoggingAspect.WEB_TRACKER_MARKER_CSV, "Web Tracker Error", 
				url, message, type, stacktrace, cause);
		
		logger.info("CommonFlowController : webtrackerError : Leaving.");
		
		return ResponseUtility.constructSuccessRes(req);
	
	}
	
	@RequestMapping(value ="/webtracker/searchReport", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO webtrackerSearchReport(@RequestBody @Valid WebTracker req){
		logger.info("CommonFlowController : webtrackerSearch : Entered.");
		ResponseDTO response = new ResponseDTO();
		WebTrackerReportResponseDTO webTrackerReportResponseDTO=new WebTrackerReportResponseDTO();
		
		webTrackerReportResponseDTO = webTrackerService.getWebtrackerSearchReport(req);
		response.setData(webTrackerReportResponseDTO);
		response.setStatusMessage(MessageConstants.WEBTRACKER_BYUSERID_FETCHED_SUCCESSFULLY);
		
		logger.info("CommonFlowController : webtrackerSearch : Entered.");
		return response;
	}
	
	@RequestMapping(value = "/feedback", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO createFeedback(@RequestBody @Valid VOFeedbackRequest req) throws SalesForceException {
		// reqDTO.setSfToken(sfToken);
		logger.info("CommonFlowController : createFeedback : Entered.");
		ResponseEntity<?> result = vacationOwnershipService.createFeedback(req);
		logger.info("CommonFlowController : createFeedback : Leaving.");
		return ResponseUtility.constructSuccessRes(result.getBody());
	}
	
	@RequestMapping(value = "/uploadFile", method = RequestMethod.POST,  produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseDTO uploadingFile(@RequestParam(name ="uploadingFiles") MultipartFile[] uploadingFiles, @RequestParam String user) {
		
		logger.info("uploadingPost : uploadFile : entered ");

		try {
			return fileUploadService.uploadFile(uploadingFiles, user);
		} catch (Exception e1) {
			logger.error("aws upload : Error : ", e1);
		}
		return null;
	}

	@RequestMapping(value = "/profileImage/uploadEncodedFiles", method = RequestMethod.POST,  produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseDTO uploadingEncodedProfileImageFile(@RequestBody(required=false) FileUploadDTO[] requests) {
		
		logger.info("uploadingPost : uploadEncodedFiles : entered");
		
		try {
			List<String> uploadEncodedFile = fileUploadService.profileImgUploadEncodedFile(requests);
			updateProfileImageInSF(requests,uploadEncodedFile);
			return  ResponseUtility.constructSuccessRes(uploadEncodedFile);
		} catch (Exception e1) {
			logger.error("aws upload : Error : ", e1);
		}
		return null;
	}
	
	@RequestMapping(value = "/uploadEncodedFiles", method = RequestMethod.POST,  produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseDTO uploadingEncodedFile(@RequestBody(required=false) FileUploadDTO[] requests) {
		
		logger.info("uploadingPost : uploadEncodedFiles : entered");
		
		try {
			List<String> uploadEncodedFile = fileUploadService.uploadEncodedFile(requests);
			return  ResponseUtility.constructSuccessRes(uploadEncodedFile);
		} catch (Exception e1) {
			logger.error("aws upload : Error : ", e1);
		}
		return null;
	}

	@RequestMapping(value = "/commonUploadFiles", method = RequestMethod.POST,  produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseDTO uploadingEncodedFile(@RequestBody FileUploadDTO[] requests, String path) {
		
		logger.info("uploadingPost : uploadEncodedFiles : entered");
		
		try {
			return fileUploadService.commonUploadFiles(requests, path);
		} catch (Exception e1) {
			logger.error("aws upload : Error : ", e1);
		}
		return null;
	}

	@RequestMapping(value = "/download", method = RequestMethod.POST,  produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseDTO uploadingEncodedFile(@RequestParam("filePath") String requests, @RequestParam("user") String user) {
		
		logger.info("uploadingPost : download : entered");
		
		try {
			FileContentDTO downloadFile = fileUploadService.downloadFile(user, requests);
			return ResponseUtility.constructSuccessRes(downloadFile);
		} catch (Exception e1) {
			logger.error("aws upload : Error : ", e1.getMessage());
		}
		return null;
	}

	@RequestMapping(value = "/clearSeason", method = RequestMethod.POST,  produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseDTO clearSeason() {
		
		logger.info("uploadingPost : clearSeason : entered");
		
		try {
			Cache cache = cacheMngr.getCache(AppConstants.cacheGroups.seasonDataCache.name());
			cache.clear();
			return ResponseUtility.constructSuccessRes(MessageConstants.SUCCESS);
		} catch (Exception e1) {
			logger.error("aws upload : Error : ", e1);
		}
		return null;
	}

	@RequestMapping(value = "/statesByCountry", method = RequestMethod.POST,  produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseDTO statesByCountry(@RequestParam("country") String country) {
		logger.info("VacationOwnershipController : statesByCountry : Entered.");
		List<CityMasterDTO> accountData = vacationOwnershipService.statesByCountry(country);
		logger.info("VacationOwnershipController : statesByCountry : Leaving.");
		return ResponseUtility.constructSuccessRes(accountData);
	}

	@RequestMapping(value = "/citiesByState", method = RequestMethod.POST,  produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseDTO citiesByState(@RequestParam("country") String country, @RequestParam("state") String state) {
		logger.info("VacationOwnershipController : citiesByState : Entered.");
		List<CityMasterDTO> accountData = vacationOwnershipService.citiesByState(country, state);
		logger.info("VacationOwnershipController : citiesByState : Leaving.");
		return ResponseUtility.constructSuccessRes(accountData);
	}

	private void updateProfileImageInSF(FileUploadDTO[] requests, List<String> uploadEncodedFile) {
		logger.info("UpdateProfileImageInSF  : Entered.");
		VoGetAccountRequestDTO voGetAccountRequestDTO=new VoGetAccountRequestDTO();
		for (FileUploadDTO fileUploadDTO:requests) {
			if(fileUploadDTO!=null) {
				voGetAccountRequestDTO.setContractId(fileUploadDTO.getContractId());
				voGetAccountRequestDTO.setEmail(fileUploadDTO.getContactEmail());
			}
		}
		ResponseEntity<VOCustomerPersonalDetails> accountData = vacationOwnershipService.getAccountData(voGetAccountRequestDTO);
		if(accountData!=null && !uploadEncodedFile.isEmpty()) {
			VOCustomerPersonalDetails userAccountData = accountData.getBody();
			userAccountData.setProfileImage(uploadEncodedFile.get(0));
			vacationOwnershipService.updateProfileData(userAccountData);
		}
		logger.info("UpdateProfileImageInSF  : leaving.");
	}
}
