package com.sterling.bookingapi.controller;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.sterling.bookingapi.aop.LoggingAspect;
import com.sterling.bookingapi.dto.maximojo.request.HotelAvailGetReqDTO;
import com.sterling.bookingapi.dto.maximojo.request.HotelAvailNotifReqDTO;
import com.sterling.bookingapi.dto.maximojo.request.HotelRateAmountNotifReqDTO;
import com.sterling.bookingapi.dto.maximojo.request.HotelRatePlanReqDTO;
import com.sterling.bookingapi.dto.maximojo.response.HotelAvailGetResDTO;
import com.sterling.bookingapi.dto.maximojo.response.HotelAvailNotifResDTO;
import com.sterling.bookingapi.dto.maximojo.response.HotelRateAmountNotifResDTO;
import com.sterling.bookingapi.dto.maximojo.response.HotelRatePlanForSummaryFalseResDTO;
import com.sterling.bookingapi.dto.maximojo.response.HotelRatePlanResDTO;
import com.sterling.bookingapi.dto.maximojo.response.HotelResNotifResDTO;
import com.sterling.bookingapi.exception.BookingEngineException;
import com.sterling.bookingapi.service.ChannelManagerService;
import com.sterling.bookingapi.utils.BookingEngineUtils;


/**
 * The Class ChannelManagerController.
 */
/**
 * @author tcs
 *
 */
@RestController
public class ChannelManagerController extends BaseController {
	
	/** The ChannelManager service. */
	@Autowired
	private ChannelManagerService channelManagerService;
	
	
	/** The Constant logger. */
	private static final Logger logger = LogManager.getLogger(ChannelManagerController.class);
	
	/**
	 * Gets the room rate plans.
	 *
	 * @param hotelRatePlanReq the hotel rate plan req
	 * @return the room rate plans
	 * @throws BookingEngineException the booking engine exception
	 */
	@ResponseBody
	@CrossOrigin(origins = "*")
    @RequestMapping(value = "/OTA_HotelRatePlanRQ",method = RequestMethod.POST,  
			produces = {MediaType.APPLICATION_XML_VALUE},
			consumes = {MediaType.APPLICATION_XML_VALUE})
    public HotelRatePlanResDTO getRoomRatePlans(@RequestBody HotelRatePlanReqDTO hotelRatePlanReq) throws BookingEngineException {
		logger.info("ChannelManagerController : getRatePlansRoomType : Entered.");
		logger.info(LoggingAspect.CHANNEL_MANGER_MARKER, "OTA_HotelRatePlanRQ Request :***** {}", BookingEngineUtils.getXMLString(hotelRatePlanReq));

		HotelRatePlanResDTO response = new HotelRatePlanResDTO();
		if(hotelRatePlanReq.getSummaryOnly()){
			response =  channelManagerService.getRoomRatePlans(hotelRatePlanReq);
		}
		
		logger.info(LoggingAspect.CHANNEL_MANGER_MARKER, "OTA_HotelRatePlanRQ Response :***** {}", BookingEngineUtils.getXMLString(response));
		logger.info("ChannelManagerController : getRatePlansRoomType : leaving.");
		return response;
    }
	
	
	/**
	 * Gets the room rate plans to fetch rates.
	 *
	 * @param hotelRatePlanReq the hotel rate plan req
	 * @return the room rate plans to fetch rates
	 * @throws BookingEngineException the booking engine exception
	 */
	@ResponseBody
	@CrossOrigin(origins = "*")
    @RequestMapping(value = "/OTA_HotelRatePlanRQ_ToFetchRates",method = RequestMethod.POST,  
			produces = {MediaType.APPLICATION_XML_VALUE},
			consumes = {MediaType.APPLICATION_XML_VALUE})
    public HotelRatePlanForSummaryFalseResDTO getRoomRatePlansToFetchRates(@RequestBody HotelRatePlanReqDTO hotelRatePlanReq) throws BookingEngineException {
		logger.info("ChannelManagerController : getRatePlansRoomType : Entered.");
		logger.info(LoggingAspect.CHANNEL_MANGER_MARKER, "OTA_HotelRatePlanRQ_ToFetchRates Request :***** {}", BookingEngineUtils.getXMLString(hotelRatePlanReq));
		
		HotelRatePlanForSummaryFalseResDTO response = new HotelRatePlanForSummaryFalseResDTO();
		if(!hotelRatePlanReq.getSummaryOnly()){
			response =  channelManagerService.getRoomRatePlansToFetchRates(hotelRatePlanReq);
		}
		
		logger.info(LoggingAspect.CHANNEL_MANGER_MARKER, "OTA_HotelRatePlanRQ_ToFetchRates Response :***** {}", BookingEngineUtils.getXMLString(response));
		logger.info("ChannelManagerController : getRatePlansRoomType : leaving.");
		return response;
    }
	
	/**
	 * Update hotel rate amount.
	 *
	 * @param hotelRateAmountNotifReqDTO the hotel rate amount notif req DTO
	 * @return the hotel rate amount notif res DTO
	 * @throws BookingEngineException the booking engine exception
	 */
	@ResponseBody
	@CrossOrigin(origins = "*")
    @RequestMapping(value = "/OTA_HotelRateAmountNotifRQ",method = RequestMethod.POST,  
			produces = {MediaType.APPLICATION_XML_VALUE},
			consumes = {MediaType.APPLICATION_XML_VALUE})
	 public HotelRateAmountNotifResDTO updateHotelRateAmount(@RequestBody HotelRateAmountNotifReqDTO hotelRateAmountNotifReqDTO) throws BookingEngineException{
		 logger.info("ChannelManagerController : updateHotelRateAmount : Entered.");
		 logger.info(LoggingAspect.CHANNEL_MANGER_MARKER, "OTA_HotelRateAmountNotifRQ Request :***** {}", BookingEngineUtils.getXMLString(hotelRateAmountNotifReqDTO));
		
		 HotelRateAmountNotifResDTO respone =  channelManagerService.updateHotelRateAmount(hotelRateAmountNotifReqDTO);
		 
		 logger.info(LoggingAspect.CHANNEL_MANGER_MARKER, "OTA_HotelRateAmountNotifRQ Response :***** {}", BookingEngineUtils.getXMLString(respone));
		 logger.info("ChannelManagerController : updateHotelRateAmount : leaving.");
		 return respone;
	 }
	
	/**
	 * Update hotel availiblity.
	 *
	 * @param hotelAvailNotifReqDTO the hotel avail notif req DTO
	 * @return the hotel avail notif res DTO
	 * @throws BookingEngineException the booking engine exception
	 */
	@ResponseBody
	@CrossOrigin(origins = "*")
    @RequestMapping(value = "/OTA_HotelAvailNotifRQ",method = RequestMethod.POST,  
			produces = {MediaType.APPLICATION_XML_VALUE},
			consumes = {MediaType.APPLICATION_XML_VALUE})
	 public HotelAvailNotifResDTO updateHotelAvailiblity(@RequestBody @Valid HotelAvailNotifReqDTO hotelAvailNotifReqDTO) throws BookingEngineException{
		
		 logger.info("ChannelManagerController : updateHotelAvailiblity : Entered.");
		 logger.info(LoggingAspect.CHANNEL_MANGER_MARKER, "OTA_HotelAvailNotifRQ Request :***** {}", BookingEngineUtils.getXMLString(hotelAvailNotifReqDTO));
		 
		 HotelAvailNotifResDTO respone =  channelManagerService.updateHotelAvailiblity(hotelAvailNotifReqDTO);
		 
		 logger.info(LoggingAspect.CHANNEL_MANGER_MARKER, "OTA_HotelAvailNotifRQ Response :***** {}", BookingEngineUtils.getXMLString(respone));
		 logger.info("ChannelManagerController : updateHotelAvailiblity : leaving.");
		 return respone;
	 }
	
	/**
	 * Gets the hotel availibility.
	 *
	 * @param hotelAvailGetReqDTO the hotel avail get req DTO
	 * @return the hotel availibility
	 * @throws BookingEngineException the booking engine exception
	 */
	@ResponseBody
	@CrossOrigin(origins = "*")
    @RequestMapping(value = "/OTA_HotelAvailGetRQ",method = RequestMethod.POST,  
			produces = {MediaType.APPLICATION_XML_VALUE},
			consumes = {MediaType.APPLICATION_XML_VALUE})
	 public HotelAvailGetResDTO getHotelAvailibility(@RequestBody HotelAvailGetReqDTO hotelAvailGetReqDTO) throws BookingEngineException{
		 logger.info("ChannelManagerController : getHotelAvailibility : Entered.");
		 logger.info(LoggingAspect.CHANNEL_MANGER_MARKER, "OTA_HotelAvailGetRQ Request :***** {}", BookingEngineUtils.getXMLString(hotelAvailGetReqDTO));
		 
		 HotelAvailGetResDTO respone =  channelManagerService.getHotelAvailibility(hotelAvailGetReqDTO);
		 
		 logger.info(LoggingAspect.CHANNEL_MANGER_MARKER, "OTA_HotelAvailGetRQ Response :***** {}", BookingEngineUtils.getXMLString(respone));
		 logger.info("ChannelManagerController : getHotelAvailibility : leaving.");
		 return respone;
	 }
	
	/**
	 * Creates the booking.
	 *
	 * @param bookingId the booking id
	 * @param bookingStatus the booking status
	 * @return the hotel res notif res DTO
	 * @throws BookingEngineException the booking engine exception
	 */
	@ResponseBody
	@CrossOrigin(origins = "*")
    @RequestMapping(value = "/OTA_HotelResNotifRQ",method = RequestMethod.GET,  
			produces = {MediaType.APPLICATION_XML_VALUE},
			consumes = {MediaType.APPLICATION_XML_VALUE})
	 public HotelResNotifResDTO createBooking(@RequestParam String bookingId,@RequestParam String bookingStatus) throws BookingEngineException{
		 logger.info("ChannelManagerController : createBooking : Entered.");
		 HotelResNotifResDTO respone =  channelManagerService.createBooking(bookingId,bookingStatus);
		 logger.info("ChannelManagerController : createBooking : leaving.");
		 return respone;
	 }
}
