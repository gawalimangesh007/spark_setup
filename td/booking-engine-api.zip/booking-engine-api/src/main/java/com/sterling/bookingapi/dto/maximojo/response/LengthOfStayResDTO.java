package com.sterling.bookingapi.dto.maximojo.response;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class LengthOfStayResDTO.
 * @author tcs
 * @version 1.0
 */
public class LengthOfStayResDTO {

	/** The min max message type. */
	@JacksonXmlProperty(localName = "MinMaxMessageType", isAttribute = true)
	private String minMaxMessageType;

	/** The time. */
	@JacksonXmlProperty(localName = "Time", isAttribute = true)
	private int time;

	/**
	 * Gets the time.
	 *
	 * @return the time
	 */
	public int getTime() {
		return time;
	}

	/**
	 * Sets the time.
	 *
	 * @param time            the time to set
	 */
	public void setTime(int time) {
		this.time = time;
	}

	/**
	 * Gets the min max message type.
	 *
	 * @return the minMaxMessageType
	 */
	public String getMinMaxMessageType() {
		return minMaxMessageType;
	}

	/**
	 * Sets the min max message type.
	 *
	 * @param minMaxMessageType            the minMaxMessageType to set
	 */
	public void setMinMaxMessageType(String minMaxMessageType) {
		this.minMaxMessageType = minMaxMessageType;
	}

}
