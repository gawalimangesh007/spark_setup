package com.sterling.bookingapi.dto.maximojo.request;

import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class HotelReservationsReqDTO.
 */
/**
 * @author tcs
 *
 */
public class HotelReservationsReqDTO {

	/** The create date time. */
	@JacksonXmlProperty(localName = "CreateDateTime", isAttribute = true)
	private String createDateTime;

	/** The creator ID. */
	@JacksonXmlProperty(localName = "CreatorID", isAttribute = true)
    private String creatorID;

	/** The unique ID. */
	@JacksonXmlProperty(localName = "UniqueID")
    private UniqueIDReqDTO uniqueID;

    /** The room stay. */
    @JacksonXmlElementWrapper(useWrapping=true,localName = "RoomStays")
	@JacksonXmlProperty(localName = "RoomStay")
    private List<RoomStayReqDTO> roomStay;

    /** The res guest. */
    @JacksonXmlElementWrapper(useWrapping=true,localName = "ResGuests")
	@JacksonXmlProperty(localName = "ResGuest")
    private List<ResGuestsReqDTO> resGuest;
    
    /** The res global info. */
    @JacksonXmlProperty(localName = "ResGlobalInfo")
    private ResGlobalInfoReqDTO resGlobalInfo;
    
	/**
	 * Gets the creates the date time.
	 *
	 * @return the createDateTime
	 */
	public String getCreateDateTime() {
		return createDateTime;
	}

	/**
	 * Sets the creates the date time.
	 *
	 * @param createDateTime the createDateTime to set
	 */
	public void setCreateDateTime(String createDateTime) {
		this.createDateTime = createDateTime;
	}

	/**
	 * Gets the res global info.
	 *
	 * @return the resGlobalInfo
	 */
	public ResGlobalInfoReqDTO getResGlobalInfo() {
		return resGlobalInfo;
	}

	/**
	 * Sets the res global info.
	 *
	 * @param resGlobalInfo the resGlobalInfo to set
	 */
	public void setResGlobalInfo(ResGlobalInfoReqDTO resGlobalInfo) {
		this.resGlobalInfo = resGlobalInfo;
	}

	/**
	 * Gets the creator ID.
	 *
	 * @return the creatorID
	 */
	public String getCreatorID() {
		return creatorID;
	}

	/**
	 * Sets the creator ID.
	 *
	 * @param creatorID the creatorID to set
	 */
	public void setCreatorID(String creatorID) {
		this.creatorID = creatorID;
	}

	/**
	 * Gets the res guest.
	 *
	 * @return the resGuest
	 */
	public List<ResGuestsReqDTO> getResGuest() {
		return resGuest;
	}

	/**
	 * Sets the res guest.
	 *
	 * @param resGuest the resGuest to set
	 */
	public void setResGuest(List<ResGuestsReqDTO> resGuest) {
		this.resGuest = resGuest;
	}

	/**
	 * Gets the unique ID.
	 *
	 * @return the uniqueID
	 */
	public UniqueIDReqDTO getUniqueID() {
		return uniqueID;
	}

	/**
	 * Sets the unique ID.
	 *
	 * @param uniqueID the uniqueID to set
	 */
	public void setUniqueID(UniqueIDReqDTO uniqueID) {
		this.uniqueID = uniqueID;
	}

	/**
	 * Gets the room stay.
	 *
	 * @return the roomStay
	 */
	public List<RoomStayReqDTO> getRoomStay() {
		return roomStay;
	}

	/**
	 * Sets the room stay.
	 *
	 * @param roomStay the roomStay to set
	 */
	public void setRoomStay(List<RoomStayReqDTO> roomStay) {
		this.roomStay = roomStay;
	}
    
    

}
