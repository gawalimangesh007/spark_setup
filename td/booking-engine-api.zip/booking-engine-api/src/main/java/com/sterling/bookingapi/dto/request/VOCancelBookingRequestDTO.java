package com.sterling.bookingapi.dto.request;

import java.io.Serializable;

public class VOCancelBookingRequestDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String cvNumber;
	private String otp;

	
	public String getCvNumber() {
		return cvNumber;
	}

	public void setCvNumber(String cvNumber) {
		this.cvNumber = cvNumber;
	}

	public String getOtp() {
		return otp;
	}

	public void setOtp(String otp) {
		this.otp = otp;
	}
	
	
}
