package com.sterling.bookingapi.auth.bean;

/**
 * @author tcs
 *
 */
public enum SocialAccountType {
	GOOGLE("GOOGLE"),
	FACEBOOK("FACEBOOK");
	
	private String loginType;
	
	/**
	 * @param lType
	 * set the authtype
	 */
	private SocialAccountType(String lType){
		this.setLoginType(lType);
	}

	/**
	 * @return loginType
	 */
	public String getLoginType() {
		return loginType;
	}

	/**
	 * @param loginType
	 * set the loginType
	 */
	public void setLoginType(String loginType) {
		this.loginType = loginType;
	}

	/**
	 * @param val
	 * @return true or false
	 */
	public static boolean contains(String val) {
		for (SocialAccountType el : SocialAccountType.values()) {
			if(el.getLoginType().equalsIgnoreCase(val)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * @param val
	 * @return authType
	 */
	public static SocialAccountType getFrom(String val) {
		for (SocialAccountType el : SocialAccountType.values()) {
			if(el.getLoginType().equalsIgnoreCase(val)) {
				return el;
			}
		}
		return null;
	}
}
