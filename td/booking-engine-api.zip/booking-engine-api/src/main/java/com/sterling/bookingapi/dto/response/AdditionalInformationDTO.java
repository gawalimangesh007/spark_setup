package com.sterling.bookingapi.dto.response;

import java.io.Serializable;

/**
 * @author tcs
 * @version 1.0
 *
 */
public class AdditionalInformationDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String maritalStatus;
	private String weddingDay;
	private String phoneFaxNumber;
	private AddressDTO permanentAddress;
	/**
	 * @return maritalStatus
	 */
	public String getMaritalStatus() {
		return maritalStatus;
	}
	/**
	 * @param maritalStatus
	 * set the maritalStatus
	 */
	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}
	/**
	 * @return weddingDay
	 */
	public String getWeddingDay() {
		return weddingDay;
	}
	/**
	 * @param weddingDay
	 * set the weddingDay
	 */
	public void setWeddingDay(String weddingDay) {
		this.weddingDay = weddingDay;
	}
	/**
	 * @return phoneFaxNumber
	 */
	public String getPhoneFaxNumber() {
		return phoneFaxNumber;
	}
	/**
	 * @param phoneFaxNumber
	 * set the phoneFaxNumber
	 */
	public void setPhoneFaxNumber(String phoneFaxNumber) {
		this.phoneFaxNumber = phoneFaxNumber;
	}
	/**
	 * @return permanentAddress
	 */
	public AddressDTO getPermanentAddress() {
		return permanentAddress;
	}
	/**
	 * @param permanentAddress
	 * set the permanentAddress
	 */
	public void setPermanentAddress(AddressDTO permanentAddress) {
		this.permanentAddress = permanentAddress;
	}
}
