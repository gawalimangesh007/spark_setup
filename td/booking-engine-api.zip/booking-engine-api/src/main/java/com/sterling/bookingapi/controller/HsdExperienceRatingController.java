package com.sterling.bookingapi.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.sterling.bookingapi.dto.request.HsdExperienceRatingRequestDTO;
import com.sterling.bookingapi.dto.response.ResponseDTO;
import com.sterling.bookingapi.exception.BookingEngineException;
import com.sterling.bookingapi.service.HsdExperienceRatingService;


/**
 * The Class HsdExperienceRatingController.
 */
/**
 * @author tcs
 *
 */
@RestController

public class HsdExperienceRatingController extends BaseController {

	/** The Constant logger. */
	private static final Logger logger = LogManager.getLogger(HsdExperienceRatingController.class);
	
	/** The hsd experience rating service. */
	@Autowired
	private HsdExperienceRatingService hsdExperienceRatingService;
	
	/**
	 * Creates the experience rating.
	 *
	 * @param request the request
	 * @return the response DTO
	 * @throws BookingEngineException the booking engine exception
	 */
	@ResponseBody
	@RequestMapping(value = "/hsdExperience", method = RequestMethod.POST)
	public ResponseDTO createExperienceRating(@RequestBody final HsdExperienceRatingRequestDTO request) 
						throws BookingEngineException {
		logger.info("hsdExperienceRatingService : createExperienceRating : Entered.");
		ResponseDTO response = hsdExperienceRatingService.createExperienceRating(request); 

		logger.info(" hsdExperienceRatingService : createExperienceRating : Leaving.");
		return response;
	}
		
}
