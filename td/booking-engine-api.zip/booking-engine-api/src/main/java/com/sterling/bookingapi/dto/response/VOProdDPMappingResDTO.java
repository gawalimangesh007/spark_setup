package com.sterling.bookingapi.dto.response;

import java.io.Serializable;
import java.util.List;

public class VOProdDPMappingResDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String productId;
	private String productName;
	private String productDesc;
	private String dpId;
	private String dpVal;

	private List<VOTenureDTO> emiTenureList;

	
	public String getProductDesc() {
		return productDesc;
	}

	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	/**
	 * @return dpId
	 */
	public String getDpId() {
		return dpId;
	}

	/**
	 * @param dpId
	 * set the dpId
	 */
	public void setDpId(String dpId) {
		this.dpId = dpId;
	}

	/**
	 * @return dpVal
	 */
	public String getDpVal() {
		return dpVal;
	}

	/**
	 * @param dpVal
	 * set the dpVal
	 */
	public void setDpVal(String dpVal) {
		this.dpVal = dpVal;
	}

	/**
	 * @return emiTenureList
	 */
	public List<VOTenureDTO> getEmiTenureList() {
		return emiTenureList;
	}

	/**
	 * @param emiTenureList
	 * set the emiTenureList
	 */
	public void setEmiTenureList(List<VOTenureDTO> emiTenureList) {
		this.emiTenureList = emiTenureList;
	}
	
	
}
