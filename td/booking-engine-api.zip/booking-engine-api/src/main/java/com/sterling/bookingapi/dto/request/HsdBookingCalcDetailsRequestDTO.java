package com.sterling.bookingapi.dto.request;



/**
 * The Class HsdBookingCalcDetailsRequestDTO.
 */
/**
 * @author tcs
 *
 */
public class HsdBookingCalcDetailsRequestDTO {
	
	/** The room rental amount. */
	private double roomRentalAmount;
	
	/** The extra person cost. */
	private double extraPersonCost;
	
	/** The tax details. */
	//private HsdTaxDetailsRequestDTO taxDetails;
	private Object taxDetails;
	
	/** The tax amount. */
	private double taxAmount;
	
	/** The enhancement cost. */
	private double enhancementCost;
	
	/** The enhancement cost summary. */
	private String enhancementCostSummary;
	
	/** The roomUpgrade cost. */
	private double roomUpgradeCost;
	
	/** The roomUpgrade cost summary. */
	//private String roomUpgradeCostSummary;
	
	/** The sub total cost. */
	private double subTotalCost;
	
	/** The discount amount. */
	private double discountAmount;
	
	/** The total cost. */
	private double totalCost;
	
	/** The currency code. */
	private String currencyCode;
	
	/**
	 * Gets the room rental amount.
	 *
	 * @return the room rental amount
	 */
	public double getRoomRentalAmount() {
		return roomRentalAmount;
	}
	
	/**
	 * Sets the room rental amount.
	 *
	 * @param roomRentalAmount the new room rental amount
	 */
	public void setRoomRentalAmount(double roomRentalAmount) {
		this.roomRentalAmount = roomRentalAmount;
	}
	
	/**
	 * Gets the extra person cost.
	 *
	 * @return the extra person cost
	 */
	public double getExtraPersonCost() {
		return extraPersonCost;
	}
	
	/**
	 * Sets the extra person cost.
	 *
	 * @param extraPersonCost the new extra person cost
	 */
	public void setExtraPersonCost(double extraPersonCost) {
		this.extraPersonCost = extraPersonCost;
	}
		
	public Object getTaxDetails() {
		return taxDetails;
	}

	public void setTaxDetails(Object taxDetails) {
		this.taxDetails = taxDetails;
	}

	/**
	 * Gets the tax amount.
	 *
	 * @return the tax amount
	 */
	public double getTaxAmount() {
		return taxAmount;
	}
	
	/**
	 * Sets the tax amount.
	 *
	 * @param taxAmount the new tax amount
	 */
	public void setTaxAmount(double taxAmount) {
		this.taxAmount = taxAmount;
	}
	
	/**
	 * Gets the enhancement cost.
	 *
	 * @return the enhancement cost
	 */
	public double getEnhancementCost() {
		return enhancementCost;
	}
	
	/**
	 * Sets the enhancement cost.
	 *
	 * @param enhancementCost the new enhancement cost
	 */
	public void setEnhancementCost(double enhancementCost) {
		this.enhancementCost = enhancementCost;
	}
	
	public String getEnhancementCostSummary() {
		return enhancementCostSummary;
	}

	public void setEnhancementCostSummary(String enhancementCostSummary) {
		this.enhancementCostSummary = enhancementCostSummary;
	}

	/**
	 * Gets the sub total cost.
	 *
	 * @return the sub total cost
	 */
	public double getSubTotalCost() {
		return subTotalCost;
	}
	
	/**
	 * Sets the sub total cost.
	 *
	 * @param subTotalCost the new sub total cost
	 */
	public void setSubTotalCost(double subTotalCost) {
		this.subTotalCost = subTotalCost;
	}
	
	/**
	 * Gets the discount amount.
	 *
	 * @return the discount amount
	 */
	public double getDiscountAmount() {
		return discountAmount;
	}
	
	/**
	 * Sets the discount amount.
	 *
	 * @param discountAmount the new discount amount
	 */
	public void setDiscountAmount(double discountAmount) {
		this.discountAmount = discountAmount;
	}
	
	/**
	 * Gets the total cost.
	 *
	 * @return the total cost
	 */
	public double getTotalCost() {
		return totalCost;
	}
	
	/**
	 * Sets the total cost.
	 *
	 * @param totalCost the new total cost
	 */
	public void setTotalCost(double totalCost) {
		this.totalCost = totalCost;
	}
	
	/**
	 * Gets the currency code.
	 *
	 * @return the currency code
	 */
	public String getCurrencyCode() {
		return currencyCode;
	}
	
	/**
	 * Sets the currency code.
	 *
	 * @param currencyCode the new currency code
	 */
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public double getRoomUpgradeCost() {
		return roomUpgradeCost;
	}

	public void setRoomUpgradeCost(double roomUpgradeCost) {
		this.roomUpgradeCost = roomUpgradeCost;
	}

}