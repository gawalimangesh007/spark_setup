package com.sterling.bookingapi.engine.rules.models;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PointsTable {

	private List<RoomPointsDTO> purple = null;
	private List<RoomPointsDTO> red = null;
	private List<RoomPointsDTO> white = null;
	private List<RoomPointsDTO> blue = null;
	
	public List<RoomPointsDTO> getPurple() {
		return purple;
	}
	public void setPurple(List<RoomPointsDTO> purple) {
		this.purple = purple;
	}
	public List<RoomPointsDTO> getRed() {
		return red;
	}
	public void setRed(List<RoomPointsDTO> red) {
		this.red = red;
	}
	public List<RoomPointsDTO> getWhite() {
		return white;
	}
	public void setWhite(List<RoomPointsDTO> white) {
		this.white = white;
	}
	public List<RoomPointsDTO> getBlue() {
		return blue;
	}
	public void setBlue(List<RoomPointsDTO> blue) {
		this.blue = blue;
	}
	
}
