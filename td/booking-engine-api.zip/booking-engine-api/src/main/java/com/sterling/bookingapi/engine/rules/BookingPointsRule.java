package com.sterling.bookingapi.engine.rules;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.BooleanUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;
import org.joda.time.LocalDate;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.sterling.bookingapi.dto.request.VOConfirmBookingRequest;
import com.sterling.bookingapi.dto.response.MemberDetails;
import com.sterling.bookingapi.dto.response.VODashboardResponse;
import com.sterling.bookingapi.dto.response.VOSeasonWeekDTO;
import com.sterling.bookingapi.dto.response.VOUnitProductPointDetailResDTO;
import com.sterling.bookingapi.dto.response.VOUnitProductPointMatrixResDTO;
import com.sterling.bookingapi.engine.rules.models.BookingRule;
import com.sterling.bookingapi.engine.rules.models.RoomPointsDTO;
import com.sterling.bookingapi.engine.rules.models.Season;
import com.sterling.bookingapi.engine.rules.models.VOBookingRuleDTO;
import com.sterling.bookingapi.utils.AppConstants;
import com.sterling.bookingapi.utils.AppConstants.VORoomTypes;
import com.sterling.bookingapi.utils.BookingEngineUtils;


@Rule(name="BookingPointsRule", description="BOOKING_POINT_VALIDATION")
public class BookingPointsRule {

	private static final Logger logger = LogManager.getLogger(BookingPointsRule.class);

	@Condition
	public boolean when(@Fact("bookingRequest") VOConfirmBookingRequest req, 
			@Fact("pointMatrix") List<VOUnitProductPointMatrixResDTO> pointMatrix, 
			@Fact("productRules") Map<String, List<VOBookingRuleDTO>> rulesMap,
			@Fact("bookingSeasons") Set<String> bookingSeason,
			@Fact("seasonsWeeks") List<VOSeasonWeekDTO> seasonsWeeks,
			@Fact("memberDetail") VODashboardResponse memberDetails) {
		//my rule conditions
		logger.info("=========== BOOKING_POINT_VALIDATION executing");

		//dont add the rules if the point matrix is null and for OFFER bookings
		if(CollectionUtils.isNotEmpty(pointMatrix) && BooleanUtils.isNotTrue(req.getIsOfferBooking())) {

			List<VOBookingRuleDTO> ruleList = Lists.newArrayList();
			List<VOBookingRuleDTO> minNightRules = rulesMap.get(BookingRule.MIN_NIGHT_RULE.getRuleName());
			List<VOBookingRuleDTO> holidayRules = rulesMap.get(BookingRule.VACATION_HOLIDAY_RULE.getRuleName());
			List<VOBookingRuleDTO> nationalRules = rulesMap.get(BookingRule.NATIONAL_HOLIDAY_RULE.getRuleName());
			if(minNightRules != null) {
				ruleList.addAll(minNightRules);
			}
			if(BooleanUtils.isTrue(req.getIsHolidayFallen()) && holidayRules != null) {
				ruleList.addAll(holidayRules);
			}
			if(BooleanUtils.isTrue(req.getIsNationalHolidayFallen()) && nationalRules != null) {
				ruleList.addAll(nationalRules);
			}
				
			int configureDays = 0;
			if(CollectionUtils.isNotEmpty(ruleList)) {
				for (VOBookingRuleDTO rule : ruleList) {
					if(BooleanUtils.isTrue(rule.getActive()) && BookingEngineUtils.havingAnySeason(bookingSeason, rule.getApplicableSeasons())) {
						int dayCount = Integer.parseInt(rule.getParameters().get(0).getValue());
						if(dayCount > configureDays) {
							configureDays = dayCount;
						}
					}
				}
			}
			Map<String, RoomPointsDTO> roomPoints = getRoomPoints(pointMatrix.get(0), req, bookingSeason);
			if(roomPoints != null) {
				double calulatedPoint;
				MemberDetails membershipDetails = memberDetails.getMembershipDetails();
				if(AppConstants.PRODUCT_CATEGORY_TIMESHARE.equalsIgnoreCase(membershipDetails.getRecordType())) {
					calulatedPoint = getPointsForTimeshare(roomPoints, seasonsWeeks, req, configureDays, bookingSeason, membershipDetails.getPointsOwnedTimeShare());
				} else {
					calulatedPoint = getPoints(roomPoints, seasonsWeeks, req, configureDays, bookingSeason);
				}
				
				double bookingPoint = BookingEngineUtils.roundDouble(Double.parseDouble(req.getBookingPoints()), 2);
				calulatedPoint = BookingEngineUtils.roundDouble(calulatedPoint, 2);
				logger.info("=========== BOOKING_POINT_VALIDATION :: Calculated Points={}, points in request={}.", calulatedPoint, bookingPoint);
				if(bookingPoint != calulatedPoint) {
					logger.error("=========== BOOKING_POINT_VALIDATION :: points unmatched with booking Calculated Points={}, points in request={}.", calulatedPoint, bookingPoint);
					//return false;
				}
			}
		}

		return true;
	}

	private double getPointsForTimeshare(Map<String, RoomPointsDTO> roomPoints, List<VOSeasonWeekDTO> seasonsWeeks,
			VOConfirmBookingRequest req, int configureDays, Set<String> bookingSeason, Double pointsOwnedTimeShare) {
		double calulatedPoint = getPoints(roomPoints, seasonsWeeks, req, configureDays, bookingSeason);
		
		return calulatedPoint/pointsOwnedTimeShare;
	}

	private double getPoints(Map<String, RoomPointsDTO> roomPoints,
			List<VOSeasonWeekDTO> seasonsWeeks,
			VOConfirmBookingRequest req, int configureDays, Set<String> bookingSeason) {

		double totalPoints = 0;

		int noOf1BR = NumberUtils.toInt(req.getNoOf1BR());
		int noOf2BR = NumberUtils.toInt(req.getNoOf2BR());
		int noOfST = NumberUtils.toInt(req.getNoOfStudio());
		int noOfGR = NumberUtils.toInt(req.getNoOfGuest());

		LocalDate startDate = BookingEngineUtils.parseSFLocalDate(req.getCheckInDate());
		LocalDate endDate = BookingEngineUtils.parseSFLocalDate(req.getCheckOutDate());

		Map<String, Long> seasons= Maps.newHashMap();
		if(configureDays > 0 && BookingEngineUtils.daysDiff(startDate, endDate) < configureDays) {
			//if weekend/holiday fallen, apply highest season for all days 
			logger.info("=========== BOOKING_POINT_VALIDATION falling in Weekend/Holidays, Configured max days : {}", configureDays);
			seasons.put(getHighSeason(bookingSeason), new Long(configureDays));
		} else {
			logger.info("=========== BOOKING_POINT_VALIDATION :: No Weekend/Holidays");
			List<String> seasonList = Lists.newArrayList();
			while(startDate.isBefore(endDate)){
				for (VOSeasonWeekDTO voSeasonWeekDTO : seasonsWeeks) {
					if(BookingEngineUtils.isDateBetweeen(voSeasonWeekDTO.getStartDate(), voSeasonWeekDTO.getEndDate(), startDate)){
						seasonList.add(voSeasonWeekDTO.getSeason());
						break;
					}
				}
				startDate = startDate.plusDays(1);
			}
			//get daycount by grouping season 
			seasons= BookingEngineUtils.groupList(seasonList);
		}
		
		for (Entry<String, Long> season : seasons.entrySet()) {
			RoomPointsDTO roomPointsDTO = roomPoints.get(season.getKey());
			double oneBRPoints = roomPointsDTO.getOneBR();
			double twoBRPoints = roomPointsDTO.getTwoBR();
			double stPoints = roomPointsDTO.getSt();
			double grPoints = roomPointsDTO.getGr();

			Long daysCount = season.getValue();
			totalPoints += (oneBRPoints * noOf1BR * daysCount);
			totalPoints += (twoBRPoints * noOf2BR * daysCount);
			totalPoints += (stPoints * noOfST * daysCount);
			totalPoints += (grPoints * noOfGR * daysCount);
		}

		return totalPoints;
	}


	/**
	 * return high weighted season from given
	 * @param bookingSeason
	 * @return
	 */
	private String getHighSeason(Set<String> bookingSeason) {
		//get highest season
		
		Season highSeason = null; 
		for (String season : bookingSeason) {
			Season seasonE = Season.getByName(season);
			if(highSeason == null || seasonE.getWeight() > highSeason.getWeight()) {
				highSeason = seasonE;
			}
		}
		return highSeason.getSeasonName();
	}

	private Map<String, RoomPointsDTO> getRoomPoints(VOUnitProductPointMatrixResDTO voUnitProductPointMatrixResDTO,
			VOConfirmBookingRequest req, Set<String> bookingSeason) {

		Map<String, RoomPointsDTO> pointMap = Maps.newHashMap();
		for (VOUnitProductPointDetailResDTO point : voUnitProductPointMatrixResDTO.getPointDetails()) {
			String season = point.getSeason();
			if(bookingSeason.contains(season)) {
				RoomPointsDTO dto = null;
				if(pointMap.containsKey(season)) {
					dto = pointMap.get(season);
				} else {
					dto = new RoomPointsDTO();
					pointMap.put(season, dto);
				}

				Double points = point.getPoints();
				if(StringUtils.containsIgnoreCase(point.getRoomType(), AppConstants.VORoomTypes._1BR.getRoomType())) {
					dto.setOneBR(points);
				} else if(StringUtils.containsIgnoreCase(point.getRoomType(), VORoomTypes._2BR.getRoomType())) {
					dto.setTwoBR(points);
				} else if(StringUtils.containsIgnoreCase(point.getRoomType(), VORoomTypes._ST.getRoomType())) {
					dto.setSt(points);
				} else if(StringUtils.containsIgnoreCase(point.getRoomType(), VORoomTypes._GR.getRoomType())) {
					dto.setGr(points);
				}
			}
		}
		return pointMap;
	}

	@Action(order = 1)
	public void then() throws Exception {
		//my actions
		logger.info("################# excecuting action");
	}
}
