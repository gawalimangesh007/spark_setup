package com.sterling.bookingapi.dto.response;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.sterling.bookingapi.dto.request.RateAHolidayRequest;

/**
 * @author tcs
 * @version 1.0
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class HolidayDetails implements Serializable  {
	
	private static final long serialVersionUID = 1L;
	
	private String bookindId;
	
	private String bookingDate;
	
	private ApartmentDetails apartmentDetails;
	
	private String checkinDate;
	
	private String checkoutDate;

	private String pointsDetucted;
	
	private String status;
	
	private String resortMasterName;
	private String resortMasterId;
	private String resortSerialNo;
	
	private String cvNumber;
	private Integer noOfAdults;
	private Integer noOfChildren;
	private String season;
	
	private String travelingType;
	private Boolean brwBookingFlag;
	
	private RateAHolidayRequest ratings;
	
	public Boolean getBrwBookingFlag() {
		return brwBookingFlag;
	}

	public void setBrwBookingFlag(Boolean brwBookingFlag) {
		this.brwBookingFlag = brwBookingFlag;
	}

	public RateAHolidayRequest getRatings() {
		return ratings;
	}

	public void setRatings(RateAHolidayRequest ratings) {
		this.ratings = ratings;
	}

	/**
	 * @return bookindId
	 */
	public String getBookindId() {
		return bookindId;
	}

	/**
	 * @param bookindId
	 * set the bookindId
	 */
	public void setBookindId(String bookindId) {
		this.bookindId = bookindId;
	}

	/**
	 * @return apartmentDetails
	 */
	public ApartmentDetails getApartmentDetails() {
		return apartmentDetails;
	}

	/**
	 * @param apartmentDetails
	 * set the apartmentDetails
	 */
	public void setApartmentDetails(ApartmentDetails apartmentDetails) {
		this.apartmentDetails = apartmentDetails;
	}

	public String getCheckinDate() {
		return checkinDate;
	}

	public void setCheckinDate(String checkinDate) {
		this.checkinDate = checkinDate;
	}

	public String getCheckoutDate() {
		return checkoutDate;
	}

	public void setCheckoutDate(String checkoutDate) {
		this.checkoutDate = checkoutDate;
	}

	public String getPointsDetucted() {
		return pointsDetucted;
	}

	public void setPointsDetucted(String pointsDetucted) {
		this.pointsDetucted = pointsDetucted;
	}

	/**
	 * @return status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status
	 * set the status
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return resortMasterName
	 */
	public String getResortMasterName() {
		return resortMasterName;
	}

	/**
	 * @param resortMasterName
	 * set the resortMasterName
	 */
	public void setResortMasterName(String resortMasterName) {
		this.resortMasterName = resortMasterName;
	}

	/**
	 * @return resortSerialNo
	 */
	public String getResortSerialNo() {
		return resortSerialNo;
	}

	/**
	 * @param resortSerialNo
	 * set the resortSerialNo
	 */
	public void setResortSerialNo(String resortSerialNo) {
		this.resortSerialNo = resortSerialNo;
	}

	/**
	 * @return cvNumber
	 */
	public String getCvNumber() {
		return cvNumber;
	}

	/**
	 * @param cvNumber
	 * set the cvNumber
	 */
	public void setCvNumber(String cvNumber) {
		this.cvNumber = cvNumber;
	}

	/**
	 * @return noOfAdults
	 */
	public Integer getNoOfAdults() {
		return noOfAdults;
	}

	/**
	 * @param noOfAdults
	 * set the noOfAdults
	 */
	public void setNoOfAdults(Integer noOfAdults) {
		this.noOfAdults = noOfAdults;
	}

	/**
	 * @return noOfChildren
	 */
	public Integer getNoOfChildren() {
		return noOfChildren;
	}

	/**
	 * @param noOfChildren
	 * set the noOfChildren
	 */
	public void setNoOfChildren(Integer noOfChildren) {
		this.noOfChildren = noOfChildren;
	}

	/**
	 * @return bookingDate
	 */
	public String getBookingDate() {
		return bookingDate;
	}

	/**
	 * @param bookingDate
	 * set the bookingDate
	 */
	public void setBookingDate(String bookingDate) {
		this.bookingDate = bookingDate;
	}

	public String getResortMasterId() {
		return resortMasterId;
	}

	public void setResortMasterId(String resortMasterId) {
		this.resortMasterId = resortMasterId;
	}

	public String getSeason() {
		return season;
	}

	public void setSeason(String season) {
		this.season = season;
	}

	public String getTravelingType() {
		return travelingType;
	}

	public void setTravelingType(String travelingType) {
		this.travelingType = travelingType;
	}
}
