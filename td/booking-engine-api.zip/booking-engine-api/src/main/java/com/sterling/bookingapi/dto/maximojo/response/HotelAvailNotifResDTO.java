package com.sterling.bookingapi.dto.maximojo.response;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;


/**
 * The Class HotelAvailNotifResDTO.
 * @author tcs
 * @version 1.0
 */
@JacksonXmlRootElement(localName = "OTA_HotelAvailNotifRS")
public class HotelAvailNotifResDTO {

	/** The time stamp. */
	@JacksonXmlProperty(localName = "TimeStamp", isAttribute = true)
	private String timeStamp;

	/** The xmlns. */
	@JacksonXmlProperty(localName = "xmlns", isAttribute = true)
    private String xmlns;

	/** The version. */
	@JacksonXmlProperty(localName = "Version", isAttribute = true)
    private String version;

	/** The success. */
	@JacksonXmlProperty(localName = "Success")
    private SuccessResDTO success;

	/**
	 * Gets the time stamp.
	 *
	 * @return the timeStamp
	 */
	public String getTimeStamp() {
		return timeStamp;
	}

	/**
	 * Sets the time stamp.
	 *
	 * @param timeStamp the timeStamp to set
	 */
	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}

	/**
	 * Gets the xmlns.
	 *
	 * @return the xmlns
	 */
	public String getXmlns() {
		return xmlns;
	}

	/**
	 * Sets the xmlns.
	 *
	 * @param xmlns the xmlns to set
	 */
	public void setXmlns(String xmlns) {
		this.xmlns = xmlns;
	}

	/**
	 * Gets the version.
	 *
	 * @return the version
	 */
	public String getVersion() {
		return version;
	}

	/**
	 * Sets the version.
	 *
	 * @param version the version to set
	 */
	public void setVersion(String version) {
		this.version = version;
	}

	/**
	 * Gets the success.
	 *
	 * @return the success
	 */
	public SuccessResDTO getSuccess() {
		return success;
	}

	/**
	 * Sets the success.
	 *
	 * @param success the success to set
	 */
	public void setSuccess(SuccessResDTO success) {
		this.success = success;
	}

	
	
	
}
