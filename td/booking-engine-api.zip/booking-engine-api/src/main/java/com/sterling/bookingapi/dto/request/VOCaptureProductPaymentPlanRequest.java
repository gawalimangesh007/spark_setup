package com.sterling.bookingapi.dto.request;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author tcs
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class VOCaptureProductPaymentPlanRequest implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String leadId;
	private String opportunityId;
	private String saleId;
	
	private String email;
	private String productId;
	private String productCost;
	private String dPAmount;
	private String emiAmount;
	private String lmsDPId;
	private String emiTenureId;
	
	private String planName;
	private String emiValue;
	private String tenureValue;
	private String dpPercent;
	
	
	public String getEmiValue() {
		return emiValue;
	}
	public void setEmiValue(String emiValue) {
		this.emiValue = emiValue;
	}
	public String getTenureValue() {
		return tenureValue;
	}
	public void setTenureValue(String tenureValue) {
		this.tenureValue = tenureValue;
	}
	public String getDpPercent() {
		return dpPercent;
	}
	public void setDpPercent(String dpPercent) {
		this.dpPercent = dpPercent;
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	/**
	 * @return lead id
	 */
	public String getLeadId() {
		return leadId;
	}
	/**
	 * @param leadId
	 * set the lead id
	 */
	public void setLeadId(String leadId) {
		this.leadId = leadId;
	}
	/**
	 * @return email
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * @param email
	 * set the email
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	/**
	 * @return productId
	 */
	public String getProductId() {
		return productId;
	}
	/**
	 * @param productId
	 * set the productId
	 */
	public void setProductId(String productId) {
		this.productId = productId;
	}
	/**
	 * @return productCost
	 */
	public String getProductCost() {
		return productCost;
	}
	/**
	 * @param productCost
	 * set the productCost
	 */
	public void setProductCost(String productCost) {
		this.productCost = productCost;
	}
	/**
	 * @return dPAmount
	 */
	public String getdPAmount() {
		return dPAmount;
	}
	/**
	 * @param dPAmount
	 * set the dPAmount
	 */
	public void setdPAmount(String dPAmount) {
		this.dPAmount = dPAmount;
	}
	/**
	 * @return emiAmount
	 */
	public String getEmiAmount() {
		return emiAmount;
	}
	/**
	 * @param emiAmount
	 * set the emiAmount
	 */
	public void setEmiAmount(String emiAmount) {
		this.emiAmount = emiAmount;
	}
	/**
	 * @return lmsDPId
	 */
	public String getLmsDPId() {
		return lmsDPId;
	}
	/**
	 * @param lmsDPId
	 * set the lmsDPId
	 */
	public void setLmsDPId(String lmsDPId) {
		this.lmsDPId = lmsDPId;
	}
	/**
	 * @return emiTenureId
	 */
	public String getEmiTenureId() {
		return emiTenureId;
	}
	/**
	 * @param emiTenureId
	 * set the emiTenureId
	 */
	public void setEmiTenureId(String emiTenureId) {
		this.emiTenureId = emiTenureId;
	}
	/**
	 * @return opportunityId
	 */
	public String getOpportunityId() {
		return opportunityId;
	}
	/**
	 * @param opportunityId
	 * set the opportunityId
	 */
	public void setOpportunityId(String opportunityId) {
		this.opportunityId = opportunityId;
	}
	/**
	 * @return saled id
	 */
	public String getSaleId() {
		return saleId;
	}
	/**
	 * @param saleId
	 * set the sale id
	 */
	public void setSaleId(String saleId) {
		this.saleId = saleId;
	}
	
	

}
