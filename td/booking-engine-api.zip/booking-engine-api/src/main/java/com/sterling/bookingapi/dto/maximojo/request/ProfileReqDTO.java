package com.sterling.bookingapi.dto.maximojo.request;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class ProfileReqDTO.
 */
/**
 * @author tcs
 *
 */
public class ProfileReqDTO {

	/** The profile type. */
	@JacksonXmlProperty(localName = "ProfileType", isAttribute = true)
    private int profileType;
	
	/** The customer. */
	@JacksonXmlProperty(localName = "Customer")
	private CustomerReqDTO customer;

	/**
	 * Gets the customer.
	 *
	 * @return the customer
	 */
	public CustomerReqDTO getCustomer() {
		return customer;
	}

	/**
	 * Sets the customer.
	 *
	 * @param customer the customer to set
	 */
	public void setCustomer(CustomerReqDTO customer) {
		this.customer = customer;
	}

	/**
	 * Gets the profile type.
	 *
	 * @return the profileType
	 */
	public int getProfileType() {
		return profileType;
	}

	/**
	 * Sets the profile type.
	 *
	 * @param profileType the profileType to set
	 */
	public void setProfileType(int profileType) {
		this.profileType = profileType;
	}
    
    
}
