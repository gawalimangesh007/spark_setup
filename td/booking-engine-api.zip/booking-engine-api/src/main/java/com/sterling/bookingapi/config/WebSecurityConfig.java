package com.sterling.bookingapi.config;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.authentication.logout.LogoutSuccessHandler;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

import com.sterling.bookingapi.auth.filter.AuthFilter;
import com.sterling.bookingapi.auth.filter.LoginFilter;
import com.sterling.bookingapi.auth.filter.SocialLoginFilter;
import com.sterling.bookingapi.auth.impl.TokenAuthenticationService;
import com.sterling.bookingapi.auth.impl.TokenAuthenticationServiceImpl;

/**
 * @author tcs
 *
 */
@EnableWebSecurity
@Configuration
class WebSecurityConfig extends WebSecurityConfigurerAdapter {
	
	private Logger logger = LogManager.getLogger(WebSecurityConfig.class);
	
	@Autowired
	private LogoutSuccessHandler sterlingLogoutHandler;

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		
		http.csrf().disable();
		http.cors();
		http.headers().frameOptions().deny();
		http.headers().xssProtection().block(true);
		http.exceptionHandling()
		.and()
		.anonymous()
		.and()
		.servletApi()
		//sss			.and()
		//sss	.headers().cacheControl()
		.and()
		.authorizeRequests()
		.antMatchers(HttpMethod.OPTIONS,"/login").permitAll()
		.antMatchers(HttpMethod.OPTIONS,"/sociallogin").permitAll()
		.antMatchers("/vo/feedback", "/voDashboard/essentialsToCarry").hasAnyAuthority("VO", "HSD")
		.antMatchers("/vo/**", "/vo*/**").hasAuthority("VO")
		.anyRequest().authenticated()
		.and()
		
		.logout().logoutRequestMatcher(new AntPathRequestMatcher("/logout", "POST")).logoutSuccessHandler(sterlingLogoutHandler)
		.and()
		
		.addFilterBefore(new LoginFilter(new AntPathRequestMatcher("/login", "POST")), UsernamePasswordAuthenticationFilter.class)
//		.addFilterBefore(new LogoutFilter(new AntPathRequestMatcher("/logout", "POST")), UsernamePasswordAuthenticationFilter.class)
		.addFilterBefore(new SocialLoginFilter(new AntPathRequestMatcher("/sociallogin", "POST")), UsernamePasswordAuthenticationFilter.class)
		.addFilterBefore(new AuthFilter(), UsernamePasswordAuthenticationFilter.class);
	}

	/**
	 * @return
	 */
	@Bean
	public TokenAuthenticationService tokenAuthenticationService() {
		return new TokenAuthenticationServiceImpl();
	}
	
	@Override
	public void configure(WebSecurity web) throws Exception {
		web.ignoring().antMatchers(HttpMethod.OPTIONS, "/**")
			.antMatchers(
				"/hsd*/**", 
				"/hsd/**", 
				"/mice*/**",
				//"/user*/**", 
				//"/user/**", 
				"/rateplan/**", 
				"/OTA*", 
				//"/vo/**", 
				//"/vo*/**", 
				
				"/vo/createLead",
				"/vo/updateLead",
				"/vo/seasonCalender",
				"/vo/forgotPwd",
				"/vo/resetPwd",
				"/vo/userOtp",
				"/vo/package/create",
				"/vo/updatePayment",
				"/vo/ruleConfig",
				"/voProduct/getProducts",
				"/voProduct/getProduct",
				"/voProduct/captureProductPmntPlan",
				"/voProduct/updateProductPmntPlan",
				"/voProduct/getDownPaymentPDF",
				"/voProduct/capture/kyc",
				"/voProduct/get/unitProductPointMatrix",
				"/voProduct/getOffer",
				"/voProduct/getSpecificOffer",
				"/voProduct/getProductPaymentPlan",
				"/vo/payDP",
				
				"/common/**",
				"/otp/**", 
				"/temp/**",
				//"/mockAuth*",
				"/getAuthHeader",
				//for swaggers
				"/configuration/**", 
				"/swagger-resources", 
				"/v2*/**", 
				"/**/*.html","/**/*.js", "/**/*.png", "/**/*.css"
				);
				
				
		super.configure(web);
	}
}
