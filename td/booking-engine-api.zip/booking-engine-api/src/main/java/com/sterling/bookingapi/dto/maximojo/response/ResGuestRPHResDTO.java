package com.sterling.bookingapi.dto.maximojo.response;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class ResGuestRPHResDTO.
 * @author tcs
 * @version 1.0
 */
public class ResGuestRPHResDTO {

	/** The rph. */
	@JacksonXmlProperty(localName = "RPH", isAttribute = true)
	private String RPH;

	/**
	 * Gets the rph.
	 *
	 * @return the rPH
	 */
	public String getRPH() {
		return RPH;
	}

	/**
	 * Sets the rph.
	 *
	 * @param rPH the rPH to set
	 */
	public void setRPH(String rPH) {
		RPH = rPH;
	}
	
	
}
