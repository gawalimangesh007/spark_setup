package com.sterling.bookingapi.dto.maximojo.response;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class TotalResDTO.
 * @author tcs
 * @version 1.0
 */
public class TotalResDTO {

	/** The amount after tax. */
	@JacksonXmlProperty(localName = "AmountAfterTax", isAttribute = true)
	private String amountAfterTax;
	
	/** The amount before tax. */
	@JacksonXmlProperty(localName = "AmountBeforeTax", isAttribute = true)
	private String amountBeforeTax;

	/** The currency code. */
	@JacksonXmlProperty(localName = "CurrencyCode", isAttribute = true)
    private String currencyCode;

	/**
	 * Gets the amount after tax.
	 *
	 * @return the amountAfterTax
	 */
	public String getAmountAfterTax() {
		return amountAfterTax;
	}

	/**
	 * Sets the amount after tax.
	 *
	 * @param amountAfterTax the amountAfterTax to set
	 */
	public void setAmountAfterTax(String amountAfterTax) {
		this.amountAfterTax = amountAfterTax;
	}

	/**
	 * Gets the currency code.
	 *
	 * @return the currencyCode
	 */
	public String getCurrencyCode() {
		return currencyCode;
	}

	/**
	 * Sets the currency code.
	 *
	 * @param currencyCode the currencyCode to set
	 */
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	/**
	 * Gets the amount before tax.
	 *
	 * @return the amountBeforeTax
	 */
	public String getAmountBeforeTax() {
		return amountBeforeTax;
	}

	/**
	 * Sets the amount before tax.
	 *
	 * @param amountBeforeTax the amountBeforeTax to set
	 */
	public void setAmountBeforeTax(String amountBeforeTax) {
		this.amountBeforeTax = amountBeforeTax;
	}
	
	
}
