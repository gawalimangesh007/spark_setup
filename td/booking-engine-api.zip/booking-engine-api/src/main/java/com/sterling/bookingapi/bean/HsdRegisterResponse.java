package com.sterling.bookingapi.bean;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Generated;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;


/**
 * The Class HsdRegisterResponse.
 */
/**
 * @author tcs
 *
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@Generated("org.jsonschema2pojo")
@JsonPropertyOrder({ "Status" })
public class HsdRegisterResponse {

	/**
	 * Instantiates a new hsd register response.
	 */
	public HsdRegisterResponse() {
		super();

	}

	/** The Status. */
	@JsonProperty("Status")
	private String Status;
	
	/** The Lead id. */
	@JsonProperty("LeadId")
	private String LeadId;

	

	/** The additional properties. */
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<>();

	/**
	 * Creates the.
	 *
	 * @param jsonString the json string
	 * @return the hsd register response
	 * @throws JsonParseException the json parse exception
	 * @throws JsonMappingException the json mapping exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	@JsonCreator
	public static HsdRegisterResponse Create(String jsonString)
			throws JsonParseException, JsonMappingException, IOException {
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY,
				true);
		HsdRegisterResponse d = null;
		d = mapper.readValue(jsonString, HsdRegisterResponse.class);
		return d;
	}

	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	@JsonProperty("Status")
	public String getStatus() {
		return Status;
	}

	/**
	 * Sets the status.
	 *
	 * @param status            the status to set
	 */
	@JsonProperty("Status")
	public void setStatus(String status) {
		this.Status = status;
	}

	
	/**
	 * Gets the lead id.
	 *
	 * @return the leadId
	 */
	@JsonProperty("LeadId")
	public String getLeadId() {
		return LeadId;
	}

	/**
	 * Sets the lead id.
	 *
	 * @param leadId the leadId to set
	 */
	@JsonProperty("LeadId")
	public void setLeadId(String leadId) {
		LeadId = leadId;
	}
	
	/**
	 * Gets the additional properties.
	 *
	 * @return the additional properties
	 */
	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	/**
	 * Sets the additional property.
	 *
	 * @param name the name
	 * @param value the value
	 */
	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

}