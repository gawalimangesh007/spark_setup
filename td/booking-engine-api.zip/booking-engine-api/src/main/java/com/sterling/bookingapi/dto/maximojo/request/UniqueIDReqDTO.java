package com.sterling.bookingapi.dto.maximojo.request;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class UniqueIDReqDTO.
 */
/**
 * @author tcs
 *
 */
public class UniqueIDReqDTO {

	/** The id. */
	@JacksonXmlProperty(localName = "ID", isAttribute = true)
	private String ID;
	
	/** The type. */
	@JacksonXmlProperty(localName = "Type", isAttribute = true)
	private int type;

	/**
	 * Gets the type.
	 *
	 * @return the type
	 */
	public int getType() {
		return type;
	}

	/**
	 * Sets the type.
	 *
	 * @param type the type to set
	 */
	public void setType(int type) {
		this.type = type;
	}

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public String getID() {
		return ID;
	}

	/**
	 * Sets the id.
	 *
	 * @param iD the new id
	 */
	public void setID(String iD) {
		ID = iD;
	}


	
}
