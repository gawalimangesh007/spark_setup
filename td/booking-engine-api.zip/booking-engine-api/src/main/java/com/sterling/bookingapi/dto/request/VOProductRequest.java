package com.sterling.bookingapi.dto.request;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author tcs
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class VOProductRequest implements Serializable {

	private static final long serialVersionUID = 1L;

	private String productId;


	public String getProductId() {
		return productId;
	}


	public void setProductId(String productId) {
		this.productId = productId;
	}

	

}
