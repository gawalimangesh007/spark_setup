package com.sterling.bookingapi.dto.maximojo.request;

import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class AvailStatusMessageReqDTO.
 */
/**
 * @author tcs
 *
 */
public class AvailStatusMessageReqDTO {

	/** The status application control. */
	@JacksonXmlProperty(localName = "StatusApplicationControl")
	private StatusApplicationControlReqDTO statusApplicationControl;

	/** The booking limit. */
	@JacksonXmlProperty(localName = "BookingLimit", isAttribute = true)
    private int bookingLimit;

	/** The restriction status. */
	@JacksonXmlProperty(localName = "RestrictionStatus")
    private RestrictionStatusReqDTO restrictionStatus;
	
	/** The length of stay. */
	@JacksonXmlElementWrapper(useWrapping=true, localName = "LengthsOfStay")
	@JacksonXmlProperty(localName = "LengthOfStay")
    private List<LengthOfStayReqDTO> lengthOfStay;

	/**
	 * Gets the status application control.
	 *
	 * @return the statusApplicationControl
	 */
	public StatusApplicationControlReqDTO getStatusApplicationControl() {
		return statusApplicationControl;
	}

	/**
	 * Sets the status application control.
	 *
	 * @param statusApplicationControl the statusApplicationControl to set
	 */
	public void setStatusApplicationControl(StatusApplicationControlReqDTO statusApplicationControl) {
		this.statusApplicationControl = statusApplicationControl;
	}

	/**
	 * Gets the booking limit.
	 *
	 * @return the bookingLimit
	 */
	public int getBookingLimit() {
		return bookingLimit;
	}

	/**
	 * Sets the booking limit.
	 *
	 * @param bookingLimit the bookingLimit to set
	 */
	public void setBookingLimit(int bookingLimit) {
		this.bookingLimit = bookingLimit;
	}

	/**
	 * Gets the restriction status.
	 *
	 * @return the restrictionStatus
	 */
	public RestrictionStatusReqDTO getRestrictionStatus() {
		return restrictionStatus;
	}

	/**
	 * Sets the restriction status.
	 *
	 * @param restrictionStatus the restrictionStatus to set
	 */
	public void setRestrictionStatus(RestrictionStatusReqDTO restrictionStatus) {
		this.restrictionStatus = restrictionStatus;
	}

	/**
	 * Gets the length of stay.
	 *
	 * @return the lengthOfStay
	 */
	public List<LengthOfStayReqDTO> getLengthOfStay() {
		return lengthOfStay;
	}

	/**
	 * Sets the length of stay.
	 *
	 * @param lengthOfStay the lengthOfStay to set
	 */
	public void setLengthOfStay(List<LengthOfStayReqDTO> lengthOfStay) {
		this.lengthOfStay = lengthOfStay;
	}
	
	
	
}
