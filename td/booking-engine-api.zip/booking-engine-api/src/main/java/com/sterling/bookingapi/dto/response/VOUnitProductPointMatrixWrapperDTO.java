package com.sterling.bookingapi.dto.response;

import java.io.Serializable;
import java.util.List;

public class VOUnitProductPointMatrixWrapperDTO implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private List<VOUnitProductPointMatrixResDTO> unitProductPointMatrix;

	public List<VOUnitProductPointMatrixResDTO> getUnitProductPointMatrix() {
		return unitProductPointMatrix;
	}
	
	public void setUnitProductPointMatrix(
			List<VOUnitProductPointMatrixResDTO> unitProductPointMatrix) {
		this.unitProductPointMatrix = unitProductPointMatrix;
	}
		
}
