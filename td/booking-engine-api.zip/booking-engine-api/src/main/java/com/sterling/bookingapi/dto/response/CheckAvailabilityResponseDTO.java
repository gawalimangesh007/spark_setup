package com.sterling.bookingapi.dto.response;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.sterling.bookingapi.utils.CustomJsonDateSerializer;


/**
 * The Class CheckAvailabilityResponseDTO.
 */
public class CheckAvailabilityResponseDTO {
	
	/** The resort id. */
	private String resortId;

	/** The check in. */
	@JsonSerialize(using = CustomJsonDateSerializer.class)
	private Date checkIn;

	/** The check out. */
	@JsonSerialize(using = CustomJsonDateSerializer.class)
	private Date checkOut;

	/** The resort availability. */
	private List<CheckAvailabilityGroupedRooms> resortAvailability = new ArrayList<>();
	
	/** The resort availability. */
	private Collection<checkAvailabilityRoomStatus> roomTypeStatus = new ArrayList<>();
	
	private boolean isSuggested;
	
	@JsonSerialize(contentUsing = CustomJsonDateSerializer.class)
	private List<Date> suggestedDates;
	
	private List<CheckAvailabilityRecommendResorts> recommendedResorts;
	/**
	 * Gets the resort id.
	 *
	 * @return the resort id
	 */
	public String getResortId() {
		return resortId;
	}

	/**
	 * Sets the resort id.
	 *
	 * @param resortId the new resort id
	 */
	public void setResortId(String resortId) {
		this.resortId = resortId;
	}

	/**
	 * Gets the check in.
	 *
	 * @return the check in
	 */
	public Date getCheckIn() {
		return checkIn;
	}

	/**
	 * Sets the check in.
	 *
	 * @param checkIn the new check in
	 */
	public void setCheckIn(Date checkIn) {
		this.checkIn = checkIn;
	}

	/**
	 * Gets the check out.
	 *
	 * @return the check out
	 */
	public Date getCheckOut() {
		return checkOut;
	}

	/**
	 * Sets the check out.
	 *
	 * @param checkOut the new check out
	 */
	public void setCheckOut(Date checkOut) {
		this.checkOut = checkOut;
	}

	/**
	 * Gets the resort availability.
	 *
	 * @return the resort availability
	 */
	public List<CheckAvailabilityGroupedRooms> getResortAvailability() {
		return resortAvailability;
	}

	/**
	 * Sets the resort availability.
	 *
	 * @param resortAvailability the new resort availability
	 */
	public void setResortAvailability(List<CheckAvailabilityGroupedRooms> resortAvailability) {
		this.resortAvailability = resortAvailability;
	}

	public boolean isSuggested() {
		return isSuggested;
	}

	public void setSuggested(boolean isSuggested) {
		this.isSuggested = isSuggested;
	}

	public List<Date> getSuggestedDates() {
		return suggestedDates;
	}

	public void setSuggestedDates(List<Date> suggestedDates) {
		this.suggestedDates = suggestedDates;
	}

	public Collection<checkAvailabilityRoomStatus> getRoomTypeStatus() {
		return roomTypeStatus;
	}

	public void setRoomTypeStatus(
			Collection<checkAvailabilityRoomStatus> roomTypeStatus) {
		this.roomTypeStatus = roomTypeStatus;
	}

	public List<CheckAvailabilityRecommendResorts> getRecommendedResorts() {
		return recommendedResorts;
	}

	public void setRecommendedResorts(
			List<CheckAvailabilityRecommendResorts> recommendedResorts) {
		this.recommendedResorts = recommendedResorts;
	}
}
