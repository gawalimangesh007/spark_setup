package com.sterling.bookingapi.dto.request;



/**
 * The Class HsdBookingCustomerRequestDTO.
 */
/**
 * @author tcs
 *
 */
public class HsdBookingCustomerRequestDTO {
	
	/** The first name. */
	//@NotNull(message="Guest user name should not be empty")
	private String firstName;
	
	/** The last name. */
	//@NotNull(message="Guest user name should not be empty")
	private String lastName;
	
	/** The email id. */
	//@NotNull(message="Guest user EmailId should not be empty")
	private String emailId;
	
	/** The mobile no. */
	//@NotNull(message="Guest user mobile number should not be empty")
	private String mobileNo;
	
	
	
	/**
	 * Gets the first name.
	 * 
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * sets the email id.
	 * 
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * Gets the email id.
	 * 
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * Gets the email id.
	 * 
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * Gets the email id.
	 *
	 * @return the email id
	 */
	public String getEmailId() {
		return emailId;
	}
	
	/**
	 * Sets the email id.
	 *
	 * @param emailId the new email id
	 */
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	
	/**
	 * Gets the mobile no.
	 *
	 * @return the mobile no
	 */
	public String getMobileNo() {
		return mobileNo;
	}
	
	/**
	 * Sets the mobile no.
	 *
	 * @param mobileNo the new mobile no
	 */
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
}