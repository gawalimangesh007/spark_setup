package com.sterling.bookingapi.dto.response;

import java.io.Serializable;

public class VOSeasonCalenderWeekDataDTO implements Serializable {
	
	private static final long serialVersionUID = 1L;

	private String date;
	
	private String roomType = "ALL";
	
	private String season;
	
	private String weekNumber;

	/**
	 * @return weekNumber
	 */
	public String getWeekNumber() {
		return weekNumber;
	}

	/**
	 * @param weekNumber
	 * set the weekNumber
	 */
	public void setWeekNumber(String weekNumber) {
		this.weekNumber = weekNumber;
	}

	/**
	 * @return date
	 */
	public String getDate() {
		return date;
	}

	/**
	 * @param date
	 * set the date
	 */
	public void setDate(String date) {
		this.date = date;
	}

	/**
	 * @return roomType
	 */
	public String getRoomType() {
		return roomType;
	}

	/**
	 * @param roomType
	 * set the roomType
	 */
	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}

	/**
	 * @return season
	 */
	public String getSeason() {
		return season;
	}

	/**
	 * @param season
	 * set the season
	 */
	public void setSeason(String season) {
		this.season = season;
	}
	
}
