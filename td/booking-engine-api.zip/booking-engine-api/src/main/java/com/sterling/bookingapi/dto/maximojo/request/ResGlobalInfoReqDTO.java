package com.sterling.bookingapi.dto.maximojo.request;

import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class ResGlobalInfoReqDTO.
 */
/**
 * @author tcs
 *
 */
public class ResGlobalInfoReqDTO {

	
	/** The total. */
	@JacksonXmlProperty(localName = "Total")
	private TotalReqForResGlobalInfo total;
	
	/** The hotel reservation ID. */
	@JacksonXmlElementWrapper(useWrapping=true,localName = "HotelReservationIDs")
	@JacksonXmlProperty(localName = "HotelReservationID")
	private List<HotelReservationIDReqDTO> hotelReservationID;

	/**
	 * Gets the hotel reservation ID.
	 *
	 * @return the hotelReservationID
	 */
	public List<HotelReservationIDReqDTO> getHotelReservationID() {
		return hotelReservationID;
	}

	/**
	 * Sets the hotel reservation ID.
	 *
	 * @param hotelReservationID the hotelReservationID to set
	 */
	public void setHotelReservationID(List<HotelReservationIDReqDTO> hotelReservationID) {
		this.hotelReservationID = hotelReservationID;
	}

	/**
	 * Gets the total.
	 *
	 * @return the total
	 */
	public TotalReqForResGlobalInfo getTotal() {
		return total;
	}

	/**
	 * Sets the total.
	 *
	 * @param total the total to set
	 */
	public void setTotal(TotalReqForResGlobalInfo total) {
		this.total = total;
	}
	
	
}
