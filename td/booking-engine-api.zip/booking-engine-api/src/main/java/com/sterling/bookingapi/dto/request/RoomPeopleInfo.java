package com.sterling.bookingapi.dto.request;

import javax.validation.constraints.NotNull;



/**
 * The Class RoomPeopleInfo.
 */
/**
 * @author tcs
 *
 */
public class RoomPeopleInfo {

/** The room count. */
//	@NotNull
	private int roomCount;

	/** The adult count. */
	@NotNull
	private int adultCount;

	
	/** The child count. */
	private int childCount;

	
	/** The infant count. */
	private int infantCount;


	/**
	 * Gets the adult count.
	 *
	 * @return the adult count
	 */
	public int getAdultCount() {
		return adultCount;
	}

	/**
	 * Sets the adult count.
	 *
	 * @param adultCount the new adult count
	 */
	public void setAdultCount(int adultCount) {
		this.adultCount = adultCount;
	}

	/**
	 * Gets the child count.
	 *
	 * @return the child count
	 */
	public int getChildCount() {
		return childCount;
	}

	/**
	 * Sets the child count.
	 *
	 * @param childCount the new child count
	 */
	public void setChildCount(int childCount) {
		this.childCount = childCount;
	}

	/**
	 * Gets the infant count.
	 *
	 * @return the infant count
	 */
	public int getInfantCount() {
		return infantCount;
	}

	/**
	 * Sets the infant count.
	 *
	 * @param infantCount the new infant count
	 */
	public void setInfantCount(int infantCount) {
		this.infantCount = infantCount;
	}

	/**
	 * Gets the room count.
	 *
	 * @return the room count
	 */
	public int getRoomCount() {
		return roomCount;
	}

	/**
	 * Sets the room count.
	 *
	 * @param roomCount the new room count
	 */
	public void setRoomCount(int roomCount) {
		this.roomCount = roomCount;
	}

	/**
	 * Gets the pax count.
	 *
	 * @return the pax count
	 */
	public int getPaxCount(){
		int paxCount = 0;
			if (this.adultCount > 0) {
			paxCount += this.adultCount;
			}
			if (this.childCount > 0) {
				paxCount += this.childCount;
			}
			
		return paxCount;
	}
}
