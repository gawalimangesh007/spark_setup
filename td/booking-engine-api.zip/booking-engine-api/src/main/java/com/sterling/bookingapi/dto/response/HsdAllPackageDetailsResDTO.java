package com.sterling.bookingapi.dto.response;


import java.util.ArrayList;
import java.util.List;



/**
 * @author tcs
 * @version 1.0
 *
 */
public class HsdAllPackageDetailsResDTO {
	
	/** The hsd packages lists. */
	private List<HsdPackageDetailsResponseDTO> hsdPackagesLists = new ArrayList<>();
	
	
	/**
	 * Instantiates a new hsd all package details res DTO.
	 */
	public HsdAllPackageDetailsResDTO() {
		super();
	}
	
	/**
	 * Instantiates a new hsd all package details res DTO.
	 *
	 * @param hsdPackagesLists the hsd packages lists
	 */
	public HsdAllPackageDetailsResDTO(List<HsdPackageDetailsResponseDTO> hsdPackagesLists) {
		
		this.hsdPackagesLists = hsdPackagesLists;
	}

	/**
	 * Gets the hsd packages lists.
	 *
	 * @return the hsd packages lists
	 */
	public List<HsdPackageDetailsResponseDTO> getHsdPackagesLists() {
		return hsdPackagesLists;
	}

	/**
	 * Sets the hsd packages lists.
	 *
	 * @param hsdPackagesLists the new hsd packages lists
	 */
	public void setHsdPackagesLists(List<HsdPackageDetailsResponseDTO> hsdPackagesLists) {
		this.hsdPackagesLists = hsdPackagesLists;
	}

	
}
