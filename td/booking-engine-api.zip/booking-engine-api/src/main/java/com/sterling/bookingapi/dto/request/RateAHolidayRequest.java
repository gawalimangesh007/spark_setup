package com.sterling.bookingapi.dto.request;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class RateAHolidayRequest implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String resortId;
	private String cleanlinessRating;
	private String foodRating;
	private String amenitiesRating;
	private String hospitalityRating;
	private String roomsRating;
	private String overallRating;
	private String reviewTitle;
	private String reviewDetail;
	private String image1;
	private String image2;
	private Boolean optSocailMediaShare;
	private String memberBookingRequest;
	private String nonMemberBookingRequest;
	private String userEmailId;
	private String type;
	
	public String getResortId() {
		return resortId;
	}
	public void setResortId(String resortId) {
		this.resortId = resortId;
	}
	public String getCleanlinessRating() {
		return cleanlinessRating;
	}
	public void setCleanlinessRating(String cleanlinessRating) {
		this.cleanlinessRating = cleanlinessRating;
	}
	public String getFoodRating() {
		return foodRating;
	}
	public void setFoodRating(String foodRating) {
		this.foodRating = foodRating;
	}
	public String getAmenitiesRating() {
		return amenitiesRating;
	}
	public void setAmenitiesRating(String amenitiesRating) {
		this.amenitiesRating = amenitiesRating;
	}
	public String getHospitalityRating() {
		return hospitalityRating;
	}
	public void setHospitalityRating(String hospitalityRating) {
		this.hospitalityRating = hospitalityRating;
	}
	public String getRoomsRating() {
		return roomsRating;
	}
	public void setRoomsRating(String roomsRating) {
		this.roomsRating = roomsRating;
	}
	public String getOverallRating() {
		return overallRating;
	}
	public void setOverallRating(String overallRating) {
		this.overallRating = overallRating;
	}
	public String getReviewTitle() {
		return reviewTitle;
	}
	public void setReviewTitle(String reviewTitle) {
		this.reviewTitle = reviewTitle;
	}
	public String getReviewDetail() {
		return reviewDetail;
	}
	public void setReviewDetail(String reviewDetail) {
		this.reviewDetail = reviewDetail;
	}
	public String getImage1() {
		return image1;
	}
	public void setImage1(String image1) {
		this.image1 = image1;
	}
	public String getImage2() {
		return image2;
	}
	public void setImage2(String image2) {
		this.image2 = image2;
	}
	public Boolean isOptSocailMediaShare() {
		return optSocailMediaShare;
	}
	public void setOptSocailMediaShare(Boolean optSocailMediaShare) {
		this.optSocailMediaShare = optSocailMediaShare;
	}
	public String getMemberBookingRequest() {
		return memberBookingRequest;
	}
	public void setMemberBookingRequest(String memberBookingRequest) {
		this.memberBookingRequest = memberBookingRequest;
	}
	public String getNonMemberBookingRequest() {
		return nonMemberBookingRequest;
	}
	public void setNonMemberBookingRequest(String nonMemberBookingRequest) {
		this.nonMemberBookingRequest = nonMemberBookingRequest;
	}
	public String getUserEmailId() {
		return userEmailId;
	}
	public void setUserEmailId(String userEmailId) {
		this.userEmailId = userEmailId;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
}
