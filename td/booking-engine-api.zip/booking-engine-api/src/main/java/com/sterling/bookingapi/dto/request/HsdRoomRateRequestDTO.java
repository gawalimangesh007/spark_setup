package com.sterling.bookingapi.dto.request;

import java.util.Date;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.sterling.bookingapi.utils.CustomJsonDateDeserializer;

public class HsdRoomRateRequestDTO {

	/** The resort id. */
	@NotNull
	private String resortId;

	/** The check in. */
	@NotNull
	@JsonDeserialize(using = CustomJsonDateDeserializer.class)
	private Date checkIn;

	/** The check out. */
	@NotNull
	@JsonDeserialize(using = CustomJsonDateDeserializer.class)
	private Date checkOut;
	
	/** The resort id. */
	@NotNull
	private String roomTypeId;

	public String getResortId() {
		return resortId;
	}

	public void setResortId(String resortId) {
		this.resortId = resortId;
	}

	public Date getCheckIn() {
		return checkIn;
	}

	public void setCheckIn(Date checkIn) {
		this.checkIn = checkIn;
	}

	public Date getCheckOut() {
		return checkOut;
	}

	public void setCheckOut(Date checkOut) {
		this.checkOut = checkOut;
	}

	public String getRoomTypeId() {
		return roomTypeId;
	}

	public void setRoomTypeId(String roomTypeId) {
		this.roomTypeId = roomTypeId;
	}
}
