package com.sterling.bookingapi.engine.rules;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.BooleanUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;

import com.sterling.bookingapi.dto.request.VOConfirmBookingRequest;
import com.sterling.bookingapi.dto.response.HolidayDetails;
import com.sterling.bookingapi.dto.response.VODashboardResponse;
import com.sterling.bookingapi.engine.rules.models.BookingRule;
import com.sterling.bookingapi.engine.rules.models.VOBookingRuleDTO;
import com.sterling.bookingapi.utils.BookingEngineUtils;


@Rule(name = "MaxBookYearRule", description = "MAX_BOOK_IN_YEAR_RULE")
public class MaxBookingInYearRule {

	private static final Logger logger = LogManager.getLogger(MaxBookingInYearRule.class);

	
	@Condition
	public boolean when(@Fact("bookingRequest") VOConfirmBookingRequest req, 
			@Fact("productRules") Map<String, List<VOBookingRuleDTO>> rulesMap,
			@Fact("memberDetail") VODashboardResponse memberDetail,
			@Fact("bookingSeasons") Set<String> bookingSeason) {
		//my rule conditions
		
		logger.info("=========== MAX_BOOK_IN_YEAR_RULE executing");
		String reqResortMaster = req.getResortMasterId();
		Date reqCheckinDate = BookingEngineUtils.parseDate(req.getCheckInDate(), BookingEngineUtils.SF_DATE_FORMAT);
		
		int reqYear = BookingEngineUtils.getYear(reqCheckinDate);
		
		List<HolidayDetails> holidayDetails = memberDetail.getHolidayDetails();
		
		List<VOBookingRuleDTO> ruleList = rulesMap.get(BookingRule.MAX_BOOK_IN_YEAR_RULE.getRuleName());
		
		//Set<String> bookingSeason = BookingEngineUtils.parseSeasons(req.getSeasonDetail());
		for (VOBookingRuleDTO rule : ruleList) {
			if(BooleanUtils.isTrue(rule.getActive()) && BookingEngineUtils.havingAnySeason(bookingSeason, rule.getApplicableSeasons())) {
				
				int configNoYr = Integer.parseInt(rule.getParameters().get(0).getValue()); //maxBookYear
				
				//loop booking history and check the booking is present already with matched criterias
				for (HolidayDetails holidayDetail : holidayDetails) {
					String bookedResortId = holidayDetail.getResortMasterId();
					int bookedYr = BookingEngineUtils.getYear(holidayDetail.getCheckinDate());
					if(holidayDetail.getSeason() != null) {
						List<String> bookedSeason = new ArrayList<String>(Arrays.asList(holidayDetail.getSeason().split(",")));
						if(bookedResortId.equals(reqResortMaster) //same resort
								&& bookedYr >= (reqYear-configNoYr) //if not booked previously 
								&& BookingEngineUtils.havingAnySeason(bookedSeason, rule.getApplicableSeasons())) //in configured season
						{
							logger.info("=========== MAX_BOOK_IN_YEAR_RULE :: Criteria matched with booking {},", holidayDetail.getCvNumber());
							return false;
						}
					}
				}
				
			} else {
				logger.info("=========== MAX_BOOK_IN_YEAR_RULE :: booking season is not matched with configured rules, hence passing");
			}
		}
		//check the season and then point
		
		logger.info("################# excecuting condition " + req.getCheckInDate());
		return true;
	}

	@Action(order = 1)
	public void then() throws Exception {
		//my actions
		logger.info("################# excecuting action");
	}
	

}
