package com.sterling.bookingapi.mail;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.sterling.bookingapi.exception.BookingEngineException;
import com.sterling.bookingapi.utils.AppConstants.TemplateAction;
import com.sterling.bookingapi.utils.MessageConstants;

/**
 * A factory for creating Template objects.
 */
/**
 * @author tcs
 * @version 1.0
 *
 */
public class TemplateFactory {

	/** The Constant logger. */
	private static final Logger logger = LogManager.getLogger(TemplateFactory.class);

	/**
	 * Gets the template.
	 *
	 * @param templateAction
	 *            the template action
	 * @return the template
	 * @throws BookingEngineException
	 *             the booking engine exception
	 */
	public static String getTemplate(TemplateAction templateAction) throws BookingEngineException {

		switch (templateAction) {

		case FORGOT_PASSWORD:
			logger.info("TemplateFactory : getTemplate : Forgot password tempalte fetched.");
			return "resetPassword.html";
		case BOOKING_CONFIRMATION:
			logger.info("TemplateFactory : getTemplate : Booking confirmation tempalte fetched.");
			return "bookingConfirmation.html";
		case FEEDBACK_USER_MAIL:
			logger.info("TemplateFactory : getTemplate : Booking confirmation tempalte fetched.");
			return "feedbackUserMail.html";
		case USER_ACTIVATION:
			logger.info("TemplateFactory : getTemplate : User activation tempalte fetched.");
			return "userActivation.html";
		case GROUP_BOOKING:
			logger.info("TemplateFactory : getTemplate : Group Booking tempalte fetched.");
			return "groupBooking.html";	
		case BOOKING_VOUCHER:
			logger.info("TemplateFactory : getTemplate : Booking voucher tempalte fetched.");
			return "confirmationVoucher.html";

		default:
			logger.error("TemplateFactory : getTemplate : No template action present for the type provided {}.", templateAction);
			throw new BookingEngineException(MessageConstants.TEMPLATE_NOT_FOUND);
		}
	}
}
