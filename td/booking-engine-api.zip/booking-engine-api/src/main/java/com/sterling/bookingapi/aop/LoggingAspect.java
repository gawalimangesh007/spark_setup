package com.sterling.bookingapi.aop;

import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.Marker;
import org.apache.logging.log4j.MarkerManager;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.sterling.bookingapi.utils.BookingEngineUtils;


/**
 * The Class LoggingAspect.
 */
@Aspect
@Component
/**
 * @author tcs
 *
 */
public class LoggingAspect {

	/** The Constant logger. */
	private static final Logger logger = LogManager.getLogger();
	
	public final static Marker PERFORMANCE_MARKER = MarkerManager.getMarker("Performance");
	public final static Marker BOOKING_TRACKER_MARKER = MarkerManager.getMarker("bookingTracker");
	public final static Marker CHANNEL_MANGER_MARKER = MarkerManager.getMarker("ChannelManager");
	public final static Marker BOOKING_TRACKER_MARKER_CSV = MarkerManager.getMarker("bookingTrackerCSV");
	public static final Marker WEB_TRACKER_MARKER_CSV = MarkerManager.getMarker("webtrackerCSV");
	
	@Pointcut("within(com.sterling.bookingapi..*)")
	public void enteringMethodPointcut(){
	}
	
	@Pointcut("execution(public * *(..))")
	private void anyPublicOperation() {}
	
	@Pointcut("execution(* com.sterling.bookingapi.controller.*.*(..))")
	public void controllerPointcut(){
	}
	
	@Pointcut("controllerPointcut() && anyPublicOperation()")
	public void controllerPublicPointcut(){
	}	
	
	@Pointcut("execution(* com.sterling.bookingapi.restapi.SterlingRestAPI.exchange(..))")
	public void restCallPointcut(){
	}
	
	
//	@Before(value = "enteringMethodPointcut()")
	public void logBeforePackageInterface(JoinPoint joinPoint) {
		
		String methodName = joinPoint.getSignature().getName();
		logger.info("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% LoggingAspect :: logBefore : {} : Entered",methodName);
		
	}

//	@After(value = "enteringMethodPointcut()")
	public void logAfterPackageInterface(JoinPoint joinPoint) {
		
		String methodName = joinPoint.getSignature().getName();
		logger.info("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% LoggingAspect :: logAfter : {} : Entered",methodName);
	}
	
	@Around(value = "controllerPublicPointcut() || restCallPointcut()")
	public Object logControllerEntry(ProceedingJoinPoint point) throws Throwable {
		
		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
		long start = System.currentTimeMillis();
		Object[] args = point.getArgs();
		Signature signature = point.getSignature();
		
		String declaringTypeName = signature.getDeclaringTypeName();
		for (Object arg : args) {
			logger.info(PERFORMANCE_MARKER,">>>>>>>>>>>>>>>>>>>>>>>> Request >>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
			logger.info(PERFORMANCE_MARKER,
					">>>>>>>>>> request for >>>>>>>>>> {}.{}",
					declaringTypeName,
					signature.getName());
			
			String contentType = request.getContentType();
			logger.info(PERFORMANCE_MARKER,">>>>>>>>>> Content Type : {} >>>>>>>>>>>>>>>",contentType);
			if((MediaType.APPLICATION_JSON_VALUE).equals(contentType))
				logger.info(PERFORMANCE_MARKER,BookingEngineUtils.convertObjectToString(arg));
			logger.info(PERFORMANCE_MARKER,">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
		}
		
		Object result;
		try {
			result = point.proceed();
		} catch (Exception e) {
			logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>> Error on {} >>>>>>>>>>>>>>>>>>>>>>>>>> request \n {}", declaringTypeName, BookingEngineUtils.convertObjectToString(args));
			throw e;
		}
		
		logger.info(PERFORMANCE_MARKER,">>>>>>>>>>>>>>>>>>>>>>>>>>> Response >>>>>>>>>>>>>>>>>>>>>>>>>>");
		logger.info(PERFORMANCE_MARKER,
				">>>>>>>>>> response for >>>>>>>>>> {}.{}",
				declaringTypeName,
				signature.getName());
		logger.info(PERFORMANCE_MARKER,BookingEngineUtils.convertObjectToString(result));
		logger.info(PERFORMANCE_MARKER,">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
		
		logger.info(PERFORMANCE_MARKER,
				"*********** PERFOMANCE *************** {}.{}: in {} ms",
				declaringTypeName,
				signature.getName(),
				System.currentTimeMillis() - start
				);
		
		return result;
	}
	

}