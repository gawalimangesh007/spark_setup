package com.sterling.bookingapi.dto.maximojo.response;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class BaseByGuestAmtResDTO.
 * @author tcs
 * @version 1.0
 */
public class BaseByGuestAmtResDTO {
	
	/** The number of guests. */
	@JacksonXmlProperty(localName = "NumberOfGuests", isAttribute = true)
	private int numberOfGuests;

	/** The amount before tax. */
	@JacksonXmlProperty(localName = "AmountBeforeTax", isAttribute = true)
    private double amountBeforeTax;

	/**
	 * Gets the number of guests.
	 *
	 * @return the numberOfGuests
	 */
	public int getNumberOfGuests() {
		return numberOfGuests;
	}

	/**
	 * Sets the number of guests.
	 *
	 * @param numberOfGuests the numberOfGuests to set
	 */
	public void setNumberOfGuests(int numberOfGuests) {
		this.numberOfGuests = numberOfGuests;
	}

	/**
	 * Gets the amount before tax.
	 *
	 * @return the amountBeforeTax
	 */
	public double getAmountBeforeTax() {
		return amountBeforeTax;
	}

	/**
	 * Sets the amount before tax.
	 *
	 * @param amountBeforeTax the amountBeforeTax to set
	 */
	public void setAmountBeforeTax(double amountBeforeTax) {
		this.amountBeforeTax = amountBeforeTax;
	}


}
