package com.sterling.bookingapi.dto.request;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.sterling.bookingapi.dto.PDFCancellationRuleDTO;
import com.sterling.bookingapi.dto.PDFCancellationRuleReqDTO;

/**
 * @author tcs
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class PDFContentRequestDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String bookingDate;
	
	private String resortImage;
	  private String resortLogo;
	  private String resortMoreImage;
	  private String sightSeeingImage;
	  private String resortMoreInfo;
	  private List<String> sightSeeingDetail;
	  private String insuranceImage;
	  private String additionalInfo;
	  List<PDFCancellationRuleReqDTO> cancellationRule;
	  private String resortAddress;
	  private String airportName;
	  private String aiportDetail;
	  private String railwayName;
	  private String railwayDetail;
	  private String busName;
	  private String busDetail;
	  List<String> usefulInfo;
	  String thingsToRemember;
	  private String idProofNote;
	  private String disclaimer;
	  List<String> resortList;
	  private String welcomeOfferCancellation;
	public String getBookingDate() {
		return bookingDate;
	}
	public void setBookingDate(String bookingDate) {
		this.bookingDate = bookingDate;
	}
	public String getResortImage() {
		return resortImage;
	}
	public void setResortImage(String resortImage) {
		this.resortImage = resortImage;
	}
	public String getResortLogo() {
		return resortLogo;
	}
	public void setResortLogo(String resortLogo) {
		this.resortLogo = resortLogo;
	}
	public String getResortMoreImage() {
		return resortMoreImage;
	}
	public void setResortMoreImage(String resortMoreImage) {
		this.resortMoreImage = resortMoreImage;
	}
	public String getSightSeeingImage() {
		return sightSeeingImage;
	}
	public void setSightSeeingImage(String sightSeeingImage) {
		this.sightSeeingImage = sightSeeingImage;
	}
	public String getResortMoreInfo() {
		return resortMoreInfo;
	}
	public void setResortMoreInfo(String resortMoreInfo) {
		this.resortMoreInfo = resortMoreInfo;
	}
	public List<String> getSightSeeingDetail() {
		return sightSeeingDetail;
	}
	public void setSightSeeingDetail(List<String> sightSeeingDetail) {
		this.sightSeeingDetail = sightSeeingDetail;
	}
	public String getInsuranceImage() {
		return insuranceImage;
	}
	public void setInsuranceImage(String insuranceImage) {
		this.insuranceImage = insuranceImage;
	}
	public String getAdditionalInfo() {
		return additionalInfo;
	}
	public void setAdditionalInfo(String additionalInfo) {
		this.additionalInfo = additionalInfo;
	}
	
	
	public List<PDFCancellationRuleReqDTO> getCancellationRule() {
		return cancellationRule;
	}
	public void setCancellationRule(List<PDFCancellationRuleReqDTO> cancellationRule) {
		this.cancellationRule = cancellationRule;
	}
	public String getResortAddress() {
		return resortAddress;
	}
	public void setResortAddress(String resortAddress) {
		this.resortAddress = resortAddress;
	}
	public String getAirportName() {
		return airportName;
	}
	public void setAirportName(String airportName) {
		this.airportName = airportName;
	}
	
	public String getAiportDetail() {
		return aiportDetail;
	}
	public void setAiportDetail(String aiportDetail) {
		this.aiportDetail = aiportDetail;
	}
	public String getRailwayName() {
		return railwayName;
	}
	public void setRailwayName(String railwayName) {
		this.railwayName = railwayName;
	}
	public String getRailwayDetail() {
		return railwayDetail;
	}
	public void setRailwayDetail(String railwayDetail) {
		this.railwayDetail = railwayDetail;
	}
	public String getBusName() {
		return busName;
	}
	public void setBusName(String busName) {
		this.busName = busName;
	}
	public String getBusDetail() {
		return busDetail;
	}
	public void setBusDetail(String busDetail) {
		this.busDetail = busDetail;
	}
	public List<String> getUsefulInfo() {
		return usefulInfo;
	}
	public void setUsefulInfo(List<String> usefulInfo) {
		this.usefulInfo = usefulInfo;
	}
	public String getThingsToRemember() {
		return thingsToRemember;
	}
	public void setThingsToRemember(String thingsToRemember) {
		this.thingsToRemember = thingsToRemember;
	}
	public String getIdProofNote() {
		return idProofNote;
	}
	public void setIdProofNote(String idProofNote) {
		this.idProofNote = idProofNote;
	}
	public String getDisclaimer() {
		return disclaimer;
	}
	public void setDisclaimer(String disclaimer) {
		this.disclaimer = disclaimer;
	}
	public List<String> getResortList() {
		return resortList;
	}
	public void setResortList(List<String> resortList) {
		this.resortList = resortList;
	}
	public String getWelcomeOfferCancellation() {
		return welcomeOfferCancellation;
	}
	public void setWelcomeOfferCancellation(String welcomeOfferCancellation) {
		this.welcomeOfferCancellation = welcomeOfferCancellation;
	}
	  
	  
	  
	

}
