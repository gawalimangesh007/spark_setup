package com.sterling.bookingapi.dto.maximojo.request;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class ResGuestRPHReqDTO.
 */
/**
 * @author tcs
 *
 */
public class ResGuestRPHReqDTO {
	
	/** The rph. */
	@JacksonXmlProperty(localName = "RPH", isAttribute = true)
	private int RPH;

	/**
	 * Gets the rph.
	 *
	 * @return the rPH
	 */
	public int getRPH() {
		return RPH;
	}

	/**
	 * Sets the rph.
	 *
	 * @param rPH the rPH to set
	 */
	public void setRPH(int rPH) {
		RPH = rPH;
	}
	
	
}
