package com.sterling.bookingapi.dto.maximojo.request;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class TaxesReqDTO.
 */
/**
 * @author tcs
 *
 */
public class TaxesReqDTO {

	/** The amount. */
	@JacksonXmlProperty(localName = "Amount", isAttribute = true)
	private double amount;

	/** The currency code. */
	@JacksonXmlProperty(localName = "CurrencyCode", isAttribute = true)
    private String currencyCode;

	/**
	 * Gets the amount.
	 *
	 * @return the amount
	 */
	public double getAmount() {
		return amount;
	}

	/**
	 * Sets the amount.
	 *
	 * @param amount the amount to set
	 */
	public void setAmount(double amount) {
		this.amount = amount;
	}

	/**
	 * Gets the currency code.
	 *
	 * @return the currencyCode
	 */
	public String getCurrencyCode() {
		return currencyCode;
	}

	/**
	 * Sets the currency code.
	 *
	 * @param currencyCode the currencyCode to set
	 */
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	
}
