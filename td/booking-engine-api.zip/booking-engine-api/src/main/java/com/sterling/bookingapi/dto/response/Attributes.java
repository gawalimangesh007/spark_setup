package com.sterling.bookingapi.dto.response;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;

/**
 * @author tcs
 * @version 1.0
 *
 */
@JsonTypeName("attributes")
@JsonIgnoreProperties(ignoreUnknown = true)
public class Attributes implements Serializable {
	
	private static final long serialVersionUID = 1L;

	@JsonProperty("type")
	private String type;
	
	@JsonProperty("url")
	private String url;

	/**
	 * @return type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type
	 * set the type
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return url
	 */
	public String getUrl() {
		return url;
	}

	/**
	 * @param url
	 * set the url
	 */
	public void setUrl(String url) {
		this.url = url;
	}
}
