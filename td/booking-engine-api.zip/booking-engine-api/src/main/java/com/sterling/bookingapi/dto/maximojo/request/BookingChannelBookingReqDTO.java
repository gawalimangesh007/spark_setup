package com.sterling.bookingapi.dto.maximojo.request;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class BookingChannelBookingReqDTO.
 */
/**
 * @author tcs
 *
 */
public class BookingChannelBookingReqDTO {

	/** The primary. */
	@JacksonXmlProperty(localName = "Primary",isAttribute = true)
	    private String primary;
	
	/** The type. */
	@JacksonXmlProperty(localName = "Type",isAttribute = true)
    private int type;

	/** The company name. */
	@JacksonXmlProperty(localName = "CompanyName")
	    private CompanyNameReqDTO companyName;

	/**
	 * Gets the type.
	 *
	 * @return the type
	 */
	public int getType() {
		return type;
	}

	/**
	 * Sets the type.
	 *
	 * @param type the type to set
	 */
	public void setType(int type) {
		this.type = type;
	}

	/**
	 * Gets the primary.
	 *
	 * @return the primary
	 */
	public String getPrimary() {
		return primary;
	}

	/**
	 * Sets the primary.
	 *
	 * @param primary the primary to set
	 */
	public void setPrimary(String primary) {
		this.primary = primary;
	}

	/**
	 * Gets the company name.
	 *
	 * @return the companyName
	 */
	public CompanyNameReqDTO getCompanyName() {
		return companyName;
	}

	/**
	 * Sets the company name.
	 *
	 * @param companyName the companyName to set
	 */
	public void setCompanyName(CompanyNameReqDTO companyName) {
		this.companyName = companyName;
	}
	
	
}
