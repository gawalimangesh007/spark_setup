package com.sterling.bookingapi.dto.request;

import java.io.Serializable;
import java.util.List;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author tcs
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class VOBlockBookingRequest implements Serializable {

	private static final long serialVersionUID = 1L;

	private String bookingDate;
	
	@NotEmpty(message="Contract id should not be empty")
	private String contractId;
	
	@NotEmpty(message="checkInDate should not be empty")
	private String checkInDate;
	
	@NotEmpty(message="checkOutDate should not be empty")
	private String checkOutDate;
	
	@NotEmpty(message="bookingStatus should not be empty")
	private String bookingStatus;
	
	@NotEmpty(message="noOfAdults should not be empty")
	@Pattern(regexp="^[0-9]*$", message="noOfChildren should be a number")
	private String noOfAdults;
	
	@NotEmpty(message="noOfChildren should not be empty")
	@Pattern(regexp="^[0-9]*$", message="noOfChildren should be a number")
	private String noOfChildren;
	
	@NotNull(message="productId should not be empty")
	private String productId;
	
	@NotNull(message="productCode should not be empty")
	private String productCode;
	
	@NotNull(message="Resort id should not be empty")
	private String resortMasterId;

	@NotNull(message="Resort id should not be empty")
	private String resortSerielNo;
	
	@JsonProperty("_1BR")
	private String noOf1BR;
	@JsonProperty("_2BR")
	private String noOf2BR;
	@JsonProperty("_ST")
	private String noOfStudio;
	@JsonProperty("_GR")
	private String noOfGuest;
	
	@NotEmpty(message="bookingPoints shouldnot be empty")
	private String bookingPoints;
	
	private boolean advPointsNext1;
	private boolean advPointsNext2;
	
	private String bookingType;

	private String utilityChargesMasterId;

	private Boolean isOfferBooking = false;
	private String offerType;
	private String offerCheckinDate;
	private String offerCheckoutDate;
	private String offerId;
	
	private Boolean isHolidayFallen;
	private Boolean isNationalHolidayFallen;
	
	private List<SeasonDetail> seasonDetail;
	
	@NotNull(message="blockerTimer should not be null")
	private Double blockerTimer;

	private String aliasName;

	
	@JsonIgnore
	private String bookingId;
	
	
	private String insuranceFlag;
	
	public String getInsuranceFlag() {
		return insuranceFlag;
	}

	public void setInsuranceFlag(String insuranceFlag) {
		this.insuranceFlag = insuranceFlag;
	}

	public String getOfferType() {
		return offerType;
	}

	public void setOfferType(String offerType) {
		this.offerType = offerType;
	}

	public String getOfferCheckinDate() {
		return offerCheckinDate;
	}

	public void setOfferCheckinDate(String offerCheckinDate) {
		this.offerCheckinDate = offerCheckinDate;
	}

	public String getOfferCheckoutDate() {
		return offerCheckoutDate;
	}

	public void setOfferCheckoutDate(String offerCheckoutDate) {
		this.offerCheckoutDate = offerCheckoutDate;
	}

	public String getOfferId() {
		return offerId;
	}

	public void setOfferId(String offerId) {
		this.offerId = offerId;
	}

	public String getAliasName() {
		return aliasName;
	}

	public void setAliasName(String aliasName) {
		this.aliasName = aliasName;
	}

	public String getBookingId() {
		return bookingId;
	}

	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}

	public String getUtilityChargesMasterId() {
		return utilityChargesMasterId;
	}

	public void setUtilityChargesMasterId(String utilityChargesMasterId) {
		this.utilityChargesMasterId = utilityChargesMasterId;
	}

	public Double getBlockerTimer() {
		return blockerTimer;
	}

	public void setBlockerTimer(Double blockerTimer) {
		this.blockerTimer = blockerTimer;
	}

	public String getBookingDate() {
		return bookingDate;
	}

	public void setBookingDate(String bookingDate) {
		this.bookingDate = bookingDate;
	}

	public String getContractId() {
		return contractId;
	}

	public void setContractId(String contractId) {
		this.contractId = contractId;
	}

	public String getCheckInDate() {
		return checkInDate;
	}

	public void setCheckInDate(String checkInDate) {
		this.checkInDate = checkInDate;
	}

	public String getCheckOutDate() {
		return checkOutDate;
	}

	public void setCheckOutDate(String checkOutDate) {
		this.checkOutDate = checkOutDate;
	}

	public String getBookingStatus() {
		return bookingStatus;
	}

	public void setBookingStatus(String bookingStatus) {
		this.bookingStatus = bookingStatus;
	}

	public String getNoOfAdults() {
		return noOfAdults;
	}

	public void setNoOfAdults(String noOfAdults) {
		this.noOfAdults = noOfAdults;
	}

	public String getNoOfChildren() {
		return noOfChildren;
	}

	public void setNoOfChildren(String noOfChildren) {
		this.noOfChildren = noOfChildren;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getResortMasterId() {
		return resortMasterId;
	}

	public void setResortMasterId(String resortMasterId) {
		this.resortMasterId = resortMasterId;
	}

	public String getResortSerielNo() {
		return resortSerielNo;
	}

	public void setResortSerielNo(String resortSerielNo) {
		this.resortSerielNo = resortSerielNo;
	}

	public String getNoOf1BR() {
		return noOf1BR;
	}

	public void setNoOf1BR(String noOf1BR) {
		this.noOf1BR = noOf1BR;
	}

	public String getNoOf2BR() {
		return noOf2BR;
	}

	public void setNoOf2BR(String noOf2BR) {
		this.noOf2BR = noOf2BR;
	}

	public String getNoOfStudio() {
		return noOfStudio;
	}

	public void setNoOfStudio(String noOfStudio) {
		this.noOfStudio = noOfStudio;
	}

	public String getNoOfGuest() {
		return noOfGuest;
	}

	public void setNoOfGuest(String noOfGuest) {
		this.noOfGuest = noOfGuest;
	}

	public String getBookingPoints() {
		return bookingPoints;
	}

	public void setBookingPoints(String bookingPoints) {
		this.bookingPoints = bookingPoints;
	}

	public boolean isAdvPointsNext1() {
		return advPointsNext1;
	}

	public void setAdvPointsNext1(boolean advPointsNext1) {
		this.advPointsNext1 = advPointsNext1;
	}

	public boolean isAdvPointsNext2() {
		return advPointsNext2;
	}

	public void setAdvPointsNext2(boolean advPointsNext2) {
		this.advPointsNext2 = advPointsNext2;
	}

	public String getBookingType() {
		return bookingType;
	}

	public void setBookingType(String bookingType) {
		this.bookingType = bookingType;
	}

	public Boolean getIsOfferBooking() {
		return isOfferBooking;
	}

	public void setIsOfferBooking(Boolean isOfferBooking) {
		this.isOfferBooking = isOfferBooking;
	}

	public Boolean getIsHolidayFallen() {
		return isHolidayFallen;
	}

	public void setIsHolidayFallen(Boolean isHolidayFallen) {
		this.isHolidayFallen = isHolidayFallen;
	}

	public Boolean getIsNationalHolidayFallen() {
		return isNationalHolidayFallen;
	}

	public void setIsNationalHolidayFallen(Boolean isNationalHolidayFallen) {
		this.isNationalHolidayFallen = isNationalHolidayFallen;
	}

	public List<SeasonDetail> getSeasonDetail() {
		return seasonDetail;
	}

	public void setSeasonDetail(List<SeasonDetail> seasonDetail) {
		this.seasonDetail = seasonDetail;
	}
	
}
