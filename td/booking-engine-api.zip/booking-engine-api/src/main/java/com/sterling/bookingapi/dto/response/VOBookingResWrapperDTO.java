package com.sterling.bookingapi.dto.response;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.sterling.bookingapi.dto.PaymentRequestDTO;

/**
 * @author tcs
 * @version 1.0
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class VOBookingResWrapperDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private BookingResponseDTO bookingDetail;
	private PaymentRequestDTO paymentReq;

	public VOBookingResWrapperDTO() {
		super();
	}
	
	public VOBookingResWrapperDTO(BookingResponseDTO bookingDetail,
			PaymentRequestDTO paymentReq) {
		super();
		this.bookingDetail = bookingDetail;
		this.paymentReq = paymentReq;
	}


	public BookingResponseDTO getBookingDetail() {
		return bookingDetail;
	}
	public void setBookingDetail(BookingResponseDTO bookingDetail) {
		this.bookingDetail = bookingDetail;
	}
	public PaymentRequestDTO getPaymentReq() {
		return paymentReq;
	}
	public void setPaymentReq(PaymentRequestDTO paymentReq) {
		this.paymentReq = paymentReq;
	}
	
}
