package com.sterling.bookingapi.dto.response;

import java.io.Serializable;

/**
 * @author tcs
 * @version 1.0
 *
 */
public class ASFDetails implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String structureId;
	private String invoiceNumber;
	private String dueDate;
	private String invoiceDate;
	private String dueAmount;
	private double overDueAmount;
	private String paymentType;
	
	
	/**
	 * @return structureId
	 */
	public String getStructureId() {
		return structureId;
	}
	/**
	 * @param structureId
	 * set the structureId
	 */
	public void setStructureId(String structureId) {
		this.structureId = structureId;
	}
	/**
	 * @return invoiceNumber
	 */
	public String getInvoiceNumber() {
		return invoiceNumber;
	}
	/**
	 * @param invoiceNumber
	 * set the invoiceNumber
	 */
	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}
	/**
	 * @return dueDate
	 */
	public String getDueDate() {
		return dueDate;
	}
	/**
	 * @param dueDate
	 * set the dueDate
	 */
	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}
	/**
	 * @return invoiceDate
	 */
	public String getInvoiceDate() {
		return invoiceDate;
	}
	/**
	 * @param invoiceDate
	 * set the invoiceDate
	 */
	public void setInvoiceDate(String invoiceDate) {
		this.invoiceDate = invoiceDate;
	}
	/**
	 * @return dueAmount
	 */
	public String getDueAmount() {
		return dueAmount;
	}
	/**
	 * @param dueAmount
	 * set the dueAmount
	 */
	public void setDueAmount(String dueAmount) {
		this.dueAmount = dueAmount;
	}
	/**
	 * @return overDueAmount
	 */
	public double getOverDueAmount() {
		return overDueAmount;
	}
	/**
	 * @param overDueAmount
	 * set the overDueAmount
	 */
	public void setOverDueAmount(double overDueAmount) {
		this.overDueAmount = overDueAmount;
	}
	/**
	 * @return paymentType
	 */
	public String getPaymentType() {
		return paymentType;
	}
	/**
	 * @param paymentType
	 * set the paymentType
	 */
	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}
	
	

}
