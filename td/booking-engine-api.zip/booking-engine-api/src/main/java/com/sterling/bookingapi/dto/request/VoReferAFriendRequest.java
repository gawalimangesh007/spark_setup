package com.sterling.bookingapi.dto.request;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class VoReferAFriendRequest implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private List<PersonDetailsReq> friendsList;
	private String contractId;
	

	public List<PersonDetailsReq> getFriendsList() {
		return friendsList;
	}
	public void setFriendsList(List<PersonDetailsReq> friendsList) {
		this.friendsList = friendsList;
	}
	public String getContractId() {
		return contractId;
	}
	public void setContractId(String contractId) {
		this.contractId = contractId;
	}
	
}
