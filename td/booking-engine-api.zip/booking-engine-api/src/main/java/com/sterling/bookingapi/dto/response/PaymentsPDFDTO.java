package com.sterling.bookingapi.dto.response;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author tcs
 * @version 1.0
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class PaymentsPDFDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String paymentName;
	private String paymentType;
	private String paymentMode;
	private String paymentDate;
	private Double amount;
	private Double paidAmount;
	private Double balanceAmount;
	private String transactionID;
	private String year;
	private String feeType;
	
	private Double latePaymentCharge;
	private String lateFeeStatus;

	
	public Double getPaidAmount() {
		return paidAmount;
	}
	public void setPaidAmount(Double paidAmount) {
		this.paidAmount = paidAmount;
	}
	public Double getBalanceAmount() {
		return balanceAmount;
	}
	public void setBalanceAmount(Double balanceAmount) {
		this.balanceAmount = balanceAmount;
	}
	public String getFeeType() {
		return feeType;
	}
	public void setFeeType(String feeType) {
		this.feeType = feeType;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public Double getLatePaymentCharge() {
		return latePaymentCharge;
	}
	public void setLatePaymentCharge(Double latePaymentCharge) {
		this.latePaymentCharge = latePaymentCharge;
	}
	public String getLateFeeStatus() {
		return lateFeeStatus;
	}
	public void setLateFeeStatus(String lateFeeStatus) {
		this.lateFeeStatus = lateFeeStatus;
	}
	/**
	 * @return paymentName
	 */
	public String getPaymentName() {
		return paymentName;
	}
	/**
	 * @param paymentName
	 * set the paymentName
	 */
	public void setPaymentName(String paymentName) {
		this.paymentName = paymentName;
	}
	/**
	 * @return paymentType
	 */
	public String getPaymentType() {
		return paymentType;
	}
	/**
	 * @param paymentType
	 * set the paymentType
	 */
	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}
	/**
	 * @return paymentDate
	 */
	public String getPaymentDate() {
		return paymentDate;
	}
	/**
	 * @param paymentDate
	 * set the paymentDate
	 */
	public void setPaymentDate(String paymentDate) {
		this.paymentDate = paymentDate;
	}
	/**
	 * @return amount
	 */
	public Double getAmount() {
		return amount;
	}
	/**
	 * @param amount
	 * set the amount
	 */
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	/**
	 * @return transactionID
	 */
	public String getTransactionID() {
		return transactionID;
	}
	/**
	 * @param transactionID
	 * set the transactionID
	 */
	public void setTransactionID(String transactionID) {
		this.transactionID = transactionID;
	}
	/**
	 * @return the paymentMode
	 */
	public String getPaymentMode() {
		return paymentMode;
	}
	/**
	 * @param paymentMode the paymentMode to set
	 */
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}
	
}
