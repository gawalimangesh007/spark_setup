package com.sterling.bookingapi.dto.response;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class VOUnitProductPointMatrixResDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String productCode;
	private String productId;
	private String productCategory;
	
	private String resortId;

	private List<VOUnitProductPointDetailResDTO> pointDetails;
	
	
	public String getResortId() {
		return resortId;
	}

	public void setResortId(String resortId) {
		this.resortId = resortId;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public List<VOUnitProductPointDetailResDTO> getPointDetails() {
		return pointDetails;
	}

	public void setPointDetails(List<VOUnitProductPointDetailResDTO> pointDetails) {
		this.pointDetails = pointDetails;
	}

	public String getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}
	
}
