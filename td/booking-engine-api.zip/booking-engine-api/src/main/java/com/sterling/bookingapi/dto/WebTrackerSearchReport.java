package com.sterling.bookingapi.dto;

import java.util.Date;

public class WebTrackerSearchReport {

	private int webTrackerId;
	private String browsernamenversion;
	private String osnamenversion;
	private String devicenamenversion;
	private Date timestamp;
	private String isloggedin;
	private String username;
	private String userid;
	private String pagename;
	private String refererDomain;
	private int actionid;
	private String actiontype;
	private String actiondesc;
	private String chanel;
	private String resort;
	private String ratePlan;
	private String roomType;
	private String promoCode;
	private String startedate;
	private String enddate;
	private String noofguest;
	private String name;
	private String email;
	private String mobile;
	private String eventid;
	private String eventtype;
	private String eventdec;
	private String value;
	private Date createdOn;
	private String createdBy;
	private Date updatedOn;
	private String updatedBy;
	
	public int getWebTrackerId() {
		return webTrackerId;
	}
	public void setWebTrackerId(int webTrackerId) {
		this.webTrackerId = webTrackerId;
	}
	public String getBrowsernamenversion() {
		return browsernamenversion;
	}
	public void setBrowsernamenversion(String browsernamenversion) {
		this.browsernamenversion = browsernamenversion;
	}
	public String getOsnamenversion() {
		return osnamenversion;
	}
	public void setOsnamenversion(String osnamenversion) {
		this.osnamenversion = osnamenversion;
	}
	public String getDevicenamenversion() {
		return devicenamenversion;
	}
	public void setDevicenamenversion(String devicenamenversion) {
		this.devicenamenversion = devicenamenversion;
	}
	public Date getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}
	
	public String getIsloggedin() {
		return isloggedin;
	}
	public void setIsloggedin(String isloggedin) {
		this.isloggedin = isloggedin;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getPagename() {
		return pagename;
	}
	public void setPagename(String pagename) {
		this.pagename = pagename;
	}
	public String getRefererDomain() {
		return refererDomain;
	}
	public void setRefererDomain(String refererDomain) {
		this.refererDomain = refererDomain;
	}
	public int getActionid() {
		return actionid;
	}
	public void setActionid(int actionid) {
		this.actionid = actionid;
	}
	public String getActiontype() {
		return actiontype;
	}
	public void setActiontype(String actiontype) {
		this.actiontype = actiontype;
	}
	public String getActiondesc() {
		return actiondesc;
	}
	public void setActiondesc(String actiondesc) {
		this.actiondesc = actiondesc;
	}
	public String getChanel() {
		return chanel;
	}
	public void setChanel(String chanel) {
		this.chanel = chanel;
	}
	public String getResort() {
		return resort;
	}
	public void setResort(String resort) {
		this.resort = resort;
	}
	public String getRatePlan() {
		return ratePlan;
	}
	public void setRatePlan(String ratePlan) {
		this.ratePlan = ratePlan;
	}
	public String getRoomType() {
		return roomType;
	}
	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}
	public String getPromoCode() {
		return promoCode;
	}
	public void setPromoCode(String promoCode) {
		this.promoCode = promoCode;
	}
	public String getStartedate() {
		return startedate;
	}
	public void setStartedate(String startedate) {
		this.startedate = startedate;
	}
	public String getEnddate() {
		return enddate;
	}
	public void setEnddate(String enddate) {
		this.enddate = enddate;
	}
	public String getNoofguest() {
		return noofguest;
	}
	public void setNoofguest(String noofguest) {
		this.noofguest = noofguest;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getEventid() {
		return eventid;
	}
	public void setEventid(String eventid) {
		this.eventid = eventid;
	}
	public String getEventtype() {
		return eventtype;
	}
	public void setEventtype(String eventtype) {
		this.eventtype = eventtype;
	}
	public String getEventdec() {
		return eventdec;
	}
	public void setEventdec(String eventdec) {
		this.eventdec = eventdec;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Date getUpdatedOn() {
		return updatedOn;
	}
	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	
	public WebTrackerSearchReport(int webTrackerId, String browsernamenversion,
			String osnamenversion, String devicenamenversion, Date timestamp,
			String isloggedin, String username, String userid,
			String pagename, String refererDomain, int actionid,
			String actiontype, String actiondesc, String chanel, String resort,
			String ratePlan, String roomType, String promoCode,
			String startedate, String enddate, String noofguest, String name,
			String email, String mobile, String eventid, String eventtype,
			String eventdec, String value, Date createdOn, String createdBy,
			Date updatedOn, String updatedBy) {
		super();
		this.webTrackerId = webTrackerId;
		this.browsernamenversion = browsernamenversion;
		this.osnamenversion = osnamenversion;
		this.devicenamenversion = devicenamenversion;
		this.timestamp = timestamp;
		this.isloggedin = isloggedin;
		this.username = username;
		this.userid = userid;
		this.pagename = pagename;
		this.refererDomain = refererDomain;
		this.actionid = actionid;
		this.actiontype = actiontype;
		this.actiondesc = actiondesc;
		this.chanel = chanel;
		this.resort = resort;
		this.ratePlan = ratePlan;
		this.roomType = roomType;
		this.promoCode = promoCode;
		this.startedate = startedate;
		this.enddate = enddate;
		this.noofguest = noofguest;
		this.name = name;
		this.email = email;
		this.mobile = mobile;
		this.eventid = eventid;
		this.eventtype = eventtype;
		this.eventdec = eventdec;
		this.value = value;
		this.createdOn = createdOn;
		this.createdBy = createdBy;
		this.updatedOn = updatedOn;
		this.updatedBy = updatedBy;
	}
	
	
}
