package com.sterling.bookingapi.dto.request;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class EventInfo implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private long eventrefid;
	private String eventid;
	private String eventtype;
	private String eventdec;
	private String value;
	
	public long getEventrefid() {
		return eventrefid;
	}
	public void setEventrefid(long eventrefid) {
		this.eventrefid = eventrefid;
	}
	public String getEventid() {
		return eventid;
	}
	public void setEventid(String eventid) {
		this.eventid = eventid;
	}
	public String getEventtype() {
		return eventtype;
	}
	public void setEventtype(String eventtype) {
		this.eventtype = eventtype;
	}
	public String getEventdec() {
		return eventdec;
	}
	public void setEventdec(String eventdec) {
		this.eventdec = eventdec;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}

	
}
