package com.sterling.bookingapi.dto.maximojo.response;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class HotelReservationsBookingResDTO.
 * @author tcs
 * @version 1.0
 */
public class HotelReservationsBookingResDTO {

	/** The hotel reservation. */
	@JacksonXmlProperty(localName = "HotelReservation")
	private HotelReservationBookingResDTO hotelReservation;

	/** The xmlns. */
	@JacksonXmlProperty(localName = "xmlns", isAttribute = true)
    private String xmlns;

	/**
	 * Gets the hotel reservation.
	 *
	 * @return the hotelReservation
	 */
	public HotelReservationBookingResDTO getHotelReservation() {
		return hotelReservation;
	}

	/**
	 * Sets the hotel reservation.
	 *
	 * @param hotelReservation the hotelReservation to set
	 */
	public void setHotelReservation(HotelReservationBookingResDTO hotelReservation) {
		this.hotelReservation = hotelReservation;
	}

	/**
	 * Gets the xmlns.
	 *
	 * @return the xmlns
	 */
	public String getXmlns() {
		return xmlns;
	}

	/**
	 * Sets the xmlns.
	 *
	 * @param xmlns the xmlns to set
	 */
	public void setXmlns(String xmlns) {
		this.xmlns = xmlns;
	}
	
	
}
