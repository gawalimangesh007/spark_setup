package com.sterling.bookingapi.dto.maximojo.request;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

public class ExtraAdultRateDTO {

	@JacksonXmlProperty(localName = "ExtraPersonType", isAttribute = true)
	private String extraPersonType;
	
	@JacksonXmlProperty(localName = "ExtraPersonCount", isAttribute = true)
	private int extraPersonCount;
	
	@JacksonXmlProperty(localName = "ExtraPersonRate", isAttribute = true)
	private double extraPersonRate;
	
	@JacksonXmlProperty(localName = "ExtraPersonCost", isAttribute = true)
	private double extraPersonCost;

	@JacksonXmlProperty(localName = "CurrencyCode", isAttribute = true)
    private String currencyCode;

	/**
	 * @return the extraPersonType
	 */
	public String getExtraPersonType() {
		return extraPersonType;
	}

	/**
	 * @param extraPersonType the extraPersonType to set
	 */
	public void setExtraPersonType(String extraPersonType) {
		this.extraPersonType = extraPersonType;
	}

	/**
	 * @return the extraPersonCount
	 */
	public int getExtraPersonCount() {
		return extraPersonCount;
	}

	/**
	 * @param extraPersonCount the extraPersonCount to set
	 */
	public void setExtraPersonCount(int extraPersonCount) {
		this.extraPersonCount = extraPersonCount;
	}

	/**
	 * @return the extraPersonRate
	 */
	public double getExtraPersonRate() {
		return extraPersonRate;
	}

	/**
	 * @param extraPersonRate the extraPersonRate to set
	 */
	public void setExtraPersonRate(double extraPersonRate) {
		this.extraPersonRate = extraPersonRate;
	}

	/**
	 * @return the extraPersonCost
	 */
	public double getExtraPersonCost() {
		return extraPersonCost;
	}

	/**
	 * @param extraPersonCost the extraPersonCost to set
	 */
	public void setExtraPersonCost(double extraPersonCost) {
		this.extraPersonCost = extraPersonCost;
	}

	/**
	 * @return the currencyCode
	 */
	public String getCurrencyCode() {
		return currencyCode;
	}

	/**
	 * @param currencyCode the currencyCode to set
	 */
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}
	
}
