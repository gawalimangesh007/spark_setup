package com.sterling.bookingapi.mail;


/**
 * The Class AttachmentReqDTO.
 */
/**
 * @author tcs
 * @version 1.0
 *
 */
public class AttachmentReqDTO {
	
	/** The file name. */
	private String fileName;
	
	/** The bytes. */
	private byte[] bytes;
	
	/** The mime type. */
	private String mimeType;
	
	/**
	 * Gets the file name.
	 *
	 * @return the file name
	 */
	public String getFileName() {
		return fileName;
	}
	
	/**
	 * Sets the file name.
	 *
	 * @param fileName the new file name
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	
	/**
	 * Gets the bytes.
	 *
	 * @return the bytes
	 */
	public byte[] getBytes() {
		return bytes;
	}
	
	/**
	 * Sets the bytes.
	 *
	 * @param bytes the new bytes
	 */
	public void setBytes(byte[] bytes) {
		this.bytes = bytes;
	}
	
	/**
	 * Gets the mime type.
	 *
	 * @return the mime type
	 */
	public String getMimeType() {
		return mimeType;
	}
	
	/**
	 * Sets the mime type.
	 *
	 * @param mimeType the new mime type
	 */
	public void setMimeType(String mimeType) {
		this.mimeType = mimeType;
	}
	
	
}
