package com.sterling.bookingapi.dto.response;

import java.util.List;

public class HSDResortRoomMappingResDTO {
	
	/** The room type id. */
	private String roomTypeId;

	/** The room type. */
	private String roomType;
	
	private List<HSDResortRateMappingResDTO> ratesMapped;

	public String getRoomTypeId() {
		return roomTypeId;
	}

	public void setRoomTypeId(String roomTypeId) {
		this.roomTypeId = roomTypeId;
	}

	public String getRoomType() {
		return roomType;
	}

	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}

	public List<HSDResortRateMappingResDTO> getRatesMapped() {
		return ratesMapped;
	}

	public void setRatesMapped(List<HSDResortRateMappingResDTO> ratesMapped) {
		this.ratesMapped = ratesMapped;
	}	
}
