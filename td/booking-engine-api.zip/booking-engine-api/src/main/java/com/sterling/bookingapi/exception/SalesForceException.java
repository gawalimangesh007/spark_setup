package com.sterling.bookingapi.exception;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.sterling.bookingapi.sf.dto.response.SalesForceErrorResponse;


/**
 * The Class SalesForceException.
 */
/**
 * @author tcs
 * @version 1.0
 *
 */
public class SalesForceException extends BookingEngineException {

	private static final long serialVersionUID = 1L;
	
	/** The status. */
	@JsonProperty("status")
	private int status;

	private List<SalesForceErrorResponse> err;

    /**
     * Instantiates a new sales force exception.
     *
     * @param message the message
     * @param status the status
     */
    public SalesForceException(String message, int status) {
		super(message);
		this.status = status;
	}  


    public SalesForceException(int errCode, String message, List<SalesForceErrorResponse> err) {
		super(errCode, message);
		this.status = errCode;
		this.err = err;
	} 
    /**
      * Instantiates a new sales force exception.
      *
      * @param message the message
      */
     public SalesForceException(String message){
    	 super(message);
     }

	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
    @JsonProperty("status")
	public int getStatus() {
		return status;
	}

	/**
	 * Sets the status.
	 *
	 * @param status the status to set
	 */
    @JsonProperty("status")
	public void setStatus(int status) {
		this.status = status;
	}


	public List<SalesForceErrorResponse> getErr() {
		return err;
	}


	public void setErr(List<SalesForceErrorResponse> err) {
		this.err = err;
	}
    
}