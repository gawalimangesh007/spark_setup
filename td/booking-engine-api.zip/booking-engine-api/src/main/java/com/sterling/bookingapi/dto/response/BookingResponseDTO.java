package com.sterling.bookingapi.dto.response;

/**
 * @author tcs
 * @version 1.0
 */
public class BookingResponseDTO {

	private String bookingId;

	private String cvNumber;
	
	/**
	 * @return cvNumber
	 */
	public String getCvNumber() {
		return cvNumber;
	}

	/**
	 * @param cvNumber
	 * set the cvNumber
	 */
	public void setCvNumber(String cvNumber) {
		this.cvNumber = cvNumber;
	}

	/**
	 * @return bookingId
	 */
	public String getBookingId() {
		return bookingId;
	}

	/**
	 * @param bookingId
	 * set the bookingId
	 */
	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}
	
	
}
