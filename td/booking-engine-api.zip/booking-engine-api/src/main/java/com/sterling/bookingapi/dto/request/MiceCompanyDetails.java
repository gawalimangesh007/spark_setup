package com.sterling.bookingapi.dto.request;

import java.io.Serializable;

public class MiceCompanyDetails implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String name;
	private String department;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	
}
