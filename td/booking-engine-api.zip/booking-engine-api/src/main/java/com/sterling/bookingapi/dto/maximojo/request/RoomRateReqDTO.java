package com.sterling.bookingapi.dto.maximojo.request;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class RoomRateReqDTO.
 */
/**
 * @author tcs
 *
 */
public class RoomRateReqDTO {

	/** The number of units. */
	/*@JacksonXmlProperty(localName = "NumberOfUnits", isAttribute = true)
 	private int numberOfUnits;*/

	/** The rate plan category. */
	@JacksonXmlProperty(localName = "RatePlanCategory", isAttribute = true)
    private String ratePlanCategory;
	
	/** The rate plan code. */
	@JacksonXmlProperty(localName = "RatePlanCode", isAttribute = true)
    private String ratePlanCode;

    /** The room type code. */
	@JacksonXmlProperty(localName = "RoomTypeCode", isAttribute = true)
    private String roomTypeCode;
	
	/** The room type code. */
	@JacksonXmlProperty(localName = "RoomUpgrade", isAttribute = true)
	private boolean roomUpgrade;
    
	/** The rate. */
	
	@JacksonXmlProperty(localName = "Rates")
	private RoomRateDTO rates;
	
	/** The guest counts. */
	@JacksonXmlProperty(localName = "GuestCounts")
    private GuestCountsReqDTO guestCounts;
	
	
	/**
	 * Gets the guest counts.
	 *
	 * @return the guest counts
	 */
	public GuestCountsReqDTO getGuestCounts() {
		return guestCounts;
	}

	/**
	 * Sets the guest counts.
	 *
	 * @param guestCounts the new guest counts
	 */
	public void setGuestCounts(GuestCountsReqDTO guestCounts) {
		this.guestCounts = guestCounts;
	}

   /* *//**
    	 * Gets the number of units.
    	 *
    	 * @return the numberOfUnits
    	 *//*
	public int getNumberOfUnits() {
		return numberOfUnits;
	}

	*//**
	 * Sets the number of units.
	 *
	 * @param numberOfUnits the numberOfUnits to set
	 *//*
	public void setNumberOfUnits(int numberOfUnits) {
		this.numberOfUnits = numberOfUnits;
	}*/

	/**
	 * Gets the rate.
	 *
	 * @return the rate
	 */
	

	/**
	 * Gets the rate plan category.
	 *
	 * @return the ratePlanCategory
	 */
	public String getRatePlanCategory() {
		return ratePlanCategory;
	}

	/**
	 * Sets the rate plan category.
	 *
	 * @param ratePlanCategory the ratePlanCategory to set
	 */
	public void setRatePlanCategory(String ratePlanCategory) {
		this.ratePlanCategory = ratePlanCategory;
	}

	/**
	 * Gets the rate plan code.
	 *
	 * @return the ratePlanCode
	 */
	public String getRatePlanCode() {
		return ratePlanCode;
	}

	/**
	 * Sets the rate plan code.
	 *
	 * @param ratePlanCode the ratePlanCode to set
	 */
	public void setRatePlanCode(String ratePlanCode) {
		this.ratePlanCode = ratePlanCode;
	}

	/**
	 * Gets the room type code.
	 *
	 * @return the roomTypeCode
	 */
	public String getRoomTypeCode() {
		return roomTypeCode;
	}

	/**
	 * Sets the room type code.
	 *
	 * @param roomTypeCode the roomTypeCode to set
	 */
	public void setRoomTypeCode(String roomTypeCode) {
		this.roomTypeCode = roomTypeCode;
	}

	/**
	 * @return the roomUpgrade
	 */
	public boolean isRoomUpgrade() {
		return roomUpgrade;
	}

	/**
	 * @param roomUpgrade the roomUpgrade to set
	 */
	public void setRoomUpgrade(boolean roomUpgrade) {
		this.roomUpgrade = roomUpgrade;
	}

	/**
	 * @return the rates
	 */
	public RoomRateDTO getRates() {
		return rates;
	}

	/**
	 * @param rates the rates to set
	 */
	public void setRates(RoomRateDTO rates) {
		this.rates = rates;
	}

}
