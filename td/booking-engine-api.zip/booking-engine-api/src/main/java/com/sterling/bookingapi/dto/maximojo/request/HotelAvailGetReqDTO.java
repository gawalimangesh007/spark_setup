package com.sterling.bookingapi.dto.maximojo.request;

import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;


/**
 * The Class HotelAvailGetReqDTO.
 */
/**
 * @author tcs
 *
 */
@JacksonXmlRootElement(localName = "OTA_HotelAvailGetRQ")
public class HotelAvailGetReqDTO {

	/** The time stamp. */
	@JacksonXmlProperty(localName = "TimeStamp", isAttribute = true)
	private String timeStamp;

	/** The transaction identifier. */
	@JacksonXmlProperty(localName = "TransactionIdentifier", isAttribute = true)
    private String transactionIdentifier;

	/** The xmlns. */
	@JacksonXmlProperty(localName = "xmlns", isAttribute = true)
	private String xmlns="http://www.opentravel.org/OTA/2003/05";

	/** The version. */
	@JacksonXmlProperty(localName = "Version", isAttribute = true)
    private String version;

	/** The echo token. */
	@JacksonXmlProperty(localName = "EchoToken", isAttribute = true)
    private String echoToken;

	/** The hotel avail request. */
	@JacksonXmlElementWrapper(useWrapping=true, localName = "HotelAvailRequests")
	@JacksonXmlProperty(localName = "HotelAvailRequest")
	private List<HotelAvailReqDTO> hotelAvailRequest;

	/**
	 * Gets the time stamp.
	 *
	 * @return the timeStamp
	 */
	public String getTimeStamp() {
		return timeStamp;
	}

	/**
	 * Sets the time stamp.
	 *
	 * @param timeStamp the timeStamp to set
	 */
	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}

	/**
	 * Gets the transaction identifier.
	 *
	 * @return the transactionIdentifier
	 */
	public String getTransactionIdentifier() {
		return transactionIdentifier;
	}

	/**
	 * Sets the transaction identifier.
	 *
	 * @param transactionIdentifier the transactionIdentifier to set
	 */
	public void setTransactionIdentifier(String transactionIdentifier) {
		this.transactionIdentifier = transactionIdentifier;
	}

	/**
	 * Gets the xmlns.
	 *
	 * @return the xmlns
	 */
	public String getXmlns() {
		return xmlns;
	}

	/**
	 * Sets the xmlns.
	 *
	 * @param xmlns the xmlns to set
	 */
	public void setXmlns(String xmlns) {
		this.xmlns = xmlns;
	}

	/**
	 * Gets the version.
	 *
	 * @return the version
	 */
	public String getVersion() {
		return version;
	}

	/**
	 * Sets the version.
	 *
	 * @param version the version to set
	 */
	public void setVersion(String version) {
		this.version = version;
	}

	/**
	 * Gets the echo token.
	 *
	 * @return the echoToken
	 */
	public String getEchoToken() {
		return echoToken;
	}

	/**
	 * Sets the echo token.
	 *
	 * @param echoToken the echoToken to set
	 */
	public void setEchoToken(String echoToken) {
		this.echoToken = echoToken;
	}

	/**
	 * Gets the hotel avail request.
	 *
	 * @return the hotelAvailRequest
	 */
	public List<HotelAvailReqDTO> getHotelAvailRequest() {
		return hotelAvailRequest;
	}

	/**
	 * Sets the hotel avail request.
	 *
	 * @param hotelAvailRequest the hotelAvailRequest to set
	 */
	public void setHotelAvailRequest(List<HotelAvailReqDTO> hotelAvailRequest) {
		this.hotelAvailRequest = hotelAvailRequest;
	}


	
	
}
