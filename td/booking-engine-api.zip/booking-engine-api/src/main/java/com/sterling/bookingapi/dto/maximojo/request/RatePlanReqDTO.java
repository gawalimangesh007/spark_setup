package com.sterling.bookingapi.dto.maximojo.request;

import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;


/**
 * The Class RatePlanReqDTO.
 */
/**
 * @author tcs
 *
 */
@JacksonXmlRootElement(localName = "RatePlan")
public class RatePlanReqDTO {
	
	/** The hotel ref. */
	@JacksonXmlProperty(localName = "HotelRef")
    private HotelRefReqDTO hotelRef;
	
	/** The date range. */
	@JacksonXmlProperty(localName = "DateRange")
	private DateRangeReqDTO dateRange;
	
	/** The rate plan candidate. */
	@JacksonXmlElementWrapper(useWrapping=true, localName = "RatePlanCandidates")
	@JacksonXmlProperty(localName = "RatePlanCandidate")
	private List<RatePlanCandidatesReqDTO> ratePlanCandidate;

	/**
	 * Gets the hotel ref.
	 *
	 * @return the hotel ref
	 */
	public HotelRefReqDTO getHotelRef() {
		return hotelRef;
	}

	/**
	 * Sets the hotel ref.
	 *
	 * @param hotelRef the new hotel ref
	 */
	public void setHotelRef(HotelRefReqDTO hotelRef) {
		this.hotelRef = hotelRef;
	}

	/**
	 * Gets the date range.
	 *
	 * @return the date range
	 */
	public DateRangeReqDTO getDateRange() {
		return dateRange;
	}

	/**
	 * Sets the date range.
	 *
	 * @param dateRange the new date range
	 */
	public void setDateRange(DateRangeReqDTO dateRange) {
		this.dateRange = dateRange;
	}

	/**
	 * Gets the rate plan candidate.
	 *
	 * @return the ratePlanCandidate
	 */
	public List<RatePlanCandidatesReqDTO> getRatePlanCandidate() {
		return ratePlanCandidate;
	}

	/**
	 * Sets the rate plan candidate.
	 *
	 * @param ratePlanCandidate the ratePlanCandidate to set
	 */
	public void setRatePlanCandidate(List<RatePlanCandidatesReqDTO> ratePlanCandidate) {
		this.ratePlanCandidate = ratePlanCandidate;
	}



}
	