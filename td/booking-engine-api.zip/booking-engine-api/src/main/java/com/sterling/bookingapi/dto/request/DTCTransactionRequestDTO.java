package com.sterling.bookingapi.dto.request;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


/**
 * The Class HsdBookingOfferDetailsDTO.
 */
/**
 * @author tcs
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class DTCTransactionRequestDTO implements Serializable {
	
	public DTCTransactionRequestDTO() {
		super();
	}
	private static final long serialVersionUID = 1L;
	
	
	private String contractId;
	
	private String dtcType;
	
	private String yearFrom;
	
	private String yearTo;


	/**
	 * @return the contractId
	 */
	public String getContractId() {
		return contractId;
	}


	/**
	 * @param contractId the contractId to set
	 */
	public void setContractId(String contractId) {
		this.contractId = contractId;
	}


	/**
	 * @return the yearFrom
	 */
	public String getYearFrom() {
		return yearFrom;
	}


	/**
	 * @param yearFrom the yearFrom to set
	 */
	public void setYearFrom(String yearFrom) {
		this.yearFrom = yearFrom;
	}


	/**
	 * @return the yearTo
	 */
	public String getYearTo() {
		return yearTo;
	}


	/**
	 * @param yearTo the yearTo to set
	 */
	public void setYearTo(String yearTo) {
		this.yearTo = yearTo;
	}

	public String getDtcType() {
		return dtcType;
	}
	
	public void setDtcType(String dtcType) {
		this.dtcType = dtcType;
	}
	
}