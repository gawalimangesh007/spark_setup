package com.sterling.bookingapi.dto.response;

import java.util.Date;
import java.util.List;

import com.sterling.bookingapi.dto.ResortRoomMappingDTO;
import com.sterling.bookingapi.dto.request.HsdOffersAndPromosConditionsMappingDetailsRequestDTO;
import com.sterling.bookingapi.utils.AppConstants;

/**
 * @author tcs
 * @version 1.0
 */
public class HsdOffersAndPromosSearchDetailsResponseDTO {

	/** The offer promo id. */
	private String offerPromoId;
	
	/** The offer promo type. */
	private AppConstants.Type offerPromoType;
	
	/** The offer promo category. */
	private String offerPromoCategory;
	
	/** The name. */
	private String name;
	
	/** The details. */
	private String details;	
	
	/** The sell start date. */
	private Date sellStartDate;
	
	/** The sell end date. */
	private Date sellEndDate;
	
	/** The booking start date. */
	private Date bookingStartDate;
	
	/** The booking end date. */
	private Date bookingEndDate;
	
	/** The code. */
	private String code;
	
	/** The discount amt. */
	private Double discountAmt;
	
	/** The discount code. */
	private AppConstants.DiscountCode discountCode;
	
	/** The max discount amt. */
	private Double maxDiscountAmt;
	
	/** The active. */
	private boolean active = true;
	
	/** The terms and conditions. */
	private String termsAndConditions;
	
	/** The conditions list. */
	private List<HsdOffersAndPromosConditionsMappingDetailsRequestDTO> conditionsList;
	
	/** The restort room type. */
	private List<ResortRoomMappingDTO> restortRoomType;
	
	/**
	 * Gets the offer promo id.
	 *
	 * @return the offer promo id
	 */
	public String getOfferPromoId() {
		return offerPromoId;
	}
	
	/**
	 * Sets the offer promo id.
	 *
	 * @param offerPromoId the new offer promo id
	 */
	public void setOfferPromoId(String offerPromoId) {
		this.offerPromoId = offerPromoId;
	}
	
	/**
	 * Gets the offer promo type.
	 *
	 * @return the offer promo type
	 */
	public AppConstants.Type getOfferPromoType() {
		return offerPromoType;
	}
	
	/**
	 * Sets the offer promo type.
	 *
	 * @param offerPromoType the new offer promo type
	 */
	public void setOfferPromoType(AppConstants.Type offerPromoType) {
		this.offerPromoType = offerPromoType;
	}
	
	/**
	 * Gets the offer promo category.
	 *
	 * @return the offer promo category
	 */
	public String getOfferPromoCategory() {
		return offerPromoCategory;
	}
	
	/**
	 * Sets the offer promo category.
	 *
	 * @param offerPromoCategory the new offer promo category
	 */
	public void setOfferPromoCategory(String offerPromoCategory) {
		this.offerPromoCategory = offerPromoCategory;
	}
	
	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * Sets the name.
	 *
	 * @param name the new name
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * Gets the details.
	 *
	 * @return the details
	 */
	public String getDetails() {
		return details;
	}
	
	/**
	 * Sets the details.
	 *
	 * @param details the new details
	 */
	public void setDetails(String details) {
		this.details = details;
	}
	
	/**
	 * Gets the sell start date.
	 *
	 * @return the sell start date
	 */
	public Date getSellStartDate() {
		return sellStartDate;
	}
	
	/**
	 * Sets the sell start date.
	 *
	 * @param sellStartDate the new sell start date
	 */
	public void setSellStartDate(Date sellStartDate) {
		this.sellStartDate = sellStartDate;
	}
	
	/**
	 * Gets the sell end date.
	 *
	 * @return the sell end date
	 */
	public Date getSellEndDate() {
		return sellEndDate;
	}
	
	/**
	 * Sets the sell end date.
	 *
	 * @param sellEndDate the new sell end date
	 */
	public void setSellEndDate(Date sellEndDate) {
		this.sellEndDate = sellEndDate;
	}
	
	/**
	 * Gets the booking start date.
	 *
	 * @return the booking start date
	 */
	public Date getBookingStartDate() {
		return bookingStartDate;
	}
	
	/**
	 * Sets the booking start date.
	 *
	 * @param bookingStartDate the new booking start date
	 */
	public void setBookingStartDate(Date bookingStartDate) {
		this.bookingStartDate = bookingStartDate;
	}
	
	/**
	 * Gets the booking end date.
	 *
	 * @return the booking end date
	 */
	public Date getBookingEndDate() {
		return bookingEndDate;
	}
	
	/**
	 * Sets the booking end date.
	 *
	 * @param bookingEndDate the new booking end date
	 */
	public void setBookingEndDate(Date bookingEndDate) {
		this.bookingEndDate = bookingEndDate;
	}
	
	/**
	 * Gets the code.
	 *
	 * @return the code
	 */
	public String getCode() {
		return code;
	}
	
	/**
	 * Sets the code.
	 *
	 * @param code the new code
	 */
	public void setCode(String code) {
		this.code = code;
	}
	
	/**
	 * Gets the discount amt.
	 *
	 * @return the discount amt
	 */
	public Double getDiscountAmt() {
		return discountAmt;
	}
	
	/**
	 * Sets the discount amt.
	 *
	 * @param discountAmt the new discount amt
	 */
	public void setDiscountAmt(Double discountAmt) {
		this.discountAmt = discountAmt;
	}
	
	/**
	 * Gets the discount code.
	 *
	 * @return the discount code
	 */
	public AppConstants.DiscountCode getDiscountCode() {
		return discountCode;
	}
	
	/**
	 * Sets the discount code.
	 *
	 * @param discountCode the new discount code
	 */
	public void setDiscountCode(AppConstants.DiscountCode discountCode) {
		this.discountCode = discountCode;
	}
	
	/**
	 * Gets the max discount amt.
	 *
	 * @return the max discount amt
	 */
	public Double getMaxDiscountAmt() {
		return maxDiscountAmt;
	}
	
	/**
	 * Sets the max discount amt.
	 *
	 * @param maxDiscountAmt the new max discount amt
	 */
	public void setMaxDiscountAmt(Double maxDiscountAmt) {
		this.maxDiscountAmt = maxDiscountAmt;
	}
	
	/**
	 * Checks if is active.
	 *
	 * @return true, if is active
	 */
	public boolean isActive() {
		return active;
	}
	
	/**
	 * Sets the active.
	 *
	 * @param active the new active
	 */
	public void setActive(boolean active) {
		this.active = active;
	}
	
	/**
	 * Gets the terms and conditions.
	 *
	 * @return the terms and conditions
	 */
	public String getTermsAndConditions() {
		return termsAndConditions;
	}
	
	/**
	 * Sets the terms and conditions.
	 *
	 * @param termsAndConditions the new terms and conditions
	 */
	public void setTermsAndConditions(String termsAndConditions) {
		this.termsAndConditions = termsAndConditions;
	}
	
	/**
	 * Gets the conditions list.
	 *
	 * @return the conditions list
	 */
	public List<HsdOffersAndPromosConditionsMappingDetailsRequestDTO> getConditionsList() {
		return conditionsList;
	}
	
	/**
	 * Sets the conditions list.
	 *
	 * @param conditionsList the new conditions list
	 */
	public void setConditionsList(List<HsdOffersAndPromosConditionsMappingDetailsRequestDTO> conditionsList) {
		this.conditionsList = conditionsList;
	}
	
	/**
	 * Gets the restort room type.
	 *
	 * @return the restort room type
	 */
	public List<ResortRoomMappingDTO> getRestortRoomType() {
		return restortRoomType;
	}
	
	/**
	 * Sets the restort room type.
	 *
	 * @param restortRoomType the new restort room type
	 */
	public void setRestortRoomType(List<ResortRoomMappingDTO> restortRoomType) {
		this.restortRoomType = restortRoomType;
	}

	
}
