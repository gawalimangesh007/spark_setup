package com.sterling.bookingapi.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.sterling.bookingapi.sf.dto.response.SFBaseRecord;
import com.sterling.bookingapi.sf.dto.response.VOReceivableDTO;

/**
 * @author tcs
 *
 */
public class VOCollectionReceivableConnectorReq extends SFBaseRecord {
	private static final long serialVersionUID = 1L;

	@JsonProperty("Collection__c")
	private String collectionID;
	
	@JsonProperty("Receivable__c")
	private String receivableid;
	
	@JsonProperty("Status__c")
	private String paymentConnectorStatus;

	@JsonProperty("Collection_For__c")
	private String collectionFor;
	
	@JsonProperty("Amount__c")
	private Double paidAmount;
	
	@JsonProperty("Receivable__r")
	private VOReceivableDTO receivable;

	
	public String getCollectionFor() {
		return collectionFor;
	}

	public void setCollectionFor(String collectionFor) {
		this.collectionFor = collectionFor;
	}

	public VOReceivableDTO getReceivable() {
		return receivable;
	}

	public void setReceivable(VOReceivableDTO receivable) {
		this.receivable = receivable;
	}

	/**
	 * @return receivableid
	 */
	public String getReceivableid() {
		return receivableid;
	}

	/**
	 * @param receivableid
	 * set the receivableid
	 */
	public void setReceivableid(String receivableid) {
		this.receivableid = receivableid;
	}

	/**
	 * @return collectionID
	 */
	public String getCollectionID() {
		return collectionID;
	}

	/**
	 * @param collectionID
	 * set the collectionID
	 */
	public void setCollectionID(String collectionID) {
		this.collectionID = collectionID;
	}

	public String getPaymentConnectorStatus() {
		return paymentConnectorStatus;
	}

	public void setPaymentConnectorStatus(String paymentConnectorStatus) {
		this.paymentConnectorStatus = paymentConnectorStatus;
	}

	public Double getPaidAmount() {
		return paidAmount;
	}

	public void setPaidAmount(Double paidAmount) {
		this.paidAmount = paidAmount;
	}

}
