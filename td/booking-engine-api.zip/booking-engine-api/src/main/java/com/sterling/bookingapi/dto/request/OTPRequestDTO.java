package com.sterling.bookingapi.dto.request;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.sterling.bookingapi.utils.AppConstants.ContactType;

@JsonIgnoreProperties(ignoreUnknown = true)
public class OTPRequestDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String emailId;
	private String mobileNo;
	private String leadId;
	private String cvNumber;
	
	private ContactType contactType;//MOBILE/EMAIL
	private String value;
	private OTPFlow otpFor;
	
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public ContactType getContactType() {
		return contactType;
	}
	public void setContactType(ContactType contactType) {
		this.contactType = contactType;
	}
	
	public String getCvNumber() {
		return cvNumber;
	}
	public void setCvNumber(String cvNumber) {
		this.cvNumber = cvNumber;
	}
	public String getLeadId() {
		return leadId;
	}
	public void setLeadId(String leadId) {
		this.leadId = leadId;
	}
	public OTPFlow getOtpFor() {
		return otpFor;
	}
	public void setOtpFor(OTPFlow otpFor) {
		this.otpFor = otpFor;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
}
