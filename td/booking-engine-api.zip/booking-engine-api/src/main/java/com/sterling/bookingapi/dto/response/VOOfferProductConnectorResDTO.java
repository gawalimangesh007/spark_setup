package com.sterling.bookingapi.dto.response;

import java.io.Serializable;

public class VOOfferProductConnectorResDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String id;	
	private String name;	
	private Double discountOnDP;	
	private String lmsDownPaymentId;	
	private String lmsDownPaymentName;
	
	/**
	 * @return id
	 */
	public String getId() {
		return id;
	}
	/**
	 * @param id
	 * set the id
	 */
	public void setId(String id) {
		this.id = id;
	}
	/**
	 * @return name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name
	 * set the name
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return  discountOnDP
	 */
	public Double getDiscountOnDP() {
		return discountOnDP;
	}
	/**
	 * @param discountOnDP
	 * set the discountOnDP
	 */
	public void setDiscountOnDP(Double discountOnDP) {
		this.discountOnDP = discountOnDP;
	}
	/**
	 * @return lmsDownPaymentId
	 */
	public String getLmsDownPaymentId() {
		return lmsDownPaymentId;
	}
	/**
	 * @param lmsDownPaymentId
	 * set the lmsDownPaymentId
	 */
	public void setLmsDownPaymentId(String lmsDownPaymentId) {
		this.lmsDownPaymentId = lmsDownPaymentId;
	}
	/**
	 * @return lmsDownPaymentName
	 */
	public String getLmsDownPaymentName() {
		return lmsDownPaymentName;
	}
	/**
	 * @param lmsDownPaymentName
	 * set the lmsDownPaymentName
	 */
	public void setLmsDownPaymentName(String lmsDownPaymentName) {
		this.lmsDownPaymentName = lmsDownPaymentName;
	}
	
}
