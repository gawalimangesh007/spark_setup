package com.sterling.bookingapi.dto.maximojo.request;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class DescriptionReqDTO.
 */
/**
 * @author tcs
 *
 */
public class DescriptionReqDTO {

	/** The text. */
	@JacksonXmlProperty(localName = "Text")
	private String text;

	/**
	 * Gets the text.
	 *
	 * @return the text
	 */
	public String getText() {
		return text;
	}

	/**
	 * Sets the text.
	 *
	 * @param text the text to set
	 */
	public void setText(String text) {
		this.text = text;
	}

	
}
