package com.sterling.bookingapi.dto.request;

import java.util.List;


/**
 * The Class HsdResortRoomMasterDTO.
 */
/**
 * @author tcs
 *
 */
public class HsdResortRoomMasterDTO {

	private HsdResortInfoDTO resortDetails;
	
	/** The roomdetails. */
	private List<HsdResortRoomDTO> roomDetails;
	
	private List<HsdResortRateplanDTO> rateDetails;
	
	/** The active. */
	//private boolean status;

	private boolean allRoomFlag;
	
	private boolean allRateFlag;
	/**
	 * @return the resortDetails
	 */
	public HsdResortInfoDTO getResortDetails() {
		return resortDetails;
	}

	/**
	 * @param resortDetails the resortDetails to set
	 */
	public void setResortDetails(HsdResortInfoDTO resortDetails) {
		this.resortDetails = resortDetails;
	}

	/**
	 * @return the roomDetails
	 */
	public List<HsdResortRoomDTO> getRoomDetails() {
		return roomDetails;
	}

	/**
	 * @param roomDetails the roomDetails to set
	 */
	public void setRoomDetails(List<HsdResortRoomDTO> roomDetails) {
		this.roomDetails = roomDetails;
	}

	/**
	 * @return the rateDetails
	 */
	public List<HsdResortRateplanDTO> getRateDetails() {
		return rateDetails;
	}

	/**
	 * @param rateDetails the rateDetails to set
	 */
	public void setRateDetails(List<HsdResortRateplanDTO> rateDetails) {
		this.rateDetails = rateDetails;
	}
 
	/*public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}*/

	public boolean isAllRoomFlag() {
		return allRoomFlag;
	}

	public void setAllRoomFlag(boolean allRoomFlag) {
		this.allRoomFlag = allRoomFlag;
	}

	public boolean isAllRateFlag() {
		return allRateFlag;
	}

	public void setAllRateFlag(boolean allRateFlag) {
		this.allRateFlag = allRateFlag;
	}
	
}
