package com.sterling.bookingapi.dto.request;

import java.io.Serializable;

import javax.validation.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author tcs
 * @version 1.0
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class VOWelcomeOfferReq implements Serializable{
	private static final long serialVersionUID = 1L;

	@NotEmpty(message = "Contract id should not be empty")
	private String contractId;
	
	/**
	 * @return contract id
	 */
	public String getContractId() {
		return contractId;
	}
	/**
	 * @param contractId
	 * set the contract id
	 */
	public void setContractId(String contractId) {
		this.contractId = contractId;
	}
}
