package com.sterling.bookingapi.dto.maximojo.request;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class CustomerReqDTO.
 */
/**
 * @author tcs
 *
 */
public class CustomerReqDTO {
	
	/** The person name. */
	@JacksonXmlProperty(localName = "PersonName")
	private PersonNameReqDTO personName;

	/** The telephone. */
	@JacksonXmlProperty(localName = "Telephone")
    private TelephoneReqDTO telephone;

	/** The email. */
	@JacksonXmlProperty(localName = "Email")
    private EmailReqDTO email;

	/** The address. */
	@JacksonXmlProperty(localName = "Address")
    private AddressReqDTO address;

	/**
	 * Gets the person name.
	 *
	 * @return the personName
	 */
	public PersonNameReqDTO getPersonName() {
		return personName;
	}

	/**
	 * Sets the person name.
	 *
	 * @param personName the personName to set
	 */
	public void setPersonName(PersonNameReqDTO personName) {
		this.personName = personName;
	}

	/**
	 * Gets the telephone.
	 *
	 * @return the telephone
	 */
	public TelephoneReqDTO getTelephone() {
		return telephone;
	}

	/**
	 * Sets the telephone.
	 *
	 * @param telephone the telephone to set
	 */
	public void setTelephone(TelephoneReqDTO telephone) {
		this.telephone = telephone;
	}

	/**
	 * Gets the email.
	 *
	 * @return the email
	 */
	public EmailReqDTO getEmail() {
		return email;
	}

	/**
	 * Sets the email.
	 *
	 * @param email the email to set
	 */
	public void setEmail(EmailReqDTO email) {
		this.email = email;
	}

	/**
	 * Gets the address.
	 *
	 * @return the address
	 */
	public AddressReqDTO getAddress() {
		return address;
	}

	/**
	 * Sets the address.
	 *
	 * @param address the address to set
	 */
	public void setAddress(AddressReqDTO address) {
		this.address = address;
	}
	
	
	
}
