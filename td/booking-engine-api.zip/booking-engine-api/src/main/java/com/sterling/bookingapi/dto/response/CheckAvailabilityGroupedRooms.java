package com.sterling.bookingapi.dto.response;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;




/**
 * The Class CheckAvailabilityGroupedRooms.
 */
/**
 * @author tcs
 * @version 1.0
 */
public class CheckAvailabilityGroupedRooms {

	
	/** The resort id. */
	private String resortId;
	
	/** The resort name. */
	private String resortName;
	

	
	/** The occupancy detail. */
	private String occupancyDetail;
	
	/** The extra person child cost. */
	private Double extraPersonChildCost;
	
	/** The max occupancy count. */
	private int maxOccupancyCount;
	
	/** The available rooms. */
	private int availableRooms;
	
//	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "MM/dd/yyyy")
	private String avlDate;
	
	/** The room type id. */
	private String roomTypeId;
	
	/** The base occupancy count. */
	private int baseOccupancyCount;
	
	/** The extra occupancy adult count. */
	private int extraOccupancyAdultCount;
	
	/** The extra occupancy child count. */
	private int extraOccupancyChildCount;
	
	/** The room rate plan list. */
	private List<RoomRatePlanDetailsResponseDTO> roomRatePlanList;
	
	/** The is package valid. */
	private boolean isPackageValid = false;

	
	

	
	/**
	 * Instantiates a new check availability grouped rooms.
	 *
	 * @param resortId the resort id
	 * @param roomTypeId the room type id
	 * @param availableRooms the available rooms
	 */
	public CheckAvailabilityGroupedRooms(String resortId, String roomTypeId, int availableRooms) {
		this.resortId = resortId;
		this.roomTypeId = roomTypeId;
		this.availableRooms = availableRooms;
	}

	/**
	 * Instantiates a new check availability grouped rooms.
	 *
	 * @param resortId the resort id
	 * @param roomTypeId the room type id
	 */
	public CheckAvailabilityGroupedRooms(String resortId, String roomTypeId) {
		this.resortId = resortId;
		this.roomTypeId = roomTypeId;
	}
	
	/**
	 * Instantiates a new check availability grouped rooms.
	 */
	public CheckAvailabilityGroupedRooms() {
		super();
	}

	public String getAvlDate() {
		return avlDate;
	}

	public void setAvlDate(String avlDate) {
		this.avlDate = avlDate;
	}

	/**
	 * Gets the resort id.
	 *
	 * @return the resort id
	 */
	public String getResortId() {
		return resortId;
	}

	/**
	 * Sets the resort id.
	 *
	 * @param resortId the new resort id
	 */
	public void setResortId(String resortId) {
		this.resortId = resortId;
	}

	/**
	 * Gets the room type id.
	 *
	 * @return the room type id
	 */
	public String getRoomTypeId() {
		return roomTypeId;
	}

	/**
	 * Sets the room type id.
	 *
	 * @param roomTypeId the new room type id
	 */
	public void setRoomTypeId(String roomTypeId) {
		this.roomTypeId = roomTypeId;
	}

	/**
	 * Gets the occupancy detail.
	 *
	 * @return the occupancy detail
	 */
	public String getOccupancyDetail() {
		return occupancyDetail;
	}

	/**
	 * Sets the occupancy detail.
	 *
	 * @param occupancyDetail the new occupancy detail
	 */
	public void setOccupancyDetail(String occupancyDetail) {
		this.occupancyDetail = occupancyDetail;
	}

	/**
	 * Gets the extra person child cost.
	 *
	 * @return the extra person child cost
	 */
	public Double getExtraPersonChildCost() {
		return extraPersonChildCost;
	}

	/**
	 * Sets the extra person child cost.
	 *
	 * @param extraPersonChildCost the new extra person child cost
	 */
	public void setExtraPersonChildCost(Double extraPersonChildCost) {
		this.extraPersonChildCost = extraPersonChildCost;
	}

	/**
	 * Gets the max occupancy count.
	 *
	 * @return the max occupancy count
	 */
	public int getMaxOccupancyCount() {
		return maxOccupancyCount;
	}

	/**
	 * Sets the max occupancy count.
	 *
	 * @param maxOccupancyCount the new max occupancy count
	 */
	public void setMaxOccupancyCount(int maxOccupancyCount) {
		this.maxOccupancyCount = maxOccupancyCount;
	}

	/**
	 * Gets the available rooms.
	 *
	 * @return the available rooms
	 */
	public int getAvailableRooms() {
		return availableRooms;
	}

	/**
	 * Sets the available rooms.
	 *
	 * @param availableRooms the new available rooms
	 */
	public void setAvailableRooms(int availableRooms) {
		this.availableRooms = availableRooms;
	}

	/**
	 * Gets the base occupancy count.
	 *
	 * @return the base occupancy count
	 */
	public int getBaseOccupancyCount() {
		return baseOccupancyCount;
	}

	/**
	 * Sets the base occupancy count.
	 *
	 * @param baseOccupancyCount the new base occupancy count
	 */
	public void setBaseOccupancyCount(int baseOccupancyCount) {
		this.baseOccupancyCount = baseOccupancyCount;
	}

	/**
	 * Gets the extra occupancy adult count.
	 *
	 * @return the extra occupancy adult count
	 */
	public int getExtraOccupancyAdultCount() {
		return extraOccupancyAdultCount;
	}

	/**
	 * Sets the extra occupancy adult count.
	 *
	 * @param extraOccupancyAdultCount the new extra occupancy adult count
	 */
	public void setExtraOccupancyAdultCount(int extraOccupancyAdultCount) {
		this.extraOccupancyAdultCount = extraOccupancyAdultCount;
	}

	/**
	 * Gets the extra occupancy child count.
	 *
	 * @return the extra occupancy child count
	 */
	public int getExtraOccupancyChildCount() {
		return extraOccupancyChildCount;
	}

	/**
	 * Sets the extra occupancy child count.
	 *
	 * @param extraOccupancyChildCount the new extra occupancy child count
	 */
	public void setExtraOccupancyChildCount(int extraOccupancyChildCount) {
		this.extraOccupancyChildCount = extraOccupancyChildCount;
	}

	/**
	 * Checks if is package valid.
	 *
	 * @return true, if is package valid
	 */
	public boolean isPackageValid() {
		return isPackageValid;
	}

	/**
	 * Sets the package valid.
	 *
	 * @param isPackageValid the new package valid
	 */
	public void setPackageValid(boolean isPackageValid) {
		this.isPackageValid = isPackageValid;
	}


	/**
	 * Gets the room rate plan list.
	 *
	 * @return the room rate plan list
	 */
	public List<RoomRatePlanDetailsResponseDTO> getRoomRatePlanList() {
		return roomRatePlanList;
	}

	/**
	 * Sets the room rate plan list.
	 *
	 * @param roomRatePlanList the new room rate plan list
	 */
	public void setRoomRatePlanList(List<RoomRatePlanDetailsResponseDTO> roomRatePlanList) {
		this.roomRatePlanList = roomRatePlanList;
	}

	/**
	 * Gets the resort name.
	 *
	 * @return the resort name
	 */
	public String getResortName() {
		return resortName;
	}

	/**
	 * Sets the resort name.
	 *
	 * @param resortName the new resort name
	 */
	public void setResortName(String resortName) {
		this.resortName = resortName;
	}
	
	
	
}
