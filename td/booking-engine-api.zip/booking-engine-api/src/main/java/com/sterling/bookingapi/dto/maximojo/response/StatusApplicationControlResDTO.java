package com.sterling.bookingapi.dto.maximojo.response;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class StatusApplicationControlResDTO.
 * @author tcs
 * @version 1.0
 */
public class StatusApplicationControlResDTO {

	/** The end. */
	@JacksonXmlProperty(localName = "End", isAttribute = true)
	private String end;

	/** The start. */
	@JacksonXmlProperty(localName = "Start", isAttribute = true)
    private String start;

	/** The sun. */
	@JacksonXmlProperty(localName = "Sun", isAttribute = true)
    private Boolean sun = false;

	/** The thur. */
	@JacksonXmlProperty(localName = "Thur", isAttribute = true)
    private Boolean thur = false;

	/** The inv type code. */
	@JacksonXmlProperty(localName = "InvTypeCode", isAttribute = true)
    private String invTypeCode;

	/** The sat. */
	@JacksonXmlProperty(localName = "Sat", isAttribute = true)
    private Boolean sat = false;

	/** The weds. */
	@JacksonXmlProperty(localName = "Weds", isAttribute = true)
    private Boolean weds = false;

	/** The fri. */
	@JacksonXmlProperty(localName = "Fri", isAttribute = true)
    private Boolean fri = false;

	/** The mon. */
	@JacksonXmlProperty(localName = "Mon", isAttribute = true)
    private Boolean mon = false;

	/** The tue. */
	@JacksonXmlProperty(localName = "Tue", isAttribute = true)
    private Boolean tue = false;

	/** The rate plan code. */
	@JacksonXmlProperty(localName = "RatePlanCode", isAttribute = true)
    private String ratePlanCode;


	/**
	 * Gets the end.
	 *
	 * @return the end
	 */
	public String getEnd() {
		return end;
	}

	/**
	 * Sets the end.
	 *
	 * @param end the end to set
	 */
	public void setEnd(String end) {
		this.end = end;
	}

	/**
	 * Gets the start.
	 *
	 * @return the start
	 */
	public String getStart() {
		return start;
	}

	/**
	 * Sets the start.
	 *
	 * @param start the start to set
	 */
	public void setStart(String start) {
		this.start = start;
	}

	/**
	 * Gets the sun.
	 *
	 * @return the sun
	 */
	public Boolean getSun() {
		return sun;
	}

	/**
	 * Sets the sun.
	 *
	 * @param sun the sun to set
	 */
	public void setSun(Boolean sun) {
		this.sun = sun;
	}

	/**
	 * Gets the thur.
	 *
	 * @return the thur
	 */
	public Boolean getThur() {
		return thur;
	}

	/**
	 * Sets the thur.
	 *
	 * @param thur the thur to set
	 */
	public void setThur(Boolean thur) {
		this.thur = thur;
	}

	/**
	 * Gets the inv type code.
	 *
	 * @return the invTypeCode
	 */
	public String getInvTypeCode() {
		return invTypeCode;
	}

	/**
	 * Sets the inv type code.
	 *
	 * @param invTypeCode the invTypeCode to set
	 */
	public void setInvTypeCode(String invTypeCode) {
		this.invTypeCode = invTypeCode;
	}

	/**
	 * Gets the sat.
	 *
	 * @return the sat
	 */
	public Boolean getSat() {
		return sat;
	}

	/**
	 * Sets the sat.
	 *
	 * @param sat the sat to set
	 */
	public void setSat(Boolean sat) {
		this.sat = sat;
	}

	/**
	 * Gets the weds.
	 *
	 * @return the weds
	 */
	public Boolean getWeds() {
		return weds;
	}

	/**
	 * Sets the weds.
	 *
	 * @param weds the weds to set
	 */
	public void setWeds(Boolean weds) {
		this.weds = weds;
	}

	/**
	 * Gets the fri.
	 *
	 * @return the fri
	 */
	public Boolean getFri() {
		return fri;
	}

	/**
	 * Sets the fri.
	 *
	 * @param fri the fri to set
	 */
	public void setFri(Boolean fri) {
		this.fri = fri;
	}

	/**
	 * Gets the mon.
	 *
	 * @return the mon
	 */
	public Boolean getMon() {
		return mon;
	}

	/**
	 * Sets the mon.
	 *
	 * @param mon the mon to set
	 */
	public void setMon(Boolean mon) {
		this.mon = mon;
	}

	/**
	 * Gets the tue.
	 *
	 * @return the tue
	 */
	public Boolean getTue() {
		return tue;
	}

	/**
	 * Sets the tue.
	 *
	 * @param tue the tue to set
	 */
	public void setTue(Boolean tue) {
		this.tue = tue;
	}

	/**
	 * Gets the rate plan code.
	 *
	 * @return the ratePlanCode
	 */
	public String getRatePlanCode() {
		return ratePlanCode;
	}

	/**
	 * Sets the rate plan code.
	 *
	 * @param ratePlanCode the ratePlanCode to set
	 */
	public void setRatePlanCode(String ratePlanCode) {
		this.ratePlanCode = ratePlanCode;
	}


}
