package com.sterling.bookingapi.engine.rules;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.BooleanUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;

import com.google.common.collect.Maps;
import com.sterling.bookingapi.dto.request.VOConfirmBookingRequest;
import com.sterling.bookingapi.dto.response.HolidayDetails;
import com.sterling.bookingapi.dto.response.VODashboardResponse;
import com.sterling.bookingapi.engine.rules.models.BookingRule;
import com.sterling.bookingapi.engine.rules.models.RulesSeasons;
import com.sterling.bookingapi.engine.rules.models.VOBookingRuleDTO;
import com.sterling.bookingapi.utils.BookingEngineUtils;


@Rule(name="maxUtil", description="MAX_UTILIZATION_RULE")
public class MaxUtilizationInYearRule {

	private static final Logger logger = LogManager.getLogger(MaxUtilizationInYearRule.class);
	
	@Condition
	public boolean when(@Fact("bookingRequest") VOConfirmBookingRequest req, 
			@Fact("productRules") Map<String, List<VOBookingRuleDTO>> rulesMap,
			@Fact("memberDetail") VODashboardResponse memberDetail,
			@Fact("bookingSeasons") Set<String> bookingSeason) {
		//my rule conditions
		logger.info("=========== MAX_UTILIZATION_RULE executing");
		
		Date reqCheckinDate = BookingEngineUtils.parseDate(req.getCheckInDate(), BookingEngineUtils.SF_DATE_FORMAT);
		Date reqCheckoutDate = BookingEngineUtils.parseDate(req.getCheckOutDate(), BookingEngineUtils.SF_DATE_FORMAT);
		
		int reqYear = BookingEngineUtils.getYear(reqCheckinDate);
		//Set<String> bookingSeason = BookingEngineUtils.parseSeasons(req.getSeasonDetail());
		
		Long bookingDaysCount = BookingEngineUtils.daysDiff(reqCheckinDate, reqCheckoutDate);
		
		List<HolidayDetails> holidayDetails = memberDetail.getHolidayDetails();
		

		//loop booking history and check the booking is present already with matched criterias
		Map<String, Integer> seasonBookedCount = Maps.newHashMap();
		for (HolidayDetails holidayDetail : holidayDetails) {
			int bookedYr = BookingEngineUtils.getYear(holidayDetail.getCheckinDate());
			if(holidayDetail.getSeason() != null) {
				List<String> bookedSeason = new ArrayList<String>(Arrays.asList(holidayDetail.getSeason().split(",")));
				if(reqYear == bookedYr) {
					
					Date checkinDate = BookingEngineUtils.parseDate(holidayDetail.getCheckinDate(), BookingEngineUtils.SF_DATE_FORMAT);
					Date checkoutDate = BookingEngineUtils.parseDate(holidayDetail.getCheckoutDate(), BookingEngineUtils.SF_DATE_FORMAT);

					Long noOfDays = BookingEngineUtils.daysDiff(checkinDate, checkoutDate);
					
					bookedSeason.forEach(x -> {
						Integer count = seasonBookedCount.get(x);
						if(count == null) {
							count = noOfDays.intValue();
						} else {
							count += noOfDays.intValue();
						}
						seasonBookedCount.put(x, count);
					});
				}
			}
		}
		logger.debug("=========== MAX_UTILIZATION_RULE :: total No. of days booked in this year is {}", seasonBookedCount);

		List<VOBookingRuleDTO> ruleList = rulesMap.get(BookingRule.MAX_UTILIZATION_RULE.getRuleName());
		for (VOBookingRuleDTO rule : ruleList) {
			if (BooleanUtils.isTrue(rule.getActive())) {
				RulesSeasons applicableSeasons = rule.getApplicableSeasons();
				boolean havingSeason = BookingEngineUtils.havingAnySeason(
						bookingSeason, applicableSeasons);
				
				if (havingSeason) {
					int maxUtil = Integer.parseInt(rule.getParameters().get(0).getValue()); //maxUtil
					int totalDays = getTotalDays(bookingDaysCount.intValue(), seasonBookedCount, BookingEngineUtils.getAvailableSeason(applicableSeasons));
					if(totalDays > maxUtil) {
						logger.debug("=========== MAX_UTILIZATION_RULE :: total No. of days booked is {} which exceeded the configure count {}", totalDays, maxUtil);
						return false;
					}
				}
			}
		}
		
		return true;
	}

	private int getTotalDays(int intValue,
			Map<String, Integer> seasonBookedCount, List<String> ruleSeason) {
		int count = 0;
		for (String x : ruleSeason) {
			Integer seasonCount = seasonBookedCount.get(x);
			count += (seasonCount != null ? seasonCount : 0);
		}

		return count + intValue;
	}

	@Action(order = 1)
	public void then() throws Exception {
		//my actions
		logger.info("################# excecuting action");
	}
}
