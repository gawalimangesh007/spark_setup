package com.sterling.bookingapi.dto.maximojo.response;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class BookingChannelResDTO.
 * @author tcs
 * @version 1.0
 */
public class BookingChannelResDTO {

	/** The company name. */
	@JacksonXmlProperty(localName = "CompanyName")
	private CompanyNameResDTO companyName;

	/**
	 * Gets the company name.
	 *
	 * @return the companyName
	 */
	public CompanyNameResDTO getCompanyName() {
		return companyName;
	}

	/**
	 * Sets the company name.
	 *
	 * @param companyName the companyName to set
	 */
	public void setCompanyName(CompanyNameResDTO companyName) {
		this.companyName = companyName;
	}
	
	
}
