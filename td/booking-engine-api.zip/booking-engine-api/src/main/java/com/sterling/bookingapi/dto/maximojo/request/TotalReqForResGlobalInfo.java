package com.sterling.bookingapi.dto.maximojo.request;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class TotalReqForResGlobalInfo.
 */
/**
 * @author tcs
 *
 */
public class TotalReqForResGlobalInfo {

	/** The amount before tax. */
	@JacksonXmlProperty(localName = "AmountBeforeTax", isAttribute = true)
    private double amountBeforeTax;

    /** The currency code. */
    @JacksonXmlProperty(localName = "CurrencyCode", isAttribute = true)
    private String currencyCode;
    
    /** The total amount include tax. */
	@JacksonXmlProperty(localName = "TotalAmount", isAttribute = true)
    private double totalAmount;

	/**
	 * Gets the amount before tax.
	 *
	 * @return the amount before tax
	 */
	public double getAmountBeforeTax() {
		return amountBeforeTax;
	}

	/**
	 * Sets the amount before tax.
	 *
	 * @param amountBeforeTax the new amount before tax
	 */
	public void setAmountBeforeTax(double amountBeforeTax) {
		this.amountBeforeTax = amountBeforeTax;
	}

	/**
	 * Gets the currency code.
	 *
	 * @return the currency code
	 */
	public String getCurrencyCode() {
		return currencyCode;
	}

	/**
	 * Sets the currency code.
	 *
	 * @param currencyCode the new currency code
	 */
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	/**
	 * @return the totalAmount
	 */
	public double getTotalAmount() {
		return totalAmount;
	}

	/**
	 * @param totalAmount the totalAmount to set
	 */
	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}    
}
