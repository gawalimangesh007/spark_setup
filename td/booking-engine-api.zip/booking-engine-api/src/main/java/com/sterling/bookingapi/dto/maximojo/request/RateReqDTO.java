package com.sterling.bookingapi.dto.maximojo.request;

import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class RateReqDTO.
 */
/**
 * @author tcs
 *
 */
public class RateReqDTO {

	/** The base by guest amt. */
	@JacksonXmlElementWrapper(useWrapping=true, localName = "BaseByGuestAmts")
	@JacksonXmlProperty(localName = "BaseByGuestAmt")
	private List<BaseByGuestAmtReqDTO> baseByGuestAmt;

	/** The Additional guest amount. */
	@JacksonXmlElementWrapper(useWrapping=true, localName = "AdditionalGuestAmounts")
	@JacksonXmlProperty(localName = "AdditionalGuestAmount")
    private List<AdditionalGuestAmountReqDTO> additionalGuestAmount;

	/**
	 * Gets the base by guest amt.
	 *
	 * @return the baseByGuestAmt
	 */
	public List<BaseByGuestAmtReqDTO> getBaseByGuestAmt() {
		return baseByGuestAmt;
	}

	/**
	 * Sets the base by guest amt.
	 *
	 * @param baseByGuestAmt the baseByGuestAmt to set
	 */
	public void setBaseByGuestAmt(List<BaseByGuestAmtReqDTO> baseByGuestAmt) {
		this.baseByGuestAmt = baseByGuestAmt;
	}

	/**
	 * Gets the additional guest amount.
	 *
	 * @return the additionalGuestAmount
	 */
	public List<AdditionalGuestAmountReqDTO> getAdditionalGuestAmount() {
		return additionalGuestAmount;
	}

	/**
	 * Sets the additional guest amount.
	 *
	 * @param additionalGuestAmount the additionalGuestAmount to set
	 */
	public void setAdditionalGuestAmount(List<AdditionalGuestAmountReqDTO> additionalGuestAmount) {
		this.additionalGuestAmount = additionalGuestAmount;
	}
	
	
}
