package com.sterling.bookingapi.adapter;

import java.io.IOException;

import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.ParseException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.entity.StringEntity;
import org.apache.http.util.EntityUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;

import com.sterling.bookingapi.exception.SalesForceException;
import com.sterling.bookingapi.utils.AppConstants;
import com.sterling.bookingapi.utils.ConfigurationProperties;
import com.sterling.bookingapi.utils.CustomRestTemplate;
import com.sterling.bookingapi.utils.RestAPIClient;


/**
 * The Class SalesForceRestAPI.
 */
/**
 * @author tcs
 *
 */
@Component
public class SalesForceRestAPI {

	/** The Constant logger. */
	private static final Logger logger = LogManager.getLogger(SalesForceRestAPI.class);

	/** The custom rest template. */
	@Autowired
	private CustomRestTemplate customRestTemplate;

	/** The configuration properties. */
	@Autowired
	private ConfigurationProperties configurationProperties;

	/** The rest API client. */
	@Autowired
	private RestAPIClient restAPIClient;

	/**
	 * Method to authenticate into sales force. Username , password , client id
	 * and client secret taken from application properties file.
	 *
	 * @throws SalesForceException the sales force exception
	 * @throws ParseException the parse exception
	 */
	public synchronized void authenticate() throws SalesForceException {
		logger.info(" SalesForceRestAPI : authenticate : Entered.");
		if (StringUtils.isNotEmpty(AppConstants.Authorization.ACCESS_TOKEN)) {
			return;
		}
		String resultJson = "";
		HttpResponse response = null;
		String loginURL = configurationProperties.getAuthURL() + configurationProperties.getGrantServiceURL() + "&client_id=" + configurationProperties.getClientId() + "&client_secret=" + configurationProperties.getClientSecret() + "&username="
				+ configurationProperties.getUserName() + "&password=" + configurationProperties.getPassword();
		logger.info(loginURL);

		logger.info(" SalesforceLogin : authenticate : Inside");

		try {
			response = restAPIClient.execute(loginURL, HttpMethod.POST, null, true);
		} catch (ClientProtocolException e1) {
			logger.error("ClientProtocolException on authenticate: " , e1);
		} catch (IOException e1) {
			logger.error("IOException on authenticate: " , e1);
		}

		if (response != null) {
			logger.info(response.getStatusLine().getStatusCode());
			// verify response is HTTP OK
			final int statusCode = response.getStatusLine().getStatusCode();
			if (statusCode != HttpStatus.SC_OK) {
				logger.error("Error authenticating to Force.com: " + statusCode);
				return;
			}
			try {
				resultJson = EntityUtils.toString(response.getEntity());
			} catch (ParseException e1) {
				logger.error("ParseException on authenticate: ", e1);
			} catch (IOException e1) {
				logger.error("IOException on authenticate: ", e1);
			}
			logger.info(resultJson);
			JSONObject jsonObject = null;
			try {
				jsonObject = (JSONObject) new JSONTokener(resultJson)
						.nextValue();
				setTokens(jsonObject);
			} catch (JSONException e) {
				logger.error("IOException on authenticate: ", e);
			}
			setAuthConstants();
			String baseUri = AppConstants.Authorization.BASEURI;
			logger.info("oauthHeader1: "
					+ AppConstants.Authorization.ACCESS_TOKEN);
			logger.info("\n" + response.getStatusLine().getStatusCode());
			logger.info("Successful login");
			logger.info("instance URL: "
					+ AppConstants.Authorization.INSTANCEURL);
			logger.info("access token/session ID: "
					+ AppConstants.Authorization.TOKEN);
			logger.info("baseUri: " + baseUri);
			
		}
		logger.info(" SalesForceRestAPI : authenticate : Leaving.");
	}

	private synchronized static void setTokens(JSONObject jsonObject) throws JSONException {
		logger.info(" SalesForceRestAPI : setTokens : Entered.");
		AppConstants.Authorization.TOKEN = jsonObject.getString("access_token");
		AppConstants.Authorization.TOKENTYPE = jsonObject.getString("token_type");
		AppConstants.Authorization.INSTANCEURL = jsonObject.getString("instance_url");
		logger.info(" SalesForceRestAPI : setTokens : Leaving.");
	}

	/**
	 * Sets the auth constants.
	 */
	private synchronized static void setAuthConstants() {
		logger.info(" SalesForceRestAPI : setAuthConstants : Entered.");
		AppConstants.Authorization.ACCESS_TOKEN = AppConstants.Authorization.TOKENTYPE.concat(AppConstants.Authorization.EMPTYSPACE).concat(AppConstants.Authorization.TOKEN);
		AppConstants.Authorization.BASEURI = AppConstants.Authorization.INSTANCEURL.concat(AppConstants.Authorization.REST_ENDPOINT).concat(AppConstants.Authorization.API_VERSION);
		logger.info(" SalesForceRestAPI : setAuthConstants : Leaving.");
	}

	/**
	 * Query by get method.
	 *
	 * @param query the query
	 * @throws ParseException the parse exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws SalesForceException the sales force exception
	 */
	// Query Leads using REST HttpGet
	public void queryByGetMethod(String query) throws ParseException, IOException, SalesForceException {
		logger.info(" SalesForceRestAPI : queryByGetMethod : Entered.");
		logger.info("\n_______________ Lead QUERY _______________");
		HttpResponse response = null;
		String resultJson = "";
		double points;
		int statusCode = 0;
		String uri = AppConstants.Authorization.BASEURI + query;
		logger.info("Query URL: " + uri);
		response = restAPIClient.execute(uri, HttpMethod.GET, null, false);
		statusCode = response.getStatusLine().getStatusCode();
		if (statusCode == 401) {
			resultJson = EntityUtils.toString(response.getEntity());
			JSONArray resultJsonObjArr;
			try {
				resultJsonObjArr = new JSONArray(resultJson);
				JSONObject obj = (JSONObject) resultJsonObjArr.get(0);
				if ("INVALID_SESSION_ID".equalsIgnoreCase(obj.get("errorCode").toString())) {
					authenticate();
					response = restAPIClient.execute(uri, HttpMethod.GET, null, false);
				} else {
					logger.info("Insertion unsuccessful. Status code returned is " + statusCode);
					resultJson = EntityUtils.toString(response.getEntity());
					JSONArray objArr = new JSONArray(resultJson);
					JSONObject jsonObj = (JSONObject) objArr.get(0);
					throw new SalesForceException(jsonObj.get("errorCode").toString() + " " + jsonObj.get("message").toString(), statusCode);
				}
			} catch (JSONException e) {
				logger.error("JSONException on queryByGetMethod: " , e);
			}

		}

		logger.info(response.getStatusLine().getStatusCode());

		// verify response is HTTP OK
		statusCode = response.getStatusLine().getStatusCode();
		if (statusCode == 200) {
			JSONObject json;
			try {
				json = new JSONObject(resultJson);
				logger.info("JSON result of Query:\n" + json.toString(1));
				JSONArray j = json.getJSONArray("records");
				for (int i = 0; i < j.length(); i++) {
					String leadId = json.getJSONArray("records").getJSONObject(i).getString("Name");
					points = json.getJSONArray("records").getJSONObject(i).getDouble("Points__c");
					logger.info("Lead record is: " + i + ". " + leadId + " " + points);
				}
			} catch (JSONException e) {
				logger.error("JSONException on queryByGetMethod: " , e);
			}

		} else {
			logger.info("Query was unsuccessful. Status code returned is " + statusCode);
			logger.info(resultJson);
			resultJson = EntityUtils.toString(response.getEntity());
			JSONArray objArr;
			try {
				objArr = new JSONArray(resultJson);
				JSONObject jsonObj = (JSONObject) objArr.get(0);
				throw new SalesForceException(jsonObj.get("errorCode").toString() + " " + jsonObj.get("message").toString(), statusCode);
			} catch (JSONException e) {
				logger.error("JSONException on queryByGetMethod: " , e);
			}
		}
		logger.info(" SalesForceRestAPI : queryByGetMethod : Leaving.");
	}

	/**
	 * Creates the leads.
	 *
	 * @param serviceEndPoint the service end point
	 * @throws ParseException the parse exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws SalesForceException the sales force exception
	 */
	// Create Leads using REST HttpPost
	public void createLeads(String serviceEndPoint) throws ParseException, IOException, SalesForceException {
		logger.info(" SalesForceRestAPI : createLeads : Entered.");
		logger.info("\n_______________ Lead INSERT _______________");
		String uri = AppConstants.Authorization.BASEURI + serviceEndPoint;
		String resultJson = "";
		HttpResponse response = null;
		JSONObject json = new JSONObject();
		try {
			json.put("FirstName", "Test12456");
			json.put("LastName", "HSD");
			json.put("Points__c", "15");
		} catch (JSONException e) {
			logger.error("JSONException on createLeads: " , e);
		}

		String jsonInString = json.toString();
		StringEntity reqEntity = new StringEntity(jsonInString);
		reqEntity.setContentType("application/json");

		response = restAPIClient.execute(uri, HttpMethod.POST, reqEntity, false);
		int statusCode = response.getStatusLine().getStatusCode();
		resultJson = EntityUtils.toString(response.getEntity());
		logger.info(response.getStatusLine().getStatusCode());

		if (statusCode == 401) {
			resultJson = EntityUtils.toString(response.getEntity());
			JSONArray resultJsonObjArr;
			try {
				resultJsonObjArr = new JSONArray(resultJson);
				JSONObject obj = (JSONObject) resultJsonObjArr.get(0);
				if ("INVALID_SESSION_ID".equalsIgnoreCase(obj.get("errorCode").toString())) {
					authenticate();
					response = restAPIClient.execute(uri, HttpMethod.POST, reqEntity, false);
				} else {
					logger.info("Insertion unsuccessful. Status code returned is " + statusCode);
					resultJson = EntityUtils.toString(response.getEntity());
					JSONArray objArr = new JSONArray(resultJson);
					JSONObject jsonObj = (JSONObject) objArr.get(0);
					throw new SalesForceException(jsonObj.get("errorCode").toString() + " " + jsonObj.get("message").toString(), statusCode);
				}
			} catch (JSONException e) {
				logger.error("JSONException on createLeads: " , e);
			}

		}
		// Process the results
		statusCode = response.getStatusLine().getStatusCode();
		if (statusCode == 201) {
			resultJson = EntityUtils.toString(response.getEntity());
			JSONObject jsonObj;
			String leadId = "";
			try {
				jsonObj = new JSONObject(resultJson);
				jsonObj.getString("id");
			} catch (JSONException e) {
				logger.error("JSONException on createLeads: " , e);
			}
			// Store the retrieved lead id to use when we update the lead.

			logger.info("New Lead id from response: " + leadId);
		} else {
			logger.info("Insertion unsuccessful. Status code returned is " + statusCode);
			resultJson = EntityUtils.toString(response.getEntity());
			JSONArray objArr;
			try {
				objArr = new JSONArray(resultJson);
				JSONObject jsonObj = (JSONObject) objArr.get(0);
				throw new SalesForceException(jsonObj.get("errorCode").toString() + " " + jsonObj.get("message").toString(), statusCode);
			} catch (JSONException e) {
				logger.error("JSONException on createLeads: " , e);
			}

		}
		logger.info(" SalesForceRestAPI : createLeads : Leaving.");
	}

}
