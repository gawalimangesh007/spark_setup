package com.sterling.bookingapi.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.sterling.bookingapi.dto.request.VoEssentialsRequest;
import com.sterling.bookingapi.dto.request.VoGetDashboardAccountRequestDTO;
import com.sterling.bookingapi.dto.request.VoReferAFriendRequest;
import com.sterling.bookingapi.dto.response.ResponseDTO;
import com.sterling.bookingapi.exception.BookingEngineException;
import com.sterling.bookingapi.exception.SalesForceException;
import com.sterling.bookingapi.service.VODashboardService;
import com.sterling.bookingapi.service.impl.VODashboardServiceImpl;
import com.sterling.bookingapi.utils.ResponseUtility;

/**
 * @author tcs
 *
 */
@RestController
@RequestMapping(value = "/voDashboard")
public class VODashboardController extends BaseController {
	
	/** The Constant logger. */
	private static final Logger logger = LogManager.getLogger(VODashboardController.class);
	private static final String HEADER_CACHE = "must-revalidate, post-check=0, pre-check=0";
	private static final String MEDIA_TYPE_PDF = "application/pdf";
	
	@Autowired
	public VODashboardService dashboardService;
	
	
	
	public void setDashboardService(VODashboardService dashboardService) {
		this.dashboardService = dashboardService;
	}

	public void setVODashboardService(VODashboardServiceImpl voDashboardService) {
		this.dashboardService = voDashboardService;
	}


	/**
	 * @param reqDTO
	 * @return dashboard account details
	 * @throws SalesForceException
	 */
	@RequestMapping(value = "/getDashboardAccountDetails", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO getDashboardAccountDetails(@RequestBody VoGetDashboardAccountRequestDTO reqDTO) throws SalesForceException {
		// reqDTO.setSfToken(sfToken);
		logger.info("VODashboardController : getDashboardAccountDetails : Entered.");
		ResponseEntity<?> dashboardAccountData = dashboardService.getDashboardAccountData(reqDTO);
		logger.info("VODashboardController : getDashboardAccountDetails : Leaving.");
		return ResponseUtility.constructSuccessRes(dashboardAccountData.getBody());
	}


	/**
	 * @param voDashboardService
	 * set the voDashboardService
	 */

	@RequestMapping(value = "/referAFriend", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO referAFriend(@RequestBody VoReferAFriendRequest req) throws SalesForceException{
		logger.info("VODashboardController : referAFriend : Entered.");
		ResponseEntity<?> referAFriendResponse = dashboardService.referAFriend(req);
		if(referAFriendResponse.getStatusCode() != HttpStatus.OK){
			return ResponseUtility.constructErrorRes("Not able to add Refer Friend(s) details",referAFriendResponse.getBody());
		}
		logger.info("VODashboardController : referAFriend : Leaving.");
		return ResponseUtility.constructSuccessRes(referAFriendResponse.getBody());
	}
	
	@RequestMapping(value = "/essentialsToCarry", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO essentialsToCarry(@RequestBody VoEssentialsRequest req){
		logger.info("VODashboardController : essentialsToCarry : Entered.");
		ResponseEntity<?> essentialResponse = dashboardService.essentialsToCarry(req);
		logger.info("VODashboardController : essentialsToCarry : Leaving.");
		return ResponseUtility.constructSuccessRes(essentialResponse.getBody());
		
	}
	
	/**
	 * @param reqDTO
	 * @return captureEMIResponse
	 * @throws SalesForceException
	 */
/*	@RequestMapping(value = "/captureEMI", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO captureEMIDetails(@RequestBody VoCaptureEMIPaymentRequestDTO reqDTO) throws SalesForceException {
		logger.info("VODashboardController : captureEMIDetails : Entered.");
		String captureEMIResponse = dashboardService.captureEMIDetails(reqDTO);
		logger.info("VODashboardController : captureEMIDetails : Leaving.");
		return ResponseUtility.constructSuccessRes(captureEMIResponse);
	}*/

	/**
	 * @param reqDTO
	 * @return captureEMIResponse
	 * @throws SalesForceException
	 */
/*	@RequestMapping(value = "/captureASF", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO captureASFDetails(@RequestBody VoCaptureASFPaymentRequestDTO reqDTO) throws SalesForceException {
		logger.info("VODashboardController : captureASFDetails : Entered.");
		String captureEMIResponse = dashboardService.captureASFDetails(reqDTO);
		logger.info("VODashboardController : captureASFDetails : Entered.");
		return ResponseUtility.constructSuccessRes(captureEMIResponse);
	}*/
	
	/**
	 * Download pdf.
	 *
	 * @param bookingId the booking id
	 * @return the response entity
	 * @throws BookingEngineException the booking engine exception
	 */
	@RequestMapping(value = "/getPastPaymentPDF", method = RequestMethod.GET)
	public ResponseEntity<byte[]> downloadPdf(@RequestParam String contractId,@RequestParam String paymentType) throws BookingEngineException {
		  logger.info("HsdBookingController : downloadPdf : Entered.");
		HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.parseMediaType(MEDIA_TYPE_PDF));
	    
	    String filename = contractId+".pdf";
	    
	    byte[] contents = dashboardService.getTransactionPDFContents(contractId,paymentType);
	    
	    headers.setContentDispositionFormData(filename, filename);
	    
	    headers.setCacheControl(HEADER_CACHE);
	    
		ResponseEntity<byte[]> response = new ResponseEntity<>(contents, headers, HttpStatus.OK);
		  logger.info("HsdBookingController : downloadPdf : leaving.");
		return response;
	}
}
