package com.sterling.bookingapi.dto.request;

import java.io.Serializable;

/**
 * @author tcs
 *
 */
public class HsdGetUserRequestDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String email;
	private String mobileNo;
	
	/**
	 * @return email
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * @param email
	 * set the email
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	/**
	 * @return mobile number
	 */
	public String getMobileNo() {
		return mobileNo;
	}
	/**
	 * @param mobileNo
	 * set the mobile number
	 */
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

}
