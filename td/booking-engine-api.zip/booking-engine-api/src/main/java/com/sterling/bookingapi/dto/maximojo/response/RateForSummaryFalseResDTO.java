package com.sterling.bookingapi.dto.maximojo.response;

import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class RateForSummaryFalseResDTO.
 * @author tcs
 * @version 1.0
 */
public class RateForSummaryFalseResDTO {
	
	/** The end. */
	@JacksonXmlProperty(localName = "End", isAttribute = true)
	private String end;

	/** The base by guest amt. */
	@JacksonXmlElementWrapper(useWrapping=true, localName = "BaseByGuestAmts")
	@JacksonXmlProperty(localName = "BaseByGuestAmt")
    private List<BaseByGuestAmtResDTO> baseByGuestAmt;

    /** The start. */
    @JacksonXmlProperty(localName = "Start", isAttribute = true)
    private String start;

    /** The additional guest amount. */
    @JacksonXmlElementWrapper(useWrapping=true, localName = "AdditionalGuestAmounts")
    @JacksonXmlProperty(localName = "AdditionalGuestAmount")
    private List<AdditionalGuestAmountResDTO> additionalGuestAmount;

    /** The inv type code. */
    @JacksonXmlProperty(localName = "InvTypeCode", isAttribute = true)
    private String invTypeCode;

    /** The sun. */
    @JacksonXmlProperty(localName = "Sun", isAttribute = true)
    private boolean sun = false;

    /** The thur. */
    @JacksonXmlProperty(localName = "Thur", isAttribute = true)
    private boolean thur= false;

    /** The sat. */
    @JacksonXmlProperty(localName = "Sat", isAttribute = true)
    private boolean sat= false;

    /** The weds. */
    @JacksonXmlProperty(localName = "Weds", isAttribute = true)
    private boolean weds= false;
    
    /** The fri. */
    @JacksonXmlProperty(localName = "Fri", isAttribute = true)
    private boolean fri= false;

    /** The mon. */
    @JacksonXmlProperty(localName = "Mon", isAttribute = true)
    private boolean mon= false;

    /** The tue. */
    @JacksonXmlProperty(localName = "Tue", isAttribute = true)
    private boolean tue= false;

    /** The currency code. */
    @JacksonXmlProperty(localName = "CurrencyCode", isAttribute = true)
    private String currencyCode;

	/**
	 * Gets the base by guest amt.
	 *
	 * @return the baseByGuestAmt
	 */
	public List<BaseByGuestAmtResDTO> getBaseByGuestAmt() {
		return baseByGuestAmt;
	}

	/**
	 * Sets the base by guest amt.
	 *
	 * @param baseByGuestAmt the baseByGuestAmt to set
	 */
	public void setBaseByGuestAmt(List<BaseByGuestAmtResDTO> baseByGuestAmt) {
		this.baseByGuestAmt = baseByGuestAmt;
	}
	
	/**
	 * Gets the additional guest amount.
	 *
	 * @return the additionalGuestAmount
	 */
	public List<AdditionalGuestAmountResDTO> getAdditionalGuestAmount() {
		return additionalGuestAmount;
	}

	/**
	 * Sets the additional guest amount.
	 *
	 * @param additionalGuestAmount the additionalGuestAmount to set
	 */
	public void setAdditionalGuestAmount(List<AdditionalGuestAmountResDTO> additionalGuestAmount) {
		this.additionalGuestAmount = additionalGuestAmount;
	}

	/**
	 * Gets the inv type code.
	 *
	 * @return the invTypeCode
	 */
	public String getInvTypeCode() {
		return invTypeCode;
	}

	/**
	 * Sets the inv type code.
	 *
	 * @param invTypeCode the invTypeCode to set
	 */
	public void setInvTypeCode(String invTypeCode) {
		this.invTypeCode = invTypeCode;
	}

	/**
	 * Checks if is sun.
	 *
	 * @return the sun
	 */
	public boolean isSun() {
		return sun;
	}

	/**
	 * Sets the sun.
	 *
	 * @param sun the sun to set
	 */
	public void setSun(boolean sun) {
		this.sun = sun;
	}

	/**
	 * Checks if is thur.
	 *
	 * @return the thur
	 */
	public boolean isThur() {
		return thur;
	}

	/**
	 * Sets the thur.
	 *
	 * @param thur the thur to set
	 */
	public void setThur(boolean thur) {
		this.thur = thur;
	}

	/**
	 * Checks if is sat.
	 *
	 * @return the sat
	 */
	public boolean isSat() {
		return sat;
	}

	/**
	 * Sets the sat.
	 *
	 * @param sat the sat to set
	 */
	public void setSat(boolean sat) {
		this.sat = sat;
	}

	/**
	 * Checks if is weds.
	 *
	 * @return the weds
	 */
	public boolean isWeds() {
		return weds;
	}

	/**
	 * Sets the weds.
	 *
	 * @param weds the weds to set
	 */
	public void setWeds(boolean weds) {
		this.weds = weds;
	}

	/**
	 * Checks if is fri.
	 *
	 * @return the fri
	 */
	public boolean isFri() {
		return fri;
	}

	/**
	 * Sets the fri.
	 *
	 * @param fri the fri to set
	 */
	public void setFri(boolean fri) {
		this.fri = fri;
	}

	/**
	 * Checks if is mon.
	 *
	 * @return the mon
	 */
	public boolean isMon() {
		return mon;
	}

	/**
	 * Sets the mon.
	 *
	 * @param mon the mon to set
	 */
	public void setMon(boolean mon) {
		this.mon = mon;
	}

	/**
	 * Checks if is tue.
	 *
	 * @return the tue
	 */
	public boolean isTue() {
		return tue;
	}

	/**
	 * Sets the tue.
	 *
	 * @param tue the tue to set
	 */
	public void setTue(boolean tue) {
		this.tue = tue;
	}

	/**
	 * Gets the currency code.
	 *
	 * @return the currencyCode
	 */
	public String getCurrencyCode() {
		return currencyCode;
	}

	/**
	 * Sets the currency code.
	 *
	 * @param currencyCode the currencyCode to set
	 */
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	/**
	 * Gets the end.
	 *
	 * @return the end
	 */
	public String getEnd() {
		return end;
	}

	/**
	 * Sets the end.
	 *
	 * @param end the end to set
	 */
	public void setEnd(String end) {
		this.end = end;
	}

	/**
	 * Gets the start.
	 *
	 * @return the start
	 */
	public String getStart() {
		return start;
	}

	/**
	 * Sets the start.
	 *
	 * @param start the start to set
	 */
	public void setStart(String start) {
		this.start = start;
	}

	

}
