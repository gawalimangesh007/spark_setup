package com.sterling.bookingapi.dto.maximojo.response;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class SuccessReqDTO.
 * @author tcs
 * @version 1.0
 */
public class SuccessReqDTO {

	/** The xmlns. */
	@JacksonXmlProperty(localName = "xmlns", isAttribute = true)
	 private String xmlns;

	    /**
    	 * Gets the xmlns.
    	 *
    	 * @return the xmlns
    	 */
    	public String getXmlns ()
	    {
	        return xmlns;
	    }

	    /**
    	 * Sets the xmlns.
    	 *
    	 * @param xmlns the new xmlns
    	 */
    	public void setXmlns (String xmlns)
	    {
	        this.xmlns = xmlns;
	    }
}
