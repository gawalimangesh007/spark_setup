package com.sterling.bookingapi.dto.maximojo.request;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class ProfileInfoReqDTO.
 */
/**
 * @author tcs
 *
 */
public class ProfileInfoReqDTO {

/** The profile. */
@JacksonXmlProperty(localName = "Profile")
private ProfileReqDTO profile;

/**
 * Gets the profile.
 *
 * @return the profile
 */
public ProfileReqDTO getProfile() {
	return profile;
}

/**
 * Sets the profile.
 *
 * @param profile the profile to set
 */
public void setProfile(ProfileReqDTO profile) {
	this.profile = profile;
}
	
	
}
