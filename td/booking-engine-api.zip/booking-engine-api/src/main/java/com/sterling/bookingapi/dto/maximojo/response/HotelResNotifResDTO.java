package com.sterling.bookingapi.dto.maximojo.response;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;


/**
 * The Class HotelResNotifResDTO.
 * @author tcs
 * @version 1.0
 */
@JacksonXmlRootElement(localName = "OTA_HotelResNotifRS")
public class HotelResNotifResDTO {

	/** The time stamp. */
	@JacksonXmlProperty(localName = "TimeStamp", isAttribute = true)
	private String timeStamp;

	/** The hotel reservations. */
	@JacksonXmlProperty(localName = "HotelReservations")
	private HotelReservationsBookingResDTO hotelReservations;

	/** The res response type. */
	@JacksonXmlProperty(localName = "ResResponseType", isAttribute = true)
	private String resResponseType;

	/** The transaction identifier. */
	@JacksonXmlProperty(localName = "TransactionIdentifier", isAttribute = true)
	private String transactionIdentifier;

	/** The version. */
	@JacksonXmlProperty(localName = "Version", isAttribute = true)
	private String version;

	/** The success. */
	@JacksonXmlProperty(localName = "Success")
	private SuccessReqDTO success;

	/** The echo token. */
	@JacksonXmlProperty(localName = "EchoToken", isAttribute = true)
	private String echoToken;
	
	/** The errors. */
	@JacksonXmlProperty(localName = "Errors")
	private ErrorsResDTO errors;

	/**
	 * Gets the time stamp.
	 *
	 * @return the timeStamp
	 */
	public String getTimeStamp() {
		return timeStamp;
	}

	/**
	 * Sets the time stamp.
	 *
	 * @param timeStamp            the timeStamp to set
	 */
	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}

	/**
	 * Gets the hotel reservations.
	 *
	 * @return the hotelReservations
	 */
	public HotelReservationsBookingResDTO getHotelReservations() {
		return hotelReservations;
	}

	/**
	 * Sets the hotel reservations.
	 *
	 * @param hotelReservations            the hotelReservations to set
	 */
	public void setHotelReservations(
			HotelReservationsBookingResDTO hotelReservations) {
		this.hotelReservations = hotelReservations;
	}

	/**
	 * Gets the res response type.
	 *
	 * @return the resResponseType
	 */
	public String getResResponseType() {
		return resResponseType;
	}

	/**
	 * Sets the res response type.
	 *
	 * @param resResponseType            the resResponseType to set
	 */
	public void setResResponseType(String resResponseType) {
		this.resResponseType = resResponseType;
	}

	/**
	 * Gets the transaction identifier.
	 *
	 * @return the transactionIdentifier
	 */
	public String getTransactionIdentifier() {
		return transactionIdentifier;
	}

	/**
	 * Sets the transaction identifier.
	 *
	 * @param transactionIdentifier            the transactionIdentifier to set
	 */
	public void setTransactionIdentifier(String transactionIdentifier) {
		this.transactionIdentifier = transactionIdentifier;
	}

	/**
	 * Gets the version.
	 *
	 * @return the version
	 */
	public String getVersion() {
		return version;
	}

	/**
	 * Sets the version.
	 *
	 * @param version            the version to set
	 */
	public void setVersion(String version) {
		this.version = version;
	}

	/**
	 * Gets the success.
	 *
	 * @return the success
	 */
	public SuccessReqDTO getSuccess() {
		return success;
	}

	/**
	 * Sets the success.
	 *
	 * @param success            the success to set
	 */
	public void setSuccess(SuccessReqDTO success) {
		this.success = success;
	}

	/**
	 * Gets the echo token.
	 *
	 * @return the echoToken
	 */
	public String getEchoToken() {
		return echoToken;
	}

	/**
	 * Sets the echo token.
	 *
	 * @param echoToken            the echoToken to set
	 */
	public void setEchoToken(String echoToken) {
		this.echoToken = echoToken;
	}

	/**
	 * Gets the errors.
	 *
	 * @return the errors
	 */
	public ErrorsResDTO getErrors() {
		return errors;
	}

	/**
	 * Sets the errors.
	 *
	 * @param errors the errors to set
	 */
	public void setErrors(ErrorsResDTO errors) {
		this.errors = errors;
	}

}
