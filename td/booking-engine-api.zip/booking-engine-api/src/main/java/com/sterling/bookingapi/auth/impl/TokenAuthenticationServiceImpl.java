package com.sterling.bookingapi.auth.impl;

import java.io.IOException;
import java.util.Collections;
import java.util.Date;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.core.type.TypeReference;
import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeTokenRequest;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdToken;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdToken.Payload;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdTokenVerifier;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.restfb.DefaultFacebookClient;
import com.restfb.FacebookClient;
import com.restfb.Parameter;
import com.restfb.Version;
import com.sterling.bookingapi.auth.bean.AuthType;
import com.sterling.bookingapi.auth.bean.Info;
import com.sterling.bookingapi.auth.bean.SocialAccountType;
import com.sterling.bookingapi.auth.bean.SocialLoginReq;
import com.sterling.bookingapi.auth.bean.SterlingAuthException;
import com.sterling.bookingapi.auth.bean.User;
import com.sterling.bookingapi.auth.bean.UserAuthentication;
import com.sterling.bookingapi.auth.bean.UserToken;
import com.sterling.bookingapi.context.RequestContext;
import com.sterling.bookingapi.context.RequestThreadLocal;
import com.sterling.bookingapi.dto.response.Attributes;
import com.sterling.bookingapi.dto.response.VOLoginResponseWrapper;
import com.sterling.bookingapi.exception.BookingEngineException;
import com.sterling.bookingapi.exception.ErrorCodes;
import com.sterling.bookingapi.models.VOLogin;
import com.sterling.bookingapi.service.VacationOwnershipService;
import com.sterling.bookingapi.sf.dto.response.VORecordEntryResponse;
import com.sterling.bookingapi.sf.hsd.dto.request.HsdLoginRequestDTO;
import com.sterling.bookingapi.sf.hsd.dto.request.HsdRegisterRequestDTO;
import com.sterling.bookingapi.sf.hsd.dto.response.HsdMemberResponseDTO;
import com.sterling.bookingapi.sf.hsd.service.HsdUserService;
import com.sterling.bookingapi.utils.BookingEngineUtils;

/**
 * @author tcs
 *
 */
@Service
@Transactional
public class TokenAuthenticationServiceImpl implements TokenAuthenticationService {
	private static final String ALLOW_PARALLEL_LOGIN_PARAMETER = "allowParallel";
	private static final String AUTH_HEADER_NAME = "X-AUTH-TOKEN";
	private Logger logger = LogManager.getLogger(TokenAuthenticationServiceImpl.class);

	@Autowired
	private TokenHandlerService tokenHandlerService;
	
	@Autowired
	private VacationOwnershipService voService;
	
	@Autowired
	private HsdUserService hsdUserService;
	
	@Value(value = "${google.api.key}")
	private String googleClientId;

	@Value(value = "${google.api.secret}")
	private String googleSecret;
	
	
	@Value(value = "${facebook.api.key}")
	private String facebookClientId;

	@Value(value = "${facebook.api.secret}")
	private String facebookSecret;
	
	@Override
	public Authentication getAuthenticationForLogin(HttpServletRequest request, HttpServletResponse response) {

		UserAuthentication auth = new UserAuthentication(null);
		auth.setIpAddress(request.getRemoteAddr());
//		User user = new User();
//		user.setUserId("uname");
//		user.setPassword("pass12");
		//Decrypt base64 to get uname andpwd.
		final String authHeader = request.getHeader("authorization") != null ? request.getHeader("authorization") : null;
		logger.info("Login flow %%%%%%%%%%%%%%%%%% authHeader {}", authHeader);
		Info info = auth.getInfo();
		User user = getUser(authHeader);
		if(user == null ) {
			throw new SterlingAuthException("Please check your id and password.",ErrorCodes.INVALID_USER_PASS.name(), null);
		}
		
		AuthType authType = user.getAuthType();
		try {
			if(authType == AuthType.VO) {
				logger.info("VO FLOW %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
				VOLogin voLogin = new VOLogin();
				voLogin.setUserID(user.getUserId());
				voLogin.setPassword(user.getPassword());
				VOLoginResponseWrapper voResponse = voService.voLogin(voLogin);
				user.setUserObject(voResponse);
			} else if(authType == AuthType.HSD) {
				logger.info("HSD flow %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
				HsdLoginRequestDTO hsdLogin = new HsdLoginRequestDTO();
				hsdLogin.setEmail(user.getUserId());
				hsdLogin.setPassword(user.getPassword());
				HsdMemberResponseDTO hsdRes = hsdUserService.hsdUserLogin(hsdLogin);
				user.setUserObject(hsdRes);
			}
			auth.setUser(user);
			auth.setAuthenticated(true);
			auth.setAuthType(authType);
			
			//check if already logged in
			validateParallelLogin(request, user);
			
			return auth;
			
		} catch (BookingEngineException e) {
			if(e.getErrLabel()!= null) {
				throw new SterlingAuthException(e.getMessage(), e.getErrLabel(), null);
			} else {
				throw e;
			}

		}		
	}

	private void validateParallelLogin(HttpServletRequest request, User user) {

		String token = tokenHandlerService.getLoggedUserToken(user.getAuthType().getLoginType() + user.getUserId());
		if(StringUtils.isNotEmpty(token)) {
			Object loggedUsr = tokenHandlerService.getLoggedUser(token);
			if(loggedUsr != null) {
				String isAllowParallel = request.getParameter(ALLOW_PARALLEL_LOGIN_PARAMETER);
				if(!StringUtils.equalsIgnoreCase("true", isAllowParallel)) {
					throw new SterlingAuthException("Same user logged in already", ErrorCodes.PARALLEL_LOGIN.name(), null);
				} else {
					tokenHandlerService.removeFromCache(token);
				}
			}
		}
	}
	
	@Override
	public Authentication getAuthenticationForSocialLogin(HttpServletRequest request, HttpServletResponse response) { 

		UserAuthentication auth = new UserAuthentication(null);
		auth.setIpAddress(request.getRemoteAddr());
		
		//TODO tune here
		User user = getSocialUser(request);
		AuthType authType = AuthType.HSD;//TODO currently supports HSD only
		if(user == null ) {
			throw new SterlingAuthException("Please check your data", ErrorCodes.INVALID_USER_PASS.name(), null);
		}
		
		user.setAuthType(authType);
		String email = user.getEmail();
		String contact = user.getContact();
		
		try {
			
			validateParallelLogin(request, user);
			
			if(authType == AuthType.VO) {
				logger.info("VO FLOW %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
				
			} else if(authType == AuthType.HSD) {
				
				logger.info("HSD flow %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
				HsdLoginRequestDTO hsdLogin = new HsdLoginRequestDTO();
				HsdMemberResponseDTO hsdRes = null;
				if(StringUtils.isNotEmpty(email)) {
					hsdLogin.setEmail(email);
					hsdRes = hsdUserService.getHsdUserByEmail(hsdLogin);
				} else if(StringUtils.isNotEmpty(contact)) {
					//TODO mobile number checking flow
					//hsdLogin.setMobile(email);
					//hsdRes = hsdUserService.getHsdUserByMobile(hsdLogin);
				}
				if(hsdRes == null) {
					//if user not found register here
					if(contact == null || email == null) {
						throw new SterlingAuthException("mandotory fields are missing", ErrorCodes.NUMBER_OR_EMAIL_MISSING.name(), user); 
					}
					
					HsdRegisterRequestDTO req = mapHsdUser(user);
					VORecordEntryResponse hsdUser = hsdUserService.hsdUserRegister(req);
					hsdRes = mapHsdMember(user, hsdUser);
					
				}
				user.setUserObject(hsdRes);
			}
			
			auth.setUser(user);
			auth.setAuthenticated(true);
			auth.setAuthType(authType);
			return auth;
			
		} catch (BookingEngineException e) {
			if(ErrorCodes.NON_MEMBER_DUPLICATE_ERR.name().equals(e.getErrLabel())) {
				throw new SterlingAuthException(e.getMessage(), ErrorCodes.NON_MEMBER_DUPLICATE_ERR.name(), null);
			} else if(e.getErrCode() == 401) {
				throw new SterlingAuthException(e.getMessage(), ErrorCodes.INVALID_USER_PASS.name(), null);
			} else if(e.getErrCode() == 400){
				throw new SterlingAuthException(e.getMessage(), ErrorCodes.INVALID_USER_PASS.name(), null);
			} else {
				throw new SterlingAuthException("Technical Error", ErrorCodes.GENERAL_TECH_ERROR.name(), null);
			}
		}		
	}

	private HsdMemberResponseDTO mapHsdMember(User user,
			VORecordEntryResponse hsdUser) {
		HsdMemberResponseDTO dto = new HsdMemberResponseDTO();
		if(hsdUser != null) {
			Attributes attributes = new Attributes();
			attributes.setType("Non_Member__c");
			attributes.setUrl("/services/data/v39.0/sobjects/Non_Member__c/" + hsdUser.getId());
			dto.setAttributes(attributes );
			
			dto.setId(hsdUser.getId());
			dto.setFirstName(user.getFirstName());
			dto.setLastName(user.getLastName());
			dto.setEmail(user.getEmail());
			dto.setMobileNo(user.getContact());
			dto.setGender(user.getGender());
			dto.setDob(user.getDob());
			dto.setTitle(user.getTitle());
			dto.setIsNewUser(true);
		}
		return dto;
	}

	private HsdRegisterRequestDTO mapHsdUser(User user) {
		// TODO map user to hsd user registration request
		HsdRegisterRequestDTO req = new HsdRegisterRequestDTO();
		req.setEmail(user.getEmail());
		req.setFirstName(user.getFirstName());
		req.setLastName(user.getLastName());
		req.setMobileNo(user.getContact());
		req.setDob(user.getDob());
		req.setGender(user.getGender());
		req.setTitle(user.getTitle());

		return req;
	}

	private User getSocialUser(HttpServletRequest request) {
		logger.info("get user info from social........");
		User user = null;
		final String authHeader = request.getHeader("authorization") != null ? request.getHeader("authorization") : null;
		String authReq = BookingEngineUtils.base64Decode(authHeader);
		SocialLoginReq socialLoginReq = BookingEngineUtils.convertJsonToObject(authReq, new TypeReference<SocialLoginReq>() {});
		
		if(socialLoginReq != null) {
			logger.info("get user info from social....auth type :: {}", socialLoginReq.getAccountType());
			if(SocialAccountType.getFrom(socialLoginReq.getAccountType()) == SocialAccountType.GOOGLE) {
				user = getGoogleUser(socialLoginReq);
				
			} else if(SocialAccountType.getFrom(socialLoginReq.getAccountType()) == SocialAccountType.FACEBOOK) {
				//TODO get facebook user
				user = getFacebookUser(socialLoginReq);
			}
			if(StringUtils.isNotEmpty(socialLoginReq.getMobile())) {
				user.setContact(socialLoginReq.getMobile());
			}
			if(StringUtils.isNotEmpty(socialLoginReq.getEmail())) {
				user.setEmail(socialLoginReq.getEmail());
			}

		} else {
			throw new SterlingAuthException("Please check your your data", ErrorCodes.INVALID_USER_PASS.name(), null);
		}
		
		return user;
	}

	

	private User getFacebookUser(SocialLoginReq socialLoginReq) {
		User user = null;
		try {
			FacebookClient fbClient = new DefaultFacebookClient(socialLoginReq.getToken(), Version.LATEST);
			com.restfb.types.User me = fbClient.fetchObject("me", com.restfb.types.User.class, Parameter.with("fields", "id,name,email,first_name,last_name,gender,birthday,address"));
			
			if(me != null) {
				user = new User();
				user.setFirstName(me.getFirstName());
				user.setLastName(me.getLastName());
				user.setEmail(me.getEmail());
				user.setUserId(me.getEmail());
				user.setGender(me.getGender());
				Date dob = me.getBirthdayAsDate();
				if(dob != null) {
					user.setDob(BookingEngineUtils.formatDate(dob, BookingEngineUtils.SF_DATE_FORMAT));
				}
			}
			
		} catch (Exception e) {
			logger.error(BookingEngineUtils.getErrorMessage("FB_LOGIN_ERROR"), e);
			throw new SterlingAuthException(BookingEngineUtils.getErrorMessage("FB_LOGIN_ERROR"), ErrorCodes.FB_LOGIN_ERROR.name(), null);
		}
		
		
		return user;
	}

	private User getGoogleUser(SocialLoginReq socialLoginReq) {
		logger.info("get user info from google........");
		User user = null;
		GoogleIdToken idToken = null;
		try {
			JacksonFactory jsonFactory = new JacksonFactory();
			GoogleIdTokenVerifier verifier = new GoogleIdTokenVerifier.Builder(new NetHttpTransport(), jsonFactory)
					.setAudience(Collections.singletonList(googleClientId))
					.build();

			idToken = verifier.verify(socialLoginReq.getToken());

			if (idToken != null) {
				Payload payload = idToken.getPayload();
				user = new User();

				// Get profile information from payload
				user.setEmail(payload.getEmail());
				user.setUserId(payload.getEmail());

				user.setLastName((String) payload.get("family_name"));
				user.setFirstName((String) payload.get("given_name"));
			} else {
				logger.info("google return no token...");
				throw new SterlingAuthException(BookingEngineUtils.getErrorMessage("GOOGLE_LOGIN_ERROR"), ErrorCodes.GOOGLE_LOGIN_ERROR.name(), null);
			}
		} catch (Exception e) {
			logger.error(BookingEngineUtils.getErrorMessage("GOOGLE_LOGIN_ERROR"), e);
			throw new SterlingAuthException(BookingEngineUtils.getErrorMessage("GOOGLE_LOGIN_ERROR"), ErrorCodes.GOOGLE_LOGIN_ERROR.name(), null);
		}

		return user;
	}

	/**
	 * @param authorization
	 * @return user details
	 */
	private User getUser(String authorization) {
		User user = null;
		if (authorization != null && authorization.startsWith("Basic")) {
	        // Authorization: Basic base64credentials
	        String base64Credentials = authorization.substring("Basic".length()).trim();
	        String credentials = BookingEngineUtils.base64Decode(base64Credentials);
	        logger.info("Login flow %%%%%%%%%%%%%%%%%% authHeader {}", credentials);
	        // credentials = username:password
	        final String[] values = credentials.split(":",2);
	        logger.info("Login flow %%%%%%%%%%%%%%%%%% user {}", values.toString());
	        if(BookingEngineUtils.checkArray(values, 2)) {
	        	String[] userName = values[0].split("\\|",2);
	        	if(BookingEngineUtils.checkArray(userName, 2) && isValidType(userName[0])) {
	        		user = new User();
	        		user.setAuthType(AuthType.getFrom(userName[0]));
	        		user.setPassword(values[1]);
	        		user.setUserId(userName[1]);
	        		
	        	}
	        }
		}
		return user;
	}

	private boolean isValidType(String string) {
		return AuthType.contains(string);
	}

	@Override
	public Authentication getAuthentication(HttpServletRequest request, HttpServletResponse response) throws IOException {

		String token = getCookie(request, AUTH_HEADER_NAME);
		if(StringUtils.isEmpty(token)) {
			token = request.getHeader(AUTH_HEADER_NAME);
		}
		logger.info("x-auth-token: {}", token);
		UserAuthentication auth = new UserAuthentication(null);
//		auth.setIpAddress(IPUtil.getRemoteIp(request));
		
		Info info = auth.getInfo();
		
		if (!StringUtils.isEmpty(token)) {
			User user = null;
			try {
				user = tokenHandlerService.parseUserFromToken(token);
				
				if (user != null) {
					response.setStatus(HttpServletResponse.SC_OK);
					auth.setUser(user);
					auth.setAuthenticated(true);
					auth.setToken(token);
					auth.setAuthType(user.getAuthType());
					RequestContext requestContext = RequestThreadLocal.get();
					requestContext.setToken(token);
					return auth;
				} else {
					info.setCode(101L);
					info.setDesc("user.notfound");
				}
			} catch (SterlingAuthException e) {
				info.setCode(102L);
				info.setDesc(e.getDescription());
				info.setObject(e);
				
				logger.warn("Token Exception : " + e.getMessage());
			} catch (Exception e){
				info.setCode(103L);
				info.setDesc("UNWANTED_EXCEPTION_RELOGIN_NEEDED");
				
				logger.warn("Exception", e);
			}
			
		} else {
			info.setCode(100L);
			info.setDesc("token.notfound");
		}

		response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
		auth.setAuthenticated(false);
		return auth;
	}

	@Override
	public UserToken addAuthentication(HttpServletResponse response, UserAuthentication authResult) {
		final User user = authResult.getDetails();
		String token = tokenHandlerService.calculateTokenForUser(user);

		UserToken utoken = new UserToken();
		utoken.setUser(user);
		utoken.setToken(token);
		utoken.setIpAddress(authResult.getIpAddress());
		utoken.setCreatedDate(new Date());
		tokenHandlerService.insertToCache(token, utoken);
		
		tokenHandlerService.mapUserToken(token, user.getAuthType() + user.getUserId());
		
		response.addHeader(AUTH_HEADER_NAME, token);
		Cookie cookie = new Cookie(AUTH_HEADER_NAME, token);
		cookie.setMaxAge(60*60*24);
		cookie.setPath("/");
		response.addCookie(cookie);
		
		RequestContext requestContext = RequestThreadLocal.get();
		requestContext.setToken(token);
		return utoken;
	}

	@Override
	public void removeAuthentication(HttpServletRequest request, HttpServletResponse response) {
		logger.info("removeAuthentication : Entered");
		String token = getCookie(request, AUTH_HEADER_NAME);
		if(StringUtils.isEmpty(token)) {
			token = request.getHeader(AUTH_HEADER_NAME);
		}
		logger.info("remove item from auth {}", token);
		tokenHandlerService.removeFromCache(token);
		logger.info("token removed from cache");
		removeCookie(response);
	}
	
	

	public class GoogleAuthorizationCodeTokenV4Request extends GoogleAuthorizationCodeTokenRequest {


	    public GoogleAuthorizationCodeTokenV4Request(HttpTransport transport, JsonFactory jsonFactory, String clientId, String
	            clientSecret, String code, String redirectUri) {
	        super(transport, jsonFactory, "https://www.googleapis.com/oauth2/v4/token", clientId, clientSecret,
	            code, redirectUri);
	    }
	}
	
	public String getCookie(HttpServletRequest request, String key) {
	    Cookie[] cookies = request.getCookies();

	    if (cookies == null) {
	        return null;
	    }

	    for (Cookie cookie : cookies) {
	        if ((cookie == null) || (cookie.getName() == null)) {
	            continue;
	        }

	        if (cookie.getName().equals(key)) {
	            return cookie.getValue();
	        }
	    }

	    return null;
	}
	
	private void removeCookie(HttpServletResponse response) {
		Cookie authCookie = new Cookie(AUTH_HEADER_NAME, null);
	     authCookie.setMaxAge(0);
	     authCookie.setPath("/");
	     response.addCookie(authCookie);
	}
}
