package com.sterling.bookingapi.dto.maximojo.request;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

public class ExtraPersonRateDTO {

	@JacksonXmlProperty(localName = "ExtraAdultDetail")
	private ExtraAdultRateDTO extraAdultDetails;
	
	@JacksonXmlProperty(localName = "ExtraChildDetail")
	private ExtraChildRateDTO extraChildDetails;

	/**
	 * @return the extraAdultDetails
	 */
	public ExtraAdultRateDTO getExtraAdultDetails() {
		return extraAdultDetails;
	}

	/**
	 * @param extraAdultDetails the extraAdultDetails to set
	 */
	public void setExtraAdultDetails(ExtraAdultRateDTO extraAdultDetails) {
		this.extraAdultDetails = extraAdultDetails;
	}

	/**
	 * @return the extraChildDetails
	 */
	public ExtraChildRateDTO getExtraChildDetails() {
		return extraChildDetails;
	}

	/**
	 * @param extraChildDetails the extraChildDetails to set
	 */
	public void setExtraChildDetails(ExtraChildRateDTO extraChildDetails) {
		this.extraChildDetails = extraChildDetails;
	}
}
