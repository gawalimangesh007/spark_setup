package com.sterling.bookingapi.models;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "sh_hsd_calendar")
public class HsdCalendar{
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;
		
	@Id
	@GeneratedValue( strategy = GenerationType.IDENTITY )
	@Column(name = "id", unique = true,nullable = false)
	private int Id;
	
	@Column(name = "calendar_date", unique = true,nullable = false)
	private Date calendarDate;

	public Date getCalendarDate() {
		return calendarDate;
	}

	public void setCalendarDate(Date calendarDate) {
		this.calendarDate = calendarDate;
	}
}
