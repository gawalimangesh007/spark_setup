package com.sterling.bookingapi.mail;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.sterling.bookingapi.exception.BookingEngineException;
import com.sterling.bookingapi.utils.AppConstants.TemplateAction;
import com.sterling.bookingapi.utils.BookingEngineUtils;
import com.sterling.bookingapi.utils.ConfigurationProperties;
import com.sterling.bookingapi.utils.EmailAssets;
import com.sterling.bookingapi.utils.ResourceUtils;


/**
 * The Class EmailManager.
 */
/**
 * @author tcs 
 * @version 1.0
 *
 */
@Component
@EnableAsync
public class EmailManager {

	/** The Constant logger. */
	private static final Logger logger = LogManager.getLogger(EmailManager.class);

	/** The email util. */
	@Autowired
	private EmailUtil emailUtil;
	
	/** The resource utils. */
	@Autowired
	private ResourceUtils resourceUtils;

	/** The configuration properties. */
	@Autowired
	private ConfigurationProperties configurationProperties;
	/**
	 * Send mail.
	 *
	 * @param emailId the email id
	 * @throws BookingEngineException the booking engine exception
	 */
	@Async
	public void sendMail(List<String> mailTo, String subject, Map<String, Object> dataMap, TemplateAction emailTemplate) {
		logger.info(": sendMail : Entered");
		sendMail(mailTo, null, subject, dataMap, emailTemplate);
		logger.info("sendMail : Leaving");
	}
	
	@Async
	public void sendMail(List<String> mailTo, List<String> bcc, String subject, Map<String, Object> dataMap, TemplateAction emailTemplate) {
		logger.info(" : sendMail : Entered");
		String sender = configurationProperties.getSmtpSender();
		
		try {
			InternetAddress[] recipient = getInterAddrList(mailTo);
			InternetAddress[] bccMails = getInterAddrList(bcc);
			
		/*	String logo = "images/emailContent/logo.png";
			String dot = "images/emailContent/dot.jpg";
			String dotr = "images/emailContent/dotr.jpg";
			String border = "images/emailContent/border.png";
			
			String encodedLogoContent = resourceUtils.getFileContent(logo);
			String encodedDotContent = resourceUtils.getFileContent(dot);
			String encodedDotrContent = resourceUtils.getFileContent(dotr);
			String encodedBorderContent = resourceUtils.getFileContent(border);
			
			String base64Format = "data:image/jpeg;base64,";
			dataMap.put("logo", base64Format+encodedLogoContent);
			dataMap.put("dot", base64Format+encodedDotContent);
			dataMap.put("dotr", base64Format+encodedDotrContent);
			dataMap.put("border", base64Format+encodedBorderContent); */
			
			String serverPathName = configurationProperties.getServerAEMName();
			if(!serverPathName.endsWith("/")) {
				serverPathName = serverPathName+"/"; 
			}
			dataMap.put("logo", serverPathName+BookingEngineUtils.getPropertyEmailImageURL(EmailAssets.EMAIL_CONTENT_LOGO));
			dataMap.put("dot",serverPathName+BookingEngineUtils.getPropertyEmailImageURL(EmailAssets.EMAIL_CONTENT_DOT));
			dataMap.put("dotr", serverPathName+BookingEngineUtils.getPropertyEmailImageURL(EmailAssets.EMAIL_CONTENT_DOTR));
			dataMap.put("border", serverPathName+BookingEngineUtils.getPropertyEmailImageURL(EmailAssets.EMAIL_CONTENT_BORDER));
			
			triggerEmail(sender, recipient, null, bccMails, subject , null, emailTemplate, dataMap, null);
		} catch (BookingEngineException e) {
			logger.error("Exception occured while Sending mail for {}", e);
		}
		logger.info(" sendConfirmationMail : Leaving");
	}

	@Async
	public void sendMail(List<String> mailTo, List<String> bcc, String subject, Map<String, Object> dataMap, TemplateAction emailTemplate, List<AttachmentReqDTO> attachmentList) {
		logger.info(" : sendMail : Entered");
		String sender = configurationProperties.getSmtpSender();
		
		try {
			InternetAddress[] recipient = getInterAddrList(mailTo);
			InternetAddress[] bccMails = getInterAddrList(bcc);
			
		/*	String logo = "images/emailContent/logo.png";
			String dot = "images/emailContent/dot.jpg";
			String dotr = "images/emailContent/dotr.jpg";
			String border = "images/emailContent/border.png";
			
			String encodedLogoContent = resourceUtils.getFileContent(logo);
			String encodedDotContent = resourceUtils.getFileContent(dot);
			String encodedDotrContent = resourceUtils.getFileContent(dotr);
			String encodedBorderContent = resourceUtils.getFileContent(border);
			
			String base64Format = "data:image/jpeg;base64,";
			dataMap.put("logo", base64Format+encodedLogoContent);
			dataMap.put("dot", base64Format+encodedDotContent);
			dataMap.put("dotr", base64Format+encodedDotrContent);
			dataMap.put("border", base64Format+encodedBorderContent);	*/
			
			String serverPathName = configurationProperties.getServerAEMName();
			if(!serverPathName.endsWith("/")) {
				serverPathName = serverPathName+"/"; 
			}
			dataMap.put("logo", serverPathName+BookingEngineUtils.getPropertyEmailImageURL(EmailAssets.EMAIL_CONTENT_LOGO));
			dataMap.put("dot", serverPathName+BookingEngineUtils.getPropertyEmailImageURL(EmailAssets.EMAIL_CONTENT_DOT));
			dataMap.put("dotr", serverPathName+BookingEngineUtils.getPropertyEmailImageURL(EmailAssets.EMAIL_CONTENT_DOTR));
			dataMap.put("border", serverPathName+BookingEngineUtils.getPropertyEmailImageURL(EmailAssets.EMAIL_CONTENT_BORDER));
			
			triggerEmail(sender, recipient, null, bccMails, subject , null, emailTemplate, dataMap, attachmentList);
		} catch (BookingEngineException e) {
			logger.error("Exception occured while Sending mail for {}", e);
		}
		logger.info(" sendConfirmationMail : Leaving");
	}
	
	/**
	 *  Manager to trigger mail for the required recipients with/without attachment as per the need.
	 * 
	 * @param sender - sender mail address.
	 * @param to - Array of 'to' recipients.
	 * @param cc - Array of 'to' recipients.
	 * @param bcc - Array of 'to' recipients.
	 * @param subject - Subject for the mail.
	 * @param textBody - text/content body of the mail.
	 * @param templateAction - the template needs to formatted.
	 * @param data - data map for the mail template.
	 * @param attachments - list of attachments.
	 * @return the status of trigger mail.
	 * @throws BookingEngineException - For internal errors.
	 */
	public String triggerEmail(String sender, InternetAddress[] to, InternetAddress[] cc, InternetAddress[] bcc, 
				String subject, String textBody, TemplateAction templateAction, Map<String, Object> data, 
					List<AttachmentReqDTO> attachments) throws BookingEngineException {
		logger.info("EmailManager : triggerEmail : Entered ");
		MailRequestDTO request = createMailRequest(sender, to, cc, bcc, subject,textBody, templateAction, data, attachments);
		String response;
		try {
			response = emailUtil.prepareAndSend(request);
		} catch (BookingEngineException e) {
			logger.error("EmailManager : triggerEmail :  Exception occurred while sending Email. ");
			throw e;
		}
		logger.info("EmailUtil : triggerEmail : Leaving ");
		return response;
	}

	/**
	 * Creates the mail request.
	 *
	 * @param sender
	 *            the sender
	 * @param to
	 *            the to
	 * @param cc
	 *            the cc
	 * @param bcc
	 *            the bcc
	 * @param subject
	 *            the subject
	 * @param textBody
	 *            the text body
	 * @param templateAction
	 *            the template action
	 * @param data
	 *            the data
	 * @param attachments
	 *            the attachments
	 * @return the mail request DTO
	 */
	private MailRequestDTO createMailRequest(String sender, InternetAddress[] to, InternetAddress[] cc, InternetAddress[] bcc, 
			String subject, String textBody,TemplateAction templateAction, 
			Map<String, Object> data, List<AttachmentReqDTO> attachments) {
	logger.info("EmailManager : createMailRequest : Entered ");
	MailRequestDTO request = new MailRequestDTO();
	request.setTo(to);
	request.setCc(cc);
	request.setBcc(bcc);
	request.setSender(sender);
	request.setTemplateAction(templateAction);
	request.setData(data);
	request.setSubject(subject);
	request.setTextBody(textBody);
	if (!CollectionUtils.isEmpty(attachments)) {
		request.setAttachmentAvailable(true);
		request.setAttachments(attachments);
	}
	logger.info("EmailManager : createMailRequest : Leaving ");
	return request;
}

	/**
	 * Gets the recipient list.
	 *
	 * @param recipientList
	 *            the recipient list
	 * @return the recipient list
	 * @throws BookingEngineException
	 *             the booking engine exception
	 */
	public InternetAddress[] getInterAddrList(List<String> recipientList) throws BookingEngineException {
		InternetAddress addressTo[] = null;
		logger.info("EmailManager : getRecipientList : Entered ");
		try {
			// convert email address list to email address array format as
			// expected.
			if (!CollectionUtils.isEmpty(recipientList)) {
				addressTo = new InternetAddress[recipientList.size()];
				ListIterator<String> recipientsListIterator = recipientList.listIterator();
				int z = 0;
				while (recipientsListIterator.hasNext()) {

					addressTo[z++] = new javax.mail.internet.InternetAddress((String) recipientsListIterator.next());
				}
			}
		} catch (AddressException e) {
			logger.error("EmailManager : getRecipientList :  Exception occurred formatting recipient string list into Internet address list. ");
			throw new BookingEngineException(e);
		}
		logger.info("EmailManager : getRecipientList : Leaving ");
		return addressTo;
	}

	/**
	 * Gets the recipient list.
	 *
	 * @param recipient
	 *            the recipient
	 * @return the recipient list
	 * @throws BookingEngineException
	 *             the booking engine exception
	 */
	public InternetAddress[] getRecipientList(String recipient) throws BookingEngineException {
		logger.info("EmailManager : getRecipientList : Entered ");
		List<String> recipients = new ArrayList<>();
		recipients.add(recipient);
		InternetAddress[] recipientList = getInterAddrList(recipients);
		logger.info("EmailManager : getRecipientList : Leaving ");
		return recipientList;
	}
}
