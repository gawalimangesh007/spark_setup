package com.sterling.bookingapi.dto.maximojo.request;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class RequestorIDReqDTO.
 */
/**
 * @author tcs
 *
 */
public class RequestorIDReqDTO {

	/** The message password. */
	@JacksonXmlProperty(localName = "MessagePassword", isAttribute = true)
	 private String messagePassword;

	/** The id. */
	@JacksonXmlProperty(localName = "ID", isAttribute = true)
	 private String ID;

	/** The I D context. */
	@JacksonXmlProperty(localName = "ID_Context", isAttribute = true)
	 private String ID_Context;

	/**
	 * Gets the message password.
	 *
	 * @return the messagePassword
	 */
	public String getMessagePassword() {
		return messagePassword;
	}

	/**
	 * Sets the message password.
	 *
	 * @param messagePassword the messagePassword to set
	 */
	public void setMessagePassword(String messagePassword) {
		this.messagePassword = messagePassword;
	}

	/**
	 * Gets the id.
	 *
	 * @return the iD
	 */
	public String getID() {
		return ID;
	}

	/**
	 * Sets the id.
	 *
	 * @param iD the iD to set
	 */
	public void setID(String iD) {
		ID = iD;
	}

	/**
	 * Gets the i D context.
	 *
	 * @return the iD_Context
	 */
	public String getID_Context() {
		return ID_Context;
	}

	/**
	 * Sets the i D context.
	 *
	 * @param iD_Context the iD_Context to set
	 */
	public void setID_Context(String iD_Context) {
		ID_Context = iD_Context;
	}
	
	
}
