package com.sterling.bookingapi.dto.response;

public class VOProductsPlanResponseDTO extends BaseRecord {

	private static final long serialVersionUID = 1L;

	private String id;
	private String productId;
	private Integer annualChargesUnits;
	private Integer annualCharges1BR;
	private Integer annualCharges2BR;
	private Integer annualChargesStudio;
	private VOPrimaryIdResDTO roomMaster;
	private VOPrimaryIdResDTO seasonMaster;
	private String name;
	private Integer productCost;
	private Integer vOPoints;
	
	/**
	 * @return id
	 */
	public String getId() {
		return id;
	}
	/**
	 * @param id
	 * set the id
	 */
	public void setId(String id) {
		this.id = id;
	}
	/**
	 * @return productId
	 */
	public String getProductId() {
		return productId;
	}
	/**
	 * @param productId
	 * set the productId
	 */
	public void setProductId(String productId) {
		this.productId = productId;
	}
	/**
	 * @return annualChargesUnits
	 */
	public Integer getAnnualChargesUnits() {
		return annualChargesUnits;
	}
	/**
	 * @param annualChargesUnits
	 * set the annualChargesUnits
	 */
	public void setAnnualChargesUnits(Integer annualChargesUnits) {
		this.annualChargesUnits = annualChargesUnits;
	}
	/**
	 * @return annualCharges1BR
	 */
	public Integer getAnnualCharges1BR() {
		return annualCharges1BR;
	}
	/**
	 * @param annualCharges1BR
	 * set the annualCharges1BR
	 */
	public void setAnnualCharges1BR(Integer annualCharges1BR) {
		this.annualCharges1BR = annualCharges1BR;
	}
	/**
	 * @return annualCharges2BR
	 */
	public Integer getAnnualCharges2BR() {
		return annualCharges2BR;
	}
	/**
	 * @param annualCharges2BR
	 * set the annualCharges2BR
	 */
	public void setAnnualCharges2BR(Integer annualCharges2BR) {
		this.annualCharges2BR = annualCharges2BR;
	}
	/**
	 * @return annualChargesStudio
	 */
	public Integer getAnnualChargesStudio() {
		return annualChargesStudio;
	}
	/**
	 * @param annualChargesStudio
	 * set the annualChargesStudio
	 */
	public void setAnnualChargesStudio(Integer annualChargesStudio) {
		this.annualChargesStudio = annualChargesStudio;
	}
	/**
	 * @return roomMaster
	 */
	public VOPrimaryIdResDTO getRoomMaster() {
		return roomMaster;
	}
	/**
	 * @param roomMaster
	 * set the roomMaster
	 */
	public void setRoomMaster(VOPrimaryIdResDTO roomMaster) {
		this.roomMaster = roomMaster;
	}
	/**
	 * @return seasonMaster
	 */
	public VOPrimaryIdResDTO getSeasonMaster() {
		return seasonMaster;
	}
	/**
	 * @param seasonMaster
	 * set the seasonMaster
	 */
	public void setSeasonMaster(VOPrimaryIdResDTO seasonMaster) {
		this.seasonMaster = seasonMaster;
	}
	/**
	 * @return name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name
	 * set the name
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return productCost
	 */
	public Integer getProductCost() {
		return productCost;
	}
	/**
	 * @param productCost
	 * set the productCost
	 */
	public void setProductCost(Integer productCost) {
		this.productCost = productCost;
	}
	/**
	 * @return vOPoints
	 */
	public Integer getvOPoints() {
		return vOPoints;
	}
	/**
	 * @param vOPoints
	 * set the vOPoints
	 */
	public void setvOPoints(Integer vOPoints) {
		this.vOPoints = vOPoints;
	}

}
