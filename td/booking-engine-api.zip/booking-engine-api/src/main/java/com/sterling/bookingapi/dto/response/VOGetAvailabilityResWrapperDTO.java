package com.sterling.bookingapi.dto.response;

import java.io.Serializable;
import java.util.List;


/**
 * @author tcs
 * @version 1.0
 */
public class VOGetAvailabilityResWrapperDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private VOGetAvailabilityResponseDTO primaryResort;
	private VOGetAvailabilityResponseDTO suggestedResort;
	private List<VOUnitProductPointMatrixResDTO> unitProductPointMatrix;
	
	public VOGetAvailabilityResponseDTO getPrimaryResort() {
		return primaryResort;
	}
	public void setPrimaryResort(VOGetAvailabilityResponseDTO primaryResort) {
		this.primaryResort = primaryResort;
	}
	public VOGetAvailabilityResponseDTO getSuggestedResort() {
		return suggestedResort;
	}
	public void setSuggestedResort(VOGetAvailabilityResponseDTO suggestedResort) {
		this.suggestedResort = suggestedResort;
	}
	public List<VOUnitProductPointMatrixResDTO> getUnitProductPointMatrix() {
		return unitProductPointMatrix;
	}
	public void setUnitProductPointMatrix(
			List<VOUnitProductPointMatrixResDTO> unitProductPointMatrix) {
		this.unitProductPointMatrix = unitProductPointMatrix;
	}
}
