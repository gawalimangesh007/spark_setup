package com.sterling.bookingapi.dto.response;

import java.io.Serializable;

public class VOLeadProduct implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String webProductCode;
	private String webSeasonCode;
	private String webRoomType;
	private Double webProductCost;
	private Double webProductPoints;
	private String webProductPlanId;
	private String webProductPlanName;
	
	
	public String getWebProductPlanName() {
		return webProductPlanName;
	}
	public void setWebProductPlanName(String webProductPlanName) {
		this.webProductPlanName = webProductPlanName;
	}
	public String getWebProductCode() {
		return webProductCode;
	}
	public void setWebProductCode(String webProductCode) {
		this.webProductCode = webProductCode;
	}
	public String getWebSeasonCode() {
		return webSeasonCode;
	}
	public void setWebSeasonCode(String webSeasonCode) {
		this.webSeasonCode = webSeasonCode;
	}
	public String getWebRoomType() {
		return webRoomType;
	}
	public void setWebRoomType(String webRoomType) {
		this.webRoomType = webRoomType;
	}
	public Double getWebProductCost() {
		return webProductCost;
	}
	public void setWebProductCost(Double webProductCost) {
		this.webProductCost = webProductCost;
	}
	public Double getWebProductPoints() {
		return webProductPoints;
	}
	public void setWebProductPoints(Double webProductPoints) {
		this.webProductPoints = webProductPoints;
	}
	public String getWebProductPlanId() {
		return webProductPlanId;
	}
	public void setWebProductPlanId(String webProductPlanId) {
		this.webProductPlanId = webProductPlanId;
	}

}
