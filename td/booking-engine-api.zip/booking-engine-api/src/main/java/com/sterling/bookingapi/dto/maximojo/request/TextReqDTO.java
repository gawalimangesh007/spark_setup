package com.sterling.bookingapi.dto.maximojo.request;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlText;


/**
 * The Class TextReqDTO.
 */
/**
 * @author tcs
 *
 */
public class TextReqDTO {

	/** The text. */
	@JacksonXmlText
	private String text;

	/**
	 * Gets the text.
	 *
	 * @return the text
	 */
	public String getText() {
		return text;
	}

	/**
	 * Sets the text.
	 *
	 * @param text the new text
	 */
	public void setText(String text) {
		this.text = text;
	}
	
	
}
