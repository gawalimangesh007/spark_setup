package com.sterling.bookingapi.dto.request;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author tcs
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class VOBookingEnhancementDetailReq implements Serializable {

	private static final long serialVersionUID = 1L;

	private String enhancementType;
	private String enhancementDesc;
	private Double enhancementAmount;
	private Integer enhancementQuantity;
	private Double taxCGSTPercent;
	private Double taxSGSTPercent;
	private Double taxIGSTPercent;
	private Double totalTaxGSTPercent;
	private Double taxAmountCGST;
	private Double taxAmountSGST;
	private Double taxAmountIGST;
	private Double taxamountGST;
	private String enhancementName;
	private String acrossPaxFlag;

	
	public String getEnhancementName() {
		return enhancementName;
	}
	public void setEnhancementName(String enhancementName) {
		this.enhancementName = enhancementName;
	}
	/** 
	 * @return enhanceType
	 */
	public String getEnhancementType() {
		return enhancementType;
	}
	/**
	 * @param enhancementType
	 * set the enhancementtype
	 */
	public void setEnhancementType(String enhancementType) {
		this.enhancementType = enhancementType;
	}
	/**
	 * @return enhancement description
	 */
	public String getEnhancementDesc() {
		return enhancementDesc;
	}
	/**
	 * @param enhancementDesc
	 * set the enhancement description
	 */
	public void setEnhancementDesc(String enhancementDesc) {
		this.enhancementDesc = enhancementDesc;
	}
	public Double getEnhancementAmount() {
		return enhancementAmount;
	}
	public void setEnhancementAmount(Double enhancementAmount) {
		this.enhancementAmount = enhancementAmount;
	}
	public Integer getEnhancementQuantity() {
		return enhancementQuantity;
	}
	public void setEnhancementQuantity(Integer enhancementQuantity) {
		this.enhancementQuantity = enhancementQuantity;
	}
	public Double getTaxCGSTPercent() {
		return taxCGSTPercent;
	}
	public void setTaxCGSTPercent(Double taxCGSTPercent) {
		this.taxCGSTPercent = taxCGSTPercent;
	}
	public Double getTaxSGSTPercent() {
		return taxSGSTPercent;
	}
	public void setTaxSGSTPercent(Double taxSGSTPercent) {
		this.taxSGSTPercent = taxSGSTPercent;
	}
	public Double getTaxIGSTPercent() {
		return taxIGSTPercent;
	}
	public void setTaxIGSTPercent(Double taxIGSTPercent) {
		this.taxIGSTPercent = taxIGSTPercent;
	}
	public Double getTotalTaxGSTPercent() {
		return totalTaxGSTPercent;
	}
	public void setTotalTaxGSTPercent(Double totalTaxGSTPercent) {
		this.totalTaxGSTPercent = totalTaxGSTPercent;
	}
	public Double getTaxAmountCGST() {
		return taxAmountCGST;
	}
	public void setTaxAmountCGST(Double taxAmountCGST) {
		this.taxAmountCGST = taxAmountCGST;
	}
	public Double getTaxAmountSGST() {
		return taxAmountSGST;
	}
	public void setTaxAmountSGST(Double taxAmountSGST) {
		this.taxAmountSGST = taxAmountSGST;
	}
	public Double getTaxAmountIGST() {
		return taxAmountIGST;
	}
	public void setTaxAmountIGST(Double taxAmountIGST) {
		this.taxAmountIGST = taxAmountIGST;
	}
	public Double getTaxamountGST() {
		return taxamountGST;
	}
	public void setTaxamountGST(Double taxamountGST) {
		this.taxamountGST = taxamountGST;
	}
	/**
	 * @return the acrossPaxFlag
	 */
	public String getAcrossPaxFlag() {
		return acrossPaxFlag;
	}
	/**
	 * @param acrossPaxFlag the acrossPaxFlag to set
	 */
	public void setAcrossPaxFlag(String acrossPaxFlag) {
		this.acrossPaxFlag = acrossPaxFlag;
	}
		
}
