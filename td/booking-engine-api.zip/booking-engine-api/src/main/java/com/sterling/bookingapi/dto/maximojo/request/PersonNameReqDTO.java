package com.sterling.bookingapi.dto.maximojo.request;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class PersonNameReqDTO.
 */
/**
 * @author tcs
 *
 */
public class PersonNameReqDTO {
	
	/** The given name. */
	@JacksonXmlProperty(localName = "GivenName")
	private GivenNameReqDTO givenName;
	
	/** The sur name. */
	@JacksonXmlProperty(localName = "SurName")
	private SurNameReqDTO surName;

	/**
	 * Gets the given name.
	 *
	 * @return the given name
	 */
	public GivenNameReqDTO getGivenName() {
		return givenName;
	}

	/**
	 * Sets the given name.
	 *
	 * @param givenName the new given name
	 */
	public void setGivenName(GivenNameReqDTO givenName) {
		this.givenName = givenName;
	}

	/**
	 * Gets the sur name.
	 *
	 * @return the sur name
	 */
	public SurNameReqDTO getSurName() {
		return surName;
	}

	/**
	 * Sets the sur name.
	 *
	 * @param surName the new sur name
	 */
	public void setSurName(SurNameReqDTO surName) {
		this.surName = surName;
	}
	
	
}
