package com.sterling.bookingapi.dto.response;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


/**
 * The Class ConfirmedBookingDTO.
 *  @author tcs
 *
 */

@JsonIgnoreProperties(ignoreUnknown = true)
public class DTCBookingResponseDTO implements Serializable {
	
	
	private static final long serialVersionUID = 1L;
	
	
	private String cvNumber;
	
	private String guestName;
	
	private String checkInDate;

	private String checkOutDate;
	
	private String totalNoOfRoomsBooked;
	
	private Double bookingPoints;
	
	private String reservationType;
	
	private String travelingType;
	
	private String resortName;
	
	private String typeOfRooms;
	
	private String personName;
	
	private List<String> personTraveling;
	
	public String getCvNumber() {
		return cvNumber;
	}

	public void setCvNumber(String cvNumber) {
		this.cvNumber = cvNumber;
	}

	public String getGuestName() {
		return guestName;
	}

	public void setGuestName(String guestName) {
		this.guestName = guestName;
	}

	public String getCheckInDate() {
		return checkInDate;
	}

	public void setCheckInDate(String checkInDate) {
		this.checkInDate = checkInDate;
	}

	public String getCheckOutDate() {
		return checkOutDate;
	}

	public void setCheckOutDate(String checkOutDate) {
		this.checkOutDate = checkOutDate;
	}

	public String getTotalNoOfRoomsBooked() {
		return totalNoOfRoomsBooked;
	}

	public void setTotalNoOfRoomsBooked(String totalNoOfRoomsBooked) {
		this.totalNoOfRoomsBooked = totalNoOfRoomsBooked;
	}

	public Double getBookingPoints() {
		return bookingPoints;
	}

	public void setBookingPoints(Double bookingPoints) {
		this.bookingPoints = bookingPoints;
	}

	public String getReservationType() {
		return reservationType;
	}

	public void setReservationType(String reservationType) {
		this.reservationType = reservationType;
	}

	public String getTravelingType() {
		return travelingType;
	}

	public void setTravelingType(String travelingType) {
		this.travelingType = travelingType;
	}

	public String getResortName() {
		return resortName;
	}

	public void setResortName(String resortName) {
		this.resortName = resortName;
	}

	public String getTypeOfRooms() {
		return typeOfRooms;
	}

	public void setTypeOfRooms(String typeOfRooms) {
		this.typeOfRooms = typeOfRooms;
	}

	public String getPersonName() {
		return personName;
	}

	public void setPersonName(String personName) {
		this.personName = personName;
	}

	public List<String> getPersonTraveling() {
		return personTraveling;
	}

	public void setPersonTraveling(List<String> personTraveling) {
		this.personTraveling = personTraveling;
	}
}