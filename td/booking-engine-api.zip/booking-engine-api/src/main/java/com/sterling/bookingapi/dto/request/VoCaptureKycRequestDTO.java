package com.sterling.bookingapi.dto.request;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


/**
 * The Class HsdBookingOfferDetailsDTO.
 */
/**
 * @author tcs
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class VoCaptureKycRequestDTO implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String saleId;
	private String firstName;
	private String lastName;
	private String gender;
	private String maritalStatus;
	private String email;
	private String mobileNo;
	private String dob;
	private String homeAddressLine1;
	private String homeAddressLine2;
	private String homePinCode;
	private String homeCity;
	private String homeState;
	private String homeCountry;
	private String officeAddressLine1;
	private String officeAddressLine2;
	private String officePinCode;
	private String officeCity;
	private String officeState;
	private String officeCountry;
	private String bankAccNo;
	private String bankIfscCode;
	private String bankName;
	private String bankCity;
	private String bankAddress;
	private String accountType;
	private String idProofName;
	private String idProofNumber;
	private String additionalIdProofName;
	private String additionalIdProofNumber;
	private String kycStatus;
	private List<VoKycDependentRequestDTO> dependentDetails;
	
	private String idProofLocation1;
	private String idProofLocation2;
	
	private Boolean saveFlag;
	private String kycMode;
	
	public String getIdProofLocation1() {
		return idProofLocation1;
	}
	public void setIdProofLocation1(String idProofLocation1) {
		this.idProofLocation1 = idProofLocation1;
	}
	public String getIdProofLocation2() {
		return idProofLocation2;
	}
	public void setIdProofLocation2(String idProofLocation2) {
		this.idProofLocation2 = idProofLocation2;
	}
	public Boolean getSaveFlag() {
		return saveFlag;
	}
	public void setSaveFlag(Boolean saveFlag) {
		this.saveFlag = saveFlag;
	}
	public String getKycMode() {
		return kycMode;
	}
	public void setKycMode(String kycMode) {
		this.kycMode = kycMode;
	}
	public String getSaleId() {
		return saleId;
	}
	public void setSaleId(String saleId) {
		this.saleId = saleId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getMaritalStatus() {
		return maritalStatus;
	}
	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getHomeAddressLine1() {
		return homeAddressLine1;
	}
	public void setHomeAddressLine1(String homeAddressLine1) {
		this.homeAddressLine1 = homeAddressLine1;
	}
	public String getHomeAddressLine2() {
		return homeAddressLine2;
	}
	public void setHomeAddressLine2(String homeAddressLine2) {
		this.homeAddressLine2 = homeAddressLine2;
	}
	public String getHomePinCode() {
		return homePinCode;
	}
	public void setHomePinCode(String homePinCode) {
		this.homePinCode = homePinCode;
	}
	public String getHomeCity() {
		return homeCity;
	}
	public void setHomeCity(String homeCity) {
		this.homeCity = homeCity;
	}
	public String getHomeState() {
		return homeState;
	}
	public void setHomeState(String homeState) {
		this.homeState = homeState;
	}
	public String getHomeCountry() {
		return homeCountry;
	}
	public void setHomeCountry(String homeCountry) {
		this.homeCountry = homeCountry;
	}
	public String getOfficeAddressLine1() {
		return officeAddressLine1;
	}
	public void setOfficeAddressLine1(String officeAddressLine1) {
		this.officeAddressLine1 = officeAddressLine1;
	}
	public String getOfficeAddressLine2() {
		return officeAddressLine2;
	}
	public void setOfficeAddressLine2(String officeAddressLine2) {
		this.officeAddressLine2 = officeAddressLine2;
	}
	public String getOfficePinCode() {
		return officePinCode;
	}
	public void setOfficePinCode(String officePinCode) {
		this.officePinCode = officePinCode;
	}
	public String getOfficeCity() {
		return officeCity;
	}
	public void setOfficeCity(String officeCity) {
		this.officeCity = officeCity;
	}
	public String getOfficeState() {
		return officeState;
	}
	public void setOfficeState(String officeState) {
		this.officeState = officeState;
	}
	public String getOfficeCountry() {
		return officeCountry;
	}
	public void setOfficeCountry(String officeCountry) {
		this.officeCountry = officeCountry;
	}
	public String getBankAccNo() {
		return bankAccNo;
	}
	public void setBankAccNo(String bankAccNo) {
		this.bankAccNo = bankAccNo;
	}
	public String getBankIfscCode() {
		return bankIfscCode;
	}
	public void setBankIfscCode(String bankIfscCode) {
		this.bankIfscCode = bankIfscCode;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getBankCity() {
		return bankCity;
	}
	public void setBankCity(String bankCity) {
		this.bankCity = bankCity;
	}
	public String getBankAddress() {
		return bankAddress;
	}
	public void setBankAddress(String bankAddress) {
		this.bankAddress = bankAddress;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getIdProofName() {
		return idProofName;
	}
	public void setIdProofName(String idProofName) {
		this.idProofName = idProofName;
	}
	public String getIdProofNumber() {
		return idProofNumber;
	}
	public void setIdProofNumber(String idProofNumber) {
		this.idProofNumber = idProofNumber;
	}
	public String getAdditionalIdProofName() {
		return additionalIdProofName;
	}
	public void setAdditionalIdProofName(String additionalIdProofName) {
		this.additionalIdProofName = additionalIdProofName;
	}
	public String getAdditionalIdProofNumber() {
		return additionalIdProofNumber;
	}
	public void setAdditionalIdProofNumber(String additionalIdProofNumber) {
		this.additionalIdProofNumber = additionalIdProofNumber;
	}
	public String getKycStatus() {
		return kycStatus;
	}
	public void setKycStatus(String kycStatus) {
		this.kycStatus = kycStatus;
	}
	public List<VoKycDependentRequestDTO> getDependentDetails() {
		return dependentDetails;
	}
	public void setDependentDetails(List<VoKycDependentRequestDTO> dependentDetails) {
		this.dependentDetails = dependentDetails;
	}
	
}