package com.sterling.bookingapi.dto.maximojo.response;

import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;


/**
 * The Class ResRetrieveResDTO.
 * @author tcs
 * @version 1.0
 */
@JacksonXmlRootElement(localName = "OTA_ResRetrieveRS")
public class ResRetrieveResDTO {

	/** The Hotel reservation. */
	@JacksonXmlElementWrapper(useWrapping=true, localName = "ReservationsList")
	@JacksonXmlProperty(localName = "HotelReservation")
	private List<HotelReservationResDTO> HotelReservation;

	/** The xmlns. */
	@JacksonXmlProperty(localName = "xmlns", isAttribute = true)
    private String xmlns;

	/** The version. */
	@JacksonXmlProperty(localName = "Version", isAttribute = true)
    private String version;

	/** The success. */
	@JacksonXmlProperty(localName = "Success", isAttribute = true)
    private String success;

	/**
	 * Gets the hotel reservation.
	 *
	 * @return the hotelReservation
	 */
	public List<HotelReservationResDTO> getHotelReservation() {
		return HotelReservation;
	}

	/**
	 * Sets the hotel reservation.
	 *
	 * @param hotelReservation the hotelReservation to set
	 */
	public void setHotelReservation(List<HotelReservationResDTO> hotelReservation) {
		HotelReservation = hotelReservation;
	}

	/**
	 * Gets the xmlns.
	 *
	 * @return the xmlns
	 */
	public String getXmlns() {
		return xmlns;
	}

	/**
	 * Sets the xmlns.
	 *
	 * @param xmlns the xmlns to set
	 */
	public void setXmlns(String xmlns) {
		this.xmlns = xmlns;
	}

	/**
	 * Gets the version.
	 *
	 * @return the version
	 */
	public String getVersion() {
		return version;
	}

	/**
	 * Sets the version.
	 *
	 * @param version the version to set
	 */
	public void setVersion(String version) {
		this.version = version;
	}

	/**
	 * Gets the success.
	 *
	 * @return the success
	 */
	public String getSuccess() {
		return success;
	}

	/**
	 * Sets the success.
	 *
	 * @param success the success to set
	 */
	public void setSuccess(String success) {
		this.success = success;
	}
	
	
}
