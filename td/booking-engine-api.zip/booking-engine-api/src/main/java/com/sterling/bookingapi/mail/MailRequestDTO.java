package com.sterling.bookingapi.mail;

import java.util.List;
import java.util.Map;

import javax.mail.internet.InternetAddress;

import com.sterling.bookingapi.utils.AppConstants.TemplateAction;

/**
 * The Class MailRequestDTO.
 */
/**
 * @author tcs
 * @version 1.0
 *
 */
public class MailRequestDTO {

	/** The sender. */
	private String sender;

	/** The to. */
	private InternetAddress[] to;

	/** The cc. */
	private InternetAddress[] cc;

	/** The bcc. */
	private InternetAddress[] bcc;

	/** The subject. */
	private String subject;
	
	/**
	 * Textbody has higher preference comparing to template action and data.
	 */
	private String textBody;

	/** The template action. */
	private TemplateAction templateAction;
	
	/** The data. */
	private Map<String, Object> data;
	
	
	/** The is attachment available. */
	private boolean isAttachmentAvailable;
	
	/** The attachments. */
	private List<AttachmentReqDTO> attachments;

	
	/**
	 * Gets the to.
	 *
	 * @return the to
	 */
	public InternetAddress[] getTo() {
		return to;
	}

	/**
	 * Sets the to.
	 *
	 * @param to
	 *            the new to
	 */
	public void setTo(InternetAddress[] to) {
		this.to = to;
	}

	/**
	 * Gets the cc.
	 *
	 * @return the cc
	 */
	public InternetAddress[] getCc() {
		return cc;
	}

	/**
	 * Sets the cc.
	 *
	 * @param cc
	 *            the new cc
	 */
	public void setCc(InternetAddress[] cc) {
		this.cc = cc;
	}

	/**
	 * Gets the bcc.
	 *
	 * @return the bcc
	 */
	public InternetAddress[] getBcc() {
		return bcc;
	}

	/**
	 * Sets the bcc.
	 *
	 * @param bcc
	 *            the new bcc
	 */
	public void setBcc(InternetAddress[] bcc) {
		this.bcc = bcc;
	}

	/**
	 * Gets the subject.
	 *
	 * @return the subject
	 */
	public String getSubject() {
		return subject;
	}

	/**
	 * Sets the subject.
	 *
	 * @param subject
	 *            the new subject
	 */
	public void setSubject(String subject) {
		this.subject = subject;
	}

	/**
	 * Gets the template action.
	 *
	 * @return the template action
	 */
	public TemplateAction getTemplateAction() {
		return templateAction;
	}

	/**
	 * Sets the template action.
	 *
	 * @param templateAction
	 *            the new template action
	 */
	public void setTemplateAction(TemplateAction templateAction) {
		this.templateAction = templateAction;
	}

	/**
	 * Gets the data.
	 *
	 * @return the data
	 */
	public Map<String, Object> getData() {
		return data;
	}

	/**
	 * Sets the data.
	 *
	 * @param data
	 *            the data
	 */
	public void setData(Map<String, Object> data) {
		this.data = data;
	}

	/**
	 * Gets the text body.
	 *
	 * @return the text body
	 */
	public String getTextBody() {
		return textBody;
	}

	/**
	 * Sets the text body.
	 *
	 * @param textBody
	 *            the new text body
	 */
	public void setTextBody(String textBody) {
		this.textBody = textBody;
	}

	/**
	 * Checks if is attachment available.
	 *
	 * @return true, if is attachment available
	 */
	public boolean isAttachmentAvailable() {
		return isAttachmentAvailable;
	}

	/**
	 * Sets the attachment available.
	 *
	 * @param isAttachmentAvailable
	 *            the new attachment available
	 */
	public void setAttachmentAvailable(boolean isAttachmentAvailable) {
		this.isAttachmentAvailable = isAttachmentAvailable;
	}

	/**
	 * Gets the attachments.
	 *
	 * @return the attachments
	 */
	public List<AttachmentReqDTO> getAttachments() {
		return attachments;
	}

	/**
	 * Sets the attachments.
	 *
	 * @param attachments
	 *            the new attachments
	 */
	public void setAttachments(List<AttachmentReqDTO> attachments) {
		this.attachments = attachments;
	}

	/**
	 * Gets the sender.
	 *
	 * @return the sender
	 */
	public String getSender() {
		return sender;
	}

	/**
	 * Sets the sender.
	 *
	 * @param sender
	 *            the new sender
	 */
	public void setSender(String sender) {
		this.sender = sender;
	}
	
}
