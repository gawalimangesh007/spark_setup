package com.sterling.bookingapi.dto;


public class FileUploadDTO {

	private String fileName;
	private String uploadingFiles;
	private String user;
	private String contractId;
	private String contactEmail;

	public String getFileName() {
		return fileName;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getUploadingFiles() {
		return uploadingFiles;
	}
	public void setUploadingFiles(String uploadingFiles) {
		this.uploadingFiles = uploadingFiles;
	}
	public String getContractId() {
		return contractId;
	}
	public void setContractId(String contractId) {
		this.contractId = contractId;
	}
	public String getContactEmail() {
		return contactEmail;
	}
	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}
	
}
