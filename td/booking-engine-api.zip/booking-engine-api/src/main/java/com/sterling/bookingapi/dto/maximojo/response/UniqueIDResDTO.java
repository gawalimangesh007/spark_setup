package com.sterling.bookingapi.dto.maximojo.response;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class UniqueIDResDTO.
 * @author tcs
 * @version 1.0
 */
public class UniqueIDResDTO {

	/** The type. */
	@JacksonXmlProperty(localName = "Type", isAttribute = true)
	private String type;

	/** The id. */
	@JacksonXmlProperty(localName = "ID", isAttribute = true)
    private String ID;

	/**
	 * Gets the type.
	 *
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * Sets the type.
	 *
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * Gets the id.
	 *
	 * @return the iD
	 */
	public String getID() {
		return ID;
	}

	/**
	 * Sets the id.
	 *
	 * @param iD the iD to set
	 */
	public void setID(String iD) {
		ID = iD;
	}
	
	
}
