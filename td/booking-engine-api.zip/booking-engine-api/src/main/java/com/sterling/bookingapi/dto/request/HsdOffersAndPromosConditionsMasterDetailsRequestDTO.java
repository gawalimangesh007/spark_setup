package com.sterling.bookingapi.dto.request;



/**
 * The Class HsdOffersAndPromosConditionsMasterDetailsRequestDTO.
 */
/**
 * @author tcs
 *
 */
public class HsdOffersAndPromosConditionsMasterDetailsRequestDTO {

	/** The condition master id. */
	private String conditionMasterId;
	
	/** The condition code. */
	private String conditionCode;
	
	/** The condition name. */
	private String conditionName;
	
	/** The condition data type. */
	private String conditionDataType;
	
	/**
	 * Gets the condition master id.
	 *
	 * @return the conditionMasterId
	 */
	public String getConditionMasterId() {
		return conditionMasterId;
	}
	
	/**
	 * Sets the condition master id.
	 *
	 * @param conditionMasterId the conditionMasterId to set
	 */
	public void setConditionMasterId(String conditionMasterId) {
		this.conditionMasterId = conditionMasterId;
	}
	
	/**
	 * Gets the condition code.
	 *
	 * @return the conditionCode
	 */
	public String getConditionCode() {
		return conditionCode;
	}
	
	/**
	 * Sets the condition code.
	 *
	 * @param conditionCode the conditionCode to set
	 */
	public void setConditionCode(String conditionCode) {
		this.conditionCode = conditionCode;
	}
	
	/**
	 * Gets the condition name.
	 *
	 * @return the conditionName
	 */
	public String getConditionName() {
		return conditionName;
	}
	
	/**
	 * Sets the condition name.
	 *
	 * @param conditionName the conditionName to set
	 */
	public void setConditionName(String conditionName) {
		this.conditionName = conditionName;
	}
	
	/**
	 * Gets the condition data type.
	 *
	 * @return the conditionDataType
	 */
	public String getConditionDataType() {
		return conditionDataType;
	}
	
	/**
	 * Sets the condition data type.
	 *
	 * @param conditionDataType the conditionDataType to set
	 */
	public void setConditionDataType(String conditionDataType) {
		this.conditionDataType = conditionDataType;
	}
	
	
}
