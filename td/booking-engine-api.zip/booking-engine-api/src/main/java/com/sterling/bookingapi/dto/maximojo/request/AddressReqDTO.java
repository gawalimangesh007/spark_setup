package com.sterling.bookingapi.dto.maximojo.request;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class AddressReqDTO.
 */
/**
 * @author tcs
 *
 */
public class AddressReqDTO {

	/** The type. */
	@JacksonXmlProperty(localName = "Type", isAttribute = true)
    private int type;

    /** The address line. */
    @JacksonXmlProperty(localName = "AddressLine", isAttribute = true)
    private AddressLineReqDTO addressLine;

    /** The city name. */
    @JacksonXmlProperty(localName = "CityName", isAttribute = true)
    private CityNameReqDTO cityName;
    
    /** The postal code. */
    @JacksonXmlProperty(localName = "PostalCode")
    private PostalCodeReqDTO postalCode;
    
    /** The state prov. */
    @JacksonXmlProperty(localName = "StateProv")
    private StateProvReqDTO stateProv;
    
    /** The country name. */
    @JacksonXmlProperty(localName = "CountryName")
	private CountryNameReqDTO countryName;
    
	/**
	 * Gets the country name.
	 *
	 * @return the country name
	 */
	public CountryNameReqDTO getCountryName() {
		return countryName;
	}

	/**
	 * Sets the country name.
	 *
	 * @param countryName the new country name
	 */
	public void setCountryName(CountryNameReqDTO countryName) {
		this.countryName = countryName;
	}

	/**
	 * Gets the postal code.
	 *
	 * @return the postal code
	 */
	public PostalCodeReqDTO getPostalCode() {
		return postalCode;
	}

	/**
	 * Sets the postal code.
	 *
	 * @param postalCode the new postal code
	 */
	public void setPostalCode(PostalCodeReqDTO postalCode) {
		this.postalCode = postalCode;
	}

	/**
	 * Gets the state prov.
	 *
	 * @return the state prov
	 */
	public StateProvReqDTO getStateProv() {
		return stateProv;
	}

	/**
	 * Sets the state prov.
	 *
	 * @param stateProv the new state prov
	 */
	public void setStateProv(StateProvReqDTO stateProv) {
		this.stateProv = stateProv;
	}

	/**
	 * Gets the type.
	 *
	 * @return the type
	 */
	public int getType() {
		return type;
	}

	/**
	 * Sets the type.
	 *
	 * @param type the new type
	 */
	public void setType(int type) {
		this.type = type;
	}

	/**
	 * Gets the city name.
	 *
	 * @return the city name
	 */
	public CityNameReqDTO getCityName() {
		return cityName;
	}

	/**
	 * Sets the city name.
	 *
	 * @param cityName the new city name
	 */
	public void setCityName(CityNameReqDTO cityName) {
		this.cityName = cityName;
	}

	/**
	 * Gets the address line.
	 *
	 * @return the address line
	 */
	public AddressLineReqDTO getAddressLine() {
		return addressLine;
	}

	/**
	 * Sets the address line.
	 *
	 * @param addressLine the new address line
	 */
	public void setAddressLine(AddressLineReqDTO addressLine) {
		this.addressLine = addressLine;
	}

	
}
