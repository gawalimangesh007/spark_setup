package com.sterling.bookingapi.dto.response;

public class OTPResponseDTO {
	
	private static final long serialVersionUID = 1L;

	private String uniqueId;
	private String userType;
	
	
	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}
	
	public OTPResponseDTO(String uniqueId) {
		super();
		this.uniqueId = uniqueId;
	}

	public String getUniqueId() {
		return uniqueId;
	}

	public void setUniqueId(String uniqueId) {
		this.uniqueId = uniqueId;
	}
	
}
