package com.sterling.bookingapi.auth.bean;

import java.util.UUID;

import org.springframework.security.core.AuthenticationException;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;

/**
 * @author tcs
 *
 */
@JsonAutoDetect(fieldVisibility = Visibility.PROTECTED_AND_PUBLIC, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
public class SterlingAuthException extends AuthenticationException {
	private static final long serialVersionUID = -3073888833289428868L;
	
	private String exceptionId;
	private String token;
	private String description;
	private Throwable t;
	private Object data;
	
	public SterlingAuthException(String description){
		super(description);
		this.description = description;
		this.exceptionId = UUID.randomUUID().toString();
		this.t = null;
		this.token = null;
	}
	
	public SterlingAuthException(String description, Throwable t){
		super(description, t);
		this.description = description;
		this.exceptionId = UUID.randomUUID().toString();
		this.t = t;
		this.token = null;
	}
	
	public SterlingAuthException(String msg, String errorCode, Object data){
		super(msg);
		this.description = msg;
		this.exceptionId = errorCode;
		this.data = data;
	}
	
	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	/**
	 * @return exceptionId
	 */
	public String getExceptionId() {
		return exceptionId;
	}
	/**
	 * @return token
	 */
	public String getToken() {
		return token;
	}
	/**
	 * @return description
	 */
	public String getDescription() {
		return description;
	}
	public Throwable getT() {
		return t;
	}

	@Override
	public String toString() {
		return "TokenException [token=" + token + ", description=" + description + "]";
	}
	
}
