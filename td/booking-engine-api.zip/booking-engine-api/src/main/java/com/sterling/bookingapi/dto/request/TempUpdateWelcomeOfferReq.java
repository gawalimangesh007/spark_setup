package com.sterling.bookingapi.dto.request;

import java.io.Serializable;

import javax.validation.constraints.NotEmpty;

import com.sterling.bookingapi.dto.response.BaseRecord;

/**
 * @author tcs
 *
 */
public class TempUpdateWelcomeOfferReq extends BaseRecord implements Serializable{
	
	private static final long serialVersionUID = 1L;
	@NotEmpty(message = "Contract id should not be empty")
	private String contractId;
	@NotEmpty(message = "Email id should not be empty")
	private String emailId;
	private String checkoutDate;
	private String checkinDate;
	private Boolean isWelcomeOfferUsed;
	
	/**
	 * @return contract id
	 */
	public String getContractId() {
		return contractId;
	}
	/**
	 * @param contractId
	 * set the contractId
	 */
	public void setContractId(String contractId) {
		this.contractId = contractId;
	}
	/**
	 * @return emailid
	 */
	public String getEmailId() {
		return emailId;
	}
	/**
	 * @param emailId
	 * set the emailId
	 */
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	/**
	 * @return checkoutdate
	 */
	public String getCheckoutDate() {
		return checkoutDate;
	}
	/**
	 * @param checkoutDate
	 * set the checkoutDate
	 */
	public void setCheckoutDate(String checkoutDate) {
		this.checkoutDate = checkoutDate;
	}
	/**
	 * @return checkindate
	 */
	public String getCheckinDate() {
		return checkinDate;
	}
	/**
	 * @param checkinDate
	 *  set the checkinDate
	 */
	public void setCheckinDate(String checkinDate) {
		this.checkinDate = checkinDate;
	}
	/**
	 * @return welcomeofferused
	 */
	public Boolean getIsWelcomeOfferUsed() {
		return isWelcomeOfferUsed;
	}
	/**
	 * @param isWelcomeOfferUsed
	 * set the welcome offer
	 */
	public void setIsWelcomeOfferUsed(Boolean isWelcomeOfferUsed) {
		this.isWelcomeOfferUsed = isWelcomeOfferUsed;
	}

}
