package com.sterling.bookingapi.dto.maximojo.request;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class TelephoneReqDTO.
 */
/**
 * @author tcs
 *
 */
public class TelephoneReqDTO {

	/** The default ind. */
	@JacksonXmlProperty(localName = "DefaultInd", isAttribute = true)
    private boolean defaultInd;
	
	/** The formatted ind. */
	@JacksonXmlProperty(localName = "FormattedInd", isAttribute = true)
	private boolean formattedInd;

	/** The phone number. */
	@JacksonXmlProperty(localName = "PhoneNumber", isAttribute = true)
    private String phoneNumber;

	/**
	 * Checks if is formatted ind.
	 *
	 * @return the formattedInd
	 */
	public boolean isFormattedInd() {
		return formattedInd;
	}

	/**
	 * Sets the formatted ind.
	 *
	 * @param formattedInd the formattedInd to set
	 */
	public void setFormattedInd(boolean formattedInd) {
		this.formattedInd = formattedInd;
	}

	/**
	 * Checks if is default ind.
	 *
	 * @return the defaultInd
	 */
	public boolean isDefaultInd() {
		return defaultInd;
	}

	/**
	 * Sets the default ind.
	 *
	 * @param defaultInd the defaultInd to set
	 */
	public void setDefaultInd(boolean defaultInd) {
		this.defaultInd = defaultInd;
	}

	/**
	 * Gets the phone number.
	 *
	 * @return the phoneNumber
	 */
	public String getPhoneNumber() {
		return phoneNumber;
	}

	/**
	 * Sets the phone number.
	 *
	 * @param phoneNumber the phoneNumber to set
	 */
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	
}
