package com.sterling.bookingapi.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;


/**
 * The Class HsdResortRatePlanMaster.
 */
/**
 * @author tcs
 *
 */
@Entity
@Table(name = "sh_hsd_rate_plan_resort_master")
public class HsdResortRatePlanMaster extends BaseModel{

	/** The id. */
	@Id
	@GeneratedValue( strategy = GenerationType.IDENTITY )
	@Column(name = "rate_idx_id", unique = false)
	private int id;
	
	/** The hsd resort room master. */
	@ManyToOne(fetch = FetchType.EAGER,optional = false)
	@Cascade(CascadeType.SAVE_UPDATE)
	@JoinColumn(name="resort_room_id",nullable = false)
	private HsdResortRoomMaster hsdResortRoomMaster;
	
	/** The hsd rate plan master. */
	@ManyToOne(fetch = FetchType.EAGER,optional = false)
	@Cascade(CascadeType.SAVE_UPDATE)
	@JoinColumn(name="rate_plan_id",nullable = false)
	private HsdRatePlanMaster hsdRatePlanMaster ;
	
	/** The min stay days. */
	@Column(name = "min_stay_days",nullable = true)
	private int minStayDays;
	
	/** The max stay days. */
	@Column(name = "max_stay_days",nullable = true)
	private Integer maxStayDays;
	
	/** The active. */
	@Column(name = "status",nullable = false)
	private boolean active;

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * Gets the hsd resort room master.
	 *
	 * @return the hsd resort room master
	 */
	public HsdResortRoomMaster getHsdResortRoomMaster() {
		return hsdResortRoomMaster;
	}

	/**
	 * Sets the hsd resort room master.
	 *
	 * @param hsdResortRoomMaster the new hsd resort room master
	 */
	public void setHsdResortRoomMaster(HsdResortRoomMaster hsdResortRoomMaster) {
		this.hsdResortRoomMaster = hsdResortRoomMaster;
	}
	
	/**
	 * Gets the hsd rate plan master.
	 *
	 * @return the hsd rate plan master
	 */
	public HsdRatePlanMaster getHsdRatePlanMaster() {
		return hsdRatePlanMaster;
	}

	/**
	 * Sets the hsd rate plan master.
	 *
	 * @param hsdRatePlanMaster the new hsd rate plan master
	 */
	public void setHsdRatePlanMaster(HsdRatePlanMaster hsdRatePlanMaster) {
		this.hsdRatePlanMaster = hsdRatePlanMaster;
	}

	/**
	 * Gets the min stay days.
	 *
	 * @return the min stay days
	 */
	public int getMinStayDays() {
		return minStayDays;
	}

	/**
	 * Sets the min stay days.
	 *
	 * @param minStayDays the new min stay days
	 */
	public void setMinStayDays(int minStayDays) {
		this.minStayDays = minStayDays;
	}

	/**
	 * Gets the max stay days.
	 *
	 * @return the max stay days
	 */
	public int getMaxStayDays() {
		return maxStayDays;
	}

	/**
	 * Sets the max stay days.
	 *
	 * @param maxStayDays the new max stay days
	 */
	public void setMaxStayDays(int maxStayDays) {
		this.maxStayDays = maxStayDays;
	}

	/**
	 * Checks if is active.
	 *
	 * @return the active
	 */
	public boolean isActive() {
		return active;
	}

	/**
	 * Sets the active.
	 *
	 * @param active the active to set
	 */
	public void setActive(boolean active) {
		this.active = active;
	}


}
