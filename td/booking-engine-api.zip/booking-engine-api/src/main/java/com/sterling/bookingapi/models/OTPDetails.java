package com.sterling.bookingapi.models;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The Class HsdBookingCalcDetails.
 */
@Entity
@Table(name = "sh_otp_details")
public class OTPDetails extends BaseModel{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;
	
	/** The otp id. */
	@Id
	@GeneratedValue( strategy = GenerationType.IDENTITY )
	@Column(name = "otp_idx_id", unique = true)
	private int otpId;
	
	/** User Id */
	@Column(name = "user_id", nullable = false)
	private String userId;
	
	/** OTP */
	@Column(name = "otp", nullable = false)
	private String otp;
	
	/** OTP Count*/
	@Column(name = "count", nullable = false)
	private int count;
	
	/** Booking ID*/
	/*@Column(name = "bookind_id", nullable = false)
	private String bookingId;*/
	
	/** otpFor*/
	@Column(name = "otpfor", nullable = false)
	private String otpFor;
	
	/** Expiry date */
	@Column(name = "expiry_date", nullable = false)
	@Temporal(TemporalType.TIMESTAMP)
	private Date expiryDate;

	public int getOtpId() {
		return otpId;
	}

	public void setOtpId(int otpId) {
		this.otpId = otpId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getOtp() {
		return otp;
	}

	public void setOtp(String otp) {
		this.otp = otp;
	}

	public Date getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}
	
	/**
	 * Sets count as 0 before insert.
	 */
	@PrePersist
	public void setCount() {
		this.count = 0;
	}

	/*public String getBookingId() {
		return bookingId;
	}

	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}*/

	public String getOtpFor() {
		return otpFor;
	}

	public void setOtpFor(String otpFor) {
		this.otpFor = otpFor;
	}
	
	
	
}

