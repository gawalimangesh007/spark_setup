package com.sterling.bookingapi.dto.maximojo.request;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class HotelAvailReqDTO.
 */
/**
 * @author tcs
 *
 */
public class HotelAvailReqDTO {

	/** The hotel ref. */
	@JacksonXmlProperty(localName = "HotelRef")
    private HotelAvailRefReqDTO hotelRef;
	
	/** The date range. */
	@JacksonXmlProperty(localName = "DateRange")
	private DateRangeReqDTO dateRange;

	/**
	 * Gets the hotel ref.
	 *
	 * @return the hotelRef
	 */
	public HotelAvailRefReqDTO getHotelRef() {
		return hotelRef;
	}

	/**
	 * Sets the hotel ref.
	 *
	 * @param hotelRef the hotelRef to set
	 */
	public void setHotelRef(HotelAvailRefReqDTO hotelRef) {
		this.hotelRef = hotelRef;
	}

	/**
	 * Gets the date range.
	 *
	 * @return the dateRange
	 */
	public DateRangeReqDTO getDateRange() {
		return dateRange;
	}

	/**
	 * Sets the date range.
	 *
	 * @param dateRange the dateRange to set
	 */
	public void setDateRange(DateRangeReqDTO dateRange) {
		this.dateRange = dateRange;
	}
	
	
	}
