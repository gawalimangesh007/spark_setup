package com.sterling.bookingapi.dto.response;

public class CheckAvailabilityRecommendResorts {
	private String resortId;
	private String availStatus;
	
	public String getResortId() {
		return resortId;
	}
	public void setResortId(String resortId) {
		this.resortId = resortId;
	}
	public String getAvailStatus() {
		return availStatus;
	}
	public void setAvailStatus(String availStatus) {
		this.availStatus = availStatus;
	}
}
