package com.sterling.bookingapi.dto.request;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author tcs
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class VOFeedbackRequest implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private String name;
	private String problemType;
	private String subType;
	private String description;
	private String contractId;
	private String email;
	private String mobileNo;
	private String nonMemberId;
	private String image;
	
	private String attachments;
	private Boolean isMember;

	
	public Boolean getIsMember() {
		return isMember;
	}
	public void setIsMember(Boolean isMember) {
		this.isMember = isMember;
	}
	public String getAttachments() {
		return attachments;
	}
	public void setAttachments(String attachments) {
		this.attachments = attachments;
	}
	/**
	 * @return problemType
	 */
	public String getProblemType() {
		return problemType;
	}
	/**
	 * @param problemType
	 * set the problemType
	 */
	public void setProblemType(String problemType) {
		this.problemType = problemType;
	}
	/**
	 * @return description
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description
	 * set the description
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return contractId
	 */
	public String getContractId() {
		return contractId;
	}
	/**
	 * @param contractId
	 * set the contractId
	 */
	public void setContractId(String contractId) {
		this.contractId = contractId;
	}
	/**
	 * @return email
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * @param email
	 * set the email
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getSubType() {
		return subType;
	}
	public void setSubType(String subType) {
		this.subType = subType;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getNonMemberId() {
		return nonMemberId;
	}
	public void setNonMemberId(String nonMemberId) {
		this.nonMemberId = nonMemberId;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	
//	public String getHelperField() {
//	    if (!firstName.isEmpty()) && !lastName.isEmpty()) {
//	        return firstName +" "+ lastName;
//	    }
//	    return null;
//	}
//
//	public void setHelperField(FieldType singleField) {
//	    if (!isNull(singleField)) {
//	        this.field1 = singleField.part1();
//	        this.field2 = singleField.part2();
//	    }
//	}
}
