package com.sterling.bookingapi.dto.maximojo.response;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class ProfileResDTO.
 * @author tcs
 * @version 1.0
 */
public class ProfileResDTO {

	/** The customer. */
	@JacksonXmlProperty(localName = "Customer")
	private CustomerResDTO customer;

	/** The profile type. */
	@JacksonXmlProperty(localName = "ProfileType", isAttribute = true)
    private String profileType;

	/**
	 * Gets the customer.
	 *
	 * @return the customer
	 */
	public CustomerResDTO getCustomer() {
		return customer;
	}

	/**
	 * Sets the customer.
	 *
	 * @param customer the customer to set
	 */
	public void setCustomer(CustomerResDTO customer) {
		this.customer = customer;
	}

	/**
	 * Gets the profile type.
	 *
	 * @return the profileType
	 */
	public String getProfileType() {
		return profileType;
	}

	/**
	 * Sets the profile type.
	 *
	 * @param profileType the profileType to set
	 */
	public void setProfileType(String profileType) {
		this.profileType = profileType;
	}
	
	

}
