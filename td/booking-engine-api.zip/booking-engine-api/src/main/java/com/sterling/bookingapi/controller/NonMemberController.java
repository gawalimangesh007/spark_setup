package com.sterling.bookingapi.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.sterling.bookingapi.dto.request.HsdGetUserRequestDTO;
import com.sterling.bookingapi.dto.request.HsdLoginRequestDTO;
import com.sterling.bookingapi.dto.request.HsdRegisterRequestDTO;
import com.sterling.bookingapi.dto.response.HsdMemberResponseDTO;
import com.sterling.bookingapi.dto.response.ResponseDTO;
import com.sterling.bookingapi.exception.SalesForceException;
import com.sterling.bookingapi.service.NonMemberService;
import com.sterling.bookingapi.utils.ResponseUtility;

/**
 * @author tcs
 *
 */
@RestController
@RequestMapping(value = "/nonMember")
public class NonMemberController extends BaseController {
	
	/** The Constant logger. */
	private static final Logger logger = LogManager.getLogger(NonMemberController.class);
	
	@Autowired
	private NonMemberService nonMemberService;
	
	/**
	 * @param nonMemberService
	 * set the nonMemberService
	 */
	public void setNonMemberService(NonMemberService nonMemberService) {
		logger.info("NonMemberController : setNonMemberService : Entered.");
		this.nonMemberService = nonMemberService;
		logger.info("NonMemberController : setNonMemberService : Leaving.");
	}
	
	/**
	 * @param hsdLogin
	 * @return success after login 
	 * @throws SalesForceException
	 */
	@RequestMapping(value = "/login", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO NonMemberLogin(@RequestBody HsdLoginRequestDTO hsdLogin) throws SalesForceException {
		logger.info("NonMemberController : NonMemberLogin : Entered.");
		ResponseEntity<HsdMemberResponseDTO> hsdLoginEntity = nonMemberService.NonMemberLogin(hsdLogin);
		logger.info("NonMemberController : NonMemberLogin : Leaving.");
		return ResponseUtility.constructSuccessRes(hsdLoginEntity.getBody());
	}
	
	/**
	 * @param req
	 * @return success message after registration
	 * @throws SalesForceException
	 */
	@RequestMapping(value = "/register", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO NonMemberRegister(@RequestBody HsdRegisterRequestDTO req) throws SalesForceException {
		logger.info("NonMemberController : NonMemberRegister : Entered.");
		ResponseEntity<?> hsdLoginEntity = nonMemberService.registerNonMember(req);
		logger.info("NonMemberController : NonMemberRegister : Leaving.");
		return ResponseUtility.constructSuccessRes(hsdLoginEntity.getBody());
	}

	/**
	 * @param req
	 * @return user details
	 * @throws SalesForceException
	 */
	@RequestMapping(value = "/getUserDetails", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO getUserDetails(@RequestBody HsdGetUserRequestDTO req) throws SalesForceException {
		logger.info("NonMemberController : getUserDetails : Entered.");
		ResponseEntity<HsdMemberResponseDTO> hsdLoginEntity = nonMemberService.getUserDetails(req);
		logger.info("NonMemberController : getUserDetails : Leaving.");
		return ResponseUtility.constructSuccessRes(hsdLoginEntity.getBody());
	}
}
