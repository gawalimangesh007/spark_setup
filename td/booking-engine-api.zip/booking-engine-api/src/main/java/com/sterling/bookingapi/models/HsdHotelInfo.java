package com.sterling.bookingapi.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * The Class HsdHotelInfo.
 */
/**
 * @author tcs
 *
 */
@Entity
@Table(name = "sh_hsd_hotel_info")//delete
public class HsdHotelInfo extends BaseModel{
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The id. */
	@Id
	@GeneratedValue( strategy = GenerationType.IDENTITY )
	@Column(name = "pk_idx_id", unique = true)
	private int id;
	
	/** The resort id. */
	@Column(name = "resort_id",nullable = false)
	private String resortId;
	
	/** The room type id. */
	@Column(name = "room_type_id",nullable = false)
	private String roomTypeId;
	
	/** The max accomodation count. */
	@Column(name = "member_count",nullable = false)
	private String maxAccomodationCount;
	
	/** The active. */
	@Column(name = "status",nullable = false)
	private boolean active;

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * Gets the resort id.
	 *
	 * @return the resort id
	 */
	public String getResortId() {
		return resortId;
	}

	/**
	 * Sets the resort id.
	 *
	 * @param resortId the new resort id
	 */
	public void setResortId(String resortId) {
		this.resortId = resortId;
	}

	/**
	 * Gets the room type id.
	 *
	 * @return the room type id
	 */
	public String getRoomTypeId() {
		return roomTypeId;
	}

	/**
	 * Sets the room type id.
	 *
	 * @param roomTypeId the new room type id
	 */
	public void setRoomTypeId(String roomTypeId) {
		this.roomTypeId = roomTypeId;
	}

	/**
	 * Gets the max accomodation count.
	 *
	 * @return the max accomodation count
	 */
	public String getMaxAccomodationCount() {
		return maxAccomodationCount;
	}

	/**
	 * Sets the max accomodation count.
	 *
	 * @param maxAccomodationCount the new max accomodation count
	 */
	public void setMaxAccomodationCount(String maxAccomodationCount) {
		this.maxAccomodationCount = maxAccomodationCount;
	}

	/**
	 * Checks if is active.
	 *
	 * @return true, if is active
	 */
	public boolean isActive() {
		return active;
	}

	/**
	 * Sets the active.
	 *
	 * @param active the new active
	 */
	public void setActive(boolean active) {
		this.active = active;
	}

}
