package com.sterling.bookingapi.dto.maximojo.request;

import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class HotelRatePlanNotifReqDTO.
 */
/**
 * @author tcs
 *
 */
public class HotelRatePlanNotifReqDTO {

	/** The message content code. */
	@JacksonXmlProperty(localName = "MessageContentCode", isAttribute = true)
	private String messageContentCode;

	/** The rate plans. */
	@JacksonXmlElementWrapper(useWrapping=false)
	@JacksonXmlProperty(localName = "RatePlans")
    private List<RatePlansNotifReqDTO> ratePlans;

    /** The pos. */
    @JacksonXmlProperty(localName = "POS")
    private POSReqDTO POS;

    /** The xmlns. */
    @JacksonXmlProperty(localName = "xmlns", isAttribute = true)
    private String xmlns="http://www.opentravel.org/OTA/2003/05";

    /** The version. */
    @JacksonXmlProperty(localName = "Version", isAttribute = true)
    private String version;

	/**
	 * Gets the message content code.
	 *
	 * @return the messageContentCode
	 */
	public String getMessageContentCode() {
		return messageContentCode;
	}

	/**
	 * Sets the message content code.
	 *
	 * @param messageContentCode the messageContentCode to set
	 */
	public void setMessageContentCode(String messageContentCode) {
		this.messageContentCode = messageContentCode;
	}

	/**
	 * Gets the rate plans.
	 *
	 * @return the ratePlans
	 */
	public List<RatePlansNotifReqDTO> getRatePlans() {
		return ratePlans;
	}

	/**
	 * Sets the rate plans.
	 *
	 * @param ratePlans the ratePlans to set
	 */
	public void setRatePlans(List<RatePlansNotifReqDTO> ratePlans) {
		this.ratePlans = ratePlans;
	}

	/**
	 * Gets the pos.
	 *
	 * @return the pOS
	 */
	public POSReqDTO getPOS() {
		return POS;
	}

	/**
	 * Sets the pos.
	 *
	 * @param pOS the pOS to set
	 */
	public void setPOS(POSReqDTO pOS) {
		POS = pOS;
	}

	/**
	 * Gets the xmlns.
	 *
	 * @return the xmlns
	 */
	public String getXmlns() {
		return xmlns;
	}

	/**
	 * Sets the xmlns.
	 *
	 * @param xmlns the xmlns to set
	 */
	public void setXmlns(String xmlns) {
		this.xmlns = xmlns;
	}

	/**
	 * Gets the version.
	 *
	 * @return the version
	 */
	public String getVersion() {
		return version;
	}

	/**
	 * Sets the version.
	 *
	 * @param version the version to set
	 */
	public void setVersion(String version) {
		this.version = version;
	}
    
    
}
