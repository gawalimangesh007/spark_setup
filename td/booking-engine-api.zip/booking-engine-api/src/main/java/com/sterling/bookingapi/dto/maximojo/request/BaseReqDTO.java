package com.sterling.bookingapi.dto.maximojo.request;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class BaseReqDTO.
 */
/**
 * @author tcs
 *
 */
public class BaseReqDTO {

	/** The amount before tax. */
	@JacksonXmlProperty(localName = "AmountBeforeTax", isAttribute = true)
	private double amountBeforeTax;

	/** The currency code. */
	@JacksonXmlProperty(localName = "CurrencyCode", isAttribute = true)
    private String currencyCode;

	/**
	 * Gets the amount before tax.
	 *
	 * @return the amountBeforeTax
	 */
	public double getAmountBeforeTax() {
		return amountBeforeTax;
	}

	/**
	 * Sets the amount before tax.
	 *
	 * @param amountBeforeTax the amountBeforeTax to set
	 */
	public void setAmountBeforeTax(double amountBeforeTax) {
		this.amountBeforeTax = amountBeforeTax;
	}

	/**
	 * Gets the currency code.
	 *
	 * @return the currencyCode
	 */
	public String getCurrencyCode() {
		return currencyCode;
	}

	/**
	 * Sets the currency code.
	 *
	 * @param currencyCode the currencyCode to set
	 */
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}
	
	
}
