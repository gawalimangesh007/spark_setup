package com.sterling.bookingapi.dto.maximojo.response;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class RetrieveRateResDTO.
 * @author tcs
 * @version 1.0
 */
public class RetrieveRateResDTO {

	/** The Base. */
	@JacksonXmlProperty(localName = "Base")
    private TotalResDTO Base;

	/** The expire date. */
	@JacksonXmlProperty(localName = "ExpireDate", isAttribute = true)
    private String expireDate;

	/** The rate time unit. */
	@JacksonXmlProperty(localName = "RateTimeUnit", isAttribute = true)
    private String rateTimeUnit;

	/** The unit multiplier. */
	@JacksonXmlProperty(localName = "UnitMultiplier", isAttribute = true)
    private String unitMultiplier;

	/** The effective date. */
	@JacksonXmlProperty(localName = "CreateDateTime", isAttribute = true)
    private String effectiveDate;

	/**
	 * Gets the base.
	 *
	 * @return the base
	 */
	public TotalResDTO getBase() {
		return Base;
	}

	/**
	 * Sets the base.
	 *
	 * @param base the base to set
	 */
	public void setBase(TotalResDTO base) {
		Base = base;
	}

	/**
	 * Gets the expire date.
	 *
	 * @return the expireDate
	 */
	public String getExpireDate() {
		return expireDate;
	}

	/**
	 * Sets the expire date.
	 *
	 * @param expireDate the expireDate to set
	 */
	public void setExpireDate(String expireDate) {
		this.expireDate = expireDate;
	}

	/**
	 * Gets the rate time unit.
	 *
	 * @return the rateTimeUnit
	 */
	public String getRateTimeUnit() {
		return rateTimeUnit;
	}

	/**
	 * Sets the rate time unit.
	 *
	 * @param rateTimeUnit the rateTimeUnit to set
	 */
	public void setRateTimeUnit(String rateTimeUnit) {
		this.rateTimeUnit = rateTimeUnit;
	}

	/**
	 * Gets the unit multiplier.
	 *
	 * @return the unitMultiplier
	 */
	public String getUnitMultiplier() {
		return unitMultiplier;
	}

	/**
	 * Sets the unit multiplier.
	 *
	 * @param unitMultiplier the unitMultiplier to set
	 */
	public void setUnitMultiplier(String unitMultiplier) {
		this.unitMultiplier = unitMultiplier;
	}

	/**
	 * Gets the effective date.
	 *
	 * @return the effectiveDate
	 */
	public String getEffectiveDate() {
		return effectiveDate;
	}

	/**
	 * Sets the effective date.
	 *
	 * @param effectiveDate the effectiveDate to set
	 */
	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

    
}
