package com.sterling.bookingapi.dto.response;

import java.io.Serializable;


/**
 * @author tcs
 * @version 1.0
 */
public class VOCustomer implements Serializable {

	private static final long serialVersionUID = 1L;

	private String id;
	private String productCategory;
	
	/**
	 * @return id
	 */ 
	public String getId() {
		return id;
	}
	/**
	 * @param id
	 * set the id
	 */
	public void setId(String id) {
		this.id = id;
	}
	/**
	 * @return productCategory
	 */
	public String getProductCategory() {
		return productCategory;
	}
	/**
	 * @param productCategory
	 * set the productCategory
	 */
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}
	
}
