package com.sterling.bookingapi.dto.maximojo.request;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class GuestCountReqDTO.
 */
/**
 * @author tcs
 *
 */
public class GuestCountReqDTO {
	
	/** The age qualifying code. */
	@JacksonXmlProperty(localName = "AgeQualifyingCode", isAttribute = true)
	 private int ageQualifyingCode;
	
	/** The count. */
	@JacksonXmlProperty(localName = "Count", isAttribute = true)
	 private int count;

	/**
	 * Gets the count.
	 *
	 * @return the count
	 */
	public int getCount() {
		return count;
	}

	/**
	 * Sets the count.
	 *
	 * @param count the count to set
	 */
	public void setCount(int count) {
		this.count = count;
	}

	/**
	 * Gets the age qualifying code.
	 *
	 * @return the ageQualifyingCode
	 */
	public int getAgeQualifyingCode() {
		return ageQualifyingCode;
	}

	/**
	 * Sets the age qualifying code.
	 *
	 * @param ageQualifyingCode the ageQualifyingCode to set
	 */
	public void setAgeQualifyingCode(int ageQualifyingCode) {
		this.ageQualifyingCode = ageQualifyingCode;
	}

	
}
