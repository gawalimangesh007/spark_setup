package com.sterling.bookingapi.dto;

import java.io.Serializable;


public class FileContentDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String contentType;
	private String fileData;
	public String getContentType() {
		return contentType;
	}
	public void setContentType(String contentType) {
		this.contentType = contentType;
	}
	public String getFileData() {
		return fileData;
	}
	public void setFileData(String fileData) {
		this.fileData = fileData;
	}

	
	
}
