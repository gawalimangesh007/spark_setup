package com.sterling.bookingapi.dto.response;

import java.util.ArrayList;
import java.util.List;

/**
 * @author tcs
 * @version 1.0
 */
public class VOGetApartmentResponseDTO {

	private String resortId;
	
	private String resortSerialNumber;

	private List<VOGetAvailRoomsResponseDTO> rooms;
	
	/**
	 * @return resortSerialNumber
	 */
	public String getResortSerialNumber() {
		return resortSerialNumber;
	}

	/**
	 * @param resortSerialNumber
	 * set the resortSerialNumber
	 */
	public void setResortSerialNumber(String resortSerialNumber) {
		this.resortSerialNumber = resortSerialNumber;
	}

	/**
	 * @return resortId
	 */
	public String getResortId() {
		return resortId;
	}

	/**
	 * @param resortId
	 * set the resortId
	 */
	public void setResortId(String resortId) {
		this.resortId = resortId;
	}

	/**
	 * @return rooms
	 */
	public List<VOGetAvailRoomsResponseDTO> getRooms() {
		if (rooms == null) {
			this.rooms = new ArrayList<>();
		}
		return rooms;
	}

	/**
	 * @param rooms
	 * set the rooms
	 */
	public void setRooms(List<VOGetAvailRoomsResponseDTO> rooms) {
		this.rooms = rooms;
	}

}
