package com.sterling.bookingapi.models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "sh_hsd_eventmodel")
public class EventModel extends BaseModel{
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue( strategy = GenerationType.IDENTITY )
	@Column(name = "event_id", unique = true)
	private String eventid;
	
/*	@OneToOne
	@JoinColumn(name="page_idx_id")*/
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "page_idx_id", nullable = false)
	@JsonIgnore
	private PageModel pageModel;
	
	@Column(name = "event_type", unique = true)
	private String eventtype;
	
	@Column(name = "event_dec", unique = true)
	private String eventdec;
	
	@Column(name = "value", unique = true)
	private String value;
	
	
	public String getEventid() {
		return eventid;
	}
	public void setEventid(String eventid) {
		this.eventid = eventid;
	}
	
	
	public PageModel getPageModel() {
		return pageModel;
	}
	public void setPageModel(PageModel pageModel) {
		this.pageModel = pageModel;
	}
	public String getEventtype() {
		return eventtype;
	}
	public void setEventtype(String eventtype) {
		this.eventtype = eventtype;
	}
	public String getEventdec() {
		return eventdec;
	}
	public void setEventdec(String eventdec) {
		this.eventdec = eventdec;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}

	
}
