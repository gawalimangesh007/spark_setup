package com.sterling.bookingapi.dto.response;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class VOProdPmntPlanResponse implements Serializable {

	private static final long serialVersionUID = 1L;

	public String saleId;
	public String opportunityId;
	
	/**
	 * @return saleId
	 */
	public String getSaleId() {
		return saleId ;
	}
	/**
	 * @param saleId
	 * set the saleId
	 */
	public void setSaleId(String saleId) {
		this.saleId = saleId;
	}
	/**
	 * @return opportunityId
	 */
	public String getOpportunityId() {
		return opportunityId;
	}
	/**
	 * @param opportunityId
	 * set the opportunityId
	 */
	public void setOpportunityId(String opportunityId) {
		this.opportunityId = opportunityId;
	}

	
}
