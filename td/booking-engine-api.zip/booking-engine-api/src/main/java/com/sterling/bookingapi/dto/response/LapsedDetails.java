package com.sterling.bookingapi.dto.response;

import java.io.Serializable;

/**
 * @author tcs
 * @version 1.0
 */
public class LapsedDetails implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private Double balance;
	private String description;
	private String lapsingDate;
	private Double lapsingPoint;
	private String type;
	
	/**
	 * @return balance
	 */
	public Double getBalance() {
		return balance;
	}
	/**
	 * @param balance
	 * set the balance
	 */
	public void setBalance(Double balance) {
		this.balance = balance;
	}
	/**
	 * @param lapsingPoint
	 * set the lapsingPoint
	 */
	public void setLapsingPoint(Double lapsingPoint) {
		this.lapsingPoint = lapsingPoint;
	}
	/**
	 * @return description
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description
	 * set the description
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return lapsingDate
	 */
	public String getLapsingDate() {
		return lapsingDate;
	}
	/**
	 * @param lapsingDate
	 * set the lapsingDate
	 */
	public void setLapsingDate(String lapsingDate) {
		this.lapsingDate = lapsingDate;
	}
	/**
	 * @return lapsingPoint
	 */
	public Double getLapsingPoint() {
		return lapsingPoint;
	}
	/**
	 * @return type
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type
	 * set the type
	 */
	public void setType(String type) {
		this.type = type;
	}
}
