package com.sterling.bookingapi.dto.response;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author tcs
 * @version 1.0
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class AddressDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String city;

	private String country;

	private String countryCode;

	private String geocodeAccuracy;

	private String latitude;

	private String longitude;

	private String postalCode;

	private String state;

	private String stateCode;

	private String street;

	/**
	 * @return city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * @param city
	 * set the city
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * @return country
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * @param country
	 * set the country
	 */
	public void setCountry(String country) {
		this.country = country;
	}

	/**
	 * @return countrycode
	 */
	public String getCountryCode() {
		return countryCode;
	}

	/**
	 * @param countryCode
	 * set the countryCode
	 */
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	/**
	 * @return geocodeAccuracy
	 */
	public String getGeocodeAccuracy() {
		return geocodeAccuracy;
	}

	/**
	 * @param geocodeAccuracy
	 * set the geocodeAccuracy
	 */
	public void setGeocodeAccuracy(String geocodeAccuracy) {
		this.geocodeAccuracy = geocodeAccuracy;
	}

	/**
	 * @return Latitude
	 */
	public String getLatitude() {
		return latitude;
	}

	/**
	 * @param latitude
	 * set the Latitude
	 */
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	/**
	 * @return longitude
	 */
	public String getLongitude() {
		return longitude;
	}

	/**
	 * @param longitude
	 * set the longitude
	 */
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	/**
	 * @return postalCode
	 */
	public String getPostalCode() {
		return postalCode;
	}

	/**
	 * @param postalCode
	 * set the postalCode
	 */
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	/**
	 * @return state
	 */
	public String getState() {
		return state;
	}

	/**
	 * @param state
	 * set the state
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * @return stateCode
	 */
	public String getStateCode() {
		return stateCode;
	}

	/**
	 * @param stateCode
	 * set the statecode
	 */
	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}

	/**
	 * @return street
	 */
	public String getStreet() {
		return street;
	}

	/**
	 * @param street
	 * set the street
	 */
	public void setStreet(String street) {
		this.street = street;
	}

	@Override
	public String toString() {
		return  street
				+ ", " + city		
				+ ", " + state
				+ ", " + country
				+ ", " + postalCode; 

	}
	
	
	
	
}
