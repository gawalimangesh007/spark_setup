package com.sterling.bookingapi.dto.response;

import java.io.Serializable;
import java.util.List;

/**
 * @author tcs
 * @version 1.0
 */
public class PointsDetails implements Serializable {
	

	private static final long serialVersionUID = 1L;

	private Double currentPoints;
	private Double borrowfromNextyear;
	
	private Double lastYearPoints1;
	private Double lastYearPoints2;
	private Double nextYearPoints1;
	private Double nextYearPoints2;
	
	private List<LapsedDetails> lapsedDetails;
	
	//fields for borrow point check for future years
	private boolean hasBorrowedNext1Year;
	private boolean hasBorrowedNext2Year;
	

	public boolean getHasBorrowedNext1Year() {
		return hasBorrowedNext1Year;
	}

	public void setHasBorrowedNext1Year(boolean hasBorrowedNext1Year) {
		this.hasBorrowedNext1Year = hasBorrowedNext1Year;
	}

	public boolean getHasBorrowedNext2Year() {
		return hasBorrowedNext2Year;
	}

	public void setHasBorrowedNext2Year(boolean hasBorrowedNext2Year) {
		this.hasBorrowedNext2Year = hasBorrowedNext2Year;
	}

	/**
	 * @return currentPoints
	 */
	public Double getCurrentPoints() {
		return currentPoints;
	}

	/**
	 * @param currentPoints
	 * set the currentPoints
	 */
	public void setCurrentPoints(Double currentPoints) {
		this.currentPoints = currentPoints;
	}

	/**
	 * @return borrowfromNextyear
	 */
	public Double getBorrowfromNextyear() {
		return borrowfromNextyear;
	}

	/**
	 * @param borrowfromNextyear
	 * set the borrowfromNextyear
	 */
	public void setBorrowfromNextyear(Double borrowfromNextyear) {
		this.borrowfromNextyear = borrowfromNextyear;
	}

	/**
	 * @return lastYearPoints1
	 */
	public Double getLastYearPoints1() {
		return lastYearPoints1;
	}

	/**
	 * @param lastYearPoints1
	 * set the lastYearPoints1
	 */
	public void setLastYearPoints1(Double lastYearPoints1) {
		this.lastYearPoints1 = lastYearPoints1;
	}

	/**
	 * @return lastYearPoints2
	 */
	public Double getLastYearPoints2() {
		return lastYearPoints2;
	}

	/**
	 * @param lastYearPoints2
	 * set the lastYearPoints2
	 */
	public void setLastYearPoints2(Double lastYearPoints2) {
		this.lastYearPoints2 = lastYearPoints2;
	}

	/**
	 * @return nextYearPoints1
	 */
	public Double getNextYearPoints1() {
		return nextYearPoints1;
	}

	/**
	 * @param nextYearPoints1
	 * set the nextYearPoints1
	 */
	public void setNextYearPoints1(Double nextYearPoints1) {
		this.nextYearPoints1 = nextYearPoints1;
	}

	/**
	 * @return nextYearPoints2
	 */
	public Double getNextYearPoints2() {
		return nextYearPoints2;
	}

	/**
	 * @param nextYearPoints2
	 * set the nextYearPoints2
	 */
	public void setNextYearPoints2(Double nextYearPoints2) {
		this.nextYearPoints2 = nextYearPoints2;
	}

	/**
	 * @return lapsedDetails
	 */
	public List<LapsedDetails> getLapsedDetails() {
		return lapsedDetails;
	}

	/**
	 * @param lapsedDetails
	 * set the lapsedDetails
	 */
	public void setLapsedDetails(List<LapsedDetails> lapsedDetails) {
		this.lapsedDetails = lapsedDetails;
	}
		
}
