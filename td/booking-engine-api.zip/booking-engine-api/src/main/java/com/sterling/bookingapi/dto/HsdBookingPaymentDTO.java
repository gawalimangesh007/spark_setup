package com.sterling.bookingapi.dto;


/**
 * The Class HsdBookingPaymentDTO.
 */
/**
 * @author tcs
 *
 */
public class HsdBookingPaymentDTO {

	/**
	 * Booking id is the transaction id.
	 */
	private String transactionId;
	
	/** The ap transaction id. */
	private String apTransactionId;
	
	/** The amount. */
	private String amount;
	
	/** The transaction status. */
	private String transactionStatus;
	
	/** The message. */
	private String message;
	
	/** The custom var. */
	private String customVar;
	
	/** The chmod. */
	private String chmod;
	
	/** The card issuer. */
	private String cardIssuer;
	
	/** The customer. */
	private String customer;
	
	/** The customer email. */
	private String customerEmail;
	
	/** The customer phone. */
	private String customerPhone;
	
	/** The risk. */
	private String risk;
	
	/** The currency code. */
	private String currencyCode;
	
	/** The ap secure hash. */
	private String apSecureHash;

	/**
	 * Gets the transaction id.
	 *
	 * @return the transaction id
	 */
	public String getTransactionId() {
		return transactionId;
	}

	/**
	 * Sets the transaction id.
	 *
	 * @param transactionId the new transaction id
	 */
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	/**
	 * Gets the ap transaction id.
	 *
	 * @return the ap transaction id
	 */
	public String getApTransactionId() {
		return apTransactionId;
	}

	/**
	 * Sets the ap transaction id.
	 *
	 * @param apTransactionId the new ap transaction id
	 */
	public void setApTransactionId(String apTransactionId) {
		this.apTransactionId = apTransactionId;
	}

	/**
	 * Gets the amount.
	 *
	 * @return the amount
	 */
	public String getAmount() {
		return amount;
	}

	/**
	 * Sets the amount.
	 *
	 * @param amount the new amount
	 */
	public void setAmount(String amount) {
		this.amount = amount;
	}

	/**
	 * Gets the transaction status.
	 *
	 * @return the transaction status
	 */
	public String getTransactionStatus() {
		return transactionStatus;
	}

	/**
	 * Sets the transaction status.
	 *
	 * @param transactionStatus the new transaction status
	 */
	public void setTransactionStatus(String transactionStatus) {
		this.transactionStatus = transactionStatus;
	}

	/**
	 * Gets the message.
	 *
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * Sets the message.
	 *
	 * @param message the new message
	 */
	public void setMessage(String message) {
		this.message = message;
	}

	/**
	 * Gets the custom var.
	 *
	 * @return the custom var
	 */
	public String getCustomVar() {
		return customVar;
	}

	/**
	 * Sets the custom var.
	 *
	 * @param customVar the new custom var
	 */
	public void setCustomVar(String customVar) {
		this.customVar = customVar;
	}

	/**
	 * Gets the chmod.
	 *
	 * @return the chmod
	 */
	public String getChmod() {
		return chmod;
	}

	/**
	 * Sets the chmod.
	 *
	 * @param chmod the new chmod
	 */
	public void setChmod(String chmod) {
		this.chmod = chmod;
	}

	/**
	 * Gets the card issuer.
	 *
	 * @return the card issuer
	 */
	public String getCardIssuer() {
		return cardIssuer;
	}

	/**
	 * Sets the card issuer.
	 *
	 * @param cardIssuer the new card issuer
	 */
	public void setCardIssuer(String cardIssuer) {
		this.cardIssuer = cardIssuer;
	}

	/**
	 * Gets the customer.
	 *
	 * @return the customer
	 */
	public String getCustomer() {
		return customer;
	}

	/**
	 * Sets the customer.
	 *
	 * @param customer the new customer
	 */
	public void setCustomer(String customer) {
		this.customer = customer;
	}

	/**
	 * Gets the customer email.
	 *
	 * @return the customer email
	 */
	public String getCustomerEmail() {
		return customerEmail;
	}

	/**
	 * Sets the customer email.
	 *
	 * @param customerEmail the new customer email
	 */
	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}

	/**
	 * Gets the customer phone.
	 *
	 * @return the customer phone
	 */
	public String getCustomerPhone() {
		return customerPhone;
	}

	/**
	 * Sets the customer phone.
	 *
	 * @param customerPhone the new customer phone
	 */
	public void setCustomerPhone(String customerPhone) {
		this.customerPhone = customerPhone;
	}

	/**
	 * Gets the risk.
	 *
	 * @return the risk
	 */
	public String getRisk() {
		return risk;
	}

	/**
	 * Sets the risk.
	 *
	 * @param risk the new risk
	 */
	public void setRisk(String risk) {
		this.risk = risk;
	}

	/**
	 * Gets the currency code.
	 *
	 * @return the currency code
	 */
	public String getCurrencyCode() {
		return currencyCode;
	}

	/**
	 * Sets the currency code.
	 *
	 * @param currencyCode the new currency code
	 */
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	/**
	 * Gets the ap secure hash.
	 *
	 * @return the ap secure hash
	 */
	public String getApSecureHash() {
		return apSecureHash;
	}

	/**
	 * Sets the ap secure hash.
	 *
	 * @param apSecureHash the new ap secure hash
	 */
	public void setApSecureHash(String apSecureHash) {
		this.apSecureHash = apSecureHash;
	}
	
		
}