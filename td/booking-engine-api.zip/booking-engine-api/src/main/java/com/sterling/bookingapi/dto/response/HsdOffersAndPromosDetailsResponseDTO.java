package com.sterling.bookingapi.dto.response;

import com.sterling.bookingapi.utils.AppConstants;

/**
 * @author tcs
 * @version 1.0
 */
public class HsdOffersAndPromosDetailsResponseDTO {
	
	/** The name. */
	private String name;
	
	/** The offer promo id. */
	private int offerPromoId;
	
	/** The offer promo type. */
	private AppConstants.Type offerPromoType;
	
	/** The offer promo category. */
	private String offerPromoCategory;
	
	
	/**
	 * Instantiates a new hsd offers and promos details response DTO.
	 */
	public HsdOffersAndPromosDetailsResponseDTO() {
		super();
	}
	
	/**
	 * Instantiates a new hsd offers and promos details response DTO.
	 *
	 * @param name the name
	 */
	public HsdOffersAndPromosDetailsResponseDTO(String name) {
		
		this.name = name;
	}
	
	/**
	 * Instantiates a new hsd offers and promos details response DTO.
	 *
	 * @param offerPromoId the offer promo id
	 * @param name the name
	 */
	public HsdOffersAndPromosDetailsResponseDTO(int offerPromoId, String name) {
		this.offerPromoId = offerPromoId;
		this.name = name;
	}
	
	


	/**
	 * Gets the offer promo id.
	 *
	 * @return the offer promo id
	 */
	public int getOfferPromoId() {
		return offerPromoId;
	}

	/**
	 * Sets the offer promo id.
	 *
	 * @param offerPromoId the new offer promo id
	 */
	public void setOfferPromoId(int offerPromoId) {
		this.offerPromoId = offerPromoId;
	}

	/**
	 * Gets the name.
	 *
	 * @return the packageName
	 */
	public String getName() {
		return name;
	}

	/**
	 * Sets the name.
	 *
	 * @param name the new name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Gets the offer promo type.
	 *
	 * @return the offer promo type
	 */
	public AppConstants.Type getOfferPromoType() {
		return offerPromoType;
	}

	/**
	 * Sets the offer promo type.
	 *
	 * @param offerPromoType the new offer promo type
	 */
	public void setOfferPromoType(AppConstants.Type offerPromoType) {
		this.offerPromoType = offerPromoType;
	}

	/**
	 * Gets the offer promo category.
	 *
	 * @return the offer promo category
	 */
	public String getOfferPromoCategory() {
		return offerPromoCategory;
	}

	/**
	 * Sets the offer promo category.
	 *
	 * @param offerPromoCategory the new offer promo category
	 */
	public void setOfferPromoCategory(String offerPromoCategory) {
		this.offerPromoCategory = offerPromoCategory;
	}
	
	


}
