package com.sterling.bookingapi.dto.maximojo.response;

import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class RatePlanForSummaryFalse.
 * @author tcs
 * @version 1.0
 */
public class RatePlanForSummaryFalse {

	/** The currency code. */
	@JacksonXmlProperty(localName = "CurrencyCode", isAttribute = true)
	private String currencyCode;

	/** The end. */
	@JacksonXmlProperty(localName = "End", isAttribute = true)
	private String end;

	/** The rate plan code. */
	@JacksonXmlProperty(localName = "RatePlanCode", isAttribute = true)
	private String ratePlanCode;

	/** The rate plan status type. */
	@JacksonXmlProperty(localName = "RatePlanStatusType", isAttribute = true)
	private String ratePlanStatusType;

	/** The start. */
	@JacksonXmlProperty(localName = "Start", isAttribute = true)
	private String start;

	/** The rate. */
	@JacksonXmlElementWrapper(useWrapping = true, localName = "Rates")
	@JacksonXmlProperty(localName = "Rate")
	private List<RateForSummaryFalseResDTO> rate;

	/**
	 * Gets the rate.
	 *
	 * @return the rate
	 */
	public List<RateForSummaryFalseResDTO> getRate() {
		return rate;
	}

	/**
	 * Sets the rate.
	 *
	 * @param rate the new rate
	 */
	public void setRate(List<RateForSummaryFalseResDTO> rate) {
		this.rate = rate;
	}

	/**
	 * Gets the currency code.
	 *
	 * @return the currency code
	 */
	public String getCurrencyCode() {
		return currencyCode;
	}

	/**
	 * Sets the currency code.
	 *
	 * @param currencyCode the new currency code
	 */
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	/**
	 * Gets the rate plan status type.
	 *
	 * @return the rate plan status type
	 */
	public String getRatePlanStatusType() {
		return ratePlanStatusType;
	}

	/**
	 * Sets the rate plan status type.
	 *
	 * @param ratePlanStatusType the new rate plan status type
	 */
	public void setRatePlanStatusType(String ratePlanStatusType) {
		this.ratePlanStatusType = ratePlanStatusType;
	}

	/**
	 * Gets the end.
	 *
	 * @return the end
	 */
	public String getEnd() {
		return end;
	}

	/**
	 * Sets the end.
	 *
	 * @param end            the end to set
	 */
	public void setEnd(String end) {
		this.end = end;
	}

	/**
	 * Gets the start.
	 *
	 * @return the start
	 */
	public String getStart() {
		return start;
	}

	/**
	 * Sets the start.
	 *
	 * @param start            the start to set
	 */
	public void setStart(String start) {
		this.start = start;
	}

	/**
	 * Gets the rate plan code.
	 *
	 * @return the ratePlanCode
	 */
	public String getRatePlanCode() {
		return ratePlanCode;
	}

	/**
	 * Sets the rate plan code.
	 *
	 * @param ratePlanCode            the ratePlanCode to set
	 */
	public void setRatePlanCode(String ratePlanCode) {
		this.ratePlanCode = ratePlanCode;
	}

}
