package com.sterling.bookingapi.dto.maximojo.response;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class AdditionalGuestAmountResDTO.
 * @author tcs
 * @version 1.0
 */
public class AdditionalGuestAmountResDTO {

	/** The amount. */
	@JacksonXmlProperty(localName = "Amount", isAttribute = true)
	private double amount;

	/** The age qualifying code. */
	@JacksonXmlProperty(localName = "AgeQualifyingCode", isAttribute = true)
	private int ageQualifyingCode;

	/**
	 * Gets the amount.
	 *
	 * @return the amount
	 */
	public double getAmount() {
		return amount;
	}

	/**
	 * Sets the amount.
	 *
	 * @param amount            the amount to set
	 */
	public void setAmount(double amount) {
		this.amount = amount;
	}

	/**
	 * Gets the age qualifying code.
	 *
	 * @return the age qualifying code
	 */
	public int getAgeQualifyingCode() {
		return ageQualifyingCode;
	}

	/**
	 * Sets the age qualifying code.
	 *
	 * @param ageQualifyingCode the new age qualifying code
	 */
	public void setAgeQualifyingCode(int ageQualifyingCode) {
		this.ageQualifyingCode = ageQualifyingCode;
	}

}
