package com.sterling.bookingapi.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.sterling.bookingapi.dto.request.HsdCreateCalendarRequestDTO;
import com.sterling.bookingapi.dto.request.HsdCreateResortRatePlanDTO;
import com.sterling.bookingapi.dto.request.HsdCreateResortRoomTypeDTO;
import com.sterling.bookingapi.dto.request.HsdRatePlanUpdateDTO;
import com.sterling.bookingapi.dto.request.HsdResortRoomMasterDTO;
import com.sterling.bookingapi.dto.request.HsdResortRoomMasterUpdateDTO;
import com.sterling.bookingapi.dto.request.HsdRoomTypeUpdateDTO;
import com.sterling.bookingapi.dto.response.ResponseDTO;
import com.sterling.bookingapi.exception.BookingEngineException;
import com.sterling.bookingapi.service.HsdResortRoomMasterService;


/**
 * The Class HsdResortRoomMasterController.
 */
/**
 * @author tcs
 *
 */
@RestController
@RequestMapping(value = "/hsd/resortRoomMaster")
public class HsdResortRoomMasterController extends BaseController {
	
	/** The Constant logger. */
	private static final Logger logger = LogManager.getLogger(HsdResortRoomMasterController.class);
	
	/** The hsd resort room master service. */
	@Autowired
	private HsdResortRoomMasterService hsdResortRoomMasterService;
	
	/**
	 * Gets the resort room by id.
	 *
	 * @param resortId the resort id
	 * @return the resort room by id
	 * @throws BookingEngineException the booking engine exception
	 */
	@ResponseBody
    @RequestMapping(value = "/getResortById", method = RequestMethod.POST)
	public ResponseDTO getResortRoomById(@RequestBody final String resortId)throws BookingEngineException {
		logger.info("HsdResortRoomMasterController : getResortRoomById : Entered.");
        ResponseDTO response = hsdResortRoomMasterService.getResortById(resortId);
        logger.info("HsdResortRoomMasterController : getResortRoomById : leaving.");        
        return response;
    }

	/**
	 * Creates the resort room.
	 *
	 * @param reqeust the reqeust
	 * @return the response DTO
	 * @throws BookingEngineException the booking engine exception
	 */
	@ResponseBody
    @RequestMapping(value = "/createResort", method = RequestMethod.POST)
	public ResponseDTO createResort(@RequestBody final HsdResortRoomMasterDTO reqeust)throws BookingEngineException {
		logger.info("HsdResortRoomMasterController : createResort : Entered.");
        ResponseDTO response = hsdResortRoomMasterService.createResortInfo(reqeust);
        logger.info("HsdResortRoomMasterController : createResort : leaving.");
        return response;
    }
	
	/**
	 * Update resort room.
	 *
	 * @param request the request
	 * @return the response DTO
	 * @throws BookingEngineException the booking engine exception
	 */
	@ResponseBody
    @RequestMapping(value = "/updateResort", method = RequestMethod.POST)
	public ResponseDTO updateResortRoom(@RequestBody final HsdResortRoomMasterUpdateDTO request)throws BookingEngineException {
		logger.info("HsdResortRoomMasterController : updateResortRoom : Entered.");
        ResponseDTO response = hsdResortRoomMasterService.updateResortRoom(request);
        logger.info("HsdResortRoomMasterController : updateResortRoom : leaving.");
        return response;
    }
	
	@ResponseBody
    @RequestMapping(value = "/getRatePlans", method = RequestMethod.GET)
	public ResponseDTO getRatePlans()throws BookingEngineException {
		logger.info("HsdResortRoomMasterController : getRatePlans: Begin");
		
        ResponseDTO response = hsdResortRoomMasterService.getRatePlans();
        
        logger.info("HsdResortRoomMasterController : getRatePlans: End");
        return response;
    }
	
	@ResponseBody
    @RequestMapping(value = "/createRoomType", method = RequestMethod.POST)
	public ResponseDTO createRoomType(@RequestBody final HsdCreateResortRoomTypeDTO reqeust)throws BookingEngineException {
		logger.info("HsdResortRoomMasterController : createRoomType : Entered.");
        ResponseDTO response = hsdResortRoomMasterService.createRoomType(reqeust);
        logger.info("HsdResortRoomMasterController : createRoomType : leaving.");
        return response;
    }
	
	@ResponseBody
    @RequestMapping(value = "/getAllResorts", method = RequestMethod.POST)
	public ResponseDTO getAllResorts()throws BookingEngineException {
		logger.info("HsdResortRoomMasterController : getAllResorts : Entered.");
        ResponseDTO response = hsdResortRoomMasterService.getAllResorts();
        logger.info("HsdResortRoomMasterController : getAllResorts : leaving.");        
        return response;
    }
	
	@ResponseBody
    @RequestMapping(value = "/getAllRoomTypes", method = RequestMethod.POST)
	public ResponseDTO getAllRoomTypes()throws BookingEngineException {
		logger.info("HsdResortRoomMasterController : getAllRoomTypes : Entered.");
        ResponseDTO response = hsdResortRoomMasterService.getAllRoomTypes();
        logger.info("HsdResortRoomMasterController : getAllRoomTypes : leaving.");        
        return response;
    }
	
	@ResponseBody
    @RequestMapping(value = "/createRatePlan", method = RequestMethod.POST)
	public ResponseDTO createRatePlan(@RequestBody final HsdCreateResortRatePlanDTO reqeust)throws BookingEngineException {
		logger.info("HsdResortRoomMasterController : createRatePlan : Entered.");
        ResponseDTO response = hsdResortRoomMasterService.createRatePlan(reqeust);
        logger.info("HsdResortRoomMasterController : createRatePlan : leaving.");
        return response;
    }
	
	@ResponseBody
    @RequestMapping(value = "/updateRatePlan", method = RequestMethod.POST)
	public ResponseDTO updateRatePlan(@RequestBody final HsdRatePlanUpdateDTO request)throws BookingEngineException {
		logger.info("HsdResortRoomMasterController : updateRatePlan : Entered.");
        ResponseDTO response = hsdResortRoomMasterService.updateRatePlan(request);
        logger.info("HsdResortRoomMasterController : updateRatePlan : leaving.");
        return response;
    }
	
	@ResponseBody
    @RequestMapping(value = "/updateRoomType", method = RequestMethod.POST)
	public ResponseDTO updateRoomType(@RequestBody final HsdRoomTypeUpdateDTO request)throws BookingEngineException {
		logger.info("HsdResortRoomMasterController : updateRoomType : Entered.");
        ResponseDTO response = hsdResortRoomMasterService.updateRoomType(request);
        logger.info("HsdResortRoomMasterController : updateRoomType : leaving.");
        return response;
    }
	
	@ResponseBody
    @RequestMapping(value = "/createCalendar", method = RequestMethod.POST)
	public ResponseDTO createCalendar(@RequestBody final HsdCreateCalendarRequestDTO reqeust)throws BookingEngineException {
		logger.info("HsdResortRoomMasterController : createCalendar : Entered.");
        ResponseDTO response = hsdResortRoomMasterService.createCalendar(reqeust);
        logger.info("HsdResortRoomMasterController : createCalendar : leaving.");
        return response;
    }

	@ResponseBody
    @RequestMapping(value = "/getAllResortMapping", method = RequestMethod.POST)
	public ResponseDTO getResortMapping(@RequestBody final String resortId)throws BookingEngineException {
		logger.info("HsdResortRoomMasterController : getResortMapping : Entered.");
        ResponseDTO response = hsdResortRoomMasterService.getResortMapping(resortId);
        logger.info("HsdResortRoomMasterController : getResortMapping : leaving.");        
        return response;
    }
	
	@ResponseBody
    @RequestMapping(value = "/createNewEntries", method = RequestMethod.POST)
	public ResponseDTO createNewEntries(@RequestBody final HsdCreateCalendarRequestDTO reqeust)throws BookingEngineException {
		logger.info("HsdResortRoomMasterController : createNewEntries : Entered.");
        ResponseDTO response = hsdResortRoomMasterService.createNewEntries(reqeust);
        logger.info("HsdResortRoomMasterController : createNewEntries : leaving.");
        return response;
    }
}
