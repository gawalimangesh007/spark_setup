package com.sterling.bookingapi.dto.response;

import java.io.Serializable;

import com.sterling.bookingapi.context.RequestThreadLocal;
import com.sterling.bookingapi.utils.MessageConstants;

/**
 * @author tcs
 * @version 1.0
 */
public class ResponseDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	/** The request id. */
	private String requestId = RequestThreadLocal.get().getRequestId();
	
	/** The status. */
	private String status = MessageConstants.SUCCESS;
	
	/** The status message. */
	private String statusMessage;
	
	/** The status code. */
	private int statusCode;
	
	/** The data. */
	private Object data;
	
	/** The errors. */
	private Object errors;

	private String apiError;
	
	public ResponseDTO() {
		super();
	}
	
	public ResponseDTO(Object data) {
		this.status = MessageConstants.SUCCESS;
		this.data = data;
		this.statusCode =200;
	}
	
	public ResponseDTO(String msg, Object errors) {
		this.status = MessageConstants.FAIL;
		this.statusMessage = msg;
		this.errors = errors;
		this.statusCode =500;
	}
	
	public ResponseDTO(String msg, int errCode) {
		this.status = MessageConstants.FAIL;
		this.statusMessage = msg;
		this.statusCode = errCode;
	}
	
	public String getApiError() {
		return apiError;
	}

	public void setApiError(String apiError) {
		this.apiError = apiError;
	}

	/**
	 * Gets the status message.
	 *
	 * @return the status message
	 */
	public String getStatusMessage() {
		return statusMessage;
	}
	
	/**
	 * Sets the status message.
	 *
	 * @param statusMessage the new status message
	 */
	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}
	
	/**
	 * Gets the errors.
	 *
	 * @return the errors
	 */
	public Object getErrors() {
		return errors;
	}
	
	/**
	 * Sets the errors.
	 *
	 * @param errors the new errors
	 */
	public void setErrors(Object errors) {
		this.errors = errors;
	}
	
	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	
	/**
	 * Sets the status.
	 *
	 * @param status the new status
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	
	/**
	 * Gets the data.
	 *
	 * @return the data
	 */
	public Object getData() {
		return data;
	}
	
	/**
	 * Sets the data.
	 *
	 * @param data the new data
	 */
	public void setData(Object data) {
		this.data = data;
	}
	
	/**
	 * Gets the request id.
	 *
	 * @return the request id
	 */
	public String getRequestId() {
		return requestId;
	}


	/**
	 * @return statusCode
	 */
	public int getStatusCode() {
		return statusCode;
	}


	/**
	 * @param statusCode
	 * set the statusCode
	 */
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	
}
