package com.sterling.bookingapi.engine.rules.models;

import java.io.Serializable;

public class RulesParameter implements Serializable {
	private static final long serialVersionUID = 1L;

	private String parameter;
	private String value;
	
	public String getParameter() {
		return parameter;
	}
	public void setParameter(String parameter) {
		this.parameter = parameter;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}



	/*
	  {
            "parameter": "minpoints",
            "value": ""
          }
	 */
}
