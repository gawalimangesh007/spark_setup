package com.sterling.bookingapi.dto.maximojo.response;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class HotelReservationIDResDTO.
 * @author tcs
 * @version 1.0
 */
public class HotelReservationIDResDTO {

	/** The res I D type. */
	@JacksonXmlProperty(localName = "ResID_Type", isAttribute = true)
	private String resID_Type;

	/** The res I D value. */
	@JacksonXmlProperty(localName = "ResID_Value", isAttribute = true)
    private String resID_Value;

	/** The for guest. */
	@JacksonXmlProperty(localName = "ForGuest", isAttribute = true)
	private String forGuest;
	
	/**
	 * Gets the res I D type.
	 *
	 * @return the resID_Type
	 */
	public String getResID_Type() {
		return resID_Type;
	}

	/**
	 * Sets the res I D type.
	 *
	 * @param resID_Type the resID_Type to set
	 */
	public void setResID_Type(String resID_Type) {
		this.resID_Type = resID_Type;
	}

	/**
	 * Gets the res I D value.
	 *
	 * @return the resID_Value
	 */
	public String getResID_Value() {
		return resID_Value;
	}

	/**
	 * Sets the res I D value.
	 *
	 * @param resID_Value the resID_Value to set
	 */
	public void setResID_Value(String resID_Value) {
		this.resID_Value = resID_Value;
	}

	/**
	 * Gets the for guest.
	 *
	 * @return the forGuest
	 */
	public String getForGuest() {
		return forGuest;
	}

	/**
	 * Sets the for guest.
	 *
	 * @param forGuest the forGuest to set
	 */
	public void setForGuest(String forGuest) {
		this.forGuest = forGuest;
	}
	
	
}
