package com.sterling.bookingapi.models;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The Class BaseModel.
 */
/**
 * @author tcs
 *
 */
@MappedSuperclass
public class BaseModel implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 3226670303114707274L;
	
	private static final String ADMIN = "admin";

	/** The created on. */
	@Column(name = "created_date")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdOn;

	/** The created by. */
	@Column(name = "created_by", length = 20)
	private String createdBy = ADMIN;

	/** The updated on. */
	@Column(name = "modified_date")
	@Temporal(TemporalType.TIMESTAMP)
	private Date updatedOn;

	/** The updated by. */
	@Column(name = "modified_by", length = 20)
	private String updatedBy = ADMIN;


	/**
	 * Gets the created by.
	 *
	 * @return the created by
	 */
	public String getCreatedBy() {
		return createdBy;
	}
	
	/**
	 * Sets the created by.
	 *
	 * @param createdBy the new created by
	 */
	public void setCreatedBy(String createdBy) {
		if(createdBy==null) {
			createdBy = ADMIN;
		}
		this.createdBy = createdBy;
	}


	/**
	 * Gets the updated by.
	 *
	 * @return the updated by
	 */
	public String getUpdatedBy() {
		return updatedBy;
	}
	
	/**
	 * Sets the updated by.
	 *
	 * @param updatedBy the new updated by
	 */
	public void setUpdatedBy(String updatedBy) {
		if(updatedBy==null) {
			updatedBy = ADMIN;
		}
		this.updatedBy = updatedBy;
	}

	/**
	 * Sets createdAt before insert.
	 */
	@PrePersist
	public void setCreationDate() {
		this.createdOn = new Date();
	}

	/**
	 * Sets updatedAt before update.
	 */
	@PreUpdate
	public void setChangeDate() {
		this.updatedOn = new Date();
	}


}
