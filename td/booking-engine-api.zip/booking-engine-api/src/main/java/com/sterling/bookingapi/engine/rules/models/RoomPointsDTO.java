package com.sterling.bookingapi.engine.rules.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class RoomPointsDTO {

	@JsonProperty("_1BR")
	private Double oneBR;
	
	@JsonProperty("_2BR")
	private Double twoBR;
	
	@JsonProperty("_GR")
	private Double gr;
	
	@JsonProperty("_ST")
	private Double st;

	public Double getOneBR() {
		return oneBR;
	}

	public void setOneBR(Double oneBR) {
		this.oneBR = oneBR;
	}

	public Double getTwoBR() {
		return twoBR;
	}

	public void setTwoBR(Double twoBR) {
		this.twoBR = twoBR;
	}

	public Double getGr() {
		return gr;
	}

	public void setGr(Double gr) {
		this.gr = gr;
	}

	public Double getSt() {
		return st;
	}

	public void setSt(Double st) {
		this.st = st;
	}

}
