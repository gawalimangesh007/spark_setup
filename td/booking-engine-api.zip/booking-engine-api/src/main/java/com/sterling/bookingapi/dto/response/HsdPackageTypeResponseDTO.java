package com.sterling.bookingapi.dto.response;


import java.util.List;

/**
 * @author tcs
 * @version 1.0
 */
public class HsdPackageTypeResponseDTO {
	
	/** The package types. */
	private List<Enum> packageTypes ;

	/**
	 * Gets the package types.
	 *
	 * @return the package types
	 */
	public List<Enum> getPackageTypes() {
		return packageTypes;
	}

	/**
	 * Sets the package types.
	 *
	 * @param packageTypes the new package types
	 */
	public void setPackageTypes(List<Enum> packageTypes) {
		this.packageTypes = packageTypes;
	}



}
