package com.sterling.bookingapi.auth.bean;

import java.util.UUID;

/**
 * @author tcs
 *
 */
public class Info {

	private String key;
	private Long code;
	private String desc;
	private Object object;
	
	public Info(){
		key = UUID.randomUUID().toString();
		code = 0L;
	}
	
	/**
	 * @return key
	 */
	public String getKey() {
		return key;
	}
	/**
	 * @param key
	 * set the key
	 */
	public void setKey(String key) {
		this.key = key;
	}
	/**
	 * @return code
	 */
	public Long getCode() {
		return code;
	}
	/**
	 * @param code
	 * set the code
	 */
	public void setCode(Long code) {
		this.code = code;
	}
	/**
	 * @return desc
	 */
	public String getDesc() {
		return desc;
	}
	/**
	 * @param desc
	 * set the desc
	 */
	public void setDesc(String desc) {
		this.desc = desc;
	}
	
	/**
	 * @return object
	 */
	public Object getObject() {
		return object;
	}

	/**
	 * @param object
	 * set the object
	 */
	public void setObject(Object object) {
		this.object = object;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Info [code=" + code + ", desc=" + desc + ", object=" + object + "]";
	}
	
}
