package com.sterling.bookingapi.dto.request;

import com.sterling.bookingapi.utils.AppConstants.RegisterUserType;

/**
 * @author 1269948
 *
 */
public class VOUpdatePasswordDTO {
	
	private String id;
	private String currentPassword;
	private String oldPasswordOne;
	private String oldPasswordTwo;
	private String uniqueId;
	private String newPassword;
	private String webStatus;
	private RegisterUserType updateForType;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getCurrentPassword() {
		return currentPassword;
	}
	public void setCurrentPassword(String currentPassword) {
		this.currentPassword = currentPassword;
	}
	public String getOldPasswordOne() {
		return oldPasswordOne;
	}
	public void setOldPasswordOne(String oldPasswordOne) {
		this.oldPasswordOne = oldPasswordOne;
	}
	public String getOldPasswordTwo() {
		return oldPasswordTwo;
	}
	public void setOldPasswordTwo(String oldPasswordTwo) {
		this.oldPasswordTwo = oldPasswordTwo;
	}
	public String getUniqueId() {
		return uniqueId;
	}
	public void setUniqueId(String uniqueId) {
		this.uniqueId = uniqueId;
	}
	public String getNewPassword() {
		return newPassword;
	}
	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}
	public String getWebStatus() {
		return webStatus;
	}
	public void setWebStatus(String webStatus) {
		this.webStatus = webStatus;
	}
	public RegisterUserType getUpdateForType() {
		return updateForType;
	}
	public void setUpdateForType(RegisterUserType updateForType) {
		this.updateForType = updateForType;
	}
}
