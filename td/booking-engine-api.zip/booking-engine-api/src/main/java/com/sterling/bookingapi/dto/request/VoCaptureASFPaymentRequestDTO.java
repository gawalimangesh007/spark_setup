package com.sterling.bookingapi.dto.request;

import java.io.Serializable;
import java.util.List;

import com.sterling.bookingapi.sf.dto.request.VOPGDetailsDTO;

public class VoCaptureASFPaymentRequestDTO extends VoBaseRequestDTO implements Serializable {
	private static final long serialVersionUID = 1L;
	private String contractId;
	private String primaryApplicantId;
	private VOPGDetailsDTO voPaymentGatewayDetails;
	private List<VOEMIASFDetailsDTO> asfDetailsList;
	
	public String getPrimaryApplicantId() {
		return primaryApplicantId;
	}
	public void setPrimaryApplicantId(String primaryApplicantId) {
		this.primaryApplicantId = primaryApplicantId;
	}
	public VOPGDetailsDTO getVoPaymentGatewayDetails() {
		return voPaymentGatewayDetails;
	}
	public void setVoPaymentGatewayDetails(VOPGDetailsDTO voPaymentGatewayDetails) {
		this.voPaymentGatewayDetails = voPaymentGatewayDetails;
	}	
	public String getContractId() {
		return contractId;
	}
	public void setContractId(String contractId) {
		this.contractId = contractId;
	}
	public List<VOEMIASFDetailsDTO> getAsfDetailsList() {
		return asfDetailsList;
	}
	public void setAsfDetailsList(List<VOEMIASFDetailsDTO> asfDetailsList) {
		this.asfDetailsList = asfDetailsList;
	}
		
}
