package com.sterling.bookingapi.dto.request;

import java.io.Serializable;

/**
 * @author tcs
 *
 */
public class VOCaptureDownPaymentRequest implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String saleId;
	private Double amount;
	private String transactionId;
	private String paymentStatus;
	
	/**
	 * @return saled id
	 */
	public String getSaleId() {
		return saleId;
	}
	/**
	 * @param saleId
	 * set the sales id
	 */
	public void setSaleId(String saleId) {
		this.saleId = saleId;
	}
	/**
	 * @return amount
	 */
	public Double getAmount() {
		return amount;
	}
	/**
	 * @param amount
	 * set the amount
	 */
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	/**
	 * @return transaction id
	 */
	public String getTransactionId() {
		return transactionId;
	}
	/**
	 * @param transactionId
	 * set the transaction id
	 */
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	/**
	 * @return payment status
	 */
	public String getPaymentStatus() {
		return paymentStatus;
	}
	/**
	 * @param paymentStatus
	 * set the payment status
	 */
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}
}
