package com.sterling.bookingapi.dto.response;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author tcs
 * @version 1.0
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class DueDetails implements Serializable {
	
	private static final long serialVersionUID = 1L;

	private String connectorId;
	private List<String> collectionIds;
	private String structureId;
	private String invoiceNumber;
	private String dueDate;
	private String invoiceDate;
	private Double invoiceAmount;
	private Double dueAmount;
	private Double balanceAmount;
	private Double overDueAmount;
	private String paymentType;
	private String paymentName;
	private String latePaymentCharge;
	private String year;
	private String feeType;
	
	
	public String getPaymentName() {
		return paymentName;
	}

	public void setPaymentName(String paymentName) {
		this.paymentName = paymentName;
	}

	public Double getBalanceAmount() {
		return balanceAmount;
	}

	public Double getInvoiceAmount() {
		return invoiceAmount;
	}

	public void setInvoiceAmount(Double invoiceAmount) {
		this.invoiceAmount = invoiceAmount;
	}

	public void setBalanceAmount(Double balanceAmount) {
		this.balanceAmount = balanceAmount;
	}

	public String getFeeType() {
		return feeType;
	}

	public void setFeeType(String feeType) {
		this.feeType = feeType;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public List<String> getCollectionIds() {
		return collectionIds;
	}

	public void setCollectionIds(List<String> collectionIds) {
		this.collectionIds = collectionIds;
	}

	public String getConnectorId() {
		return connectorId;
	}

	public void setConnectorId(String connectorId) {
		this.connectorId = connectorId;
	}

	public String getStructureId() {
		return structureId;
	}

	public void setStructureId(String structureId) {
		this.structureId = structureId;
	}

	public String getInvoiceNumber() {
		return invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public String getDueDate() {
		return dueDate;
	}

	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}

	public String getInvoiceDate() {
		return invoiceDate;
	}

	public void setInvoiceDate(String invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	public Double getDueAmount() {
		return dueAmount;
	}

	public void setDueAmount(Double dueAmount) {
		this.dueAmount = dueAmount;
	}

	public Double getOverDueAmount() {
		return overDueAmount;
	}

	public void setOverDueAmount(Double overDueAmount) {
		this.overDueAmount = overDueAmount;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public String getLatePaymentCharge() {
		return latePaymentCharge;
	}

	public void setLatePaymentCharge(String latePaymentCharge) {
		this.latePaymentCharge = latePaymentCharge;
	}	
}
