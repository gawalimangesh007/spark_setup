package com.sterling.bookingapi.dto.maximojo.response;

import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class RoomRateResDTO.
 * @author tcs
 * @version 1.0
 */
public class RoomRateResDTO {

	/** The Number of units. */
	@JacksonXmlProperty(localName = "NumberOfUnits", isAttribute = true)
	private String NumberOfUnits;

	/** The Rate. */
	@JacksonXmlElementWrapper(useWrapping=true, localName = "Rates")
	@JacksonXmlProperty(localName = "Rate")
    private List<RetrieveRateResDTO> Rate;

	/** The Rate plan code. */
	@JacksonXmlProperty(localName = "RatePlanCode", isAttribute = true)
    private String RatePlanCode;

	/** The Room type code. */
	@JacksonXmlProperty(localName = "RoomTypeCode", isAttribute = true)
    private String RoomTypeCode;

	/**
	 * Gets the number of units.
	 *
	 * @return the numberOfUnits
	 */
	public String getNumberOfUnits() {
		return NumberOfUnits;
	}

	/**
	 * Sets the number of units.
	 *
	 * @param numberOfUnits the numberOfUnits to set
	 */
	public void setNumberOfUnits(String numberOfUnits) {
		NumberOfUnits = numberOfUnits;
	}

	/**
	 * Gets the rate.
	 *
	 * @return the rate
	 */
	public List<RetrieveRateResDTO> getRate() {
		return Rate;
	}

	/**
	 * Sets the rate.
	 *
	 * @param rate the rate to set
	 */
	public void setRate(List<RetrieveRateResDTO> rate) {
		Rate = rate;
	}

	/**
	 * Gets the rate plan code.
	 *
	 * @return the ratePlanCode
	 */
	public String getRatePlanCode() {
		return RatePlanCode;
	}

	/**
	 * Sets the rate plan code.
	 *
	 * @param ratePlanCode the ratePlanCode to set
	 */
	public void setRatePlanCode(String ratePlanCode) {
		RatePlanCode = ratePlanCode;
	}

	/**
	 * Gets the room type code.
	 *
	 * @return the roomTypeCode
	 */
	public String getRoomTypeCode() {
		return RoomTypeCode;
	}

	/**
	 * Sets the room type code.
	 *
	 * @param roomTypeCode the roomTypeCode to set
	 */
	public void setRoomTypeCode(String roomTypeCode) {
		RoomTypeCode = roomTypeCode;
	}
	
	
	
	
}
