package com.sterling.bookingapi.dto.response;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @authortcs
 * @version 1.0
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class LapsedPoints implements Serializable {
	
	private static final long serialVersionUID = 1L;

	private Integer balance;
	private String description;
	private String lapsingDate;
	private Integer lapsingPoint;
	private String type;
	//private String name;
	//private String sterlingContract;
	

	/**
	 * @return balance
	 */
	public Integer getBalance() {
		return balance;
	}
	/**
	 * @param balance
	 * set the balance
	 */
	public void setBalance(Integer balance) {
		this.balance = balance;
	}
	/**
	 * @return description
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description
	 * set the description
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return lapsingDate
	 */
	public String getLapsingDate() {
		return lapsingDate;
	}
	/**
	 * @param lapsingDate
	 * set the lapsingDate
	 */
	public void setLapsingDate(String lapsingDate) {
		this.lapsingDate = lapsingDate;
	}
	/**
	 * @return lapsingPoint
	 */
	public Integer getLapsingPoint() {
		return lapsingPoint;
	}
	/**
	 * @param lapsingPoint
	 * set the lapsingPoint
	 */
	public void setLapsingPoint(Integer lapsingPoint) {
		this.lapsingPoint = lapsingPoint;
	}
	/**
	 * @return type
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type
	 * set the type
	 */
	public void setType(String type) {
		this.type = type;
	}
	
}
