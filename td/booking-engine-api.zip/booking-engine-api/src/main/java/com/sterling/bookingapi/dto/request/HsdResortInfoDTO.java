package com.sterling.bookingapi.dto.request;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class HsdResortInfoDTO {
	
	/** The location id. */
	private String locationId;
	
	/** The location name. */
	private String locationName;
	
	/** The resort id. */
	@NotEmpty(message="Resort Id should not be empty")
	private String channelManagerResortID;
	
	/** The resort name. */
	@NotEmpty(message="Resort Name should not be empty")
	private String resortName ;

	public String getChannelManagerResortID() {
		return channelManagerResortID;
	}

	public void setChannelManagerResortID(String channelManagerResortID) {
		this.channelManagerResortID = channelManagerResortID;
	}

	/**
	 * @return the locationId
	 */
	public String getLocationId() {
		return locationId;
	}

	/**
	 * @param locationId the locationId to set
	 */
	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}

	/**
	 * @return the locationName
	 */
	public String getLocationName() {
		return locationName;
	}

	/**
	 * @param locationName the locationName to set
	 */
	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}

	

	/**
	 * @return the resortName
	 */
	public String getResortName() {
		return resortName;
	}

	/**
	 * @param resortName the resortName to set
	 */
	public void setResortName(String resortName) {
		this.resortName = resortName;
	}
}
