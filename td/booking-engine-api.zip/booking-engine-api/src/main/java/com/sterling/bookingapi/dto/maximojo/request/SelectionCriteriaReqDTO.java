package com.sterling.bookingapi.dto.maximojo.request;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class SelectionCriteriaReqDTO.
 */
/**
 * @author tcs
 *
 */
public class SelectionCriteriaReqDTO {

	/** The selection type. */
	@JacksonXmlProperty(localName = "SelectionType", isAttribute = true)
	 private String selectionType;

	/**
	 * Gets the selection type.
	 *
	 * @return the selectionType
	 */
	public String getSelectionType() {
		return selectionType;
	}

	/**
	 * Sets the selection type.
	 *
	 * @param selectionType the selectionType to set
	 */
	public void setSelectionType(String selectionType) {
		this.selectionType = selectionType;
	}
	 
	 
}
