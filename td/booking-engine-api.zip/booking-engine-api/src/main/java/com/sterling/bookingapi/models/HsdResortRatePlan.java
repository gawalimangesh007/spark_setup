package com.sterling.bookingapi.models;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;


/**
 * The Class HsdResortRatePlan.
 */
/**
 * @author tcs
 *
 */
@Entity
@Table(name = "sh_hsd_rate_plan_resort")
public class HsdResortRatePlan extends BaseModel{

	/** The id. */
	@Id
	@GeneratedValue( strategy = GenerationType.IDENTITY )
	@Column(name = "rate_idx_id", unique = false)
	private int id;
	
	/** The hsd resort room master. */
	@ManyToOne(fetch = FetchType.EAGER,optional = false)
	@Cascade(CascadeType.SAVE_UPDATE)
	@JoinColumn(name="resort_room_id",nullable = false)
	private HsdResortRoomMaster hsdResortRoomMaster;
	
	/** The hsd rate plan master. */
	@ManyToOne(fetch = FetchType.EAGER,optional = false)
	@Cascade(CascadeType.SAVE_UPDATE)
	@JoinColumn(name="rate_plan_id",nullable = false)
	private HsdRatePlanMaster hsdRatePlanMaster ;
	
	/** The available date. */
	@Column(name = "available_date",nullable = false)
	private Date availableDate ;
	
	/** The per day rate. */
	@Column(name = "per_day_rate",nullable = true)
	private double perDayRate;
	
	/** The extra person charge. */
	@Column(name = "extra_person_charge",nullable = false)
	private double extraPersonCharge;
	
	/** The single occupancy rate. */
	@Column(name = "single_occupancy_Rate",nullable = false)
	private double singleOccupancyRate;
	
	/** The double occupancy rate. */
	@Column(name = "double_Occupancy_Rate",nullable = false)
	private double doubleOccupancyRate;
	
	/** The triple occupancy rate. */
	@Column(name = "triple_occupancy_Rate",nullable = true)
	private double tripleOccupancyRate;
	
	/** The quadruple occupancy rate. */
	@Column(name = "quadruple_occupancy_Rate",nullable = true)
	private double quadrupleOccupancyRate;
	
	/** The min stay days. */
	@Column(name = "min_stay_days",nullable = true)
	private int minStayDays;
	
	/** The max stay days. */
	@Column(name = "max_stay_days",nullable = true)
	private int maxStayDays;
	
	/** The active. */
	@Column(name = "status",nullable = false)
	private boolean active;
	
	/** The tax inclusive. */
	@Column(name = "tax_inclusive",nullable = false)
	private boolean taxInclusive;


	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * Gets the hsd resort room master.
	 *
	 * @return the hsd resort room master
	 */
	public HsdResortRoomMaster getHsdResortRoomMaster() {
		return hsdResortRoomMaster;
	}

	/**
	 * Sets the hsd resort room master.
	 *
	 * @param hsdResortRoomMaster the new hsd resort room master
	 */
	public void setHsdResortRoomMaster(HsdResortRoomMaster hsdResortRoomMaster) {
		this.hsdResortRoomMaster = hsdResortRoomMaster;
	}

	/**
	 * Gets the hsd rate plan master.
	 *
	 * @return the hsd rate plan master
	 */
	public HsdRatePlanMaster getHsdRatePlanMaster() {
		return hsdRatePlanMaster;
	}

	/**
	 * Sets the hsd rate plan master.
	 *
	 * @param hsdRatePlanMaster the new hsd rate plan master
	 */
	public void setHsdRatePlanMaster(HsdRatePlanMaster hsdRatePlanMaster) {
		this.hsdRatePlanMaster = hsdRatePlanMaster;
	}

	/**
	 * Gets the available date.
	 *
	 * @return the available date
	 */
	public Date getAvailableDate() {
		return availableDate;
	}

	/**
	 * Sets the available date.
	 *
	 * @param availableDate the new available date
	 */
	public void setAvailableDate(Date availableDate) {
		this.availableDate = availableDate;
	}

	/**
	 * Gets the per day rate.
	 *
	 * @return the per day rate
	 */
	public double getPerDayRate() {
		return perDayRate;
	}

	/**
	 * Sets the per day rate.
	 *
	 * @param perDayRate the new per day rate
	 */
	public void setPerDayRate(double perDayRate) {
		this.perDayRate = perDayRate;
	}

	/**
	 * Gets the extra person charge.
	 *
	 * @return the extra person charge
	 */
	public double getExtraPersonCharge() {
		return extraPersonCharge;
	}

	/**
	 * Sets the extra person charge.
	 *
	 * @param extraPersonCharge the new extra person charge
	 */
	public void setExtraPersonCharge(double extraPersonCharge) {
		this.extraPersonCharge = extraPersonCharge;
	}


	/**
	 * Gets the single occupancy rate.
	 *
	 * @return the single occupancy rate
	 */
	public double getSingleOccupancyRate() {
		return singleOccupancyRate;
	}

	/**
	 * Sets the single occupancy rate.
	 *
	 * @param singleOccupancyRate the new single occupancy rate
	 */
	public void setSingleOccupancyRate(double singleOccupancyRate) {
		this.singleOccupancyRate = singleOccupancyRate;
	}

	/**
	 * Gets the double occupancy rate.
	 *
	 * @return the double occupancy rate
	 */
	public double getDoubleOccupancyRate() {
		return doubleOccupancyRate;
	}

	/**
	 * Sets the double occupancy rate.
	 *
	 * @param doubleOccupancyRate the new double occupancy rate
	 */
	public void setDoubleOccupancyRate(double doubleOccupancyRate) {
		this.doubleOccupancyRate = doubleOccupancyRate;
	}

	/**
	 * Gets the triple occupancy rate.
	 *
	 * @return the triple occupancy rate
	 */
	public double getTripleOccupancyRate() {
		return tripleOccupancyRate;
	}

	/**
	 * Sets the triple occupancy rate.
	 *
	 * @param tripleOccupancyRate the new triple occupancy rate
	 */
	public void setTripleOccupancyRate(double tripleOccupancyRate) {
		this.tripleOccupancyRate = tripleOccupancyRate;
	}

	/**
	 * Gets the quadruple occupancy rate.
	 *
	 * @return the quadruple occupancy rate
	 */
	public double getQuadrupleOccupancyRate() {
		return quadrupleOccupancyRate;
	}

	/**
	 * Sets the quadruple occupancy rate.
	 *
	 * @param quadrupleOccupancyRate the new quadruple occupancy rate
	 */
	public void setQuadrupleOccupancyRate(double quadrupleOccupancyRate) {
		this.quadrupleOccupancyRate = quadrupleOccupancyRate;
	}

	/**
	 * Gets the min stay days.
	 *
	 * @return the min stay days
	 */
	public int getMinStayDays() {
		return minStayDays;
	}

	/**
	 * Sets the min stay days.
	 *
	 * @param minStayDays the new min stay days
	 */
	public void setMinStayDays(int minStayDays) {
		this.minStayDays = minStayDays;
	}

	/**
	 * Gets the max stay days.
	 *
	 * @return the max stay days
	 */
	public int getMaxStayDays() {
		return maxStayDays;
	}

	/**
	 * Sets the max stay days.
	 *
	 * @param maxStayDays the new max stay days
	 */
	public void setMaxStayDays(int maxStayDays) {
		this.maxStayDays = maxStayDays;
	}

	/**
	 * Checks if is active.
	 *
	 * @return the active
	 */
	public boolean isActive() {
		return active;
	}

	/**
	 * Sets the active.
	 *
	 * @param active the active to set
	 */
	public void setActive(boolean active) {
		this.active = active;
	}

	/**
	 * Checks if is tax inclusive.
	 *
	 * @return the taxInclusive
	 */
	public boolean isTaxInclusive() {
		return taxInclusive;
	}

	/**
	 * Sets the tax inclusive.
	 *
	 * @param taxInclusive the taxInclusive to set
	 */
	public void setTaxInclusive(boolean taxInclusive) {
		this.taxInclusive = taxInclusive;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "HsdResortRatePlan [id=" + id + ", hsdResortRoomMaster="
				+ hsdResortRoomMaster.getResortRoomId() + ", hsdRatePlanMaster="
				+ hsdRatePlanMaster.getRatePlanId() + ", availableDate=" + availableDate
				+ ", doubleOccupancyRate=" + doubleOccupancyRate + ", active="
				+ active + "]";
	}

}
