package com.sterling.bookingapi.exception;


/**
 * The Class BookingEngineException.
 */
/**
 * @author tcs
 * @version 1.0
 *
 */
public class BookingEngineException extends RuntimeException {
	
	private int errCode;
	private String errLabel;

	    /** The Constant serialVersionUID. */
	private static final long serialVersionUID = 56926887849907529L;

		/**
	     * Constructs a new instance of this class with <code>null</code> as its
	     * detail message.
	     */
	    public BookingEngineException() {
	        super();
	    }
	    
	    public BookingEngineException(int errCode) {
	    	super();
	    	this.errCode = errCode;
	    }
	    
	    public BookingEngineException(int errCode, String message) {
	    	super(message);
	    	this.errCode = errCode;
	    }
	    
	    

	    public BookingEngineException(int errCode, String errLabel, String message) {
	    	super(message);
			this.errCode = errCode;
			this.errLabel = errLabel;
		}

	    public BookingEngineException(String errLabel, String message) {
	    	super(message);
	    	this.errLabel = errLabel;
	    }

		/**
	     * Constructs a new instance of this class with the specified detail
	     * message.
	     *
	     * @param message the detail message. The detail message is saved for later
	     *                retrieval by the {@link #getMessage()} method.
	     */
	    public BookingEngineException(String message) {
	        super(message);
	    }

	    /**
	     * Constructs a new instance of this class with the specified detail message
	     * and root cause.
	     *
	     * @param message   the detail message. The detail message is saved for later
	     *                  retrieval by the {@link #getMessage()} method.
	     * @param rootCause root failure cause
	     */
	    public BookingEngineException(String message, Throwable rootCause) {
	        super(message, rootCause);
	    }

	    /**
	     * Constructs a new instance of this class with the specified root cause.
	     *
	     * @param rootCause root failure cause
	     */
	    public BookingEngineException(Throwable rootCause) {
	        super(rootCause);
	    }

		public int getErrCode() {
			return errCode;
		}

		public void setErrCode(int errCode) {
			this.errCode = errCode;
		}

		public String getErrLabel() {
			return errLabel;
		}

		public void setErrLabel(String errLabel) {
			this.errLabel = errLabel;
		}
		
	}
