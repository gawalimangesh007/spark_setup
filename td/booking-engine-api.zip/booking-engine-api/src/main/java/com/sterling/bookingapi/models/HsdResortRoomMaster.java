package com.sterling.bookingapi.models;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;


/**
 * The Class HsdResortRoomMaster.
 */
/**
 * @author tcs
 *
 */
@Entity
@Table(name = "sh_hsd_resort_room_master")
public class HsdResortRoomMaster  extends BaseModel{
	
	/** The resort room id. */
	@Id
	@GeneratedValue( strategy = GenerationType.IDENTITY )
	@Column(name = "resort_room_id", unique = false,nullable = false)
	private int resortRoomId;
	
	/** The rateplan list. */
	@OneToMany(mappedBy = "hsdResortRoomMaster")
	private List<HsdResortRatePlanMaster> rateplanList;
	
	/** The location id. */
	@Column(name = "location_id",nullable = false)
	private String locationId;
	
	/** The location name. */
	@Column(name = "location_name",nullable = false)
	private String locationName;
	
	/** The resort id. */
	@Column(name = "resort_id",nullable = true)
	private String resortId;
	
	/** The resort name. */
	@Column(name = "resort_name",nullable = false)
	private String resortName ;
	
	/** The room type id. */
	@Column(name = "room_type_id",nullable = false)
	private String roomTypeId;
	
	/** The room type. */
	@Column(name = "room_type",nullable = false)
	private String roomType;
	
	/** The occupancy detail. */
	@Column(name = "occupancy_detail",nullable = true)
	private String occupancyDetail;
	
	/** The max occupancy count. */
	@Column(name = "max_occupancy",nullable = false)
	private int maxOccupancyCount;
	
	/** The base occupancy count. */
	@Column(name = "base_occupancy",nullable = false)
	private int baseOccupancyCount;
	
	/** The extra occupancy adult count. */
	@Column(name = "extra_occupancy_adult",nullable = true)
	private int extraOccupancyAdultCount;
	
	/** The extra occupancy child count. */
	@Column(name = "extra_occupancy_child",nullable = true)
	private int extraOccupancyChildCount;
	
	/** The extra person cost child. */
	@Column(name = "extra_person_cost_child",nullable = true)
	private double extraPersonCostChild;
	
	/** The room count. */
	@Column(name = "room_count",nullable = false)
	private int roomCount;
	
	/** The active. */
	@Column(name = "status",nullable = false)
	private boolean active;

	/**
	 * Gets the location name.
	 *
	 * @return the locationName
	 */
	public String getLocationName() {
		return locationName;
	}

	/**
	 * Sets the location name.
	 *
	 * @param locationName the locationName to set
	 */
	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}

	/**
	 * Gets the resort room id.
	 *
	 * @return the resort room id
	 */
	public int getResortRoomId() {
		return resortRoomId;
	}

	/**
	 * Sets the resort room id.
	 *
	 * @param resortRoomId the new resort room id
	 */
	public void setResortRoomId(int resortRoomId) {
		this.resortRoomId = resortRoomId;
	}

	/**
	 * Gets the location id.
	 *
	 * @return the location id
	 */
	public String getLocationId() {
		return locationId;
	}

	/**
	 * Sets the location id.
	 *
	 * @param locationId the new location id
	 */
	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}

	/**
	 * Gets the resort id.
	 *
	 * @return the resort id
	 */
	public String getResortId() {
		return resortId;
	}

	/**
	 * Sets the resort id.
	 *
	 * @param resortId the new resort id
	 */
	public void setResortId(String resortId) {
		this.resortId = resortId;
	}

	/**
	 * Gets the resort name.
	 *
	 * @return the resort name
	 */
	public String getResortName() {
		return resortName;
	}

	/**
	 * Sets the resort name.
	 *
	 * @param resortName the new resort name
	 */
	public void setResortName(String resortName) {
		this.resortName = resortName;
	}

	/**
	 * Gets the room type id.
	 *
	 * @return the room type id
	 */
	public String getRoomTypeId() {
		return roomTypeId;
	}

	/**
	 * Sets the room type id.
	 *
	 * @param roomTypeId the new room type id
	 */
	public void setRoomTypeId(String roomTypeId) {
		this.roomTypeId = roomTypeId;
	}

	/**
	 * Gets the room type.
	 *
	 * @return the room type
	 */
	public String getRoomType() {
		return roomType;
	}

	/**
	 * Sets the room type.
	 *
	 * @param roomType the new room type
	 */
	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}

	/**
	 * Gets the occupancy detail.
	 *
	 * @return the occupancy detail
	 */
	public String getOccupancyDetail() {
		return occupancyDetail;
	}

	/**
	 * Sets the occupancy detail.
	 *
	 * @param occupancyDetail the new occupancy detail
	 */
	public void setOccupancyDetail(String occupancyDetail) {
		this.occupancyDetail = occupancyDetail;
	}

	/**
	 * Gets the extra occupancy adult count.
	 *
	 * @return the extra occupancy adult count
	 */
	public int getExtraOccupancyAdultCount() {
		return extraOccupancyAdultCount;
	}

	/**
	 * Sets the extra occupancy adult count.
	 *
	 * @param extraOccupancyAdultCount the new extra occupancy adult count
	 */
	public void setExtraOccupancyAdultCount(int extraOccupancyAdultCount) {
		this.extraOccupancyAdultCount = extraOccupancyAdultCount;
	}

	/**
	 * Gets the extra occupancy child count.
	 *
	 * @return the extra occupancy child count
	 */
	public int getExtraOccupancyChildCount() {
		return extraOccupancyChildCount;
	}

	/**
	 * Sets the extra occupancy child count.
	 *
	 * @param extraOccupancyChildCount the new extra occupancy child count
	 */
	public void setExtraOccupancyChildCount(int extraOccupancyChildCount) {
		this.extraOccupancyChildCount = extraOccupancyChildCount;
	}

	/**
	 * Gets the extra person cost child.
	 *
	 * @return the extra person cost child
	 */
	public double getExtraPersonCostChild() {
		return extraPersonCostChild;
	}

	/**
	 * Sets the extra person cost child.
	 *
	 * @param extraPersonCostChild the new extra person cost child
	 */
	public void setExtraPersonCostChild(double extraPersonCostChild) {
		this.extraPersonCostChild = extraPersonCostChild;
	}

	/**
	 * Gets the room count.
	 *
	 * @return the room count
	 */
	public int getRoomCount() {
		return roomCount;
	}

	/**
	 * Sets the room count.
	 *
	 * @param roomCount the new room count
	 */
	public void setRoomCount(int roomCount) {
		this.roomCount = roomCount;
	}

	/**
	 * Gets the max occupancy count.
	 *
	 * @return the max occupancy count
	 */
	public int getMaxOccupancyCount() {
		return maxOccupancyCount;
	}

	/**
	 * Sets the max occupancy count.
	 *
	 * @param maxOccupancyCount the new max occupancy count
	 */
	public void setMaxOccupancyCount(int maxOccupancyCount) {
		this.maxOccupancyCount = maxOccupancyCount;
	}

	/**
	 * Gets the base occupancy count.
	 *
	 * @return the base occupancy count
	 */
	public int getBaseOccupancyCount() {
		return baseOccupancyCount;
	}

	/**
	 * Sets the base occupancy count.
	 *
	 * @param baseOccupancyCount the new base occupancy count
	 */
	public void setBaseOccupancyCount(int baseOccupancyCount) {
		this.baseOccupancyCount = baseOccupancyCount;
	}

	/**
	 * Gets the rateplan list.
	 *
	 * @return the rateplan list
	 */
	public List<HsdResortRatePlanMaster> getRateplanList() {
		return rateplanList;
	}

	/**
	 * Sets the rateplan list.
	 *
	 * @param rateplanList the new rateplan list
	 */
	public void setRateplanList(List<HsdResortRatePlanMaster> rateplanList) {
		this.rateplanList = rateplanList;
	}

	/**
	 * Checks if is active.
	 *
	 * @return true, if is active
	 */
	public boolean isActive() {
		return active;
	}

	/**
	 * Sets the active.
	 *
	 * @param active the new active
	 */
	public void setActive(boolean active) {
		this.active = active;
	}
}
