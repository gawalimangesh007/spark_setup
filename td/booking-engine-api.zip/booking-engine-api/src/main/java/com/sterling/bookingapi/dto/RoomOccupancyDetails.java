package com.sterling.bookingapi.dto;

import java.util.Date;

import com.sterling.bookingapi.utils.BookingEngineUtils;


/**
 * The Class RoomOccupancyDetails.
 */
/**
 * @author tcs
 *
 */
public class RoomOccupancyDetails {

	/** The resort room id. */
	private int resortRoomId;
	
	/** The resort id. */
	private String resortId;
	
	/** The room type id. */
	private String roomTypeId;
	
	/** The resort name. */
	private String resortName;
	
	/** The occupancy detail. */
	private String occupancyDetail;
	
	/** The extra person child cost. */
	private Double extraPersonChildCost;
	
	/** The max occupancy count. */
	private int maxOccupancyCount;
	
	/** The available rooms. */
	private int availableRooms;
	
	/** The base occupancy count. */
	private int baseOccupancyCount;
	
	/** The extra occupancy adult count. */
	private int extraOccupancyAdultCount;
	
	/** The extra occupancy child count. */
	private int extraOccupancyChildCount;
	
	/** The total base occupancy count. */
	private int totalBaseOccupancyCount;
	
	/** The total extra adult occupancy count. */
	private int totalExtraAdultOccupancyCount;
	
	/** The total extra child occupancy count. */
	private int totalExtraChildOccupancyCount;
	
	private Date date;

	
	/**
	 * Instantiates a new room occupancy details.
	 *
	 * @param resortRoomId the resort room id
	 * @param resortId the resort id
	 * @param resortName the resort name
	 * @param roomTypeId the room type id
	 * @param occupancyDetail the occupancy detail
	 * @param extraPersonChildCost the extra person child cost
	 * @param maxOccupancyCount the max occupancy count
	 * @param availableRooms the available rooms
	 * @param baseOccupancyCount the base occupancy count
	 * @param extraOccupancyAdultCount the extra occupancy adult count
	 * @param extraOccupancyChildCount the extra occupancy child count
	 * @param totalBaseOccupancyCount the total base occupancy count
	 * @param totalExtraAdultOccupancyCount the total extra adult occupancy count
	 * @param totalExtraChildOccupancyCount the total extra child occupancy count
	 */
	public RoomOccupancyDetails(int resortRoomId, String resortId,String resortName, String roomTypeId, String occupancyDetail, Double extraPersonChildCost, int maxOccupancyCount, int availableRooms, int baseOccupancyCount, int extraOccupancyAdultCount,
			int extraOccupancyChildCount, int totalBaseOccupancyCount, int totalExtraAdultOccupancyCount, int totalExtraChildOccupancyCount) {

		this.resortRoomId = resortRoomId;
		this.resortId = resortId;
		this.resortName = resortName;
		this.roomTypeId = roomTypeId;
		this.occupancyDetail = occupancyDetail;
		
		this.extraPersonChildCost = BookingEngineUtils.roundDouble(extraPersonChildCost, 2);
		this.maxOccupancyCount = maxOccupancyCount;
		this.availableRooms = availableRooms;
		this.baseOccupancyCount = baseOccupancyCount;
		this.extraOccupancyAdultCount = extraOccupancyAdultCount;
		this.extraOccupancyChildCount = extraOccupancyChildCount;
		this.totalBaseOccupancyCount = totalBaseOccupancyCount;
		this.totalExtraAdultOccupancyCount = totalExtraAdultOccupancyCount;
		this.totalExtraChildOccupancyCount = totalExtraChildOccupancyCount;
	}
	
	public RoomOccupancyDetails(Date date, String resortId, int availableRooms, String roomTypeId) {
		this.date = date;
		this.resortId = resortId;
		this.availableRooms = availableRooms;
		this.roomTypeId = roomTypeId;
	}

	/**
	 * Instantiates a new room occupancy details.
	 *
	 * @param resortRoomId the resort room id
	 * @param resortId the resort id
	 * @param resortName the resort name
	 * @param roomTypeId the room type id
	 * @param occupancyDetail the occupancy detail
	 * @param extraPersonChildCost the extra person child cost
	 * @param maxOccupancyCount the max occupancy count
	 * @param availableRooms the available rooms
	 * @param baseOccupancyCount the base occupancy count
	 * @param extraOccupancyAdultCount the extra occupancy adult count
	 * @param extraOccupancyChildCount the extra occupancy child count
	 */
	public RoomOccupancyDetails(int resortRoomId, String resortId,String resortName, String roomTypeId, String occupancyDetail, Double extraPersonChildCost, int maxOccupancyCount, int availableRooms, int baseOccupancyCount, int extraOccupancyAdultCount,
			int extraOccupancyChildCount, Date availableDate) {

		this.resortRoomId = resortRoomId;
		this.resortId = resortId;
		this.resortName = resortName;
		this.roomTypeId = roomTypeId;
		this.occupancyDetail = occupancyDetail;
		this.date = availableDate;
		
		this.extraPersonChildCost = BookingEngineUtils.roundDouble(extraPersonChildCost, 2);
		this.maxOccupancyCount = maxOccupancyCount;
		this.availableRooms = availableRooms;
		this.baseOccupancyCount = baseOccupancyCount;
		this.extraOccupancyAdultCount = extraOccupancyAdultCount;
		this.extraOccupancyChildCount = extraOccupancyChildCount;
		
		this.totalBaseOccupancyCount = this.availableRooms * this.baseOccupancyCount;
		this.totalExtraAdultOccupancyCount = this.availableRooms * this.extraOccupancyAdultCount;
		this.totalExtraChildOccupancyCount = this.availableRooms * this.extraOccupancyChildCount;
	}
	
	public RoomOccupancyDetails() {
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	/**
	 * Gets the resort room id.
	 *
	 * @return the resort room id
	 */
	public int getResortRoomId() {
		return resortRoomId;
	}


	/**
	 * Sets the resort room id.
	 *
	 * @param resortRoomId the new resort room id
	 */
	public void setResortRoomId(int resortRoomId) {
		this.resortRoomId = resortRoomId;
	}


	/**
	 * Gets the resort id.
	 *
	 * @return the resort id
	 */
	public String getResortId() {
		return resortId;
	}


	/**
	 * Sets the resort id.
	 *
	 * @param resortId the new resort id
	 */
	public void setResortId(String resortId) {
		this.resortId = resortId;
	}


	/**
	 * Gets the room type id.
	 *
	 * @return the room type id
	 */
	public String getRoomTypeId() {
		return roomTypeId;
	}


	/**
	 * Sets the room type id.
	 *
	 * @param roomTypeId the new room type id
	 */
	public void setRoomTypeId(String roomTypeId) {
		this.roomTypeId = roomTypeId;
	}


	/**
	 * Gets the occupancy detail.
	 *
	 * @return the occupancy detail
	 */
	public String getOccupancyDetail() {
		return occupancyDetail;
	}


	/**
	 * Sets the occupancy detail.
	 *
	 * @param occupancyDetail the new occupancy detail
	 */
	public void setOccupancyDetail(String occupancyDetail) {
		this.occupancyDetail = occupancyDetail;
	}


	/**
	 * Gets the extra person child cost.
	 *
	 * @return the extra person child cost
	 */
	public Double getExtraPersonChildCost() {
		return extraPersonChildCost;
	}


	/**
	 * Sets the extra person child cost.
	 *
	 * @param extraPersonChildCost the new extra person child cost
	 */
	public void setExtraPersonChildCost(Double extraPersonChildCost) {
		this.extraPersonChildCost = extraPersonChildCost;
	}


	/**
	 * Gets the max occupancy count.
	 *
	 * @return the max occupancy count
	 */
	public int getMaxOccupancyCount() {
		return maxOccupancyCount;
	}


	/**
	 * Sets the max occupancy count.
	 *
	 * @param maxOccupancyCount the new max occupancy count
	 */
	public void setMaxOccupancyCount(int maxOccupancyCount) {
		this.maxOccupancyCount = maxOccupancyCount;
	}


	/**
	 * Gets the available rooms.
	 *
	 * @return the available rooms
	 */
	public int getAvailableRooms() {
		return availableRooms;
	}


	/**
	 * Sets the available rooms.
	 *
	 * @param availableRooms the new available rooms
	 */
	public void setAvailableRooms(int availableRooms) {
		this.availableRooms = availableRooms;
	}


	/**
	 * Gets the base occupancy count.
	 *
	 * @return the base occupancy count
	 */
	public int getBaseOccupancyCount() {
		return baseOccupancyCount;
	}


	/**
	 * Sets the base occupancy count.
	 *
	 * @param baseOccupancyCount the new base occupancy count
	 */
	public void setBaseOccupancyCount(int baseOccupancyCount) {
		this.baseOccupancyCount = baseOccupancyCount;
	}


	/**
	 * Gets the extra occupancy adult count.
	 *
	 * @return the extra occupancy adult count
	 */
	public int getExtraOccupancyAdultCount() {
		return extraOccupancyAdultCount;
	}


	/**
	 * Sets the extra occupancy adult count.
	 *
	 * @param extraOccupancyAdultCount the new extra occupancy adult count
	 */
	public void setExtraOccupancyAdultCount(int extraOccupancyAdultCount) {
		this.extraOccupancyAdultCount = extraOccupancyAdultCount;
	}


	/**
	 * Gets the extra occupancy child count.
	 *
	 * @return the extra occupancy child count
	 */
	public int getExtraOccupancyChildCount() {
		return extraOccupancyChildCount;
	}


	/**
	 * Sets the extra occupancy child count.
	 *
	 * @param extraOccupancyChildCount the new extra occupancy child count
	 */
	public void setExtraOccupancyChildCount(int extraOccupancyChildCount) {
		this.extraOccupancyChildCount = extraOccupancyChildCount;
	}


	/**
	 * Gets the total base occupancy count.
	 *
	 * @return the total base occupancy count
	 */
	public int getTotalBaseOccupancyCount() {
		return totalBaseOccupancyCount;
	}


	/**
	 * Gets the total extra adult occupancy count.
	 *
	 * @return the total extra adult occupancy count
	 */
	public int getTotalExtraAdultOccupancyCount() {
		return totalExtraAdultOccupancyCount;
	}


	/**
	 * Sets the total extra adult occupancy count.
	 *
	 * @param totalExtraAdultOccupancyCount the new total extra adult occupancy count
	 */
	public void setTotalExtraAdultOccupancyCount(int totalExtraAdultOccupancyCount) {
		this.totalExtraAdultOccupancyCount = totalExtraAdultOccupancyCount;
	}


	/**
	 * Gets the total extra child occupancy count.
	 *
	 * @return the total extra child occupancy count
	 */
	public int getTotalExtraChildOccupancyCount() {
		return totalExtraChildOccupancyCount;
	}


	/**
	 * Sets the total extra child occupancy count.
	 *
	 * @param totalExtraChildOccupancyCount the new total extra child occupancy count
	 */
	public void setTotalExtraChildOccupancyCount(int totalExtraChildOccupancyCount) {
		this.totalExtraChildOccupancyCount = totalExtraChildOccupancyCount;
	}


	/**
	 * Sets the total base occupancy count.
	 *
	 * @param totalBaseOccupancyCount the new total base occupancy count
	 */
	public void setTotalBaseOccupancyCount(int totalBaseOccupancyCount) {
		this.totalBaseOccupancyCount = totalBaseOccupancyCount;
	}

	/**
	 * Gets the resort name.
	 *
	 * @return the resort name
	 */
	public String getResortName() {
		return resortName;
	}

	/**
	 * Sets the resort name.
	 *
	 * @param resortName the new resort name
	 */
	public void setResortName(String resortName) {
		this.resortName = resortName;
	}



	
}
