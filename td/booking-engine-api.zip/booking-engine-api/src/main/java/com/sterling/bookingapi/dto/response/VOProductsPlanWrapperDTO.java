package com.sterling.bookingapi.dto.response;

import java.io.Serializable;
import java.util.List;
public class VOProductsPlanWrapperDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private List<VOProductResponseDTO> productList;

	/**
	 * @return productList
	 */
	public List<VOProductResponseDTO> getProductList() {
		return productList;
	}

	/**
	 * @param productList
	 * set the productList
	 */
	public void setProductList(List<VOProductResponseDTO> productList) {
		this.productList = productList;
	}
	
}
