package com.sterling.bookingapi.dto.response;

import org.joda.time.LocalDate;

public class VOSeasonWeekDTO {
	
	private LocalDate startDate;
	private LocalDate endDate;
	private String roomType = "ALL";
	private String season;
	
	

	public VOSeasonWeekDTO(LocalDate startDate, LocalDate endDate, String season) {
		super();
		this.startDate = startDate;
		this.endDate = endDate;
		this.season = season;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	public String getRoomType() {
		return roomType;
	}

	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}

	public String getSeason() {
		return season;
	}

	public void setSeason(String season) {
		this.season = season;
	}
	
}
