package com.sterling.bookingapi.dto.request;

import java.io.Serializable;
import java.util.List;

/**
 * @author tcs
 *
 */
public class VOEMIASFDetailsDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String invoiceNumber;
	private String paymentType;//Needs to be set from service.
	private String paymentMode;
	private Double dueAmount;
	private String dueDate;
	private String transactionId;//Needs to be removed.
	private String structureId;
	private List<String> collectionIds;
	private String connectorId;
	private String name;
	private Double latePaymentCharge;
	private boolean lateFeeFlag;
	
	//Balance amount field added - Neethi
	private Double balanceAmount;
	/**
	 * @return name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name
	 * set the name
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return invoiceNumber
	 */
	public String getInvoiceNumber() {
		return invoiceNumber;
	}
	/**
	 * @param invoiceNumber
	 * set the invoiceNumber
	 */
	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}
	/**
	 * @return paymentType
	 */
	public String getPaymentType() {
		return paymentType;
	}
	/**
	 * @param paymentType
	 * set the paymentType
	 */
	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}
	/**
	 * @return paymentMode
	 */
	public String getPaymentMode() {
		return paymentMode;
	}
	/**
	 * @param paymentMode
	 * set the paymentMode
	 */
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}
	/**
	 * @return dueAmount
	 */
	public Double getDueAmount() {
		return dueAmount;
	}
	/**
	 * @param dueAmount
	 * set the dueAmount
	 */
	public void setDueAmount(Double dueAmount) {
		this.dueAmount = dueAmount;
	}
	/**
	 * @return dueDate
	 */
	public String getDueDate() {
		return dueDate;
	}
	/**
	 * @param dueDate
	 * set the dueDate
	 */
	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}
	/**
	 * @return transactionId
	 */
	public String getTransactionId() {
		return transactionId;
	}
	/**
	 * @param transactionId
	 * set the transactionId
	 */
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	/**
	 * @return structureId
	 */
	public String getStructureId() {
		return structureId;
	}
	/**
	 * @param structureId
	 * set the structureId
	 */
	public void setStructureId(String structureId) {
		this.structureId = structureId;
	}
	
	public String getConnectorId() {
		return connectorId;
	}
	public void setConnectorId(String connectorId) {
		this.connectorId = connectorId;
	}
	public List<String> getCollectionIds() {
		return collectionIds;
	}
	public void setCollectionIds(List<String> collectionIds) {
		this.collectionIds = collectionIds;
	}
	public boolean isLateFeeFlag() {
		return lateFeeFlag;
	}
	public void setLateFeeFlag(boolean lateFeeFlag) {
		this.lateFeeFlag = lateFeeFlag;
	}
	public Double getLatePaymentCharge() {
		return latePaymentCharge;
	}
	public void setLatePaymentCharge(Double latePaymentCharge) {
		this.latePaymentCharge = latePaymentCharge;
	}
	public Double getBalanceAmount() {
		return balanceAmount;
	}
	public void setBalanceAmount(Double balanceAmount) {
		this.balanceAmount = balanceAmount;
	}
}
