package com.sterling.bookingapi.exception;

import java.io.IOException;

import org.apache.commons.io.IOUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.web.client.DefaultResponseErrorHandler;
import org.springframework.web.client.ResponseErrorHandler;

/**
 * @author tcs
 * @version 1.0
 *
 */
public class SterlingSFErrHandler implements ResponseErrorHandler {
	/** The Constant logger. */
	private static final Logger logger = LogManager.getLogger(SterlingSFErrHandler.class);
    private ResponseErrorHandler errorHandler = new DefaultResponseErrorHandler();

    public boolean hasError(ClientHttpResponse response) throws IOException {
    	boolean hasError = errorHandler.hasError(response);
    	logger.info(" SterlingSFErrHandler : hasError : {}", hasError);
		return hasError;
    }

    public void handleError(ClientHttpResponse response) throws IOException {
        String resString = IOUtils.toString(response.getBody());
        logger.info(" SterlingSFErrHandler : handleError : Leaving.");
        throw new BookingEngineException(Integer.parseInt(response.getStatusCode().toString()), resString);
    }
}