package com.sterling.bookingapi.dto.maximojo.response;

import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;


/**
 * The Class HotelRatePlanResDTO.
 * @author tcs
 * @version 1.0
 */
@JacksonXmlRootElement(localName = "OTA_HotelRatePlanRS")
public class HotelRatePlanResDTO {

	/** The xmlns. */
	// attribute true will make the property as a attribute for the tag
	@JacksonXmlProperty(localName = "xmlns", isAttribute = true)
	private String xmlns;

	/** The echo token. */
	@JacksonXmlProperty(localName = "EchoToken", isAttribute = true)
	private String echoToken;

	/** The time stamp. */
	@JacksonXmlProperty(localName = "TimeStamp", isAttribute = true)
	private String timeStamp;

	/** The version. */
	@JacksonXmlProperty(localName = "Version", isAttribute = true)
	private String version;

	/** The success. */
	@JacksonXmlProperty(localName = "Success")
	private SuccessResDTO success;

	/** The rate plans. */
	// wrapping false will not display the parent tag for this list
	@JacksonXmlElementWrapper(useWrapping = false, localName = "RatePlans")
	// @JacksonXmlProperty(localName = "Rate")
	@JacksonXmlProperty(localName = "RatePlans")
	private List<RatePlansResDTO> ratePlans;

	/**
	 * Gets the time stamp.
	 *
	 * @return the time stamp
	 */
	public String getTimeStamp() {
		return timeStamp;
	}

	/**
	 * Sets the time stamp.
	 *
	 * @param timeStamp the new time stamp
	 */
	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}

	/**
	 * Gets the rate plans.
	 *
	 * @return the rate plans
	 */
	public List<RatePlansResDTO> getRatePlans() {
		return ratePlans;
	}

	/**
	 * Sets the rate plans.
	 *
	 * @param ratePlans the new rate plans
	 */
	public void setRatePlans(List<RatePlansResDTO> ratePlans) {
		this.ratePlans = ratePlans;
	}

	/**
	 * Gets the xmlns.
	 *
	 * @return the xmlns
	 */
	public String getXmlns() {
		return xmlns;
	}

	/**
	 * Sets the xmlns.
	 *
	 * @param xmlns the new xmlns
	 */
	public void setXmlns(String xmlns) {
		this.xmlns = xmlns;
	}

	/**
	 * Gets the version.
	 *
	 * @return the version
	 */
	public String getVersion() {
		return version;
	}

	/**
	 * Sets the version.
	 *
	 * @param version the new version
	 */
	public void setVersion(String version) {
		this.version = version;
	}

	/**
	 * Gets the success.
	 *
	 * @return the success
	 */
	public SuccessResDTO getSuccess() {
		return success;
	}

	/**
	 * Sets the success.
	 *
	 * @param success            the success to set
	 */
	public void setSuccess(SuccessResDTO success) {
		this.success = success;
	}

	/**
	 * Gets the echo token.
	 *
	 * @return the echo token
	 */
	public String getEchoToken() {
		return echoToken;
	}

	/**
	 * Sets the echo token.
	 *
	 * @param echoToken the new echo token
	 */
	public void setEchoToken(String echoToken) {
		this.echoToken = echoToken;
	}

}
