package com.sterling.bookingapi.dto.maximojo.request;

import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;


/**
 * The Class HotelResNotifReq.
 */
/**
 * @author tcs
 *
 */
@JacksonXmlRootElement(localName = "OTA_HotelResNotifRQ")
public class HotelResNotifReq {
		
		/** The xmlns. */
		@JacksonXmlProperty(localName = "xmlns", isAttribute = true)
		private String xmlns="http://www.opentravel.org/OTA/2003/05";

		/** The echo token. */
		@JacksonXmlProperty(localName = "EchoToken", isAttribute = true)
	    private String echoToken;
		
		/** The res status. */
		@JacksonXmlProperty(localName = "ResStatus", isAttribute = true)
	    private String resStatus;

		/** The time stamp. */
		@JacksonXmlProperty(localName = "TimeStamp", isAttribute = true)
	    private String timeStamp;
		
		/** The version. */
		@JacksonXmlProperty(localName = "version", isAttribute = true)
	    private String version;
		
		/** The pos. */
		@JacksonXmlProperty(localName = "POS")
	    private POSBookingReqDTO pos;
		
		/** The hotel reservation. */
		@JacksonXmlElementWrapper(useWrapping=true,localName = "HotelReservations")
		@JacksonXmlProperty(localName = "HotelReservation")
	    private List<HotelReservationsReqDTO> hotelReservation;

		

		/**
		 * Gets the time stamp.
		 *
		 * @return the timeStamp
		 */
		public String getTimeStamp() {
			return timeStamp;
		}

		/**
		 * Sets the time stamp.
		 *
		 * @param timeStamp the timeStamp to set
		 */
		public void setTimeStamp(String timeStamp) {
			this.timeStamp = timeStamp;
		}

		/**
		 * Gets the hotel reservation.
		 *
		 * @return the hotelReservation
		 */
		public List<HotelReservationsReqDTO> getHotelReservation() {
			return hotelReservation;
		}

		/**
		 * Sets the hotel reservation.
		 *
		 * @param hotelReservation the hotelReservation to set
		 */
		public void setHotelReservation(List<HotelReservationsReqDTO> hotelReservation) {
			this.hotelReservation = hotelReservation;
		}

		/**
		 * Gets the pos.
		 *
		 * @return the pos
		 */
		public POSBookingReqDTO getPos() {
			return pos;
		}

		/**
		 * Sets the pos.
		 *
		 * @param pos the pos to set
		 */
		public void setPos(POSBookingReqDTO pos) {
			this.pos = pos;
		}

		/**
		 * Gets the xmlns.
		 *
		 * @return the xmlns
		 */
		public String getXmlns() {
			return xmlns;
		}

		/**
		 * Sets the xmlns.
		 *
		 * @param xmlns the xmlns to set
		 */
		public void setXmlns(String xmlns) {
			this.xmlns = xmlns;
		}

		/**
		 * Gets the res status.
		 *
		 * @return the resStatus
		 */
		public String getResStatus() {
			return resStatus;
		}

		/**
		 * Sets the res status.
		 *
		 * @param resStatus the resStatus to set
		 */
		public void setResStatus(String resStatus) {
			this.resStatus = resStatus;
		}

		/**
		 * Gets the version.
		 *
		 * @return the version
		 */
		public String getVersion() {
			return version;
		}

		/**
		 * Sets the version.
		 *
		 * @param version the version to set
		 */
		public void setVersion(String version) {
			this.version = version;
		}

		/**
		 * Gets the echo token.
		 *
		 * @return the echoToken
		 */
		public String getEchoToken() {
			return echoToken;
		}

		/**
		 * Sets the echo token.
		 *
		 * @param echoToken the echoToken to set
		 */
		public void setEchoToken(String echoToken) {
			this.echoToken = echoToken;
		}
		
		
}
