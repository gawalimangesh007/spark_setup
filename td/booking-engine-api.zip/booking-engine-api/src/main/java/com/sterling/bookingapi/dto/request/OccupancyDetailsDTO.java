package com.sterling.bookingapi.dto.request;

import java.io.Serializable;

public class OccupancyDetailsDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String roomId;
	private String  occupancyDetail;
	private int maxOccupancyCount;
	private int baseOccupancyCount;
	private int extraOccupancyAdultCount;
	private int extraOccupancyChildCount;

	public String getRoomId() {
		return roomId;
	}
	public void setRoomId(String roomId) {
		this.roomId = roomId;
	}
	public String getOccupancyDetail() {
		return occupancyDetail;
	}
	public void setOccupancyDetail(String occupancyDetail) {
		this.occupancyDetail = occupancyDetail;
	}
	public int getMaxOccupancyCount() {
		return maxOccupancyCount;
	}
	public void setMaxOccupancyCount(int maxOccupancyCount) {
		this.maxOccupancyCount = maxOccupancyCount;
	}
	public int getBaseOccupancyCount() {
		return baseOccupancyCount;
	}
	public void setBaseOccupancyCount(int baseOccupancyCount) {
		this.baseOccupancyCount = baseOccupancyCount;
	}
	public int getExtraOccupancyAdultCount() {
		return extraOccupancyAdultCount;
	}
	public void setExtraOccupancyAdultCount(int extraOccupancyAdultCount) {
		this.extraOccupancyAdultCount = extraOccupancyAdultCount;
	}
	public int getExtraOccupancyChildCount() {
		return extraOccupancyChildCount;
	}
	public void setExtraOccupancyChildCount(int extraOccupancyChildCount) {
		this.extraOccupancyChildCount = extraOccupancyChildCount;
	}

}
