package com.sterling.bookingapi.bean;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


/**
 * The Class HsdRegistrationData.
 */
/**
 * @author tcs
 *
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "FirstName", "LastName", "MobilePhone", "Email", "Alternate_Mobile__c"})
public class HsdRegistrationData {

	/** The First name. */
	@JsonProperty("FirstName")
	private String FirstName;
	
	/** The Last name. */
	@JsonProperty("LastName")
	private String LastName;
	
	/** The Mobile phone. */
	@JsonProperty("MobilePhone")
	private String MobilePhone;
	
	/** The Email. */
	@JsonProperty("Email")
	private String Email;
	
	/** The Alternate mobile c. */
	@JsonProperty("Alternate_Mobile__c")
	private String Alternate_Mobile__c;
	
	/** The additional properties. */
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<>();
	
	/**
	 * Gets the first name.
	 *
	 * @return the firstName
	 */
	@JsonProperty("FirstName")
	public String getFirstName() {
		return FirstName;
	}

	/**
	 * Sets the first name.
	 *
	 * @param firstName the firstName to set
	 */
	@JsonProperty("FirstName")
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}

	/**
	 * Gets the last name.
	 *
	 * @return the lastName
	 */
	@JsonProperty("LastName")
	public String getLastName() {
		return LastName;
	}

	/**
	 * Sets the last name.
	 *
	 * @param lastName the lastName to set
	 */
	@JsonProperty("LastName")
	public void setLastName(String lastName) {
		LastName = lastName;
	}

	/**
	 * Gets the mobile phone.
	 *
	 * @return the mobilePhone
	 */
	@JsonProperty("MobilePhone")
	public String getMobilePhone() {
		return MobilePhone;
	}

	/**
	 * Sets the mobile phone.
	 *
	 * @param mobilePhone the mobilePhone to set
	 */
	@JsonProperty("MobilePhone")
	public void setMobilePhone(String mobilePhone) {
		MobilePhone = mobilePhone;
	}

	/**
	 * Gets the email.
	 *
	 * @return the email
	 */
	@JsonProperty("Email")
	public String getEmail() {
		return Email;
	}

	/**
	 * Sets the email.
	 *
	 * @param email the email to set
	 */
	@JsonProperty("Email")
	public void setEmail(String email) {
		Email = email;
	}

	/**
	 * Gets the alternate mobile c.
	 *
	 * @return the alternate_Mobile__c
	 */
	@JsonProperty("Alternate_Mobile__c")
	public String getAlternate_Mobile__c() {
		return Alternate_Mobile__c;
	}

	/**
	 * Sets the alternate mobile c.
	 *
	 * @param alternate_Mobile__c the alternate_Mobile__c to set
	 */
	@JsonProperty("Alternate_Mobile__c")
	public void setAlternate_Mobile__c(String alternate_Mobile__c) {
		Alternate_Mobile__c = alternate_Mobile__c;
	}

	/**
	 * Gets the additional properties.
	 *
	 * @return the additional properties
	 */
	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	/**
	 * Sets the additional property.
	 *
	 * @param name the name
	 * @param value the value
	 */
	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}
}