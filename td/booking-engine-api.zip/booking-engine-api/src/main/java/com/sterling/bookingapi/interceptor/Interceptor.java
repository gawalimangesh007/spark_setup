package com.sterling.bookingapi.interceptor;

import java.util.Collection;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.google.common.collect.Lists;
import com.sterling.bookingapi.context.RequestContext;
import com.sterling.bookingapi.context.RequestThreadLocal;


/**
 * The Class Interceptor.
 */
/**
 * @author tcs
 * @version 1.0
 *
 */
@Component
public class Interceptor implements HandlerInterceptor{

	/** The Constant logger. */
	private static final Logger logger = LogManager.getLogger(Interceptor.class);

	/* (non-Javadoc)
	 * @see org.springframework.web.servlet.HandlerInterceptor#preHandle(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse, java.lang.Object)
	 */
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {

		//To add unique id to all the logs 
		//TODO : Have to implement.
		String requestId = UUID.randomUUID().toString() + "-" + new Date().getTime();
		RequestContext requestContext = RequestThreadLocal.get();
		requestContext.setRequestId(requestId);
		MDC.put("requestId", requestId);
		
		logger.debug(" Interceptor :: preHandle :: Entered ");

		String requestUrl = request.getScheme() + " :// " + request.getServerName()
				+ ":" + request.getServerPort() + request.getContextPath() + request.getRequestURI()
				+ "?" + request.getQueryString();
		logger.info(" Interceptor :: preHandle :: Request URL : " + requestUrl);

		Map<String, String> requestMap = extractParams(request);
		String requestBody = null;

		if(logger.isInfoEnabled()) {
			List<String> headerList = Lists.newArrayList();
			Enumeration<String> headerNames = request.getHeaderNames();
			while(headerNames.hasMoreElements()) {
				String nextElement = headerNames.nextElement();
				String header = request.getHeader(nextElement);
				headerList.add(nextElement + ":" + header);
			}
			logger.info(" Interceptor :: preHandle :: Request Headers :::>> " + String.join(";", headerList));
		}
		
		final StringBuilder logMessage = new StringBuilder(
				"REST Request - ").append("[HTTP METHOD:")
				.append(request.getMethod())
				.append("]")
				.append("[PATH INFO:")
				.append(request.getServletPath())
				.append("]")
				.append(" [REQUEST PARAMETERS: ").append(requestMap)
				.append("] ")
				.append("[REQUEST BODY: ")
				.append(requestBody)
				.append("] ");


		logMessage.append(" [ RESPONSE: ").append(response.getStatus()).append(" ] ");

		logger.info(" Interceptor :: preHandle :: Log Message" + logMessage);
		
		logger.info(" Interceptor :: preHandle :: Leaving ");

		return true;
	}
	

	/**
	 * Method for extracting the Http request to fetch all the header parameters.  
	 * 
	 * @param request - An object of HttpServletRequest
	 * @return - map containing the header key and value.
	 */
	private Map<String, String> extractParams(HttpServletRequest request) {
		logger.info(" Interceptor :: extractParams :: Entered ");

		Map<String, String> requestMap = new HashMap<>();


		Enumeration<String> paramNames = request.getParameterNames();

		while (paramNames.hasMoreElements()) {
			String requestParamName = (String) paramNames.nextElement();
			String requestParamValue = request.getParameter(requestParamName);
			requestMap.put(requestParamName, requestParamValue);
		}
		logger.info(" Interceptor :: extractParams :: Leaving ");
		return requestMap;
	} 

	@Override
	public void postHandle(	HttpServletRequest request, HttpServletResponse response,
			Object handler, ModelAndView modelAndView) throws Exception {
		logger.debug(" Interceptor :: postHandle :: Entered ");

		logger.info(" Interceptor :: postHandle :: Response Status : " + response.getStatus() );
		Collection<String> headerNames = response.getHeaderNames();

		Map<Object, Object> headerMap = headerNames.stream().collect(Collectors.toMap(x -> x, c -> response.getHeader(c)));
		
		logger.info(" Interceptor :: postHandle :: Response Header Map : " + headerMap.toString() );
		
		RequestThreadLocal.unset();
		logger.debug(" Interceptor :: postHandle :: Leaving ");
	}

	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response,
			Object handler, Exception ex) throws Exception {
		logger.debug(" Interceptor :: afterCompletion :: Entered ");
		
		logger.debug(" Interceptor :: afterCompletion :: Leaving ");
	}

}
