package com.sterling.bookingapi.dto.maximojo.request;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;


/**
 * The Class HotelAvailNotifReqDTO.
 */
/**
 * @author tcs
 *
 */
@JacksonXmlRootElement(localName = "OTA_HotelAvailNotifRQ")
public class HotelAvailNotifReqDTO {

	/** The time stamp. */
	@JacksonXmlProperty(localName = "TimeStamp", isAttribute = true)
	private String timeStamp;

	/** The avail status messages. */
	@JacksonXmlElementWrapper(useWrapping=false)
	@JacksonXmlProperty(localName = "AvailStatusMessages")
    private AvailStatusMessagesReqDTO availStatusMessages;
    
    /** The xmlns. */
    @JacksonXmlProperty(localName = "xmlns", isAttribute = true)
    private String xmlns="http://www.opentravel.org/OTA/2003/05";

    /** The version. */
    @JacksonXmlProperty(localName = "Version", isAttribute = true)
    private String version;

	/**
	 * Gets the time stamp.
	 *
	 * @return the timeStamp
	 */
	public String getTimeStamp() {
		return timeStamp;
	}

	/**
	 * Sets the time stamp.
	 *
	 * @param timeStamp the timeStamp to set
	 */
	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}

	/**
	 * Gets the avail status messages.
	 *
	 * @return the availStatusMessages
	 */
	public AvailStatusMessagesReqDTO getAvailStatusMessages() {
		return availStatusMessages;
	}

	/**
	 * Sets the avail status messages.
	 *
	 * @param availStatusMessages the availStatusMessages to set
	 */
	public void setAvailStatusMessages(AvailStatusMessagesReqDTO availStatusMessages) {
		this.availStatusMessages = availStatusMessages;
	}

	/**
	 * Gets the xmlns.
	 *
	 * @return the xmlns
	 */
	public String getXmlns() {
		return xmlns;
	}

	/**
	 * Sets the xmlns.
	 *
	 * @param xmlns the xmlns to set
	 */
	public void setXmlns(String xmlns) {
		this.xmlns = xmlns;
	}

	/**
	 * Gets the version.
	 *
	 * @return the version
	 */
	public String getVersion() {
		return version;
	}

	/**
	 * Sets the version.
	 *
	 * @param version the version to set
	 */
	public void setVersion(String version) {
		this.version = version;
	}
    
    
}
