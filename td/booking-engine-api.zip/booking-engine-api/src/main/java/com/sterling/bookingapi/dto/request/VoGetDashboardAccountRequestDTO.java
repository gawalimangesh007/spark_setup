package com.sterling.bookingapi.dto.request;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


/**
 * The Class HsdBookingOfferDetailsDTO.
 */
/**
 * @author tcs
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class VoGetDashboardAccountRequestDTO extends VoBaseRequestDTO implements Serializable {
	
	public VoGetDashboardAccountRequestDTO() {
		super();
	}
	private static final long serialVersionUID = 1L;
	
	
	private String contractId;
	private String primaryId;
	
	/**
	 * @return contractId
	 */
	public String getContractId() {
		return contractId;
	}
	/**
	 * @param contractId
	 * set the contractId
	 */
	public void setContractId(String contractId) {
		this.contractId = contractId;
	}
	/**
	 * @return primaryId
	 */
	public String getPrimaryId() {
		return primaryId;
	}
	/**
	 * @param primaryId
	 * set the primaryId
	 */
	public void setPrimaryId(String primaryId) {
		this.primaryId = primaryId;
	}
	
	
	
	
}