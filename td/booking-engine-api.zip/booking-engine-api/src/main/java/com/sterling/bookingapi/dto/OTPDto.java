package com.sterling.bookingapi.dto;

import java.io.Serializable;
import java.util.Date;

/**
 * @author tcs
 *
 */
public class OTPDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private String otp;
	private Date date;
	private int verifiedCount;
	
	public OTPDto() {
		super();
	}
	
	public OTPDto(String otp, Date date) {
		super();
		this.otp = otp;
		this.date = date;
	}

	/**
	 * @return otp
	 */
	public String getOtp() {
		return otp;
	}
	/**
	 * @param otp
	 * set the otp
	 */
	public void setOtp(String otp) {
		this.otp = otp;
	}
	/**
	 * @return date
	 */
	public Date getDate() {
		return date;
	}
	/**
	 * @param date
	 * set the date
	 */
	public void setDate(Date date) {
		this.date = date;
	}

	/**
	 * @return verifiedCount
	 */
	public int getVerifiedCount() {
		return verifiedCount;
	}

	/**
	 * @param verifiedCount
	 * set the verifiedCount
	 */
	public void setVerifiedCount(int verifiedCount) {
		this.verifiedCount = verifiedCount;
	}
	
}
