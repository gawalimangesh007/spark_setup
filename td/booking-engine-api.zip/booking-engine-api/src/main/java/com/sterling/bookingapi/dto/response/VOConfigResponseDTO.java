package com.sterling.bookingapi.dto.response;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author tcs
 * @version 1.0
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class VOConfigResponseDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String id;
	private String key;
	private String value;

	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
	
}
