package com.sterling.bookingapi.exception;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;


/**
 * The Class ValidationError.
 */
/**
 * @author tcs
 * @version 1.0
 *
 */
public class ValidationError {

    /** The errors. */
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private List<SpecificFieldError> errors = new ArrayList<>();

    /** The error message. */
    private final String errorMessage;

    /**
     * Instantiates a new validation error.
     *
     * @param errorMessage the error message
     */
    public ValidationError(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    /**
     * Adds the validation error.
     *
     * @param error the error
     */
    public void addValidationError(SpecificFieldError error) {
        errors.add(error);
    }

    /**
     * Gets the errors.
     *
     * @return the errors
     */
    public List<SpecificFieldError> getErrors() {
        return errors;
    }

    /**
     * Gets the error message.
     *
     * @return the error message
     */
    public String getErrorMessage() {
        return errorMessage;
    }
    
}
