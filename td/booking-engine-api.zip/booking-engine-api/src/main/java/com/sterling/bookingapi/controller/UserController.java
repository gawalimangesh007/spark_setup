package com.sterling.bookingapi.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.sterling.bookingapi.dto.request.LoginDetailsReqeustDTO;
import com.sterling.bookingapi.dto.request.UserDetailsReqeustDTO;
import com.sterling.bookingapi.dto.request.UserDetailsUpdateRequestDTO;
import com.sterling.bookingapi.dto.response.ResponseDTO;
import com.sterling.bookingapi.exception.BookingEngineException;
import com.sterling.bookingapi.service.UserService;


// TODO: Auto-generated Javadoc
/**
 * The Class UserController.
 */
/**
 * @author tcs
 *
 */
@RestController
@RequestMapping(value = "/users")
public class UserController extends BaseController {

	/** The Constant logger. */
	private static final Logger logger = LogManager.getLogger(UserController.class);

	/** The user service. */
	@Autowired
	private UserService userService;

	/**
	 * Register user.
	 *
	 * @param userDetails the user details
	 * @return the response DTO
	 * @throws BookingEngineException the booking engine exception
	 */
	@ResponseBody
	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public ResponseDTO registerUser(@RequestBody final UserDetailsReqeustDTO userDetails) throws BookingEngineException {
		logger.info(" UserServiceImpl : registerUser : Entered.");
		ResponseDTO response = userService.registerUser(userDetails);

		logger.info(" UserServiceImpl : registerUser : Leaving.");
		return response;
	}

	/**
	 * Login user.
	 *
	 * @param loginDetails the login details
	 * @return the response DTO
	 * @throws BookingEngineException the booking engine exception
	 */
	@ResponseBody
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ResponseDTO loginUser(@RequestBody final LoginDetailsReqeustDTO loginDetails) throws BookingEngineException {
		logger.info(" UserServiceImpl : loginUser : Entered.");
		ResponseDTO response = userService.loginUser(loginDetails);

		logger.info(" UserServiceImpl : loginUser : Leaving.");
		return response;
	}

	/**
	 * Gets the user.
	 *
	 * @param email the email
	 * @return the user
	 * @throws BookingEngineException the booking engine exception
	 */
	
	 //Commenting on 23/10/2017 for SF change
  	/*
	@ResponseBody
	@RequestMapping(value = "/getUser", method = RequestMethod.GET)
	public ResponseDTO getUser(@RequestParam final String email) throws BookingEngineException {
		logger.info(" UserServiceImpl : getUser : Entered.");
		ResponseDTO response = userService.getUser(email);

		logger.info(" UserServiceImpl : registerUser : Leaving.");
		return response;
	}*/

	/**
	 * Update user.
	 *
	 * @param userDetails the user details
	 * @return the response DTO
	 * @throws BookingEngineException the booking engine exception
	 */
	@ResponseBody
	@RequestMapping(value = "/updateUser", method = RequestMethod.POST)
	public ResponseDTO updateUser(@RequestBody final UserDetailsUpdateRequestDTO userDetails) throws BookingEngineException {
		logger.info(" UserServiceImpl : registerUser : Entered.");
		ResponseDTO response = userService.updateUser(userDetails);

		logger.info(" UserServiceImpl : registerUser : Leaving.");
		return response;
	}

}
