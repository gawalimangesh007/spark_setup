package com.sterling.bookingapi.dto.maximojo.request;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class POSReqDTO.
 */
/**
 * @author tcs
 *
 */
public class POSReqDTO {

	/** The Requestor ID. */
	@JacksonXmlElementWrapper(useWrapping=true,localName = "Source")
	@JacksonXmlProperty(localName = "RequestorID")
	private RequestorIDReqDTO RequestorID;

	/**
	 * Gets the requestor ID.
	 *
	 * @return the requestorID
	 */
	public RequestorIDReqDTO getRequestorID() {
		return RequestorID;
	}

	/**
	 * Sets the requestor ID.
	 *
	 * @param requestorID the requestorID to set
	 */
	public void setRequestorID(RequestorIDReqDTO requestorID) {
		RequestorID = requestorID;
	}
	
	
	
}
