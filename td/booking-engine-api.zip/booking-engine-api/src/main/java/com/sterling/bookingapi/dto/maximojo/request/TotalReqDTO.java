package com.sterling.bookingapi.dto.maximojo.request;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class TotalReqDTO.
 */
/**
 * @author tcs
 *
 */
public class TotalReqDTO {

	
	/** The amount before tax. */
	@JacksonXmlProperty(localName = "AmountBeforeTax", isAttribute = true)
    private double amountBeforeTax;
	
	/** The currency code. */
	@JacksonXmlProperty(localName = "CurrencyCode", isAttribute = true)
    private String currencyCode;

	/** The taxes. */
	@JacksonXmlProperty(localName = "Taxes")
    private TaxesReqDTO taxes;
    
	/**
	 * Gets the amount before tax.
	 *
	 * @return the amountBeforeTax
	 */
	public double getAmountBeforeTax() {
		return amountBeforeTax;
	}

	/**
	 * Sets the amount before tax.
	 *
	 * @param amountBeforeTax the amountBeforeTax to set
	 */
	public void setAmountBeforeTax(double amountBeforeTax) {
		this.amountBeforeTax = amountBeforeTax;
	}

	/**
	 * Gets the taxes.
	 *
	 * @return the taxes
	 */
	public TaxesReqDTO getTaxes() {
		return taxes;
	}

	/**
	 * Sets the taxes.
	 *
	 * @param taxes the taxes to set
	 */
	public void setTaxes(TaxesReqDTO taxes) {
		this.taxes = taxes;
	}

	/**
	 * Gets the currency code.
	 *
	 * @return the currencyCode
	 */
	public String getCurrencyCode() {
		return currencyCode;
	}

	/**
	 * Sets the currency code.
	 *
	 * @param currencyCode the currencyCode to set
	 */
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}
    
    

}
