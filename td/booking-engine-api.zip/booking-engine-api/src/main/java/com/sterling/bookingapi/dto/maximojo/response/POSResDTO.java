package com.sterling.bookingapi.dto.maximojo.response;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class POSResDTO.
 * @author tcs
 * @version 1.0
 */
public class POSResDTO {

	/** The Source. */
	@JacksonXmlProperty(localName = "Source")
	 private SourceResDTO Source;

	/**
	 * Gets the source.
	 *
	 * @return the source
	 */
	public SourceResDTO getSource() {
		return Source;
	}

	/**
	 * Sets the source.
	 *
	 * @param source the source to set
	 */
	public void setSource(SourceResDTO source) {
		Source = source;
	}

	
}
