package com.sterling.bookingapi.auth.bean;

/**
 * @author tcs
 *
 */
public enum AuthType {
	HSD("HSD"),
	VO("VO");
	
	private String loginType;
	
	/**
	 * @param lType
	 * set the authtype
	 */
	private AuthType(String lType){
		this.setLoginType(lType);
	}

	/**
	 * @return loginType
	 */
	public String getLoginType() {
		return loginType;
	}

	/**
	 * @param loginType
	 * set the loginType
	 */
	public void setLoginType(String loginType) {
		this.loginType = loginType;
	}

	/**
	 * @param val
	 * @return true or false
	 */
	public static boolean contains(String val) {
		for (AuthType el : AuthType.values()) {
			if(el.getLoginType().equals(val)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * @param val
	 * @return authType
	 */
	public static AuthType getFrom(String val) {
		for (AuthType el : AuthType.values()) {
			if(el.getLoginType().equals(val)) {
				return el;
			}
		}
		return null;
	}
}
