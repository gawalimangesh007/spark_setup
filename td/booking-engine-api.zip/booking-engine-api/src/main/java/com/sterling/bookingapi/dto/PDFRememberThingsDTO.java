package com.sterling.bookingapi.dto;

import java.io.Serializable;

public class PDFRememberThingsDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String rememberThingItem;
	
	public PDFRememberThingsDTO() {
		super();
	}

	public PDFRememberThingsDTO(String rememberThingItem) {
		super();
		this.rememberThingItem = rememberThingItem;
	}


	public String getRememberThingItem() {
		return rememberThingItem;
	}

	public void setRememberThingItem(String rememberThingItem) {
		this.rememberThingItem = rememberThingItem;
	}

	
	
}
