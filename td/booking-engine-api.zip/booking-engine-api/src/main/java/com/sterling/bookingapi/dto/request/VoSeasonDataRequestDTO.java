package com.sterling.bookingapi.dto.request;

import java.io.Serializable;

import javax.validation.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


/**
 * The Class HsdBookingOfferDetailsDTO.
 */
/**
 * @author tcs
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class VoSeasonDataRequestDTO extends VoBaseRequestDTO implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@NotEmpty(message = "Resort code should not be empty")
	private String resortCode;
	
	@NotEmpty(message = "productCode should not be empty")
	private String productCode;
	
	
	public String getProductCode() {
		return productCode;
	}


	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}


	public String getResortCode() {
		return resortCode;
	}


	public void setResortCode(String resortCode) {
		this.resortCode = resortCode;
	}


	
	
	
}