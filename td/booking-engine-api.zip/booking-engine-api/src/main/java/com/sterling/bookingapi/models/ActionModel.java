package com.sterling.bookingapi.models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "sh_hsd_actionmodel")
public class ActionModel extends BaseModel {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue( strategy = GenerationType.IDENTITY )
	@Column(name = "action_id", unique = true)
	private int actionid;
	
	/*@OneToOne
	@JoinColumn(name="page_idx_id")*/
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "page_idx_id", nullable = false)
	@JsonIgnore
	private PageModel pageModel;
	
	@Column(name = "action_type", unique = true)
	private String actiontype;
	
	@Column(name = "action_desc", unique = true)
	private String actiondesc;
	
	@Column(name = "chanel", unique = true)
	private String chanel;
	
	@Column(name = "resort", unique = true)
	private String resort;
	
	@Column(name = "rate_Plan", unique = true)
	private String ratePlan;
	
	@Column(name = "room_Type", unique = true)
	private String roomType;
	
	@Column(name = "promo_Code", unique = true)
	private String promoCode;
	
	@Column(name = "starte_date", unique = true)
	private String startedate;
	
	@Column(name = "end_date", unique = true)
	private String enddate;
	
	@Column(name = "no_of_guest", unique = true)
	private String noofguest;
	
	@Column(name = "event_type", unique = true)
	private String eventtype;
	
	@Column(name = "name", unique = true)
	private String name;
	
	@Column(name = "email", unique = true)
	private String email;
	
	@Column(name = "mobile", unique = true)
	private String mobile;

	public String getRatePlan() {
		return ratePlan;
	}

	public void setRatePlan(String ratePlan) {
		this.ratePlan = ratePlan;
	}

	public String getRoomType() {
		return roomType;
	}

	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}

	public String getPromoCode() {
		return promoCode;
	}

	public void setPromoCode(String promoCode) {
		this.promoCode = promoCode;
	}

	
	public PageModel getPageModel() {
		return pageModel;
	}

	public void setPageModel(PageModel pageModel) {
		this.pageModel = pageModel;
	}

	public int getActionid() {
		return actionid;
	}

	public void setActionid(int actionid) {
		this.actionid = actionid;
	}

	public String getActiontype() {
		return actiontype;
	}

	public void setActiontype(String actiontype) {
		this.actiontype = actiontype;
	}

	public String getActiondesc() {
		return actiondesc;
	}

	public void setActiondesc(String actiondesc) {
		this.actiondesc = actiondesc;
	}

	public String getChanel() {
		return chanel;
	}

	public void setChanel(String chanel) {
		this.chanel = chanel;
	}

	public String getResort() {
		return resort;
	}

	public void setResort(String resort) {
		this.resort = resort;
	}

	public String getStartedate() {
		return startedate;
	}

	public void setStartedate(String startedate) {
		this.startedate = startedate;
	}

	public String getEnddate() {
		return enddate;
	}

	public void setEnddate(String enddate) {
		this.enddate = enddate;
	}

	public String getNoofguest() {
		return noofguest;
	}

	public void setNoofguest(String noofguest) {
		this.noofguest = noofguest;
	}

	public String getEventtype() {
		return eventtype;
	}

	public void setEventtype(String eventtype) {
		this.eventtype = eventtype;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

}
