package com.sterling.bookingapi.dto.maximojo.response;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class DescriptionResDTO.
 * @author tcs
 * @version 1.0
 */
public class DescriptionResDTO {
	
	/** The name. */
	@JacksonXmlProperty(localName = "Name", isAttribute = true)
	private String name;

	/** The text. */
	@JacksonXmlProperty(localName = "Text")
    private TextResDTO text;

	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Sets the name.
	 *
	 * @param name the new name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Gets the text.
	 *
	 * @return the text
	 */
	public TextResDTO getText() {
		return text;
	}

	/**
	 * Sets the text.
	 *
	 * @param text the new text
	 */
	public void setText(TextResDTO text) {
		this.text = text;
	}
	
	
}
