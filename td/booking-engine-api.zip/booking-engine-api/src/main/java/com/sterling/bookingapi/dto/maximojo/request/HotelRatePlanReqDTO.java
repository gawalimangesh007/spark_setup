
package com.sterling.bookingapi.dto.maximojo.request;

import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;



/**
 * The Class HotelRatePlanReqDTO.
 */
/**
 * @author tcs
 *
 */
@JacksonXmlRootElement(localName = "OTA_HotelRatePlanRQ")
public class HotelRatePlanReqDTO {
	
		/** The time stamp. */
		@JacksonXmlProperty(localName = "TimeStamp", isAttribute = true)
	    private String timeStamp;

		/** The summary only. */
		@JacksonXmlProperty(localName = "SummaryOnly", isAttribute = true)
	    private boolean summaryOnly;
		
		/** The rate plans. */
		@JacksonXmlElementWrapper(useWrapping=true, localName = "RatePlans")
		@JacksonXmlProperty(localName = "RatePlan")
	    private List<RatePlanReqDTO> ratePlans;

		/** The xmlns. */
		@JacksonXmlProperty(localName = "xmlns", isAttribute = true)
	    private String xmlns="http://www.opentravel.org/OTA/2003/05";

		/** The version. */
		@JacksonXmlProperty(localName = "Version", isAttribute = true)
	    private String version;

		/** The echo token. */
		@JacksonXmlProperty(localName = "EchoToken", isAttribute = true)
	    private String echoToken;

		/**
		 * Gets the time stamp.
		 *
		 * @return the time stamp
		 */
		public String getTimeStamp() {
			return timeStamp;
		}

		/**
		 * Sets the time stamp.
		 *
		 * @param timeStamp the new time stamp
		 */
		public void setTimeStamp(String timeStamp) {
			this.timeStamp = timeStamp;
		}

		/**
		 * Gets the summary only.
		 *
		 * @return the summary only
		 */
		public boolean getSummaryOnly() {
			return summaryOnly;
		}

		/**
		 * Sets the summary only.
		 *
		 * @param summaryOnly the new summary only
		 */
		public void setSummaryOnly(boolean summaryOnly) {
			this.summaryOnly = summaryOnly;
		}

		
		/**
		 * Gets the xmlns.
		 *
		 * @return the xmlns
		 */
		public String getXmlns() {
			return xmlns;
		}

		/**
		 * Sets the xmlns.
		 *
		 * @param xmlns the new xmlns
		 */
		public void setXmlns(String xmlns) {
			this.xmlns = xmlns;
		}

		/**
		 * Gets the version.
		 *
		 * @return the version
		 */
		public String getVersion() {
			return version;
		}

		/**
		 * Sets the version.
		 *
		 * @param version the new version
		 */
		public void setVersion(String version) {
			this.version = version;
		}

		/**
		 * Gets the echo token.
		 *
		 * @return the echo token
		 */
		public String getEchoToken() {
			return echoToken;
		}

		/**
		 * Sets the echo token.
		 *
		 * @param echoToken the new echo token
		 */
		public void setEchoToken(String echoToken) {
			this.echoToken = echoToken;
		}

		/**
		 * Gets the rate plans.
		 *
		 * @return the rate plans
		 */
		public List<RatePlanReqDTO> getRatePlans() {
			return ratePlans;
		}

		/**
		 * Sets the rate plans.
		 *
		 * @param ratePlans the new rate plans
		 */
		public void setRatePlans(List<RatePlanReqDTO> ratePlans) {
			this.ratePlans = ratePlans;
		}

		
}