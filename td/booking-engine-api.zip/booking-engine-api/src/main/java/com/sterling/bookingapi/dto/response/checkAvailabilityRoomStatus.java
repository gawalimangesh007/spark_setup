package com.sterling.bookingapi.dto.response;

public class checkAvailabilityRoomStatus {
	
	private String roomTypeId;
	private Boolean soldOut;
	
	public String getRoomTypeId() {
		return roomTypeId;
	}
	public void setRoomTypeId(String roomTypeId) {
		this.roomTypeId = roomTypeId;
	}
	public Boolean getSoldOut() {
		return soldOut;
	}
	public void setSoldOut(Boolean soldOut) {
		this.soldOut = soldOut;
	}
}
