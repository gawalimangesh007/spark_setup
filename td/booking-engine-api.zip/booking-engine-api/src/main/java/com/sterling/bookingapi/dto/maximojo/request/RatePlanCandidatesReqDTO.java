package com.sterling.bookingapi.dto.maximojo.request;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class RatePlanCandidatesReqDTO.
 */
/**
 * @author tcs
 *
 */
public class RatePlanCandidatesReqDTO {

	/** The rate plan code. */
	@JacksonXmlProperty(localName = "RatePlanCode", isAttribute = true)
	private String ratePlanCode;

	/**
	 * Gets the rate plan code.
	 *
	 * @return the rate plan code
	 */
	public String getRatePlanCode() {
		return ratePlanCode;
	}

	/**
	 * Sets the rate plan code.
	 *
	 * @param ratePlanCode the new rate plan code
	 */
	public void setRatePlanCode(String ratePlanCode) {
		this.ratePlanCode = ratePlanCode;
	}
	
	
}
