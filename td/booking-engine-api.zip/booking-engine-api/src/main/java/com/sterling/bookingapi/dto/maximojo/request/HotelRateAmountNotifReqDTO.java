package com.sterling.bookingapi.dto.maximojo.request;

import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;


/**
 * The Class HotelRateAmountNotifReqDTO.
 */
/**
 * @author tcs
 *
 */
@JacksonXmlRootElement(localName = "OTA_HotelRateAmountNotifRQ")
public class HotelRateAmountNotifReqDTO {

	/** The time stamp. */
	@JacksonXmlProperty(localName = "TimeStamp", isAttribute = true)
	private String timeStamp;
	
	/** The Rate amount messages. */
	@JacksonXmlElementWrapper(useWrapping=false)
	@JacksonXmlProperty(localName = "RateAmountMessages")
    private List<RateAmountMessagesReqDTO> rateAmountMessages;

    /** The xmlns. */
    @JacksonXmlProperty(localName = "xmlns", isAttribute = true)
    private String xmlns="http://www.opentravel.org/OTA/2003/05";

    /** The version. */
    @JacksonXmlProperty(localName = "Version", isAttribute = true)
    private String version;
    
    /** The echo token. */
    @JacksonXmlProperty(localName = "EchoToken", isAttribute = true)
	private String echoToken;

	/**
	 * Gets the time stamp.
	 *
	 * @return the time stamp
	 */
	public String getTimeStamp() {
		return timeStamp;
	}

	/**
	 * Sets the time stamp.
	 *
	 * @param timeStamp the new time stamp
	 */
	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}

	/**
	 * Gets the rate amount messages.
	 *
	 * @return the rate amount messages
	 */
	public List<RateAmountMessagesReqDTO> getRateAmountMessages() {
		return rateAmountMessages;
	}

	/**
	 * Sets the rate amount messages.
	 *
	 * @param rateAmountMessages the new rate amount messages
	 */
	public void setRateAmountMessages(
			List<RateAmountMessagesReqDTO> rateAmountMessages) {
		this.rateAmountMessages = rateAmountMessages;
	}

	/**
	 * Gets the xmlns.
	 *
	 * @return the xmlns
	 */
	public String getXmlns() {
		return xmlns;
	}

	/**
	 * Sets the xmlns.
	 *
	 * @param xmlns the new xmlns
	 */
	public void setXmlns(String xmlns) {
		this.xmlns = xmlns;
	}

	/**
	 * Gets the version.
	 *
	 * @return the version
	 */
	public String getVersion() {
		return version;
	}

	/**
	 * Sets the version.
	 *
	 * @param version the new version
	 */
	public void setVersion(String version) {
		this.version = version;
	}

	/**
	 * Gets the echo token.
	 *
	 * @return the echoToken
	 */
	public String getEchoToken() {
		return echoToken;
	}

	/**
	 * Sets the echo token.
	 *
	 * @param echoToken the echoToken to set
	 */
	public void setEchoToken(String echoToken) {
		this.echoToken = echoToken;
	}
    
    
}
