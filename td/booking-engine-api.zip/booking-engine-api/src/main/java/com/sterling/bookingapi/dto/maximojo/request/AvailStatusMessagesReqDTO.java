package com.sterling.bookingapi.dto.maximojo.request;

import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class AvailStatusMessagesReqDTO.
 */
/**
 * @author tcs
 *
 */
public class AvailStatusMessagesReqDTO {

	/** The avail status message. */
	@JacksonXmlElementWrapper(useWrapping=false)
	@JacksonXmlProperty(localName = "AvailStatusMessage")
	private List<AvailStatusMessageReqDTO> availStatusMessage;

	/** The hotel code. */
	@JacksonXmlProperty(localName = "HotelCode", isAttribute = true)
    private String hotelCode;

	/**
	 * Gets the avail status message.
	 *
	 * @return the availStatusMessage
	 */
	public List<AvailStatusMessageReqDTO> getAvailStatusMessage() {
		return availStatusMessage;
	}

	/**
	 * Sets the avail status message.
	 *
	 * @param availStatusMessage the availStatusMessage to set
	 */
	public void setAvailStatusMessage(List<AvailStatusMessageReqDTO> availStatusMessage) {
		this.availStatusMessage = availStatusMessage;
	}

	/**
	 * Gets the hotel code.
	 *
	 * @return the hotelCode
	 */
	public String getHotelCode() {
		return hotelCode;
	}

	/**
	 * Sets the hotel code.
	 *
	 * @param hotelCode the hotelCode to set
	 */
	public void setHotelCode(String hotelCode) {
		this.hotelCode = hotelCode;
	}
	
	
}
