package com.sterling.bookingapi.dto.request;



/**
 * The Class HsdResortRoomMasterDTO.
 */
/**
 * @author tcs
 *
 */
public class HsdResortRoomMasterUpdateDTO {

	/** The location id. */
	private String locationId;
	
	/** The location name. */
	private String locationName;
	
	/** The resort id. */
	private String resortId;
	
	/** The resort name. */
	private String resortName ;
		
	/** The active. */
	//private boolean status;

	/**
	 * Gets the location id.
	 *
	 * @return the locationId
	 */
	public String getLocationId() {
		return locationId;
	}

	/**
	 * Sets the location id.
	 *
	 * @param locationId the locationId to set
	 */
	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}

	/**
	 * Gets the location name.
	 *
	 * @return the locationName
	 */
	public String getLocationName() {
		return locationName;
	}

	/**
	 * Sets the location name.
	 *
	 * @param locationName the locationName to set
	 */
	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}

	/**
	 * Gets the resort id.
	 *
	 * @return the resortId
	 */
	public String getResortId() {
		return resortId;
	}

	/**
	 * Sets the resort id.
	 *
	 * @param resortId the resortId to set
	 */
	public void setResortId(String resortId) {
		this.resortId = resortId;
	}

	/**
	 * Gets the resort name.
	 *
	 * @return the resortName
	 */
	public String getResortName() {
		return resortName;
	}

	/**
	 * Sets the resort name.
	 *
	 * @param resortName the resortName to set
	 */
	public void setResortName(String resortName) {
		this.resortName = resortName;
	}

	/*public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}
*/
}
