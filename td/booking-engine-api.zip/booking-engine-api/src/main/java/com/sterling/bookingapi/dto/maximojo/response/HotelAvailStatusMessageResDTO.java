package com.sterling.bookingapi.dto.maximojo.response;

import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class HotelAvailStatusMessageResDTO.
 * @author tcs
 * @version 1.0
 */
public class HotelAvailStatusMessageResDTO {

	/** The status application control. */
	@JacksonXmlProperty(localName = "StatusApplicationControl")
	private StatusApplicationControlResDTO statusApplicationControl;

	/** The booking limit. */
	@JacksonXmlProperty(localName = "BookingLimit", isAttribute = true)
    private int bookingLimit;

	/** The restriction status. */
	@JacksonXmlProperty(localName = "RestrictionStatus")
    private RestrictionStatusResDTO restrictionStatus;
	
	/** The length of stay. */
	@JacksonXmlElementWrapper(useWrapping=true, localName = "LengthsOfStay")
	@JacksonXmlProperty(localName = "LengthOfStay")
    private List<LengthOfStayResDTO> lengthOfStay;


	/**
	 * Gets the status application control.
	 *
	 * @return the statusApplicationControl
	 */
	public StatusApplicationControlResDTO getStatusApplicationControl() {
		return statusApplicationControl;
	}


	/**
	 * Sets the status application control.
	 *
	 * @param statusApplicationControl the statusApplicationControl to set
	 */
	public void setStatusApplicationControl(StatusApplicationControlResDTO statusApplicationControl) {
		this.statusApplicationControl = statusApplicationControl;
	}


	/**
	 * Gets the booking limit.
	 *
	 * @return the bookingLimit
	 */
	public int getBookingLimit() {
		return bookingLimit;
	}


	/**
	 * Sets the booking limit.
	 *
	 * @param bookingLimit the bookingLimit to set
	 */
	public void setBookingLimit(int bookingLimit) {
		this.bookingLimit = bookingLimit;
	}


	/**
	 * Gets the restriction status.
	 *
	 * @return the restrictionStatus
	 */
	public RestrictionStatusResDTO getRestrictionStatus() {
		return restrictionStatus;
	}


	/**
	 * Sets the restriction status.
	 *
	 * @param restrictionStatus the restrictionStatus to set
	 */
	public void setRestrictionStatus(RestrictionStatusResDTO restrictionStatus) {
		this.restrictionStatus = restrictionStatus;
	}


	/**
	 * Gets the length of stay.
	 *
	 * @return the lengthOfStay
	 */
	public List<LengthOfStayResDTO> getLengthOfStay() {
		return lengthOfStay;
	}


	/**
	 * Sets the length of stay.
	 *
	 * @param lengthOfStay the lengthOfStay to set
	 */
	public void setLengthOfStay(List<LengthOfStayResDTO> lengthOfStay) {
		this.lengthOfStay = lengthOfStay;
	}


	
	
}
