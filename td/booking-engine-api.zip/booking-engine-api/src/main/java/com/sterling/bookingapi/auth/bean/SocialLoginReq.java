package com.sterling.bookingapi.auth.bean;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author tcs
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class SocialLoginReq implements Serializable {

	private static final long serialVersionUID = 1L;
	
	//{"AccountType":"Google","Token":<auth-token-value>,"Email":"<someuser@gmail.com>"}
	
	private String accountType;
	private String token;
	private String email;
	private String authType;
	private String mobile;
	
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAuthType() {
		return authType;
	}
	public void setAuthType(String authType) {
		this.authType = authType;
	}
	
}
