package com.sterling.bookingapi.models;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;


/**
 * The Class HsdRoomsInventory.
 */
/**
 * @author tcs
 *
 */
@Entity
@Table(name = "sh_hsd_rooms_inventory")
public class HsdRoomsInventory extends BaseModel{
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The room inventory id. */
	@Id
	@GeneratedValue( strategy = GenerationType.IDENTITY )
	@Column(name = "room_inventory_id", unique = false)
	private String room_inventoryId;
	
	/** The hsd resort room master. */
	@ManyToOne(fetch = FetchType.EAGER,optional = false)
	@Cascade(CascadeType.SAVE_UPDATE)
	@JoinColumn(name="resort_room_id",nullable = false)
	private HsdResortRoomMaster hsdResortRoomMaster;
	
	/** The total room count. */
	@Column(name = "total_room_count", nullable = false)
	private int totalRoomCount;
	
	/** The available date. */
	@Column(name = "available_date",nullable = false)
	private Date availableDate;
	
	/** The available rooms. */
	@Column(name = "available_rooms",nullable = false)
	private int availableRooms;
	
	/** The active. */
	@Column(name = "status",nullable = false)
	private boolean active;

	/**
	 * Gets the room inventory id.
	 *
	 * @return the room inventory id
	 */
	public String getRoom_inventoryId() {
		return room_inventoryId;
	}

	/**
	 * Sets the room inventory id.
	 *
	 * @param room_inventoryId the new room inventory id
	 */
	public void setRoom_inventoryId(String room_inventoryId) {
		this.room_inventoryId = room_inventoryId;
	}

	/**
	 * Gets the hsd resort room master.
	 *
	 * @return the hsd resort room master
	 */
	public HsdResortRoomMaster getHsdResortRoomMaster() {
		return hsdResortRoomMaster;
	}

	/**
	 * Sets the hsd resort room master.
	 *
	 * @param hsdResortRoomMaster the new hsd resort room master
	 */
	public void setHsdResortRoomMaster(HsdResortRoomMaster hsdResortRoomMaster) {
		this.hsdResortRoomMaster = hsdResortRoomMaster;
	}

	/**
	 * Gets the total room count.
	 *
	 * @return the total room count
	 */
	public int getTotalRoomCount() {
		return totalRoomCount;
	}

	/**
	 * Sets the total room count.
	 *
	 * @param totalRoomCount the new total room count
	 */
	public void setTotalRoomCount(int totalRoomCount) {
		this.totalRoomCount = totalRoomCount;
	}

	/**
	 * Gets the available date.
	 *
	 * @return the available date
	 */
	public Date getAvailableDate() {
		return availableDate;
	}

	/**
	 * Sets the available date.
	 *
	 * @param availableDate the new available date
	 */
	public void setAvailableDate(Date availableDate) {
		this.availableDate = availableDate;
	}

	/**
	 * Gets the available rooms.
	 *
	 * @return the available rooms
	 */
	public int getAvailableRooms() {
		return availableRooms;
	}

	/**
	 * Sets the available rooms.
	 *
	 * @param availableRooms the new available rooms
	 */
	public void setAvailableRooms(int availableRooms) {
		this.availableRooms = availableRooms;
	}

	/**
	 * Checks if is active.
	 *
	 * @return true, if is active
	 */
	public boolean isActive() {
		return active;
	}

	/**
	 * Sets the active.
	 *
	 * @param active the new active
	 */
	public void setActive(boolean active) {
		this.active = active;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "HsdRoomsInventory [room_inventoryId=" + room_inventoryId
				+ ", hsdResortRoomMaster.ResortId=" + hsdResortRoomMaster.getResortId()
				+ ", hsdResortRoomMaster.ResortRoomId=" + hsdResortRoomMaster.getResortRoomId()
				+ ", hsdResortRoomMaster.RoomTypeId=" + hsdResortRoomMaster.getRoomTypeId()
				+ ", totalRoomCount=" + totalRoomCount + ", availableDate="
				+ availableDate + ", availableRooms=" + availableRooms
				+ ", active=" + active + "]";
	}

	
	
}
