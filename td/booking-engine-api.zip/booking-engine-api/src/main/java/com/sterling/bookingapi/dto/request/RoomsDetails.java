package com.sterling.bookingapi.dto.request;


/**
 * The Class RoomsDetails.
 */
/**
 * @author tcs
 *
 */
public class RoomsDetails {

	/** The room type id. */
	private String roomTypeId;

	/** The room type. */
	private String roomType;
	
	/** The occupancy detail. */
	private String occupancyDetail;
	
	/** The max occupancy count. */
	private int maxOccupancyCount;
	
	/** The base occupancy count. */
	private int baseOccupancyCount;
	
	/** The extra occupancy adult count. */
	private int extraOccupancyAdultCount;
	
	/** The extra occupancy child count. */
	private int extraOccupancyChildCount;
	
	/** The extra person cost child. */
	private double extraPersonCostChild;
	
	/** The room count. */
	private int roomCount;

	/**
	 * Gets the room type id.
	 *
	 * @return the roomTypeId
	 */
	public String getRoomTypeId() {
		return roomTypeId;
	}

	/**
	 * Sets the room type id.
	 *
	 * @param roomTypeId the roomTypeId to set
	 */
	public void setRoomTypeId(String roomTypeId) {
		this.roomTypeId = roomTypeId;
	}

	/**
	 * Gets the room type.
	 *
	 * @return the roomType
	 */
	public String getRoomType() {
		return roomType;
	}

	/**
	 * Sets the room type.
	 *
	 * @param roomType the roomType to set
	 */
	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}

	/**
	 * Gets the occupancy detail.
	 *
	 * @return the occupancyDetail
	 */
	public String getOccupancyDetail() {
		return occupancyDetail;
	}

	/**
	 * Sets the occupancy detail.
	 *
	 * @param occupancyDetail the occupancyDetail to set
	 */
	public void setOccupancyDetail(String occupancyDetail) {
		this.occupancyDetail = occupancyDetail;
	}

	/**
	 * Gets the max occupancy count.
	 *
	 * @return the maxOccupancyCount
	 */
	public int getMaxOccupancyCount() {
		return maxOccupancyCount;
	}

	/**
	 * Sets the max occupancy count.
	 *
	 * @param maxOccupancyCount the maxOccupancyCount to set
	 */
	public void setMaxOccupancyCount(int maxOccupancyCount) {
		this.maxOccupancyCount = maxOccupancyCount;
	}

	/**
	 * Gets the base occupancy count.
	 *
	 * @return the baseOccupancyCount
	 */
	public int getBaseOccupancyCount() {
		return baseOccupancyCount;
	}

	/**
	 * Sets the base occupancy count.
	 *
	 * @param baseOccupancyCount the baseOccupancyCount to set
	 */
	public void setBaseOccupancyCount(int baseOccupancyCount) {
		this.baseOccupancyCount = baseOccupancyCount;
	}

	/**
	 * Gets the extra occupancy adult count.
	 *
	 * @return the extraOccupancyAdultCount
	 */
	public int getExtraOccupancyAdultCount() {
		return extraOccupancyAdultCount;
	}

	/**
	 * Sets the extra occupancy adult count.
	 *
	 * @param extraOccupancyAdultCount the extraOccupancyAdultCount to set
	 */
	public void setExtraOccupancyAdultCount(int extraOccupancyAdultCount) {
		this.extraOccupancyAdultCount = extraOccupancyAdultCount;
	}

	/**
	 * Gets the extra occupancy child count.
	 *
	 * @return the extraOccupancyChildCount
	 */
	public int getExtraOccupancyChildCount() {
		return extraOccupancyChildCount;
	}

	/**
	 * Sets the extra occupancy child count.
	 *
	 * @param extraOccupancyChildCount the extraOccupancyChildCount to set
	 */
	public void setExtraOccupancyChildCount(int extraOccupancyChildCount) {
		this.extraOccupancyChildCount = extraOccupancyChildCount;
	}

	/**
	 * Gets the extra person cost child.
	 *
	 * @return the extraPersonCostChild
	 */
	public double getExtraPersonCostChild() {
		return extraPersonCostChild;
	}

	/**
	 * Sets the extra person cost child.
	 *
	 * @param extraPersonCostChild the extraPersonCostChild to set
	 */
	public void setExtraPersonCostChild(double extraPersonCostChild) {
		this.extraPersonCostChild = extraPersonCostChild;
	}

	/**
	 * Gets the room count.
	 *
	 * @return the roomCount
	 */
	public int getRoomCount() {
		return roomCount;
	}

	/**
	 * Sets the room count.
	 *
	 * @param roomCount the roomCount to set
	 */
	public void setRoomCount(int roomCount) {
		this.roomCount = roomCount;
	}
	
	
	
}
