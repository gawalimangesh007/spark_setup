package com.sterling.bookingapi.dto.maximojo.request;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class DepositPaymentsReqDTO.
 */
/**
 * @author tcs
 *
 */
public class DepositPaymentsReqDTO {
	
	/** The guarantee payment. */
	@JacksonXmlProperty(localName = "GuaranteePayment")
	private GuaranteePaymentReqDTO guaranteePayment;

	/**
	 * Gets the guarantee payment.
	 *
	 * @return the guarantee payment
	 */
	public GuaranteePaymentReqDTO getGuaranteePayment() {
		return guaranteePayment;
	}

	/**
	 * Sets the guarantee payment.
	 *
	 * @param guaranteePayment the new guarantee payment
	 */
	public void setGuaranteePayment(GuaranteePaymentReqDTO guaranteePayment) {
		this.guaranteePayment = guaranteePayment;
	}
	
	
}
