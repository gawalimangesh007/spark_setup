package com.sterling.bookingapi.dto.request;

import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;


/**
 * The Class SampleXMLReqDTO.
 */
/**
 * @author tcs
 *
 */
@JacksonXmlRootElement(localName="sampleReq", namespace="testing")
//@XmlRootElement(name="rootxml", namespace="testing")
public class SampleXMLReqDTO {

	/** The id. */
	@JacksonXmlProperty(localName = "id_da", isAttribute = true)
	private Long id;
    
    /** The description. */
    private String description;
    
    /** The list activity. */
    @JacksonXmlElementWrapper(useWrapping=true, localName = "lsit_activity")
    @JacksonXmlProperty(localName = "user_activity")
    private List<SampleXMLReqDTO> listActivity ;
    
    
	/**
	 * Gets the list activity.
	 *
	 * @return the list activity
	 */
	public List<SampleXMLReqDTO> getListActivity() {
		return listActivity;
	}
	
	/**
	 * Sets the list activity.
	 *
	 * @param listActivity the new list activity
	 */
	public void setListActivity(List<SampleXMLReqDTO> listActivity) {
		this.listActivity = listActivity;
	}
	
	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public Long getId() {
		return id;
	}
	
	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(Long id) {
		this.id = id;
	}
	
	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
	
	/**
	 * Sets the description.
	 *
	 * @param description the new description
	 */
	public void setDescription(String description) {
		this.description = description;
	}
    
    
}
