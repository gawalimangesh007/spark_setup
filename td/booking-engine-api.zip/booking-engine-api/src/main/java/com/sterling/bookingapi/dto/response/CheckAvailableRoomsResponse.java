package com.sterling.bookingapi.dto.response;


public class CheckAvailableRoomsResponse {
	
	/** The resort id. */
	private String resortId;
	
	/** The resort name. */
	private String resortName;
	
	/** The room type id. */
	private String roomTypeId;
	
	/** The available rooms. */
	private int availableRooms;

	/**
	 * @return the resortId
	 */
	public String getResortId() {
		return resortId;
	}

	/**
	 * @param resortId the resortId to set
	 */
	public void setResortId(String resortId) {
		this.resortId = resortId;
	}

	/**
	 * @return the resortName
	 */
	public String getResortName() {
		return resortName;
	}

	/**
	 * @param resortName the resortName to set
	 */
	public void setResortName(String resortName) {
		this.resortName = resortName;
	}

	/**
	 * @return the roomTypeId
	 */
	public String getRoomTypeId() {
		return roomTypeId;
	}

	/**
	 * @param roomTypeId the roomTypeId to set
	 */
	public void setRoomTypeId(String roomTypeId) {
		this.roomTypeId = roomTypeId;
	}

	/**
	 * @return the availableRooms
	 */
	public int getAvailableRooms() {
		return availableRooms;
	}

	/**
	 * @param availableRooms the availableRooms to set
	 */
	public void setAvailableRooms(int availableRooms) {
		this.availableRooms = availableRooms;
	}
	
}
