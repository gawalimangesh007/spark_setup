package com.sterling.bookingapi.dto.response;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CheckAvailableRoomResponseDTO {
	
	/** The resort id. */
	private String resortId;

	/** The check in. */
	private Date checkIn;

	/** The check out. */
	private Date checkOut;

	/** The resort availability. */
	private List<CheckAvailableRoomsResponse> available = new ArrayList<>();

	/**
	 * @return the resortId
	 */
	public String getResortId() {
		return resortId;
	}

	/**
	 * @param resortId the resortId to set
	 */
	public void setResortId(String resortId) {
		this.resortId = resortId;
	}

	/**
	 * @return the checkIn
	 */
	public Date getCheckIn() {
		return checkIn;
	}

	/**
	 * @param checkIn the checkIn to set
	 */
	public void setCheckIn(Date checkIn) {
		this.checkIn = checkIn;
	}

	/**
	 * @return the checkOut
	 */
	public Date getCheckOut() {
		return checkOut;
	}

	/**
	 * @param checkOut the checkOut to set
	 */
	public void setCheckOut(Date checkOut) {
		this.checkOut = checkOut;
	}

	/**
	 * @return the available
	 */
	public List<CheckAvailableRoomsResponse> getAvailable() {
		return available;
	}

	/**
	 * @param available the available to set
	 */
	public void setAvailable(List<CheckAvailableRoomsResponse> available) {
		this.available = available;
	}
	
}
