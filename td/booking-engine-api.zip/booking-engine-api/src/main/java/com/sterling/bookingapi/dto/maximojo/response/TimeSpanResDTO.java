package com.sterling.bookingapi.dto.maximojo.response;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class TimeSpanResDTO.
 * @author tcs
 * @version 1.0
 */
public class TimeSpanResDTO {

	/** The end. */
	@JacksonXmlProperty(localName = "End", isAttribute = true)
	private String end;

	/** The start. */
	@JacksonXmlProperty(localName = "Start", isAttribute = true)
    private String start;

	/**
	 * Gets the end.
	 *
	 * @return the end
	 */
	public String getEnd() {
		return end;
	}

	/**
	 * Sets the end.
	 *
	 * @param end the end to set
	 */
	public void setEnd(String end) {
		this.end = end;
	}

	/**
	 * Gets the start.
	 *
	 * @return the start
	 */
	public String getStart() {
		return start;
	}

	/**
	 * Sets the start.
	 *
	 * @param start the start to set
	 */
	public void setStart(String start) {
		this.start = start;
	}
	
	

}
