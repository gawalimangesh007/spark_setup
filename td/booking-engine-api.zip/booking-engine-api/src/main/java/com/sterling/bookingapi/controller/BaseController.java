package com.sterling.bookingapi.controller;

/**
 * The Class BaseController.
 */
/**
 * @author tcs
 *
 */
public class BaseController {

}
