package com.sterling.bookingapi.dto.response;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * Object for DTCOverallSummaryDTO
 * @author tcs
 * @version 1.0
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class DTCOverallSummaryResponseDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private Double openingEntitlement;
	private Double currentEntitlement;
	private Double lapsedThreshold;
	private Double lapsedPoints;
	private Double utilized;
	private Double closingBalance;
	
	private List<DTCEntitlementResponseDTO> advancedEntitlements;

	
	public Double getOpeningEntitlement() {
		return openingEntitlement;
	}

	public void setOpeningEntitlement(Double openingEntitlement) {
		this.openingEntitlement = openingEntitlement;
	}

	public Double getCurrentEntitlement() {
		return currentEntitlement;
	}

	public void setCurrentEntitlement(Double currentEntitlement) {
		this.currentEntitlement = currentEntitlement;
	}

	public Double getLapsedThreshold() {
		return lapsedThreshold;
	}

	public void setLapsedThreshold(Double lapsedThreshold) {
		this.lapsedThreshold = lapsedThreshold;
	}

	public Double getLapsedPoints() {
		return lapsedPoints;
	}

	public void setLapsedPoints(Double lapsedPoints) {
		this.lapsedPoints = lapsedPoints;
	}

	public Double getUtilized() {
		return utilized;
	}

	public void setUtilized(Double utilized) {
		this.utilized = utilized;
	}

	public Double getClosingBalance() {
		return closingBalance;
	}

	public void setClosingBalance(Double closingBalance) {
		this.closingBalance = closingBalance;
	}

	public List<DTCEntitlementResponseDTO> getAdvancedEntitlements() {
		return advancedEntitlements;
	}

	public void setAdvancedEntitlements(List<DTCEntitlementResponseDTO> advancedEntitlements) {
		this.advancedEntitlements = advancedEntitlements;
	} 
	

	
	
	
}
