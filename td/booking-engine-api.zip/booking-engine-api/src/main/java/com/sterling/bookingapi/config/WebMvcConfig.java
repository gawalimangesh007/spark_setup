package com.sterling.bookingapi.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.sterling.bookingapi.interceptor.Interceptor;


/**
 * The Class WebMvcConfig.
 */
/**
 * @author tcs
 *
 */
@Configuration
public class WebMvcConfig {
	
	@Value("${sterling.api.allowed.origins}")
	private String[] allowedOrigins;

	/** The interceptor. */
//	@Autowired
//	private HandlerInterceptor interceptor;
//	
//	// Adding custom Handler Interceptor.
//	@Override
//	public void addInterceptors(InterceptorRegistry registry) {
//		registry.addInterceptor(interceptor);
//	}
//
//	@Override
//	public void addCorsMappings(CorsRegistry registry) {
//		
//		registry.addMapping("/**")
//		.allowedOrigins("*")
//		.allowedMethods("GET", "PUT", "POST", "OPTIONS")
//		.allowedHeaders("x-auth-token","Authorization","Access-Control-Allow-Origin","Access-Control-Allow-Credentials","Content-Type", "Accept", "X-Requested-With")
//        .exposedHeaders("x-auth-token","Authorization","Access-Control-Allow-Origin","Access-Control-Allow-Credentials","Content-Type", "Accept", "X-Requested-With")
//		.allowCredentials(false).maxAge(3600);
//	}
	
	 @Bean
	 public WebMvcConfigurer corsConfigurer() {
	        return new WebMvcConfigurerAdapter() {
	            @Override
	            public void addCorsMappings(CorsRegistry registry) {
	            	registry.addMapping("/**")
	        		.allowedOrigins(allowedOrigins)
	        		.allowCredentials(true)
	        		.allowedMethods("GET", "PUT", "POST", "OPTIONS")
	        		.allowedHeaders("x-auth-token","Authorization","Access-Control-Allow-Origin","Access-Control-Allow-Credentials","Content-Type", "Accept", "X-Requested-With")
	                .exposedHeaders("x-auth-token","Authorization","Access-Control-Allow-Origin","Access-Control-Allow-Credentials","Content-Type", "Accept", "X-Requested-With")
	        		.allowCredentials(true)
	        		.maxAge(3600);
	            }
	            
	            @Override
	            public void addInterceptors(InterceptorRegistry registry) {
	            	registry.addInterceptor(new Interceptor());
	            }
	        };
	    }

}