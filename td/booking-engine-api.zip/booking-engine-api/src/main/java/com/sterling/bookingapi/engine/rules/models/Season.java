package com.sterling.bookingapi.engine.rules.models;

public enum Season {

	PURPLE("Super Red", 4, "Super Red"), RED("Red", 3, "Red"), WHITE("White", 2, "White"), BLUE("Blue", 1, "Blue");
	
	private String seasonName;
	private int weight;
	private String sfName;

	private Season(String seasonName, int weight, String sfName) {
		this.seasonName = seasonName;
		this.weight = weight;
		this.sfName = sfName;
	}
	
	public String getSfName() {
		return sfName;
	}
	public void setSfName(String sfName) {
		this.sfName = sfName;
	}


	public int getWeight() {
		return weight;
	}

	public void setWeight(int weight) {
		this.weight = weight;
	}

	public String getSeasonName() {
		return seasonName;
	}
	public void setSeasonName(String seasonName) {
		this.seasonName = seasonName;
	}

	public static Season getByName(String seasonCode) {
		Season season = null;
		if(seasonCode != null) {
			for (Season se : Season.values()) {
				if(se.getSeasonName().equalsIgnoreCase(seasonCode)) {
					season = se;
					break;
				}
			}
		}
		return season;
	}

	public static String getActualName(String seasonCode) {
		if(seasonCode != null) {
			for (Season se : Season.values()) {
				if(se.getSfName().equalsIgnoreCase(seasonCode)) {
					return se.getSeasonName();
				}
			}
		}
		return null;
	}
}
