package com.sterling.bookingapi.dto.response;


public class CoApplicantDetailsDTO extends BaseRecord {
	
	private static final long serialVersionUID = 1L;
	
	private String secondaryApplicantTitle;
	
	private String secondaryApplicantFirstName;
	
	private String secondaryApplicantLastName;
	
	private String secondaryApplicantGender;
	
	private String secondaryApplicantDateofBirth;
	
	private String secondaryApplicantMaritalStatus;
	
	private String secondaryApplicantWeddingDate;
	
	private String secondaryApplicantMobile;
	
	private String secondaryApplicantMobile1;
	
	private String secondaryApplicantMobile2;
	
	private String secondaryApplicanEmail;
	
	private String secondaryApplicantEmail1;
	
	private String secondaryApplicantEmail2;
	
	private String secondaryApplicantLandline;
	
	private String secondaryApplicantLandline1;
	
	private String secondaryApplicantLandline2;
	
	private String secondaryApplicantCountry;
	
	private String secondaryApplicantStateProvince;
	
	private String secondaryApplicantCity;
	
	private String secondaryApplicantStreet;
	
	private String secondaryApplicantZipPostalCode;
	
	private String thirdApplicantTitle;
	
	private String thirdApplicantName;
	
	private String thirdApplicantLasName;
	
	private String thirdApplicantGender;
	
	private String thirdApplicantDateofBirth;
	
	private String thirdApplicantMaritalStatus;
	
	private String thirdApplicantWeddingDate;
	
	private String thirdApplicantPhone;
	
	private String thirdApplicantMobile1;
	
	private String thirdApplicantMobile2;
	
	private String thirdApplicantEmail;
	
	private String thirdApplicantEmail1;
	
	private String thirdApplicantLandline1;
	
	private String thirdApplicantLandline2;
	
	private String thirdApplicantCountry;
	
	private String thirdApplicantStateProvince;
	
	private String thirdApplicantCity;
	
	private String thirdApplicantStreet;
	
	private String thirdApplicantZipPostalCode;

	public String getSecondaryApplicantTitle() {
		return secondaryApplicantTitle;
	}

	public void setSecondaryApplicantTitle(String secondaryApplicantTitle) {
		this.secondaryApplicantTitle = secondaryApplicantTitle;
	}

	public String getSecondaryApplicantFirstName() {
		return secondaryApplicantFirstName;
	}

	public void setSecondaryApplicantFirstName(String secondaryApplicantFirstName) {
		this.secondaryApplicantFirstName = secondaryApplicantFirstName;
	}

	public String getSecondaryApplicantLastName() {
		return secondaryApplicantLastName;
	}

	public void setSecondaryApplicantLastName(String secondaryApplicantLastName) {
		this.secondaryApplicantLastName = secondaryApplicantLastName;
	}

	public String getSecondaryApplicantGender() {
		return secondaryApplicantGender;
	}

	public void setSecondaryApplicantGender(String secondaryApplicantGender) {
		this.secondaryApplicantGender = secondaryApplicantGender;
	}

	public String getSecondaryApplicantDateofBirth() {
		return secondaryApplicantDateofBirth;
	}

	public void setSecondaryApplicantDateofBirth(String secondaryApplicantDateofBirth) {
		this.secondaryApplicantDateofBirth = secondaryApplicantDateofBirth;
	}

	public String getSecondaryApplicantMaritalStatus() {
		return secondaryApplicantMaritalStatus;
	}

	public void setSecondaryApplicantMaritalStatus(String secondaryApplicantMaritalStatus) {
		this.secondaryApplicantMaritalStatus = secondaryApplicantMaritalStatus;
	}

	public String getSecondaryApplicantWeddingDate() {
		return secondaryApplicantWeddingDate;
	}

	public void setSecondaryApplicantWeddingDate(String secondaryApplicantWeddingDate) {
		this.secondaryApplicantWeddingDate = secondaryApplicantWeddingDate;
	}

	public String getSecondaryApplicantMobile() {
		return secondaryApplicantMobile;
	}

	public void setSecondaryApplicantMobile(String secondaryApplicantMobile) {
		this.secondaryApplicantMobile = secondaryApplicantMobile;
	}

	public String getSecondaryApplicantMobile1() {
		return secondaryApplicantMobile1;
	}

	public void setSecondaryApplicantMobile1(String secondaryApplicantMobile1) {
		this.secondaryApplicantMobile1 = secondaryApplicantMobile1;
	}

	public String getSecondaryApplicantMobile2() {
		return secondaryApplicantMobile2;
	}

	public void setSecondaryApplicantMobile2(String secondaryApplicantMobile2) {
		this.secondaryApplicantMobile2 = secondaryApplicantMobile2;
	}

	public String getSecondaryApplicanEmail() {
		return secondaryApplicanEmail;
	}

	public void setSecondaryApplicanEmail(String secondaryApplicanEmail) {
		this.secondaryApplicanEmail = secondaryApplicanEmail;
	}

	public String getSecondaryApplicantEmail1() {
		return secondaryApplicantEmail1;
	}

	public void setSecondaryApplicantEmail1(String secondaryApplicantEmail1) {
		this.secondaryApplicantEmail1 = secondaryApplicantEmail1;
	}

	public String getSecondaryApplicantEmail2() {
		return secondaryApplicantEmail2;
	}

	public void setSecondaryApplicantEmail2(String secondaryApplicantEmail2) {
		this.secondaryApplicantEmail2 = secondaryApplicantEmail2;
	}

	public String getSecondaryApplicantLandline() {
		return secondaryApplicantLandline;
	}

	public void setSecondaryApplicantLandline(String secondaryApplicantLandline) {
		this.secondaryApplicantLandline = secondaryApplicantLandline;
	}

	public String getSecondaryApplicantLandline1() {
		return secondaryApplicantLandline1;
	}

	public void setSecondaryApplicantLandline1(String secondaryApplicantLandline1) {
		this.secondaryApplicantLandline1 = secondaryApplicantLandline1;
	}

	public String getSecondaryApplicantLandline2() {
		return secondaryApplicantLandline2;
	}

	public void setSecondaryApplicantLandline2(String secondaryApplicantLandline2) {
		this.secondaryApplicantLandline2 = secondaryApplicantLandline2;
	}

	public String getSecondaryApplicantCountry() {
		return secondaryApplicantCountry;
	}

	public void setSecondaryApplicantCountry(String secondaryApplicantCountry) {
		this.secondaryApplicantCountry = secondaryApplicantCountry;
	}

	public String getSecondaryApplicantStateProvince() {
		return secondaryApplicantStateProvince;
	}

	public void setSecondaryApplicantStateProvince(String secondaryApplicantStateProvince) {
		this.secondaryApplicantStateProvince = secondaryApplicantStateProvince;
	}

	public String getSecondaryApplicantCity() {
		return secondaryApplicantCity;
	}

	public void setSecondaryApplicantCity(String secondaryApplicantCity) {
		this.secondaryApplicantCity = secondaryApplicantCity;
	}

	public String getSecondaryApplicantStreet() {
		return secondaryApplicantStreet;
	}

	public void setSecondaryApplicantStreet(String secondaryApplicantStreet) {
		this.secondaryApplicantStreet = secondaryApplicantStreet;
	}

	public String getSecondaryApplicantZipPostalCode() {
		return secondaryApplicantZipPostalCode;
	}

	public void setSecondaryApplicantZipPostalCode(String secondaryApplicantZipPostalCode) {
		this.secondaryApplicantZipPostalCode = secondaryApplicantZipPostalCode;
	}

	public String getThirdApplicantTitle() {
		return thirdApplicantTitle;
	}

	public void setThirdApplicantTitle(String thirdApplicantTitle) {
		this.thirdApplicantTitle = thirdApplicantTitle;
	}

	public String getThirdApplicantName() {
		return thirdApplicantName;
	}

	public void setThirdApplicantName(String thirdApplicantName) {
		this.thirdApplicantName = thirdApplicantName;
	}

	public String getThirdApplicantLasName() {
		return thirdApplicantLasName;
	}

	public void setThirdApplicantLasName(String thirdApplicantLasName) {
		this.thirdApplicantLasName = thirdApplicantLasName;
	}

	public String getThirdApplicantGender() {
		return thirdApplicantGender;
	}

	public void setThirdApplicantGender(String thirdApplicantGender) {
		this.thirdApplicantGender = thirdApplicantGender;
	}

	public String getThirdApplicantDateofBirth() {
		return thirdApplicantDateofBirth;
	}

	public void setThirdApplicantDateofBirth(String thirdApplicantDateofBirth) {
		this.thirdApplicantDateofBirth = thirdApplicantDateofBirth;
	}

	public String getThirdApplicantMaritalStatus() {
		return thirdApplicantMaritalStatus;
	}

	public void setThirdApplicantMaritalStatus(String thirdApplicantMaritalStatus) {
		this.thirdApplicantMaritalStatus = thirdApplicantMaritalStatus;
	}

	public String getThirdApplicantWeddingDate() {
		return thirdApplicantWeddingDate;
	}

	public void setThirdApplicantWeddingDate(String thirdApplicantWeddingDate) {
		this.thirdApplicantWeddingDate = thirdApplicantWeddingDate;
	}

	public String getThirdApplicantPhone() {
		return thirdApplicantPhone;
	}

	public void setThirdApplicantPhone(String thirdApplicantPhone) {
		this.thirdApplicantPhone = thirdApplicantPhone;
	}

	public String getThirdApplicantMobile1() {
		return thirdApplicantMobile1;
	}

	public void setThirdApplicantMobile1(String thirdApplicantMobile1) {
		this.thirdApplicantMobile1 = thirdApplicantMobile1;
	}

	public String getThirdApplicantMobile2() {
		return thirdApplicantMobile2;
	}

	public void setThirdApplicantMobile2(String thirdApplicantMobile2) {
		this.thirdApplicantMobile2 = thirdApplicantMobile2;
	}

	public String getThirdApplicantEmail() {
		return thirdApplicantEmail;
	}

	public void setThirdApplicantEmail(String thirdApplicantEmail) {
		this.thirdApplicantEmail = thirdApplicantEmail;
	}

	public String getThirdApplicantEmail1() {
		return thirdApplicantEmail1;
	}

	public void setThirdApplicantEmail1(String thirdApplicantEmail1) {
		this.thirdApplicantEmail1 = thirdApplicantEmail1;
	}

	public String getThirdApplicantLandline1() {
		return thirdApplicantLandline1;
	}

	public void setThirdApplicantLandline1(String thirdApplicantLandline1) {
		this.thirdApplicantLandline1 = thirdApplicantLandline1;
	}

	public String getThirdApplicantLandline2() {
		return thirdApplicantLandline2;
	}

	public void setThirdApplicantLandline2(String thirdApplicantLandline2) {
		this.thirdApplicantLandline2 = thirdApplicantLandline2;
	}

	public String getThirdApplicantCountry() {
		return thirdApplicantCountry;
	}

	public void setThirdApplicantCountry(String thirdApplicantCountry) {
		this.thirdApplicantCountry = thirdApplicantCountry;
	}

	public String getThirdApplicantStateProvince() {
		return thirdApplicantStateProvince;
	}

	public void setThirdApplicantStateProvince(String thirdApplicantStateProvince) {
		this.thirdApplicantStateProvince = thirdApplicantStateProvince;
	}

	public String getThirdApplicantCity() {
		return thirdApplicantCity;
	}

	public void setThirdApplicantCity(String thirdApplicantCity) {
		this.thirdApplicantCity = thirdApplicantCity;
	}

	public String getThirdApplicantStreet() {
		return thirdApplicantStreet;
	}

	public void setThirdApplicantStreet(String thirdApplicantStreet) {
		this.thirdApplicantStreet = thirdApplicantStreet;
	}

	public String getThirdApplicantZipPostalCode() {
		return thirdApplicantZipPostalCode;
	}

	public void setThirdApplicantZipPostalCode(String thirdApplicantZipPostalCode) {
		this.thirdApplicantZipPostalCode = thirdApplicantZipPostalCode;
	}

	
}
