package com.sterling.bookingapi.dto.response;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.sterling.bookingapi.dto.request.RateAHolidayRequest;
import com.sterling.bookingapi.dto.request.VOBookingEnhancementDetailReq;
import com.sterling.bookingapi.dto.request.VOBookingRoomDetailReq;
import com.sterling.bookingapi.dto.request.VOExtarPersonDetailDTO;
import com.sterling.bookingapi.dto.request.VOGuestDetailDTO;
import com.sterling.bookingapi.sf.dto.response.VOUtilityChargesMasterDTO;

/**
 * @author tcs
 * @version 1.0
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class VOBookingDetailResponse  implements Serializable {

	private static final long serialVersionUID = 1L;

	private String bookingId;
	
	private String bookingDate;

	private String contractId;
	 
	private String checkInDate;
	 
	private String checkOutDate;

	private String bookingStatus;

	private String noOfAdults;
	 
	private String noOfChildren;

	private String cvNumber;

	private String productId;
	 
	private String resortMasterId;
	
	private String resortMasterName;
	
	private String resortSerialNumber;
	 
	@JsonProperty("_1BR")
	private String noOf1BR;
	@JsonProperty("_2BR") 
	private String noOf2BR;
	@JsonProperty("_ST") 
	private String noOfStudio;
	@JsonProperty("_GR") 
	private String noOfGuest;

	private String utilityChargesMasterId;
	
	private VOUtilityChargesMasterDTO utilityChargesMaster;

	private String bookingPoints;

	private String pointsCurrent;
	 
	private String pointsNext1;
	 
	private String pointsNext2;
	 
	private String pointsPrevious1;
	 
	private String pointsPrevious2;

	private String hPointsCurrent;
	 
	private String hPointsPrevious1;
	 
	private String hPointsPrevious2;
	 
	private String hPointsNext1;
	 
	private String hPointsNext2;
	
	private Double borrowedPoints;
	
	private boolean advPointsNext1;
	
	private boolean advPointsNext2;

	private String seasonCode;
	
	private String bookingType;
	
	private String offerType;
	
	private String offerCheckinDate;
	
	private String offerCheckoutDate;
	
	private String offeredUnits;
	
	private String bookingMode;
	
	private List<VOBookingRoomDetailReq> bookingRoomDetails;
	
	private List<VOBookingEnhancementDetailReq> enhancementDetails;
	
	private VOExtarPersonDetailDTO guestFeeDetail;
	
	private String memberName;
	
	private RateAHolidayRequest ratings;

	private Boolean brdBookingFlag;
	
	private String reservationType;
	
	private VOGuestDetailDTO guestDetail;

	private List<VOEmiAsfResDTO> emiAsfDetails;
	
	private String travelingType;
	
	private Double payatResortGuestFee;
	private Double payatResortUtilityCharge;
	private Boolean payatResortGuestFlag;
	private Boolean payatResortUtilityFlag;
	private Double pointsRecredit;	
	
	public Boolean getPayatResortGuestFlag() {
		return payatResortGuestFlag;
	}
	public void setPayatResortGuestFlag(Boolean payatResortGuestFlag) {
		this.payatResortGuestFlag = payatResortGuestFlag;
	}
	public Boolean getPayatResortUtilityFlag() {
		return payatResortUtilityFlag;
	}
	public void setPayatResortUtilityFlag(Boolean payatResortUtilityFlag) {
		this.payatResortUtilityFlag = payatResortUtilityFlag;
	}
	public Double getPayatResortGuestFee() {
		return payatResortGuestFee;
	}
	public void setPayatResortGuestFee(Double payatResortGuestFee) {
		this.payatResortGuestFee = payatResortGuestFee;
	}

	public Double getPayatResortUtilityCharge() {
		return payatResortUtilityCharge;
	}

	public void setPayatResortUtilityCharge(Double payatResortUtilityCharge) {
		this.payatResortUtilityCharge = payatResortUtilityCharge;
	}

	public String getTravelingType() {
		return travelingType;
	}

	public void setTravelingType(String travelingType) {
		this.travelingType = travelingType;
	}

	public List<VOEmiAsfResDTO> getEmiAsfDetails() {
		return emiAsfDetails;
	}

	public void setEmiAsfDetails(List<VOEmiAsfResDTO> emiAsfDetails) {
		this.emiAsfDetails = emiAsfDetails;
	}

	public VOGuestDetailDTO getGuestDetail() {
		return guestDetail;
	}

	public void setGuestDetail(VOGuestDetailDTO guestDetail) {
		this.guestDetail = guestDetail;
	}

	public String getReservationType() {
		return reservationType;
	}

	public void setReservationType(String reservationType) {
		this.reservationType = reservationType;
	}

	public VOUtilityChargesMasterDTO getUtilityChargesMaster() {
		return utilityChargesMaster;
	}

	public void setUtilityChargesMaster(
			VOUtilityChargesMasterDTO utilityChargesMaster) {
		this.utilityChargesMaster = utilityChargesMaster;
	}

	public Boolean getBrdBookingFlag() {
		return brdBookingFlag;
	}

	public void setBrdBookingFlag(Boolean brdBookingFlag) {
		this.brdBookingFlag = brdBookingFlag;
	}

	public RateAHolidayRequest getRatings() {
		return ratings;
	}

	public void setRatings(RateAHolidayRequest ratings) {
		this.ratings = ratings;
	}

	/**
	 * @return bookingId
	 */
	public String getBookingId() {
		return bookingId;
	}

	/**
	 * @param bookingId
	 * set the bookingId
	 */
	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}

	/**
	 * @return bookingDate
	 */
	public String getBookingDate() {
		return bookingDate;
	}

	/**
	 * @param bookingDate
	 * set the bookingDate
	 */
	public void setBookingDate(String bookingDate) {
		this.bookingDate = bookingDate;
	}

	/**
	 * @return contractId
	 */
	public String getContractId() {
		return contractId;
	}

	/**
	 * @param contractId
	 * set the contractId
	 */
	public void setContractId(String contractId) {
		this.contractId = contractId;
	}

	/**
	 * @return checkInDate
	 */
	public String getCheckInDate() {
		return checkInDate;
	}

	/**
	 * @param checkInDate
	 * set the checkInDate
	 */
	public void setCheckInDate(String checkInDate) {
		this.checkInDate = checkInDate;
	}

	/**
	 * @return checkOutDate
	 */
	public String getCheckOutDate() {
		return checkOutDate;
	}

	/**
	 * @param checkOutDate
	 * set the checkOutDate
	 */
	public void setCheckOutDate(String checkOutDate) {
		this.checkOutDate = checkOutDate;
	}

	/**
	 * @return bookingStatus
	 */
	public String getBookingStatus() {
		return bookingStatus;
	}

	/**
	 * @param bookingStatus
	 * set the bookingStatus
	 */
	public void setBookingStatus(String bookingStatus) {
		this.bookingStatus = bookingStatus;
	}

	/**
	 * @return noOfAdults
	 */
	public String getNoOfAdults() {
		return noOfAdults;
	}

	/**
	 * @param noOfAdults
	 * set the noOfAdults
	 */
	public void setNoOfAdults(String noOfAdults) {
		this.noOfAdults = noOfAdults;
	}

	/**
	 * @return noOfChildren
	 */
	public String getNoOfChildren() {
		return noOfChildren;
	}

	/**
	 * @param noOfChildren
	 * set the noOfChildren
	 */
	public void setNoOfChildren(String noOfChildren) {
		this.noOfChildren = noOfChildren;
	}

	/**
	 * @return cvNumber
	 */
	public String getBookingCVNumber() {
		return cvNumber;
	}

	/**
	 * @param bookingCVNumber
	 * set the bookingCVNumber
	 */
	public void setBookingCVNumber(String bookingCVNumber) {
		this.cvNumber = bookingCVNumber;
	}

	/**
	 * @return productId
	 */
	public String getProductId() {
		return productId;
	}

	/**
	 * @param productId
	 * set the productId
	 */
	public void setProductId(String productId) {
		this.productId = productId;
	}

	/**
	 * @return resortMasterId
	 */
	public String getResortMasterId() {
		return resortMasterId;
	}

	/**
	 * @param resortMasterId
	 * set the resortMasterId
	 */
	public void setResortMasterId(String resortMasterId) {
		this.resortMasterId = resortMasterId;
	}

	/**
	 * @return noOf1BR
	 */
	public String getNoOf1BR() {
		return noOf1BR;
	}

	/**
	 * @param noOf1BR
	 * set the noOf1BR
	 */
	public void setNoOf1BR(String noOf1BR) {
		this.noOf1BR = noOf1BR;
	}

	/**
	 * @return noOf2BR
	 */
	public String getNoOf2BR() {
		return noOf2BR;
	}

	/**
	 * @param noOf2BR
	 * set the noOf2BR
	 */
	public void setNoOf2BR(String noOf2BR) {
		this.noOf2BR = noOf2BR;
	}

	/**
	 * @return noOfStudio
	 */
	public String getNoOfStudio() {
		return noOfStudio;
	}

	/**
	 * @param noOfStudio
	 * set the noOfStudio
	 */
	public void setNoOfStudio(String noOfStudio) {
		this.noOfStudio = noOfStudio;
	}

	/**
	 * @return noOfGuest
	 */
	public String getNoOfGuest() {
		return noOfGuest;
	}

	/**
	 * @param noOfGuest
	 * set the noOfGuest
	 */
	public void setNoOfGuest(String noOfGuest) {
		this.noOfGuest = noOfGuest;
	}

	/**
	 * @return utilityChargesMasterId
	 */
	public String getUtilityChargesMasterId() {
		return utilityChargesMasterId;
	}

	/**
	 * @param utilityChargesMasterId
	 * set the utilityChargesMasterId
	 */
	public void setUtilityChargesMasterId(String utilityChargesMasterId) {
		this.utilityChargesMasterId = utilityChargesMasterId;
	}

	/**
	 * @return bookingPoints
	 */
	public String getBookingPoints() {
		return bookingPoints;
	}

	/**
	 * @param bookingPoints
	 * set the bookingPoints
	 */
	
	public void setBookingPoints(String bookingPoints) {
		this.bookingPoints = bookingPoints;
	}

	/**
	 * @return pointsCurrent
	 */
	public String getPointsCurrent() {
		return pointsCurrent;
	}

	/**
	 * @param pointsCurrent
	 * set the pointsCurrent
	 */
	public void setPointsCurrent(String pointsCurrent) {
		this.pointsCurrent = pointsCurrent;
	}

	/**
	 * @return pointsNext1
	 */
	public String getPointsNext1() {
		return pointsNext1;
	}

	/**
	 * @param pointsNext1
	 * set the pointsNext1
	 */
	public void setPointsNext1(String pointsNext1) {
		this.pointsNext1 = pointsNext1;
	}

	/**
	 * @return pointsNext2
	 */
	public String getPointsNext2() {
		return pointsNext2;
	}

	/**
	 * @param pointsNext2
	 * set the pointsNext2
	 */
	public void setPointsNext2(String pointsNext2) {
		this.pointsNext2 = pointsNext2;
	}

	/**
	 * @return pointsPrevious1
	 */
	public String getPointsPrevious1() {
		return pointsPrevious1;
	}

	/**
	 * @param pointsPrevious1
	 * set the pointsPrevious1
	 */
	public void setPointsPrevious1(String pointsPrevious1) {
		this.pointsPrevious1 = pointsPrevious1;
	}

	/**
	 * @return pointsPrevious2
	 */
	public String getPointsPrevious2() {
		return pointsPrevious2;
	}

	/**
	 * @param pointsPrevious2
	 * set the pointsPrevious2
	 */
	public void setPointsPrevious2(String pointsPrevious2) {
		this.pointsPrevious2 = pointsPrevious2;
	}

	/**
	 * @return hPointsCurrent
	 */
	public String gethPointsCurrent() {
		return hPointsCurrent;
	}

	/**
	 * @param hPointsCurrent
	 * set the hPointsCurrent
	 */
	public void sethPointsCurrent(String hPointsCurrent) {
		this.hPointsCurrent = hPointsCurrent;
	}

	/**
	 * @return hPointsPrevious1
	 */
	public String gethPointsPrevious1() {
		return hPointsPrevious1;
	}

	/**
	 * @param hPointsPrevious1
	 * set the hPointsPrevious1
	 */
	public void sethPointsPrevious1(String hPointsPrevious1) {
		this.hPointsPrevious1 = hPointsPrevious1;
	}

	/**
	 * @return hPointsPrevious2
	 */
	public String gethPointsPrevious2() {
		return hPointsPrevious2;
	}

	/**
	 * @param hPointsPrevious2
	 * set the hPointsPrevious2
	 */
	public void sethPointsPrevious2(String hPointsPrevious2) {
		this.hPointsPrevious2 = hPointsPrevious2;
	}

	/**
	 * @return hPointsNext1
	 */
	public String gethPointsNext1() {
		return hPointsNext1;
	}

	/**
	 * @param hPointsNext1
	 * set the hPointsNext1
	 */
	public void sethPointsNext1(String hPointsNext1) {
		this.hPointsNext1 = hPointsNext1;
	}

	/**
	 * @return hPointsNext2
	 */
	public String gethPointsNext2() {
		return hPointsNext2;
	}

	/**
	 * @param hPointsNext2
	 * set the hPointsNext2
	 */
	public void sethPointsNext2(String hPointsNext2) {
		this.hPointsNext2 = hPointsNext2;
	}

	/**
	 * @return advPointsNext1
	 */
	public boolean isAdvPointsNext1() {
		return advPointsNext1;
	}

	/**
	 * @param advPointsNext1
	 * set the advPointsNext1
	 */
	public void setAdvPointsNext1(boolean advPointsNext1) {
		this.advPointsNext1 = advPointsNext1;
	}

	/**
	 * @return advPointsNext2
	 */
	public boolean isAdvPointsNext2() {
		return advPointsNext2;
	}

	/**
	 * @param advPointsNext2
	 * set the advPointsNext2
	 */
	public void setAdvPointsNext2(boolean advPointsNext2) {
		this.advPointsNext2 = advPointsNext2;
	}

	/**
	 * @return bookingRoomDetails
	 */
	public List<VOBookingRoomDetailReq> getBookingRoomDetails() {
		return bookingRoomDetails;
	}

	/**
	 * @param bookingRoomDetails
	 * set the bookingRoomDetails
	 */
	public void setBookingRoomDetails(
			List<VOBookingRoomDetailReq> bookingRoomDetails) {
		this.bookingRoomDetails = bookingRoomDetails;
	}

	/**
	 * @return cvNumber
	 */
	public String getCvNumber() {
		return cvNumber;
	}

	/**
	 * @param cvNumber
	 * set the cvNumber
	 */
	public void setCvNumber(String cvNumber) {
		this.cvNumber = cvNumber;
	}

	/**
	 * @return resortMasterName
	 */
	public String getResortMasterName() {
		return resortMasterName;
	}

	/**
	 * @param resortMasterName
	 * set the resortMasterName
	 */
	public void setResortMasterName(String resortMasterName) {
		this.resortMasterName = resortMasterName;
	}

	/**
	 * @return resortSerialNumber
	 */
	public String getResortSerialNumber() {
		return resortSerialNumber;
	}

	/**
	 * @param resortSerialNumber
	 * set the resortSerialNumber
	 */
	public void setResortSerialNumber(String resortSerialNumber) {
		this.resortSerialNumber = resortSerialNumber;
	}

	/**
	 * @return seasonCode
	 */
	public String getSeasonCode() {
		return seasonCode;
	}

	/**
	 * @param seasonCode
	 * set the seasonCode
	 */
	public void setSeasonCode(String seasonCode) {
		this.seasonCode = seasonCode;
	}

	/**
	 * @return enhancementDetails
	 */
	public List<VOBookingEnhancementDetailReq> getEnhancementDetails() {
		return enhancementDetails;
	}

	/**
	 * @param enhancementDetails
	 * set the enhancementDetails
	 */
	public void setEnhancementDetails(
			List<VOBookingEnhancementDetailReq> enhancementDetails) {
		this.enhancementDetails = enhancementDetails;
	}

	/**
	 * @return memberName
	 */
	public String getMemberName() {
		return memberName;
	}

	/**
	 * @param memberName
	 * set the memberName
	 */
	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}

	public String getOfferType() {
		return offerType;
	}

	public void setOfferType(String offerType) {
		this.offerType = offerType;
	}

	public String getOfferCheckinDate() {
		return offerCheckinDate;
	}

	public void setOfferCheckinDate(String offerCheckinDate) {
		this.offerCheckinDate = offerCheckinDate;
	}

	public String getOfferCheckoutDate() {
		return offerCheckoutDate;
	}

	public void setOfferCheckoutDate(String offerCheckoutDate) {
		this.offerCheckoutDate = offerCheckoutDate;
	}

	public String getOfferedUnits() {
		return offeredUnits;
	}

	public void setOfferedUnits(String offeredUnits) {
		this.offeredUnits = offeredUnits;
	}

	public String getBookingType() {
		return bookingType;
	}

	public void setBookingType(String bookingType) {
		this.bookingType = bookingType;
	}

	public String getBookingMode() {
		return bookingMode;
	}

	public void setBookingMode(String bookingMode) {
		this.bookingMode = bookingMode;
	}
	
	public Double getBorrowedPoints() {
		return borrowedPoints;
	}

	public void setBorrowedPoints(Double borrowedPoints) {
		this.borrowedPoints = borrowedPoints;
	}

	public VOExtarPersonDetailDTO getGuestFeeDetail() {
		return guestFeeDetail;
	}

	public void setGuestFeeDetail(VOExtarPersonDetailDTO guestFeeDetail) {
		this.guestFeeDetail = guestFeeDetail;
	}
	/**
	 * @return the pointsRecredit
	 */
	public Double getPointsRecredit() {
		return pointsRecredit;
	}
	/**
	 * @param pointsRecredit the pointsRecredit to set
	 */
	public void setPointsRecredit(Double pointsRecredit) {
		this.pointsRecredit = pointsRecredit;
	}
}
