package com.sterling.bookingapi.dto;

import java.io.Serializable;

/**
 * @author tcs
 *
 */
public class PaymentRequestDTO implements Serializable {
  
	private static final long serialVersionUID = 1L;
	/**
     * Calculated based on all the data provided using SHA-256 Algorithm.
     */
	private String privatekey;
	/**
     * Calculated based on all the data provided using MD-5 Algorithm.
     */
	private String checksum;
    /**
     * Have to defined before deployment
     */
    private String mercid;
    /**
     * Have to defined before deployment
     */
    private String chmod;
    /**
     * orderId - Unique Booking id. 
     */
    private String orderid;
    
    /**
     * Email - mandatory
     */
    private String buyerEmail;
    private String buyerPhone;
    /**
     * First Name - mandatory
     */
    private String buyerFirstName;
    /**
     * Last Name - mandatory
     */
    private String buyerLastName;
    private String buyerAddress;
    private String buyerCity;
    private String buyerState;
    private String buyerCountry;
    private String buyerPinCode;
    /**
     * Amount to be paid- mandatory
     */
    private Double amount;
    
    private String customVar;
   
	public String getCustomVar() {
		return customVar;
	}
	public void setCustomVar(String customVar) {
		this.customVar = customVar;
	}
	public String getPrivatekey() {
		return privatekey;
	}
	public void setPrivatekey(String privatekey) {
		this.privatekey = privatekey;
	}
	public String getChecksum() {
		return checksum;
	}
	public void setChecksum(String checksum) {
		this.checksum = checksum;
	}
	public String getMercid() {
		return mercid;
	}
	public void setMercid(String mercid) {
		this.mercid = mercid;
	}
	public String getOrderid() {
		return orderid;
	}
	public void setOrderid(String orderid) {
		this.orderid = orderid;
	}
	public String getBuyerEmail() {
		return buyerEmail;
	}
	public void setBuyerEmail(String buyerEmail) {
		this.buyerEmail = buyerEmail;
	}
	public String getBuyerPhone() {
		return buyerPhone;
	}
	public void setBuyerPhone(String buyerPhone) {
		this.buyerPhone = buyerPhone;
	}
	public String getBuyerFirstName() {
		return buyerFirstName;
	}
	public void setBuyerFirstName(String buyerFirstName) {
		this.buyerFirstName = buyerFirstName;
	}
	public String getBuyerLastName() {
		return buyerLastName;
	}
	public void setBuyerLastName(String buyerLastName) {
		this.buyerLastName = buyerLastName;
	}
	public String getBuyerAddress() {
		return buyerAddress;
	}
	public void setBuyerAddress(String buyerAddress) {
		this.buyerAddress = buyerAddress;
	}
	public String getBuyerCity() {
		return buyerCity;
	}
	public void setBuyerCity(String buyerCity) {
		this.buyerCity = buyerCity;
	}
	public String getBuyerState() {
		return buyerState;
	}
	public void setBuyerState(String buyerState) {
		this.buyerState = buyerState;
	}
	public String getBuyerCountry() {
		return buyerCountry;
	}
	public void setBuyerCountry(String buyerCountry) {
		this.buyerCountry = buyerCountry;
	}
	public String getBuyerPinCode() {
		return buyerPinCode;
	}
	public void setBuyerPinCode(String buyerPinCode) {
		this.buyerPinCode = buyerPinCode;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public String getChmod() {
		return chmod;
	}
	public void setChmod(String chmod) {
		this.chmod = chmod;
	}
    
    
}
