package com.sterling.bookingapi.dto.request;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.sterling.bookingapi.sf.dto.request.VOPGDetailsDTO;


/**
 * The Class HsdBookingOfferDetailsDTO.
 */
/**
 * @author tcs
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class VoCaptureEMIPaymentRequestDTO extends VoBaseRequestDTO implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	
	private String contractId;
	
	private String primaryApplicantId;
	
	private List<VOEMIASFDetailsDTO> emiDetailsList;
	
	private VOPGDetailsDTO voPaymentGatewayDetails;

	/**
	 * @return primaryApplicantId
	 */
	public String getPrimaryApplicantId() {
		return primaryApplicantId;
	}
	/**
	 * @param primaryApplicantId
	 * set the primaryApplicantId
	 */
	public void setPrimaryApplicantId(String primaryApplicantId) {
		this.primaryApplicantId = primaryApplicantId;
	}
	
	/**
	 * @return voPaymentGatewayDetails
	 */
	public VOPGDetailsDTO getVoPaymentGatewayDetails() {
		return voPaymentGatewayDetails;
	}
	/**
	 * @param voPaymentGatewayDetails
	 * set the voPaymentGatewayDetails
	 */
	public void setVoPaymentGatewayDetails(VOPGDetailsDTO voPaymentGatewayDetails) {
		this.voPaymentGatewayDetails = voPaymentGatewayDetails;
	}
	/**
	 * @return contract id
	 */
	public String getContractId() {
		return contractId;
	}
	/**
	 * @return emiDetailsList
	 */
	public List<VOEMIASFDetailsDTO> getEmiDetailsList() {
		return emiDetailsList;
	}
	/**
	 * @param emiDetailsList
	 * set the emiDetailsList
	 */
	public void setEmiDetailsList(List<VOEMIASFDetailsDTO> emiDetailsList) {
		this.emiDetailsList = emiDetailsList;
	}
	/**
	 * @param contractId
	 * set the contract id
	 */
	public void setContractId(String contractId) {
		this.contractId = contractId;
	}
}