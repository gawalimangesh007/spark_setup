package com.sterling.bookingapi.dto.request;

public enum OTPFlow {

	LEAD_REG_FLOW,
	HSD_REG_FLOW,
	VO_FORGOT_PASS,
	HSD_FORGOT_PASS,
	VO_RESET_PASS,
	HSD_RESET_PASS,
	VO_CANCEL_BOOKING,
	HSD_CANCEL_BOOKING, 
	VO_USER_UPDATE_OTP;
	
}
