package com.sterling.bookingapi.dto.maximojo.response;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class RateResDTO.
 * @author tcs
 * @version 1.0
 */
public class RateResDTO {

	/** The inv code. */
	@JacksonXmlProperty(localName = "InvCode", isAttribute = true)
	private String invCode;

	/** The inv type code. */
	@JacksonXmlProperty(localName = "InvTypeCode", isAttribute = true)
	private String invTypeCode;

	/** The number of units. */
	@JacksonXmlProperty(localName = "NumberOfUnits", isAttribute = true)
	private int numberOfUnits;

	/**
	 * Gets the number of units.
	 *
	 * @return the numberOfUnits
	 */
	public int getNumberOfUnits() {
		return numberOfUnits;
	}

	/**
	 * Sets the number of units.
	 *
	 * @param numberOfUnits            the numberOfUnits to set
	 */
	public void setNumberOfUnits(int numberOfUnits) {
		this.numberOfUnits = numberOfUnits;
	}

	/**
	 * Gets the inv code.
	 *
	 * @return the inv code
	 */
	public String getInvCode() {
		return invCode;
	}

	/**
	 * Sets the inv code.
	 *
	 * @param invCode the new inv code
	 */
	public void setInvCode(String invCode) {
		this.invCode = invCode;
	}

	/**
	 * Gets the inv type code.
	 *
	 * @return the inv type code
	 */
	public String getInvTypeCode() {
		return invTypeCode;
	}

	/**
	 * Sets the inv type code.
	 *
	 * @param invTypeCode the new inv type code
	 */
	public void setInvTypeCode(String invTypeCode) {
		this.invTypeCode = invTypeCode;
	}

}
