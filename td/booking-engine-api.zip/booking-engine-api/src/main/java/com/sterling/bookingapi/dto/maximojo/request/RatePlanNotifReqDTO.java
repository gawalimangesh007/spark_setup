package com.sterling.bookingapi.dto.maximojo.request;

import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class RatePlanNotifReqDTO.
 */
/**
 * @author tcs
 *
 */
public class RatePlanNotifReqDTO {

	/** The end. */
	@JacksonXmlProperty(localName = "End", isAttribute = true)
	private String end;

	/** The description. */
	@JacksonXmlProperty(localName = "Description")
    private DescriptionReqDTO description;

	/** The start. */
	@JacksonXmlProperty(localName = "Start", isAttribute = true)
    private String start;

	/** The rate. */
	@JacksonXmlElementWrapper(useWrapping=true,localName = "Rates")
	@JacksonXmlProperty(localName = "Rate")
    private List<RateNotifReqDTO> rate;

	/** The rate plan code. */
	@JacksonXmlProperty(localName = "RatePlanCode", isAttribute = true)
    private String ratePlanCode;

	/**
	 * Gets the end.
	 *
	 * @return the end
	 */
	public String getEnd() {
		return end;
	}

	/**
	 * Sets the end.
	 *
	 * @param end the end to set
	 */
	public void setEnd(String end) {
		this.end = end;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public DescriptionReqDTO getDescription() {
		return description;
	}

	/**
	 * Sets the description.
	 *
	 * @param description the description to set
	 */
	public void setDescription(DescriptionReqDTO description) {
		this.description = description;
	}

	/**
	 * Gets the start.
	 *
	 * @return the start
	 */
	public String getStart() {
		return start;
	}

	/**
	 * Sets the start.
	 *
	 * @param start the start to set
	 */
	public void setStart(String start) {
		this.start = start;
	}

	/**
	 * Gets the rate.
	 *
	 * @return the rate
	 */
	public List<RateNotifReqDTO> getRate() {
		return rate;
	}

	/**
	 * Sets the rate.
	 *
	 * @param rate the rate to set
	 */
	public void setRate(List<RateNotifReqDTO> rate) {
		this.rate = rate;
	}

	/**
	 * Gets the rate plan code.
	 *
	 * @return the ratePlanCode
	 */
	public String getRatePlanCode() {
		return ratePlanCode;
	}

	/**
	 * Sets the rate plan code.
	 *
	 * @param ratePlanCode the ratePlanCode to set
	 */
	public void setRatePlanCode(String ratePlanCode) {
		this.ratePlanCode = ratePlanCode;
	}
	
	
}
