package com.sterling.bookingapi.dto.maximojo.request;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class RateBooingReqDTO.
 */
/**
 * @author tcs
 *
 */
public class RateBooingReqDTO {

	/** The effective date. */
	@JacksonXmlProperty(localName = "EffectiveDate", isAttribute = true)
    private String effectiveDate;
	
	/** The expire date. */
	@JacksonXmlProperty(localName = "ExpireDate", isAttribute = true)
    private String expireDate;
	
	/** The rate time unit. */
	@JacksonXmlProperty(localName = "RateTimeUnit", isAttribute = true)
    private String rateTimeUnit;

	/** The unit multiplier. */
	@JacksonXmlProperty(localName = "UnitMultiplier", isAttribute = true)
    private int unitMultiplier;
	
	/** The base. */
	@JacksonXmlProperty(localName = "Base")
	private BaseReqDTO base;

	/**
	 * Gets the base.
	 *
	 * @return the base
	 */
	public BaseReqDTO getBase() {
		return base;
	}

	/**
	 * Sets the base.
	 *
	 * @param base the new base
	 */
	public void setBase(BaseReqDTO base) {
		this.base = base;
	}

	/**
	 * Gets the expire date.
	 *
	 * @return the expire date
	 */
	public String getExpireDate() {
		return expireDate;
	}

	/**
	 * Sets the expire date.
	 *
	 * @param expireDate the new expire date
	 */
	public void setExpireDate(String expireDate) {
		this.expireDate = expireDate;
	}

	/**
	 * Gets the rate time unit.
	 *
	 * @return the rate time unit
	 */
	public String getRateTimeUnit() {
		return rateTimeUnit;
	}

	/**
	 * Sets the rate time unit.
	 *
	 * @param rateTimeUnit the new rate time unit
	 */
	public void setRateTimeUnit(String rateTimeUnit) {
		this.rateTimeUnit = rateTimeUnit;
	}

	/**
	 * Gets the effective date.
	 *
	 * @return the effective date
	 */
	public String getEffectiveDate() {
		return effectiveDate;
	}

	/**
	 * Sets the effective date.
	 *
	 * @param effectiveDate the new effective date
	 */
	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	/**
	 * Gets the unit multiplier.
	 *
	 * @return the unit multiplier
	 */
	public int getUnitMultiplier() {
		return unitMultiplier;
	}

	/**
	 * Sets the unit multiplier.
	 *
	 * @param unitMultiplier the new unit multiplier
	 */
	public void setUnitMultiplier(int unitMultiplier) {
		this.unitMultiplier = unitMultiplier;
	}

	
}
