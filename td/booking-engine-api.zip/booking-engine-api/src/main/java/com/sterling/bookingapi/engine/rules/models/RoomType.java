package com.sterling.bookingapi.engine.rules.models;

public enum RoomType {

	ONE_BR("1BR"), TWO_BR("2BR"), ST("Studio Room"), GR("Guest Room");

	private String type;
	
	private RoomType(String type) {
		this.type = type;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	public static RoomType getByName(String type) {
		RoomType roomType = null;
		if(type != null) {
			for (RoomType rType : RoomType.values()) {
				if(rType.getType().equalsIgnoreCase(type)) {
					roomType = rType;
					break;
				}
			}
		}
		return roomType;
	}
	
}
