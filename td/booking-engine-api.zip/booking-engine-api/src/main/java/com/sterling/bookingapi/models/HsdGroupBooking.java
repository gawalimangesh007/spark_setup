package com.sterling.bookingapi.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.Email;


/**
 * The Class HsdGroupBooking.
 */
/**
 * @author tcs
 *
 */
@Entity
@Table(name = "sh_hsd_group_booking_details")
public class HsdGroupBooking extends BaseModel{
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The Id. */
	@Id
	@GeneratedValue( strategy = GenerationType.IDENTITY )
	@Column(name = "booking_idx_id", unique = true)
	private int Id;
		
	/** The first name. */
	@Column(name = "first_name",nullable = false)
	private String first_name;
	
	/** The last name. */
	@Column(name = "last_name",nullable = false)
	private String last_name;
	
	/** The email. */
	@Column(name = "email",nullable = false)
	private String email;
	
	/** The mobile. */
	@Column(name = "mobile",nullable = false)
	private String mobile;
	
	/** The number of person. */
	@Column(name = "number_of_person",nullable = false)
	private String numberOfPerson;
	
	/** The number of room. */
	@Column(name = "number_of_room",nullable = false)
	private String numberOfRoom;
	
	/** The comments. */
	@Column(name = "comments",nullable = false)
	private String comments;

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public int getId() {
		return Id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(int id) {
		Id = id;
	}

	/**
	 * Gets the first name.
	 *
	 * @return the first name
	 */
	public String getFirst_name() {
		return first_name;
	}

	/**
	 * Sets the first name.
	 *
	 * @param first_name the new first name
	 */
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	/**
	 * Gets the last name.
	 *
	 * @return the last name
	 */
	public String getLast_name() {
		return last_name;
	}

	/**
	 * Sets the last name.
	 *
	 * @param last_name the new last name
	 */
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	/**
	 * Gets the email.
	 *
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * Sets the email.
	 *
	 * @param email the new email
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * Gets the mobile.
	 *
	 * @return the mobile
	 */
	public String getMobile() {
		return mobile;
	}

	/**
	 * Sets the mobile.
	 *
	 * @param mobile the new mobile
	 */
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	/**
	 * Gets the number of person.
	 *
	 * @return the number of person
	 */
	public String getNumberOfPerson() {
		return numberOfPerson;
	}

	/**
	 * Sets the number of person.
	 *
	 * @param numberOfPerson the new number of person
	 */
	public void setNumberOfPerson(String numberOfPerson) {
		this.numberOfPerson = numberOfPerson;
	}

	/**
	 * Gets the number of room.
	 *
	 * @return the number of room
	 */
	public String getNumberOfRoom() {
		return numberOfRoom;
	}

	/**
	 * Sets the number of room.
	 *
	 * @param numberOfRoom the new number of room
	 */
	public void setNumberOfRoom(String numberOfRoom) {
		this.numberOfRoom = numberOfRoom;
	}

	/**
	 * Gets the comments.
	 *
	 * @return the comments
	 */
	public String getComments() {
		return comments;
	}

	/**
	 * Sets the comments.
	 *
	 * @param comments the new comments
	 */
	public void setComments(String comments) {
		this.comments = comments;
	}
	
}
