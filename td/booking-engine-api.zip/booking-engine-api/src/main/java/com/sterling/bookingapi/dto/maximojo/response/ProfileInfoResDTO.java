package com.sterling.bookingapi.dto.maximojo.response;

import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class ProfileInfoResDTO.
 * @author tcs
 * @version 1.0
 */
public class ProfileInfoResDTO {

	/** The profile. */
	@JacksonXmlElementWrapper(useWrapping=false, localName = "Profile")
    @JacksonXmlProperty(localName = "Profile")
	private List<ProfileResDTO> profile;

	/**
	 * Gets the profile.
	 *
	 * @return the profile
	 */
	public List<ProfileResDTO> getProfile() {
		return profile;
	}

	/**
	 * Sets the profile.
	 *
	 * @param profile the profile to set
	 */
	public void setProfile(List<ProfileResDTO> profile) {
		this.profile = profile;
	}
	
	
}
