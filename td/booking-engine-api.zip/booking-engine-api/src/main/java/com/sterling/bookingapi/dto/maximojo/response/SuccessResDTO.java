package com.sterling.bookingapi.dto.maximojo.response;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlText;


/**
 * The Class SuccessResDTO.
 * @author tcs
 * @version 1.0
 */
public class SuccessResDTO {
	
	/** The success. */
	@JacksonXmlText
	private String success;

	/**
	 * Gets the success.
	 *
	 * @return the success
	 */
	public String getSuccess() {
		return success;
	}

	/**
	 * Sets the success.
	 *
	 * @param success the success to set
	 */
	public void setSuccess(String success) {
		this.success = success;
	}

	

}
