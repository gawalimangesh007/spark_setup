package com.sterling.bookingapi.dto.response;

import java.io.Serializable;
import java.util.List;

public class VOProdDPMappingWrapperDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private List<VOProdDPMappingResDTO> prodDPMapping;
	
	public VOProdDPMappingWrapperDTO() {
		super();
	}

	public VOProdDPMappingWrapperDTO(List<VOProdDPMappingResDTO> prodDPMapping) {
		super();
		this.prodDPMapping = prodDPMapping;
	}

	public List<VOProdDPMappingResDTO> getProdDPMapping() {
		return prodDPMapping;
	}

	public void setProdDPMapping(List<VOProdDPMappingResDTO> prodDPMapping) {
		this.prodDPMapping = prodDPMapping;
	}

}
