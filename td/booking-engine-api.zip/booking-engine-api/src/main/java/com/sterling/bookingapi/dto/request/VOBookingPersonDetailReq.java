package com.sterling.bookingapi.dto.request;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author tcs
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class VOBookingPersonDetailReq implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String relationship;
	private String name;
	private String age;
	private String gender;
	private String typeOfGuest;
	private Boolean isExtraPerson;
	private String typeOfRoom;
	private Integer sequenceNo;
	/**
	 * @return relationship detail
	 */
	public String getRelationship() {
		return relationship;
	}
	/**
	 * @param relationship
	 * set the relationship
	 */
	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}
	/**
	 * @return name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name
	 * set the name
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return age
	 */
	public String getAge() {
		return age;
	}
	/**
	 * @param age
	 * set the age
	 */
	public void setAge(String age) {
		this.age = age;
	}
	/**
	 * @return gender
	 */
	public String getGender() {
		return gender;
	}
	/**
	 * @param gender
	 * set the gender
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}
	/**
	 * @return type of guest
	 */
	public String getTypeOfGuest() {
		return typeOfGuest;
	}
	/**
	 * @param typeOfGuest
	 * set the type of guest
	 */
	public void setTypeOfGuest(String typeOfGuest) {
		this.typeOfGuest = typeOfGuest;
	}
	/**
	 * @return get extra person is available or not
	 */
	public Boolean getIsExtraPerson() {
		return isExtraPerson;
	}
	/**
	 * @param isExtraPerson
	 * set extra person
	 */
	public void setIsExtraPerson(Boolean isExtraPerson) {
		this.isExtraPerson = isExtraPerson;
	}
	/**
	 * @return type of room
	 */
	public String getTypeOfRoom() {
		return typeOfRoom;
	}
	/**
	 * @param typeOfRoom
	 * set the type of room
	 */
	public void setTypeOfRoom(String typeOfRoom) {
		this.typeOfRoom = typeOfRoom;
	}
	public Integer getSequenceNo() {
		return sequenceNo;
	}
	public void setSequenceNo(Integer sequenceNo) {
		this.sequenceNo = sequenceNo;
	}

	
}
