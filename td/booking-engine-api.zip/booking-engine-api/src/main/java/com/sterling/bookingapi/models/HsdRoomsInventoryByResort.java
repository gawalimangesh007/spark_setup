package com.sterling.bookingapi.models;

import java.util.Date;


/**
 * The Class HsdRoomsInventoryByResort.
 */
/**
 * @author tcs
 *
 */
public class HsdRoomsInventoryByResort {
	
	/** The resort room id. */
	private int resortRoomId;
	
	/** The available date. */
	private Date availableDate;
	
	/** The available rooms. */
	private int availableRooms;
	
	/** The room type. */
	private String roomType;
	
	/** The rate plan. */
	private String ratePlan;
	
	/** The status. */
	private boolean status;
	
	/** The min stay days. */
	private int minStayDays;
	
	/** The max staydays. */
	private int maxStaydays;
	
	/**
	 * Gets the available date.
	 *
	 * @return the availableDate
	 */
	public Date getAvailableDate() {
		return availableDate;
	}
	
	/**
	 * Sets the available date.
	 *
	 * @param availableDate the availableDate to set
	 */
	public void setAvailableDate(Date availableDate) {
		this.availableDate = availableDate;
	}
	
	/**
	 * Gets the available rooms.
	 *
	 * @return the availableRooms
	 */
	public int getAvailableRooms() {
		return availableRooms;
	}
	
	/**
	 * Sets the available rooms.
	 *
	 * @param availableRooms the availableRooms to set
	 */
	public void setAvailableRooms(int availableRooms) {
		this.availableRooms = availableRooms;
	}
	
	/**
	 * Gets the rate plan.
	 *
	 * @return the ratePlan
	 */
	public String getRatePlan() {
		return ratePlan;
	}
	
	/**
	 * Sets the rate plan.
	 *
	 * @param ratePlan the ratePlan to set
	 */
	public void setRatePlan(String ratePlan) {
		this.ratePlan = ratePlan;
	}
	
	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	public boolean getStatus() {
		return status;
	}
	
	/**
	 * Sets the status.
	 *
	 * @param status the status to set
	 */
	public void setStatus(boolean status) {
		this.status = status;
	}
	
	/**
	 * Gets the min stay days.
	 *
	 * @return the minStayDays
	 */
	public int getMinStayDays() {
		return minStayDays;
	}
	
	/**
	 * Sets the min stay days.
	 *
	 * @param minStayDays the minStayDays to set
	 */
	public void setMinStayDays(int minStayDays) {
		this.minStayDays = minStayDays;
	}
	
	/**
	 * Gets the max staydays.
	 *
	 * @return the maxStaydays
	 */
	public int getMaxStaydays() {
		return maxStaydays;
	}
	
	/**
	 * Sets the max staydays.
	 *
	 * @param maxStaydays the maxStaydays to set
	 */
	public void setMaxStaydays(int maxStaydays) {
		this.maxStaydays = maxStaydays;
	}
	
	/**
	 * Gets the room type.
	 *
	 * @return the roomType
	 */
	public String getRoomType() {
		return roomType;
	}
	
	/**
	 * Sets the room type.
	 *
	 * @param roomType the roomType to set
	 */
	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}
	
	/**
	 * Gets the resort room id.
	 *
	 * @return the resortRoomId
	 */
	public int getResortRoomId() {
		return resortRoomId;
	}
	
	/**
	 * Sets the resort room id.
	 *
	 * @param resortRoomId the resortRoomId to set
	 */
	public void setResortRoomId(int resortRoomId) {
		this.resortRoomId = resortRoomId;
	}
	
	/**
	 * Instantiates a new hsd rooms inventory by resort.
	 *
	 * @param resortRoomId the resort room id
	 * @param availableDate the available date
	 * @param availableRooms the available rooms
	 * @param roomType the room type
	 * @param ratePlan the rate plan
	 * @param status the status
	 * @param minStayDays the min stay days
	 * @param maxStaydays the max staydays
	 */
	public HsdRoomsInventoryByResort(int resortRoomId, Date availableDate, int availableRooms, String roomType,
			String ratePlan, boolean status, int minStayDays, int maxStaydays) {
		super();
		this.resortRoomId = resortRoomId;
		this.availableDate = availableDate;
		this.availableRooms = availableRooms;
		this.roomType = roomType;
		this.ratePlan = ratePlan;
		this.status = status;
		this.minStayDays = minStayDays;
		this.maxStaydays = maxStaydays;
	}
	
	
}
