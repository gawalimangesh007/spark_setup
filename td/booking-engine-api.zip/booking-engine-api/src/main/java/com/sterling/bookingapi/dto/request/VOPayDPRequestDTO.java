package com.sterling.bookingapi.dto.request;

import java.io.Serializable;

/**
 * @author tcs
 *
 */
public class VOPayDPRequestDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private VOPayCustomerDetailsDTO customerDetails;
	private String saleId;
	private Double amount;
	
	/**
	 * @return customerDetails
	 */
	public VOPayCustomerDetailsDTO getCustomerDetails() {
		return customerDetails;
	}
	/**
	 * @param customerDetails
	 * set the customerDetails
	 */
	public void setCustomerDetails(VOPayCustomerDetailsDTO customerDetails) {
		this.customerDetails = customerDetails;
	}
	/**
	 * @return salesid
	 */
	public String getSaleId() {
		return saleId;
	}
	/**
	 * @param saleId
	 * set the sales id
	 */
	public void setSaleId(String saleId) {
		this.saleId = saleId;
	}
	/**
	 * @return amount
	 */
	public Double getAmount() {
		return amount;
	}
	/**
	 * @param amount
	 * set the amount
	 */
	public void setAmount(Double amount) {
		this.amount = amount;
	}

}
