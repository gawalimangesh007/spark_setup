package com.sterling.bookingapi.auth.bean;

import java.io.Serializable;
import java.util.Date;

public class UserToken implements Serializable {

	private static final long serialVersionUID = -4720986982733184274L;

	private Long id;
	private User user;
	private String token;
	private String ipAddress;
	private String authType;
	private Long status;
	private Date createdDate;

	/**
	 * @return id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id
	 * set the id
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return  user
	 */
	public User getUser() {
		return user;
	}

	/**
	 * @param user
	 * set the user
	 */
	public void setUser(User user) {
		this.user = user;
	}

	/**
	 * @return authType
	 */
	public String getAuthType() {
		return authType;
	}

	/**
	 * @param authType
	 * set the authType
	 */
	public void setAuthType(String authType) {
		this.authType = authType;
	}

	/**
	 * @return token
	 */
	public String getToken() {
		return token;
	}

	/**
	 * @param token
	 * set the token
	 */
	public void setToken(String token) {
		this.token = token;
	}

	/**
	 * @return createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate
	 * set the createdDate
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	
	/**
	 * @return ipAddress
	 */
	public String getIpAddress() {
		return ipAddress;
	}

	/**
	 * @param ipAddress
	 * set the ipAddress
	 */
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	/**
	 * @return status
	 */
	public Long getStatus() {
		return status;
	}

	/**
	 * @param status
	 * set the status
	 */
	public void setStatus(Long status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "UserToken [user=" + user + ", token=" + token + "]";
	}

}
