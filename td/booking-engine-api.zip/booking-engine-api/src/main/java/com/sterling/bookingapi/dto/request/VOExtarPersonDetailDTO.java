package com.sterling.bookingapi.dto.request;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class VOExtarPersonDetailDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private Double totalAmount;
	private Integer quantity;
	private Double taxCGSTPercent;
	private Double taxSGSTPercent;
	private Double taxIGSTPercent;
	private Double totalTaxGSTPercent;
	private Double taxAmountCGST;
	private Double taxAmountSGST;
	private Double taxAmountIGST;
	private Double taxamountGST;
	
	public Double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	public Double getTaxCGSTPercent() {
		return taxCGSTPercent;
	}
	public void setTaxCGSTPercent(Double taxCGSTPercent) {
		this.taxCGSTPercent = taxCGSTPercent;
	}
	public Double getTaxSGSTPercent() {
		return taxSGSTPercent;
	}
	public void setTaxSGSTPercent(Double taxSGSTPercent) {
		this.taxSGSTPercent = taxSGSTPercent;
	}
	public Double getTaxIGSTPercent() {
		return taxIGSTPercent;
	}
	public void setTaxIGSTPercent(Double taxIGSTPercent) {
		this.taxIGSTPercent = taxIGSTPercent;
	}
	public Double getTotalTaxGSTPercent() {
		return totalTaxGSTPercent;
	}
	public void setTotalTaxGSTPercent(Double totalTaxGSTPercent) {
		this.totalTaxGSTPercent = totalTaxGSTPercent;
	}
	public Double getTaxAmountCGST() {
		return taxAmountCGST;
	}
	public void setTaxAmountCGST(Double taxAmountCGST) {
		this.taxAmountCGST = taxAmountCGST;
	}
	public Double getTaxAmountSGST() {
		return taxAmountSGST;
	}
	public void setTaxAmountSGST(Double taxAmountSGST) {
		this.taxAmountSGST = taxAmountSGST;
	}
	public Double getTaxAmountIGST() {
		return taxAmountIGST;
	}
	public void setTaxAmountIGST(Double taxAmountIGST) {
		this.taxAmountIGST = taxAmountIGST;
	}
	public Double getTaxamountGST() {
		return taxamountGST;
	}
	public void setTaxamountGST(Double taxamountGST) {
		this.taxamountGST = taxamountGST;
	}
}
