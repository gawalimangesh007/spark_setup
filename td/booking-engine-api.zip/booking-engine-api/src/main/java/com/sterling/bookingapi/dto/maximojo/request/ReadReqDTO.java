package com.sterling.bookingapi.dto.maximojo.request;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class ReadReqDTO.
 */
/**
 * @author tcs
 *
 */
public class ReadReqDTO {

	/** The hotel read request. */
	@JacksonXmlElementWrapper(useWrapping=true, localName = "ReadRequests")
	@JacksonXmlProperty(localName = "HotelReadRequest")
	private HotelReadReqDTO hotelReadRequest;

	/** The xmlns. */
	@JacksonXmlProperty(localName = "xmlns", isAttribute = true)
	private String xmlns="http://www.opentravel.org/OTA/2003/05";

	/** The version. */
	@JacksonXmlProperty(localName = "Version", isAttribute = true)
    private String version;

	/** The echo token. */
	@JacksonXmlProperty(localName = "EchoToken", isAttribute = true)
    private String echoToken;

	/**
	 * Gets the hotel read request.
	 *
	 * @return the hotelReadRequest
	 */
	public HotelReadReqDTO getHotelReadRequest() {
		return hotelReadRequest;
	}

	/**
	 * Sets the hotel read request.
	 *
	 * @param hotelReadRequest the hotelReadRequest to set
	 */
	public void setHotelReadRequest(HotelReadReqDTO hotelReadRequest) {
		this.hotelReadRequest = hotelReadRequest;
	}

	/**
	 * Gets the xmlns.
	 *
	 * @return the xmlns
	 */
	public String getXmlns() {
		return xmlns;
	}

	/**
	 * Sets the xmlns.
	 *
	 * @param xmlns the xmlns to set
	 */
	public void setXmlns(String xmlns) {
		this.xmlns = xmlns;
	}

	/**
	 * Gets the version.
	 *
	 * @return the version
	 */
	public String getVersion() {
		return version;
	}

	/**
	 * Sets the version.
	 *
	 * @param version the version to set
	 */
	public void setVersion(String version) {
		this.version = version;
	}

	/**
	 * Gets the echo token.
	 *
	 * @return the echoToken
	 */
	public String getEchoToken() {
		return echoToken;
	}

	/**
	 * Sets the echo token.
	 *
	 * @param echoToken the echoToken to set
	 */
	public void setEchoToken(String echoToken) {
		this.echoToken = echoToken;
	}
	
	
}
