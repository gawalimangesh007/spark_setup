package com.sterling.bookingapi.dto.response;

import com.sterling.bookingapi.dto.PaymentRequestDTO;

/**
 * @author tcs
 * @version 1.0
 */
public class HsdBookingResponseDTO {
	
	/** The booking id. */
	private String bookingId;
	
	private PaymentRequestDTO paymentDetails;

	/**
	 * Gets the booking id.
	 *
	 * @return the booking id
	 */
	public String getBookingId() {
		return bookingId;
	}

	/**
	 * Sets the booking id.
	 *
	 * @param bookingId the new booking id
	 */
	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}

	public PaymentRequestDTO getPaymentDetails() {
		return paymentDetails;
	}

	public void setPaymentDetails(PaymentRequestDTO paymentDetails) {
		this.paymentDetails = paymentDetails;
	}
	
}
