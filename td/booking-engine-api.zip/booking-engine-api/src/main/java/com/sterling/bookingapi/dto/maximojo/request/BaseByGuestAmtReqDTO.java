package com.sterling.bookingapi.dto.maximojo.request;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class BaseByGuestAmtReqDTO.
 */
/**
 * @author tcs
 *
 */
public class BaseByGuestAmtReqDTO {

	/** The age qualifying code. */
	@JacksonXmlProperty(localName = "AgeQualifyingCode", isAttribute = true)
	private int ageQualifyingCode;

	/** The amount */
	@JacksonXmlProperty(localName = "Amount", isAttribute = true)
    private double amount;

	/** The number of guests. */
	@JacksonXmlProperty(localName = "NumberOfGuests", isAttribute = true)
    private int numberOfGuests;
	
	/**
	 * Gets the age qualifying code.
	 *
	 * @return the ageQualifyingCode
	 */
	public int getAgeQualifyingCode() {
		return ageQualifyingCode;
	}

	/**
	 * Sets the age qualifying code.
	 *
	 * @param ageQualifyingCode the ageQualifyingCode to set
	 */
	public void setAgeQualifyingCode(int ageQualifyingCode) {
		this.ageQualifyingCode = ageQualifyingCode;
	}

	/**
	 * Gets the amount after tax.
	 *
	 * @return the amountAfterTax
	 */
	public double getAmount() {
		return amount;
	}

	/**
	 * Sets the amount after tax.
	 *
	 * @param amountAfterTax the amountAfterTax to set
	 */
	public void setAmount(double amount) {
		this.amount = amount;
	}

	/**
	 * Gets the number of guests.
	 *
	 * @return the numberOfGuests
	 */
	public int getNumberOfGuests() {
		return numberOfGuests;
	}

	/**
	 * Sets the number of guests.
	 *
	 * @param numberOfGuests the numberOfGuests to set
	 */
	public void setNumberOfGuests(int numberOfGuests) {
		this.numberOfGuests = numberOfGuests;
	}
	
	
}
