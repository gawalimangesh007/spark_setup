package com.sterling.bookingapi.dto.request;


/**
 * The Class HsdEnhancementCostSummaryDTO.
 */
/**
 * @author tcs
 *
 */
public class HsdEnhancementCostSummaryDTO {
	
	/** The meals cost. */
	private double mealsCost;
	
	/** The spa cost. */
	private double spaCost;
	
	/**
	 * Gets the meals cost.
	 *
	 * @return the meals cost
	 */
	public double getMealsCost() {
		return mealsCost;
	}
	
	/**
	 * Sets the meals cost.
	 *
	 * @param mealsCost the new meals cost
	 */
	public void setMealsCost(double mealsCost) {
		this.mealsCost = mealsCost;
	}
	
	/**
	 * Gets the spa cost.
	 *
	 * @return the spa cost
	 */
	public double getSpaCost() {
		return spaCost;
	}
	
	/**
	 * Sets the spa cost.
	 *
	 * @param spaCost the new spa cost
	 */
	public void setSpaCost(double spaCost) {
		this.spaCost = spaCost;
	}
	
}