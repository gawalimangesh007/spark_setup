package com.sterling.bookingapi.models;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;


/**
 * The Class Roles.
 */
/**
 * @author tcs
 *
 */
@Table(name = "sh_roles")
@Entity
public class Roles extends BaseModel{
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 3491647414265726204L;

	/** The role id. */
	@Id
	@GeneratedValue( strategy = GenerationType.IDENTITY )
	@Column(name = "role_id", unique = true)
	private int roleId;

	/** The name. */
	@Column(nullable = false)
	private String name;
	
	/** The description. */
	@Column(name="description")
	private String description;
	
	/** The active. */
	@Column(name = "status")
	private boolean active = true;
	
	/** The role type. */
	@Column(nullable=false)
	@Enumerated(EnumType.STRING)
	private RoleType roleType;
	
	/** The user roles. */
	@OneToMany(mappedBy = "role")
	@Cascade(CascadeType.SAVE_UPDATE)
	private List<UserRoleMapping> userRoles;
	
	/**
	 * Gets the user roles.
	 *
	 * @return the user roles
	 */
	public List<UserRoleMapping> getUserRoles() {
		return userRoles;
	}

	/**
	 * Sets the user roles.
	 *
	 * @param userRoles the new user roles
	 */
	public void setUserRoles(List<UserRoleMapping> userRoles) {
		this.userRoles = userRoles;
	}

	/**
	 * Gets the role id.
	 *
	 * @return the role id
	 */
	public int getRoleId() {
		return roleId;
	}

	/**
	 * Sets the role id.
	 *
	 * @param roleId the new role id
	 */
	public void setRoleId(int roleId) {
		this.roleId = roleId;
	}

	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Sets the name.
	 *
	 * @param name the new name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * Sets the description.
	 *
	 * @param description the new description
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * Checks if is active.
	 *
	 * @return true, if is active
	 */
	public boolean isActive() {
		return active;
	}

	/**
	 * Sets the active.
	 *
	 * @param active the new active
	 */
	public void setActive(boolean active) {
		this.active = active;
	}

	/**
	 * Gets the role type.
	 *
	 * @return the role type
	 */
	public RoleType getRoleType() {
		return roleType;
	}

	/**
	 * Sets the role type.
	 *
	 * @param roleType the new role type
	 */
	public void setRoleType(RoleType roleType) {
		this.roleType = roleType;
	}

	
}
