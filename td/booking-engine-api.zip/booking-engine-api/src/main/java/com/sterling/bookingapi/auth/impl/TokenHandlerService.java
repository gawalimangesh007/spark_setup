package com.sterling.bookingapi.auth.impl;

import com.sterling.bookingapi.auth.bean.SterlingAuthException;
import com.sterling.bookingapi.auth.bean.User;
import com.sterling.bookingapi.auth.bean.UserToken;


/**
 * @author tcs
 *
 */
public interface TokenHandlerService {

	/**
	 * @param token
	 * @return user details
	 * @throws SterlingAuthException
	 */
	User parseUserFromToken(String token) throws SterlingAuthException;
	
	/**
	 * @param user
	 * @return token
	 */ 
	String calculateTokenForUser(User user);

	/**
	 * @param token
	 * @param utoken
	 * set the token to cache
	 */
	void insertToCache(String token, UserToken utoken);

	void removeFromCache(String token);

	void mapUserToken(String token, String userId);

	Object getLoggedUser(String token);

	String getLoggedUserToken(String userId);

	
}
