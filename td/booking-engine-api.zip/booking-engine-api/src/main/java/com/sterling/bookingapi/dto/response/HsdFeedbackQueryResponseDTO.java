package com.sterling.bookingapi.dto.response;

/**
 * @author tcs
 * @version 1.0
 */
public class HsdFeedbackQueryResponseDTO {
	
	/** The feedback id. */
	private String feedbackId;

	/**
	 * Gets the feedback id.
	 *
	 * @return the feedback id
	 */
	public String getFeedbackId() {
		return feedbackId;
	}

	/**
	 * Sets the feedback id.
	 *
	 * @param feedbackId the new feedback id
	 */
	public void setFeedbackId(String feedbackId) {
		this.feedbackId = feedbackId;
	}
	
}