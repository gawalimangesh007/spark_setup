package com.sterling.bookingapi.dto.maximojo.request;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlText;


/**
 * The Class AddressLineReqDTO.
 */
/**
 * @author tcs
 *
 */
public class AddressLineReqDTO {

	/** The address line. */
	@JacksonXmlText
	private String addressLine;

	/**
	 * Gets the address line.
	 *
	 * @return the address line
	 */
	public String getAddressLine() {
		return addressLine;
	}

	/**
	 * Sets the address line.
	 *
	 * @param addressLine the new address line
	 */
	public void setAddressLine(String addressLine) {
		this.addressLine = addressLine;
	}
	
	
}
