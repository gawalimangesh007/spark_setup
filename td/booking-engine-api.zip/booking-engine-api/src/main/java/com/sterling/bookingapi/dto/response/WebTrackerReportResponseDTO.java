package com.sterling.bookingapi.dto.response;

import java.util.List;

import com.sterling.bookingapi.dto.WebTrackerSearchReport;
import com.sterling.bookingapi.models.WebTrackerModel;

public class WebTrackerReportResponseDTO {


	private List<WebTrackerModel> webTrackerModel;

	public List<WebTrackerModel> getWebTrackerModel() {
		return webTrackerModel;
	}

	public void setWebTrackerModel(List<WebTrackerModel> webTrackerModel) {
		this.webTrackerModel = webTrackerModel;
	}

	
	
	
}
