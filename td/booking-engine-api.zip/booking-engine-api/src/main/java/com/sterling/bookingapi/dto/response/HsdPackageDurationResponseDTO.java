package com.sterling.bookingapi.dto.response;

/**
 * @author tcs
 * @version 1.0
 */
public class HsdPackageDurationResponseDTO {
	
	/** The days. */
	private String days;
	
	/** The nights. */
	private String nights;
	
	/**
	 * Instantiates a new hsd package duration response DTO.
	 *
	 * @param days the days
	 * @param nights the nights
	 */
	public HsdPackageDurationResponseDTO(String days, String nights) {
		this.days = days;
		this.nights = nights;
	}
	
	/**
	 * Gets the days.
	 *
	 * @return the days
	 */
	public String getDays() {
		return days;
	}
	
	/**
	 * Sets the days.
	 *
	 * @param days the new days
	 */
	public void setDays(String days) {
		this.days = days;
	}
	
	/**
	 * Gets the nights.
	 *
	 * @return the nights
	 */
	public String getNights() {
		return nights;
	}
	
	/**
	 * Sets the nights.
	 *
	 * @param nights the new nights
	 */
	public void setNights(String nights) {
		this.nights = nights;
	}
	
}
