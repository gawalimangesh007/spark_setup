package com.sterling.bookingapi.dto.maximojo.response;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class CommentResDTO.
 * @author tcs
 * @version 1.0
 */
public class CommentResDTO {

	/** The text. */
	@JacksonXmlProperty(localName = "Text", isAttribute = true)
	private String text;

	/**
	 * Gets the text.
	 *
	 * @return the text
	 */
	public String getText() {
		return text;
	}

	/**
	 * Sets the text.
	 *
	 * @param text the text to set
	 */
	public void setText(String text) {
		this.text = text;
	}
	
	
}
