package com.sterling.bookingapi.engine.rules.models;

import java.io.Serializable;

public class RulesSeasons implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private Boolean purple;
	private Boolean red;
	private Boolean blue;
	private Boolean white;
	
	public Boolean getPurple() {
		return purple;
	}
	public void setPurple(Boolean purple) {
		this.purple = purple;
	}
	public Boolean getRed() {
		return red;
	}
	public void setRed(Boolean red) {
		this.red = red;
	}
	public Boolean getBlue() {
		return blue;
	}
	public void setBlue(Boolean blue) {
		this.blue = blue;
	}
	public Boolean getWhite() {
		return white;
	}
	public void setWhite(Boolean white) {
		this.white = white;
	}
	
	/*
	 {
          "purple": false,
          "red": false,
          "blue": false,
          "white": false
        }
	 */
}
