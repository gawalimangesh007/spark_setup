package com.sterling.bookingapi.controller;

import java.util.List;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.sterling.bookingapi.dto.request.VOCaptureProductPaymentPlanRequest;
import com.sterling.bookingapi.dto.request.VOOfferRequest;
import com.sterling.bookingapi.dto.request.VOProductRequest;
import com.sterling.bookingapi.dto.request.VoCaptureKycRequestDTO;
import com.sterling.bookingapi.dto.response.ResponseDTO;
import com.sterling.bookingapi.dto.response.VOOfferWrapperDTO;
import com.sterling.bookingapi.dto.response.VOProdDPMappingResDTO;
import com.sterling.bookingapi.dto.response.VOProdDPMappingWrapperDTO;
import com.sterling.bookingapi.dto.response.VOProductResponseDTO;
import com.sterling.bookingapi.dto.response.VOProductsPlanWrapperDTO;
import com.sterling.bookingapi.dto.response.VOUnitProductPointMatrixWrapperDTO;
import com.sterling.bookingapi.exception.BookingEngineException;
import com.sterling.bookingapi.exception.SalesForceException;
import com.sterling.bookingapi.service.VOProductService;
import com.sterling.bookingapi.utils.ResponseUtility;

/**
 * @author tcs
 *
 */
@RestController
@RequestMapping(value = "/voProduct")
public class VOProductController extends BaseController {
	
	/** The Constant logger. */
	private static final Logger logger = LogManager.getLogger(VOProductController.class);
	private static final String HEADER_CACHE = "must-revalidate, post-check=0, pre-check=0";
	private static final String MEDIA_TYPE_PDF = "application/pdf";
	
	@Autowired
	private VOProductService voProductService;
	

	/**
	 * @param voProductService
	 * set the voProductService
	 */
	public void setVoProductService(VOProductService voProductService) {
		this.voProductService = voProductService;
	}


	/**
	 * @return product details
	 * @throws SalesForceException
	 */
	@RequestMapping(value = "/getProducts", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO getProducts() throws SalesForceException {
		
		logger.info("VOProductController : getProducts : Entered.");
	
		VOProductsPlanWrapperDTO products = voProductService.getProductMaster();
		logger.info("VOProductController : getProducts : Leaving.");
		return ResponseUtility.constructSuccessRes(products);
	}

	/**
	 * @return product details
	 * @throws SalesForceException
	 */
	@RequestMapping(value = "/getProduct", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO getProducts(@RequestBody VOProductRequest request) throws SalesForceException {
		
		logger.info("VOProductController : getProducts : Entered.");
		
		VOProductResponseDTO products = voProductService.getProduct(request);
		logger.info("VOProductController : getProducts : Leaving.");
		return ResponseUtility.constructSuccessRes(products);
	}

	/**
	 * @return product details
	 * @throws SalesForceException
	 */
	@RequestMapping(value = "/getProductPaymentPlan", method = RequestMethod.GET, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO getProductPaymentPlan(@RequestParam @Valid String planName) throws SalesForceException {
		
		logger.info("VOProductController : getProducts : Entered.");
		
		VOProdDPMappingWrapperDTO productsPlans= voProductService.getProductPaymentPlan(planName);
		logger.info("VOProductController : getProducts : Leaving.");
		return ResponseUtility.constructSuccessRes(productsPlans);
	}
	
	/**
	 * @param request
	 * @return success after captureProductPmntPlan
	 * @throws SalesForceException
	 */
	@RequestMapping(value = "/captureProductPmntPlan", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO captureProductPmntPlan(@RequestBody VOCaptureProductPaymentPlanRequest request) throws SalesForceException {
		logger.info("VOProductController : captureProductPmntPlan : Entered.");
		ResponseEntity<Object> response = voProductService.captureProductPaymentPlan(request);
		logger.info("VOProductController : captureProductPmntPlan : Leaving.");
		return ResponseUtility.constructSuccessRes(response.getBody());
	}
	
	/**
	 * @param request
	 * @return success after updating ProductPmntPlan
	 * @throws SalesForceException
	 */
	@RequestMapping(value = "/updateProductPmntPlan", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO updateProductPmntPlan(@RequestBody VOCaptureProductPaymentPlanRequest request) throws SalesForceException {
		logger.info("VOProductController : updateProductPmntPlan : Entered.");
		ResponseEntity<Object> response = voProductService.updateProductPayPlan(request);
		logger.info("VOProductController : updateProductPmntPlan : Leaving.");
		return ResponseUtility.constructSuccessRes(response.getBody());
	}
	
	/*@RequestMapping(value = "/captureDownPayment", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO captureDownPayment(@RequestBody VOCaptureDownPaymentRequest request) throws SalesForceException {
		logger.info("VOProductController : captureDownPayment : Entered.");
		ResponseEntity<VORecordEntryRespose> response = voProductService.captureDownPayment(request);
		logger.info("VOProductController : captureDownPayment : Leaving.");
		return ResponseUtility.constructSuccessRes(response.getBody());

	}*/
	
	/**
	 * @param voCaptureKYCRequestDTO
	 * @return success after captureKYC
	 * @throws SalesForceException
	 */
	@RequestMapping(value = "/capture/kyc", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO captureKYC(@RequestBody VoCaptureKycRequestDTO voCaptureKYCRequestDTO) throws SalesForceException {
		logger.info("VacationOwnershipController : captureKYC : Entered.");
		ResponseEntity<?> captureKYC = voProductService.captureKYC(voCaptureKYCRequestDTO);
		logger.info("VacationOwnershipController : captureKYC : Leaving.");
		return ResponseUtility.constructSuccessRes(captureKYC.getBody());
	}
	
	/**
	 * @return unit Product Point Matrix 
	 * @throws SalesForceException
	 */
	@RequestMapping(value = "/get/unitProductPointMatrix", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO getUnitProductPointMatrix() throws SalesForceException {
		
		logger.info("VOProductController : getUnitProductPointMatrix : Entered.");
	
		VOUnitProductPointMatrixWrapperDTO products = voProductService.getUnitProductPointMatrix();
		logger.info("VOProductController : getUnitProductPointMatrix : Leaving.");
		return ResponseUtility.constructSuccessRes(products);
	}
	
	
	/**
	 * @return offer details
	 * @throws SalesForceException
	 */
	@RequestMapping(value = "/getOffer", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO getOffers(@RequestBody VOOfferRequest request) throws SalesForceException {
		
		logger.info("VOProductController : getOffers : Entered.");
		
		VOOfferWrapperDTO offers = voProductService.getOffer(request);
		logger.info("VOProductController : getOffers : Leaving.");
		return ResponseUtility.constructSuccessRes(offers);
	}
	
	/**
	 * @return Specific offer details
	 * @throws SalesForceException
	 */
	@RequestMapping(value = "/getSpecificOffer", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public ResponseDTO getSpecificOffers(@RequestBody VOOfferRequest request) throws SalesForceException {
		
		logger.info("VOProductController : getSpecificOffers : Entered.");
		
		VOOfferWrapperDTO offers = voProductService.getSpecificOffer(request);
		logger.info("VOProductController : getSpecificOffers : Leaving.");
		return ResponseUtility.constructSuccessRes(offers);
	}
	
	
	@RequestMapping(value = "/getDownPaymentPDF", method = RequestMethod.GET)
	public ResponseEntity<byte[]> downpaymentPdf(@RequestParam String emailId,@RequestParam String transactionId) throws BookingEngineException {
		  logger.info("VOProductController : downpaymentPdf : Entered.");
		HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.parseMediaType(MEDIA_TYPE_PDF));
	    
	    String filename = "DownPaymentReceipt.pdf";
	    
	    byte[] contents = voProductService.getDownPayPDFContents(emailId,transactionId);
	    
	    headers.setContentDispositionFormData(filename, filename);
	    
	    headers.setCacheControl(HEADER_CACHE);
	    
		ResponseEntity<byte[]> response = new ResponseEntity<>(contents, headers, HttpStatus.OK);
		  logger.info("VOProductController : downpaymentPdf : leaving.");
		return response;
	}
}
