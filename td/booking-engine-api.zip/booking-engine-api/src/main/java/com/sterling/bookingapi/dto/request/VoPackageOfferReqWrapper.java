package com.sterling.bookingapi.dto.request;

import java.io.Serializable;
import java.util.List;

import javax.validation.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author tcs
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class VoPackageOfferReqWrapper implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@NotEmpty(message = "package Name should not be empty")
	private List<VoPackageOfferReq> packages;

	public List<VoPackageOfferReq> getPackages() {
		return packages;
	}

	public void setPackages(List<VoPackageOfferReq> packages) {
		this.packages = packages;
	}
	
}
