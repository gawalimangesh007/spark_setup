package com.sterling.bookingapi.dto.response;

import java.io.Serializable;

/**
 * @author tcs
 * @version 1.0
 *
 */
public class VOVenueOfferResponseDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String offerId;
	private String offerType;
	private Boolean isValidVoucher;
	private Boolean isVenueOfferUSed;
	private String validTo;
	private String title;
	private String firstName;
	private String lastName;
	private String gender;
	private String maritalStatus;
	private String dob;
	private String mobileNo;
	private String alternateMobileNo;
	private String contactEmail;
	private String alternateEmail;
	private String fixedLineNumber;
	private String alternateFixedLine;
	private String PermanentAddress;
	private String correspondenceAddress;
	
	/**
	 * @return offerId
	 */
	public String getOfferId() {
		return offerId;
	}
	/**
	 * @param offerId
	 * set the offerId
	 */
	public void setOfferId(String offerId) {
		this.offerId = offerId;
	}
	/**
	 * @return offerType
	 */
	public String getOfferType() {
		return offerType;
	}
	/**
	 * @param offerType
	 * set the offerType
	 */
	public void setOfferType(String offerType) {
		this.offerType = offerType;
	}
	/**
	 * @return isValidVoucher
	 */
	public Boolean getIsValidVoucher() {
		return isValidVoucher;
	}
	/**
	 * @param isValidVoucher
	 * set the isValidVoucher
	 */
	public void setIsValidVoucher(Boolean isValidVoucher) {
		this.isValidVoucher = isValidVoucher;
	}
	/**
	 * @return isVenueOfferUSed
	 */
	public Boolean getIsVenueOfferUSed() {
		return isVenueOfferUSed;
	}
	/**
	 * @param isVenueOfferUSed
	 * set the isVenueOfferUSed
	 */
	public void setIsVenueOfferUSed(Boolean isVenueOfferUSed) {
		this.isVenueOfferUSed = isVenueOfferUSed;
	}
	/**
	 * @return validTo
	 */
	public String getValidTo() {
		return validTo;
	}
	/**
	 * @param validTo
	 * set the validTo
	 */
	public void setValidTo(String validTo) {
		this.validTo = validTo;
	}
	/**
	 * @return title
	 */
	public String getTitle() {
		return title;
	}
	/**
	 * @param title
	 * set the title
	 */
	public void setTitle(String title) {
		this.title = title;
	}
	/**
	 * @return firstName
	 */
	public String getFirstName() {
		return firstName;
	}
	/**
	 * @param firstName
	 * set the firstName
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	/**
	 * @return lastName
	 */
	public String getLastName() {
		return lastName;
	}
	/**
	 * @param lastName
	 * set the lastName
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	/**
	 * @return gender
	 */
	public String getGender() {
		return gender;
	}
	/**
	 * @param gender
	 * set the gender
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}
	/**
	 * @return maritalStatus
	 */
	public String getMaritalStatus() {
		return maritalStatus;
	}
	/**
	 * @param maritalStatus
	 * set the maritalStatus
	 */
	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}
	/**
	 * @return dob
	 */
	public String getDob() {
		return dob;
	}
	/**
	 * @param dob
	 * set the dob
	 */
	public void setDob(String dob) {
		this.dob = dob;
	}
	/**
	 * @return mobileNo
	 */
	public String getMobileNo() {
		return mobileNo;
	}
	/**
	 * @param mobileNo
	 * set the mobileNo
	 */
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	/**
	 * @return alternateMobileNo
	 */
	public String getAlternateMobileNo() {
		return alternateMobileNo;
	}
	/**
	 * @param alternateMobileNo
	 * set the alternateMobileNo
	 */
	public void setAlternateMobileNo(String alternateMobileNo) {
		this.alternateMobileNo = alternateMobileNo;
	}
	/**
	 * @return contactEmail
	 */
	public String getContactEmail() {
		return contactEmail;
	}
	/**
	 * @param contactEmail
	 * set the contactEmail
	 */
	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}
	/**
	 * @return alternateEmail
	 */
	public String getAlternateEmail() {
		return alternateEmail;
	}
	/**
	 * @param alternateEmail
	 * set the alternateEmail
	 */
	public void setAlternateEmail(String alternateEmail) {
		this.alternateEmail = alternateEmail;
	}
	/**
	 * @return fixedLineNumber
	 */
	public String getFixedLineNumber() {
		return fixedLineNumber;
	}
	/**
	 * @param fixedLineNumber
	 * set the fixedLineNumber
	 */
	public void setFixedLineNumber(String fixedLineNumber) {
		this.fixedLineNumber = fixedLineNumber;
	}
	/**
	 * @return alternateFixedLine
	 */
	public String getAlternateFixedLine() {
		return alternateFixedLine;
	}
	/**
	 * @param alternateFixedLine
	 * set the alternateFixedLine
	 */
	public void setAlternateFixedLine(String alternateFixedLine) {
		this.alternateFixedLine = alternateFixedLine;
	}
	/**
	 * @return PermanentAddress
	 */
	public String getPermanentAddress() {
		return PermanentAddress;
	}
	/**
	 * @param permanentAddress
	 * set the PermanentAddress
	 */
	public void setPermanentAddress(String permanentAddress) {
		PermanentAddress = permanentAddress;
	}
	/**
	 * @return correspondenceAddress
	 */
	public String getCorrespondenceAddress() {
		return correspondenceAddress;
	}
	/**
	 * @param correspondenceAddress
	 * set the correspondenceAddress
	 */
	public void setCorrespondenceAddress(String correspondenceAddress) {
		this.correspondenceAddress = correspondenceAddress;
	}
}
