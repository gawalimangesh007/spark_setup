package com.sterling.bookingapi.exception;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.validation.Errors;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;


/**
 * The Class ValidationErrorBuilder.
 */
/**
 * @author tcs
 * @version 1.0
 *
 */
public class ValidationErrorBuilder {

    /**
     * From binding errors.
     *
     * @param errors the errors
     * @return the validation error
     */
	/** The Constant logger. */
	private static final Logger logger = LogManager.getLogger(ValidationErrorBuilder.class);
    public static ValidationError fromBindingErrors(Errors errors) {
    	logger.info(" ValidationErrorBuilder : fromBindingErrors : Entered.");
    	ValidationError error = new ValidationError("Request Validation failed. " + errors.getErrorCount() + " error(s)");
        SpecificFieldError specificFieldError = null;
        for (ObjectError objectError : errors.getAllErrors()) {
        	
        	specificFieldError = new SpecificFieldError();
        	
        	String fieldName = null;
        	if (objectError instanceof FieldError){

        		FieldError fieldError = (FieldError)objectError;
        		fieldName = fieldError.getField();
        		specificFieldError.setFieldName(fieldName);
			}
        	specificFieldError.setDefaultMessage(objectError.getDefaultMessage());
		
            error.addValidationError(specificFieldError);
        }
        logger.info(" ValidationErrorBuilder : fromBindingErrors : Leaving.");
        return error;
    }
}
