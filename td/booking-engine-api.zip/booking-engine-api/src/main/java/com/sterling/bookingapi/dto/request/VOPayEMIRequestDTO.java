package com.sterling.bookingapi.dto.request;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.sterling.bookingapi.dto.PaymentRequestDTO;

/**
 * @author tcs
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class VOPayEMIRequestDTO implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	
	private List<VOEMIASFDetailsDTO> emiDetailsList;	
	private VOPayCustomerDetailsDTO customerDetails;
	private Double totalAmount;
	private boolean isMultiplePayment;
	
	//sf Airpay dto, hide from Frontend 
	@JsonIgnore
	private PaymentRequestDTO paymentRequestDTO;
	
	
	public PaymentRequestDTO getPaymentRequestDTO() {
		return paymentRequestDTO;
	}
	public void setPaymentRequestDTO(PaymentRequestDTO paymentRequestDTO) {
		this.paymentRequestDTO = paymentRequestDTO;
	}
	/**
	 * @return totalAmount
	 */
	public Double getTotalAmount() {
		return totalAmount;
	}
	/**
	 * @param totalAmount
	 * set the totalAmount
	 */
	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}
	/**
	 * @return isMultiplePayment
	 */
	public boolean isMultiplePayment() {
		return isMultiplePayment;
	}
	/**
	 * @param isMultiplePayment
	 * set the isMultiplePayment
	 */
	public void setMultiplePayment(boolean isMultiplePayment) {
		this.isMultiplePayment = isMultiplePayment;
	}
	/**
	 * @return emiDetailsList
	 */
	public List<VOEMIASFDetailsDTO> getEmiDetailsList() {
		return emiDetailsList;
	}
	/**
	 * @param emiDetailsList
	 * set the emiDetailsList
	 */
	public void setEmiDetailsList(List<VOEMIASFDetailsDTO> emiDetailsList) {
		this.emiDetailsList = emiDetailsList;
	}
	/**
	 * @return customerDetails
	 */
	public VOPayCustomerDetailsDTO getCustomerDetails() {
		return customerDetails;
	}
	/**
	 * @param customerDetails
	 * set the customerDetails
	 */
	public void setCustomerDetails(VOPayCustomerDetailsDTO customerDetails) {
		this.customerDetails = customerDetails;
	}
    
}
