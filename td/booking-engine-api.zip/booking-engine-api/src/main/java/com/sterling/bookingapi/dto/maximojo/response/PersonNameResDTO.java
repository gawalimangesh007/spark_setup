package com.sterling.bookingapi.dto.maximojo.response;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class PersonNameResDTO.
 * @author tcs
 * @version 1.0
 */
public class PersonNameResDTO {

	/** The given name. */
	@JacksonXmlProperty(localName = "GivenName")
	private String givenName;

	/** The surname. */
	@JacksonXmlProperty(localName = "Surname")
    private String surname;

	/**
	 * Gets the given name.
	 *
	 * @return the givenName
	 */
	public String getGivenName() {
		return givenName;
	}

	/**
	 * Sets the given name.
	 *
	 * @param givenName the givenName to set
	 */
	public void setGivenName(String givenName) {
		this.givenName = givenName;
	}

	/**
	 * Gets the surname.
	 *
	 * @return the surname
	 */
	public String getSurname() {
		return surname;
	}

	/**
	 * Sets the surname.
	 *
	 * @param surname the surname to set
	 */
	public void setSurname(String surname) {
		this.surname = surname;
	}
	
	
}
