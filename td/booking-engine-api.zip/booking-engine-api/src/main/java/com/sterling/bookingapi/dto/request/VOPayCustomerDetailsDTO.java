package com.sterling.bookingapi.dto.request;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author tcs
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class VOPayCustomerDetailsDTO implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private String contractId;
	private String primaryId;
	private String emailId;
    private String phoneNo;
    private String firstName;
    private String lastName;
    private String address;
    private String city;
    private String state;
    private String country;
    private String pinCode;
    private String paymentType;
    
	/**
	 * @return contractId
	 */
	public String getContractId() {
		return contractId;
	}
	/**
	 * @param contractId
	 * set the contractId
	 */
	public void setContractId(String contractId) {
		this.contractId = contractId;
	}
	/**
	 * @return primaryId
	 */
	public String getPrimaryId() {
		return primaryId;
	}
	/**
	 * @param primaryId
	 * set the primaryId
	 */
	public void setPrimaryId(String primaryId) {
		this.primaryId = primaryId;
	}
	/**
	 * @return emailId
	 */
	public String getEmailId() {
		return emailId;
	}
	/**
	 * @param emailId
	 * set the emailId
	 */
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	/**
	 * @return phoneNo
	 */
	public String getPhoneNo() {
		return phoneNo;
	}
	/**
	 * @param phoneNo
	 * set the phoneNo
	 */
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	/**
	 * @return firstName
	 */
	public String getFirstName() {
		return firstName;
	}
	/**
	 * @param firstName
	 * set the firstName
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	/**
	 * @return lastName
	 */
	public String getLastName() {
		return lastName;
	}
	/**
	 * @param lastName
	 * set the lastName
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	/**
	 * @return address
	 */
	public String getAddress() {
		return address;
	}
	/**
	 * @param address
	 * set the address
	 */
	public void setAddress(String address) {
		this.address = address;
	}
	/**
	 * @return city
	 */
	public String getCity() {
		return city;
	}
	/**
	 * @param city
	 * set the city
	 */
	public void setCity(String city) {
		this.city = city;
	}
	/**
	 * @return state
	 */
	public String getState() {
		return state;
	}
	/**
	 * @param state
	 * set the state
	 */
	public void setState(String state) {
		this.state = state;
	}
	/**
	 * @return country
	 */
	public String getCountry() {
		return country;
	}
	/**
	 * @param country
	 * set the country
	 */
	public void setCountry(String country) {
		this.country = country;
	}
	/**
	 * @return pinCode
	 */
	public String getPinCode() {
		return pinCode;
	}
	/**
	 * @param pinCode
	 * set the pinCode
	 */
	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}
	/**
	 * @return paymentType
	 */
	public String getPaymentType() {
		return paymentType;
	}
	/**
	 * @param paymentType
	 * set the paymentType
	 */
	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}
}
