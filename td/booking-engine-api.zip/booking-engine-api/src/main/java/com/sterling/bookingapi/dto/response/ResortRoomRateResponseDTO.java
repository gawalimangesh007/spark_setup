package com.sterling.bookingapi.dto.response;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.sterling.bookingapi.utils.CustomJsonDateSerializer;

public class ResortRoomRateResponseDTO {
	
	/** The resort id. */
	private String resortId;

	/** The check in. */
	@JsonSerialize(using = CustomJsonDateSerializer.class)
	private Date checkIn;

	/** The check out. */
	@JsonSerialize(using = CustomJsonDateSerializer.class)
	private Date checkOut;

	private String roomTypeId;
	
	private List<RoomRatePlanDetailsResponseDTO> roomRatePlanList;

	public String getResortId() {
		return resortId;
	}

	public void setResortId(String resortId) {
		this.resortId = resortId;
	}

	public Date getCheckIn() {
		return checkIn;
	}

	public void setCheckIn(Date checkIn) {
		this.checkIn = checkIn;
	}

	public Date getCheckOut() {
		return checkOut;
	}

	public void setCheckOut(Date checkOut) {
		this.checkOut = checkOut;
	}

	public String getRoomTypeId() {
		return roomTypeId;
	}

	public void setRoomTypeId(String roomTypeId) {
		this.roomTypeId = roomTypeId;
	}

	public List<RoomRatePlanDetailsResponseDTO> getRoomRatePlanList() {
		return roomRatePlanList;
	}

	public void setRoomRatePlanList(
			List<RoomRatePlanDetailsResponseDTO> roomRatePlanList) {
		this.roomRatePlanList = roomRatePlanList;
	}	
}
