package com.sterling.bookingapi.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class VOUsagePointsResponseDTO  extends BaseRecord {

	private static final long serialVersionUID = 1L;
	
	private String id;
	private Integer balanced;
	private Integer banking;
	private Integer broughtForward;
	private Integer entitlement;
	private Integer lapsed;
	private String sterlingContractId;
	private Integer utilized;
	private Integer year;

	/** 
	 * @return id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id
	 * set the id
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return balanced
	 */
	public Integer getBalanced() {
		return balanced;
	}

	/**
	 * @param balanced
	 * set the balanced
	 */
	public void setBalanced(Integer balanced) {
		this.balanced = balanced;
	}

	/**
	 * @return banking
	 */
	public Integer getBanking() {
		return banking;
	}

	/**
	 * @param banking
	 * set the banking
	 */
	public void setBanking(Integer banking) {
		this.banking = banking;
	}

	/**
	 * @return broughtForward
	 */
	public Integer getBroughtForward() {
		return broughtForward;
	}

	/**
	 * @param broughtForward
	 * set the broughtForward
	 */
	public void setBroughtForward(Integer broughtForward) {
		this.broughtForward = broughtForward;
	}

	/**
	 * @return entitlement
	 */
	public Integer getEntitlement() {
		return entitlement;
	}

	/**
	 * @param entitlement
	 * set the entitlement
	 */
	public void setEntitlement(Integer entitlement) {
		this.entitlement = entitlement;
	}

	/**
	 * @return lapsed
	 */
	public Integer getLapsed() {
		return lapsed;
	}

	/**
	 * @param lapsed
	 * set the lapsed
	 */
	public void setLapsed(Integer lapsed) {
		this.lapsed = lapsed;
	}

	/**
	 * @return sterlingContractId
	 */
	public String getSterlingContractId() {
		return sterlingContractId;
	}

	/**
	 * @param sterlingContractId
	 * set the sterlingContractId
	 */
	public void setSterlingContractId(String sterlingContractId) {
		this.sterlingContractId = sterlingContractId;
	}

	/**
	 * @return utilized
	 */
	public Integer getUtilized() {
		return utilized;
	}

	/**
	 * @param utilized
	 * set the utilized
	 */
	public void setUtilized(Integer utilized) {
		this.utilized = utilized;
	}

	/**
	 * @return year
	 */
	public Integer getYear() {
		return year;
	}

	/**
	 * @param year
	 * set the year
	 */
	public void setYear(Integer year) {
		this.year = year;
	}
}

