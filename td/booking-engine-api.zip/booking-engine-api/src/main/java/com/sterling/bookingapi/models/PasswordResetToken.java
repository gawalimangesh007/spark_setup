package com.sterling.bookingapi.models;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;


/**
 * The Class PasswordResetToken.
 */
/**
 * @author tcs
 *
 */
@Entity
@Table(name = "sh_password_reset_token")
public class PasswordResetToken  extends BaseModel{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 9067784990346289559L;

	/** The id. */
	@Id
	@GeneratedValue( strategy = GenerationType.IDENTITY )
	@Column(name = "pk_idx_id", unique = true)
	private int id;
	
	/** The token. */
	@Column(name = "token", unique = true, nullable = false)
	private String token;
	
	/** The user. */
	@OneToOne(optional = false)
	@Cascade(CascadeType.SAVE_UPDATE)
	@JoinColumn(name="user_id")
	private Users user;
	
	/** The expiry date. */
	@Column(name = "expiry_date", nullable = false)
	@Temporal(TemporalType.TIMESTAMP)
	private Date expiryDate = new Date();
	
	/** The active. */
	@Column(name = "status", nullable = false)
	private boolean active;

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * Gets the token.
	 *
	 * @return the token
	 */
	public String getToken() {
		return token;
	}

	/**
	 * Sets the token.
	 *
	 * @param token the new token
	 */
	public void setToken(String token) {
		this.token = token;
	}

	/**
	 * Gets the user.
	 *
	 * @return the user
	 */
	public Users getUser() {
		return user;
	}

	/**
	 * Sets the user.
	 *
	 * @param user the new user
	 */
	public void setUser(Users user) {
		this.user = user;
	}

	/**
	 * Gets the expiry date.
	 *
	 * @return the expiry date
	 */
	public Date getExpiryDate() {
		return expiryDate;
	}

	/**
	 * Sets the expiry date.
	 *
	 * @param expiryDate the new expiry date
	 */
	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	/**
	 * Checks if is active.
	 *
	 * @return true, if is active
	 */
	public boolean isActive() {
		return active;
	}

	/**
	 * Sets the active.
	 *
	 * @param active the new active
	 */
	public void setActive(boolean active) {
		this.active = active;
	}
	
	
	
}
