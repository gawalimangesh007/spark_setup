package com.sterling.bookingapi.dto.maximojo.request;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class RequestorIDBookingReqDTO.
 */
/**
 * @author tcs
 *
 */
public class RequestorIDBookingReqDTO {
	
	/** The id. */
	@JacksonXmlProperty(localName = "ID",isAttribute = true)
    private String ID;

	/** The I D context. */
	@JacksonXmlProperty(localName = "ID_Context",isAttribute = true)
    private String ID_Context;
	
	/** The message password. */
	@JacksonXmlProperty(localName = "MessagePassword",isAttribute = true)
	private String messagePassword;
	
	/** The type. */
	@JacksonXmlProperty(localName = "Type",isAttribute = true)
    private int type;

	/**
	 * Gets the message password.
	 *
	 * @return the messagePassword
	 */
	public String getMessagePassword() {
		return messagePassword;
	}

	/**
	 * Sets the message password.
	 *
	 * @param messagePassword the messagePassword to set
	 */
	public void setMessagePassword(String messagePassword) {
		this.messagePassword = messagePassword;
	}

	/**
	 * Gets the type.
	 *
	 * @return the type
	 */
	public int getType() {
		return type;
	}

	/**
	 * Sets the type.
	 *
	 * @param type the type to set
	 */
	public void setType(int type) {
		this.type = type;
	}

	/**
	 * Gets the id.
	 *
	 * @return the iD
	 */
	public String getID() {
		return ID;
	}

	/**
	 * Sets the id.
	 *
	 * @param iD the iD to set
	 */
	public void setID(String iD) {
		ID = iD;
	}

	/**
	 * Gets the i D context.
	 *
	 * @return the iD_Context
	 */
	public String getID_Context() {
		return ID_Context;
	}

	/**
	 * Sets the i D context.
	 *
	 * @param iD_Context the iD_Context to set
	 */
	public void setID_Context(String iD_Context) {
		ID_Context = iD_Context;
	}

	
}
