package com.sterling.bookingapi.dto.response;


import java.util.Date;
import java.util.List;

import com.sterling.bookingapi.dto.ResortRoomMappingDTO;

/**
 * @author tcs
 * @version 1.0
 */
public class HsdPackageDetailsResponseDTO {
	
	/** The package id. */
	private Integer packageId;
	
	/** The package type. */
	private String packageType;
	
	/** The package name. */
	private String packageName;
	
	/** The package details. */
	private String packageDetails;
	
	/** The package inclusion. */
	private String packageInclusion;
	
	/** The package cost. */
	private String packageCost;
	
	/** The package start date. */
	private Date packageStartDate;
	
	/** The package end date. */
	private Date packageEndDate;
	
	/** The adults count. */
	private String adultsCount;
	
	/** The kids count. */
	private String kidsCount;
	
	/** The duration. */
	private Object duration;
	
	/** The package duration. */
	private int packageDuration;
	
	/** The resort room mapping list. */
	private List<ResortRoomMappingDTO> resortRoomMappingList;
	
	/**
	 * Instantiates a new hsd package details response DTO.
	 *
	 * @param packageId the package id
	 * @param packageType the package type
	 * @param packageName the package name
	 * @param packageDetails the package details
	 * @param packageInclusion the package inclusion
	 * @param packageCost the package cost
	 * @param packageStartDate the package start date
	 * @param packageEndDate the package end date
	 * @param adultsCount the adults count
	 * @param kidsCount the kids count
	 */
	public HsdPackageDetailsResponseDTO(Integer packageId, String packageType, String packageName, String packageDetails, String packageInclusion, String packageCost, Date packageStartDate,
			Date packageEndDate, String adultsCount, String kidsCount) {
		this.packageId = packageId;
		this.packageType = packageType;
		this.packageName = packageName;
		this.packageCost = packageCost;
		this.packageDetails = packageDetails;
		this.packageInclusion = packageInclusion;
		this.packageStartDate = packageStartDate;
		this.packageEndDate = packageEndDate;
		this.adultsCount = adultsCount;
		this.kidsCount = kidsCount;
		this.packageCost = packageCost;
	}
	
	/**
	 * Gets the package id.
	 *
	 * @return the package id
	 */
	public Integer getPackageId() {
		return packageId;
	}

	/**
	 * Sets the package id.
	 *
	 * @param packageId the new package id
	 */
	public void setPackageId(Integer packageId) {
		this.packageId = packageId;
	}
	
	/**
	 * Gets the package type.
	 *
	 * @return the package type
	 */
	public String getPackageType() {
		return packageType;
	}
	
	/**
	 * Sets the package type.
	 *
	 * @param packageType the new package type
	 */
	public void setPackageType(String packageType) {
		this.packageType = packageType;
	}
	
	/**
	 * Gets the package name.
	 *
	 * @return the package name
	 */
	public String getPackageName() {
		return packageName;
	}
	
	/**
	 * Sets the package name.
	 *
	 * @param packageName the new package name
	 */
	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}
	
	/**
	 * Gets the package details.
	 *
	 * @return the package details
	 */
	public String getPackageDetails() {
		return packageDetails;
	}
	
	/**
	 * Sets the package details.
	 *
	 * @param packageDetails the new package details
	 */
	public void setPackageDetails(String packageDetails) {
		this.packageDetails = packageDetails;
	}
	
	/**
	 * Gets the package inclusion.
	 *
	 * @return the package inclusion
	 */
	public String getPackageInclusion() {
		return packageInclusion;
	}
	
	/**
	 * Sets the package inclusion.
	 *
	 * @param packageInclusion the new package inclusion
	 */
	public void setPackageInclusion(String packageInclusion) {
		this.packageInclusion = packageInclusion;
	}
	
	/**
	 * Gets the package cost.
	 *
	 * @return the package cost
	 */
	public String getPackageCost() {
		return packageCost;
	}
	
	/**
	 * Sets the package cost.
	 *
	 * @param packageCost the new package cost
	 */
	public void setPackageCost(String packageCost) {
		this.packageCost = packageCost;
	}
	
	/**
	 * Gets the package start date.
	 *
	 * @return the package start date
	 */
	public Date getPackageStartDate() {
		return packageStartDate;
	}
	
	/**
	 * Sets the package start date.
	 *
	 * @param packageStartDate the new package start date
	 */
	public void setPackageStartDate(Date packageStartDate) {
		this.packageStartDate = packageStartDate;
	}
	
	/**
	 * Gets the package end date.
	 *
	 * @return the package end date
	 */
	public Date getPackageEndDate() {
		return packageEndDate;
	}
	
	/**
	 * Sets the package end date.
	 *
	 * @param packageEndDate the new package end date
	 */
	public void setPackageEndDate(Date packageEndDate) {
		this.packageEndDate = packageEndDate;
	}
	
	/**
	 * Gets the adults count.
	 *
	 * @return the adults count
	 */
	public String getAdultsCount() {
		return adultsCount;
	}
	
	/**
	 * Sets the adults count.
	 *
	 * @param adultsCount the new adults count
	 */
	public void setAdultsCount(String adultsCount) {
		this.adultsCount = adultsCount;
	}
	
	/**
	 * Gets the kids count.
	 *
	 * @return the kids count
	 */
	public String getKidsCount() {
		return kidsCount;
	}
	
	/**
	 * Sets the kids count.
	 *
	 * @param kidsCount the new kids count
	 */
	public void setKidsCount(String kidsCount) {
		this.kidsCount = kidsCount;
	}
	
	/**
	 * Gets the duration.
	 *
	 * @return the duration
	 */
	public Object getDuration() {
		return duration;
	}
	
	/**
	 * Sets the duration.
	 *
	 * @param duration the new duration
	 */
	public void setDuration(Object duration) {
		this.duration = duration;
	}

	/**
	 * Gets the package duration.
	 *
	 * @return the package duration
	 */
	public int getPackageDuration() {
		return packageDuration;
	}

	/**
	 * Sets the package duration.
	 *
	 * @param packageDuration the new package duration
	 */
	public void setPackageDuration(int packageDuration) {
		this.packageDuration = packageDuration;
	}

	/**
	 * Gets the resort room mapping list.
	 *
	 * @return the resort room mapping list
	 */
	public List<ResortRoomMappingDTO> getResortRoomMappingList() {
		return resortRoomMappingList;
	}

	/**
	 * Sets the resort room mapping list.
	 *
	 * @param resortRoomMappingList the new resort room mapping list
	 */
	public void setResortRoomMappingList(List<ResortRoomMappingDTO> resortRoomMappingList) {
		this.resortRoomMappingList = resortRoomMappingList;
	}
	
}
