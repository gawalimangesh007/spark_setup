package com.sterling.bookingapi.dto.maximojo.response;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


/**
 * The Class BasicPropertyInfoResDTO.
 * @author tcs
 * @version 1.0
 */
public class BasicPropertyInfoResDTO {

	/** The hotel code. */
	@JacksonXmlProperty(localName = "HotelCode", isAttribute = true)
	private String hotelCode;

	/**
	 * Gets the hotel code.
	 *
	 * @return the hotelCode
	 */
	public String getHotelCode() {
		return hotelCode;
	}

	/**
	 * Sets the hotel code.
	 *
	 * @param hotelCode the hotelCode to set
	 */
	public void setHotelCode(String hotelCode) {
		this.hotelCode = hotelCode;
	}
	
	
}
